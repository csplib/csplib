from mdx_smartypants.core import *
from mdx_smartypants.spants import Quotes