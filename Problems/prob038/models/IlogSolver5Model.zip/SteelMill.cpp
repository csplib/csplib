// SteelMill.cpp: implementation of the SteelMill class.
//
//////////////////////////////////////////////////////////////////////

#include "SteelMill.h"

//////////////////////////////////////////////////////////////////////
// Construction
//////////////////////////////////////////////////////////////////////

SteelMill::SteelMill() {
  model = IloModel(env) ;
  solver = IloSolver(env) ;
}

//////////////////////////////////////////////////////////////////////
// display()
void SteelMill::display() {
    IloInt i ;
	solver.out() << "Opt: " << solver.getValue(optVar) << endl ;
	solver.out() << "Slabs: " ;
    for (i = 0; i < j; i++)
	  solver.out() << solver.getValue(S[i]) << " " ;
	solver.out() << endl << endl ;
	for (i = 0; i < j*j; i++) {
	  solver.out() << solver.getValue(OA[i]) << " ";
      if ((i+1) % j == 0) solver.out() << endl ;
	}
}

//////////////////////////////////////////////////////////////////////
// getTotalOrderWeight()
IloInt SteelMill::getTotalOrderWeight() {
  IloInt totalOrderWeight = 0 ;
  for (IloInt i = 0; i < j; i++)
	totalOrderWeight += orderWeights[i] ;
  return totalOrderWeight ;
}

//////////////////////////////////////////////////////////////////////
// initModel()
void SteelMill::initModel() {
  IloInt i = 0, i2, p = 2 ;
  IloInt totalOrderWeight = getTotalOrderWeight() ;
  cout << "Total Order Weight: " << totalOrderWeight << endl ;

  //Slab Variables:
  S = IloNumVarArray(env) ;
  for (i = 0; i < j; i++) S.add(IloDiscreteNumVar(env, sizes, ILOINT)) ;
  //Slab symmetry breaking
  for (i = 0; i < j-1; i++)
	model.add(S[i] >= S[i+1]) ;
  cout << "Slab domains created" << endl ;

  //Order Matrix: 
  OA = IloNumVarArray(env, j*j, 0, 1, ILOINT) ;
  for (i = 0; i < j; i++) {                                                   
	IloNumVarArray orderMRow(env, j, 0, 1, ILOINT) ;
	for (i2 = 0; i2 < j; i2++)
	  orderMRow[i2] = OA[i*j+i2] ;
	model.add(IloScalProd(orderMRow, orderWeights) <= S[i]) ;
  }
  for (i = 0; i < j; i++) {
	IloNumVarArray orderMCol(env, j, 0, 1, ILOINT) ;
	for (i2 = 0; i2 < j; i2++)
	  orderMCol[i2] = OA[i2*j+i] ;
	model.add(IloSum(orderMCol) == 1) ;
  }
  cout << "Order matrix created" << endl ;
	  
  //Colour Matrix: Rows
  IloNumVarArray colourM(env, k*j, 0, 1, ILOINT) ;
  for (i = 0; i < j; i++) {
    IloNumVarArray colourMRow(env, k, 0, 1, ILOINT) ;
	for (i2 = 0; i2 < k; i2++)
	  colourMRow[i2] = colourM[i*k+i2] ;
    model.add(IloSum(colourMRow) <= p) ;
  }
  cout << "Colour matrix created" << endl ;

  //Channelling.
  for (i = 0; i < j; i++)
	for(i2 = 0; i2 < j; i2++)
	  model.add(IloIfThen(env, OA[i*j+i2] == 1,
		                       colourM[i*k+orderColours[i2]-1] == 1)) ;
  cout << "Channelling constraints created" << endl ;

  //Optimisation:
  optVar = IloNumVar(env, 0, 1000, ILOINT) ;
  model.add(optVar == IloSum(S)) ;
  model.add(IloMinimize(env, optVar)) ;
  solver.extract(model) ;
}

//////////////////////////////////////////////////////////////////////
int main(int argc, char* argv[]) {
  SteelMill * sm = new SteelMill() ;
  if(sm->readProblem(argv[1])) {
	cout << "Got data ok" << endl ;
	sm->solve() ;
  }
  return 0;
}

//////////////////////////////////////////////////////////////////////
// readProblem()
bool SteelMill::readProblem(char *fname) {
  ifstream infile ;
  infile.open(fname) ;
  if (!infile.good()) {
	cout << "Could not open " << fname << endl ;
	return false ;
  }
  infile >> sigma ;
  sizes = IloNumArray(env, sigma+1) ;
  sizes[0] = 0 ;
  for (IloInt i = 0; i < sigma; i++)
    infile >> sizes[i+1] ;
  cout << sigma << " sizes: " << sizes << endl ;
  infile >> k >> j ;
  orderWeights = IloNumArray(env, j) ;
  orderColours = IloNumArray(env, j) ;
  for (i = 0; i < j; i++)
    infile >> orderWeights[i] >> orderColours[i] ;
  cout << j << " orders, " << k << " colours " << endl ;
  for (i = 0; i < j; i++)
    cout << orderWeights[i] << " " << orderColours[i] << endl ;
  infile.close() ;
  return true ;
}


//////////////////////////////////////////////////////////////////////
// selectMaxA
IlcIntSelect SteelMill::SelectMaxA(IloSolver s) {
  return new (s.getHeap()) ValSelectorA() ;
}

//////////////////////////////////////////////////////////////////////
// solve()
void SteelMill::solve() {
  try {
	IloInt i, i2 ;
    initModel() ;

	//Goal: instantiate orders by column
	IloNumVarArray goalVars(env) ;
	for (i = 0; i < j; i++) goalVars.add(S[i]) ;
      for (i = 0; i < j; i++)      //col loop
		for (i2 = 0; i2 < j; i2++) //row loop
		  goalVars.add(OA[i2*j+i]) ;
    IloGoal goal = IloGenerate(env, goalVars, IlcChooseFirstUnboundInt, SelectMaxA(solver)) ;
	IlcSearch search = solver.newSearch(goal);

	cout << "Starting search" << endl ;
    while (search.next()) {
	  display() ;
	  solver.printInformation() ;
	}
	cout << endl << endl << "Proven Optimal:" << endl ;
	solver.printInformation() ;
    search.end();
  }
  catch (IloException& ex) {
    cerr << "Error: " << ex << endl;
  }
  env.end();
}