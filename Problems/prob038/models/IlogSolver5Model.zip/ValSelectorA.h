// ValSelectorA.h: interface for the ValSelectorA class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_VALSELECTORA_H__045C6AE3_FF5F_42D9_A660_F7218D082E01__INCLUDED_)
#define AFX_VALSELECTORA_H__045C6AE3_FF5F_42D9_A660_F7218D082E01__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <ilsolver/ilosolver.h>

class ValSelectorA : public IlcIntSelectI {
public:
  ValSelectorA() {}
  virtual IlcInt select(IlcIntVar var) ;
};

#endif // !defined(AFX_VALSELECTORA_H__045C6AE3_FF5F_42D9_A660_F7218D082E01__INCLUDED_)
