// ValSelectorA.cpp: implementation of the ValSelectorA class.
//
//////////////////////////////////////////////////////////////////////

#include "ValSelectorA.h"

//////////////////////////////////////////////////////////////////////
// If it's a slab, select the smallest.
// If it's an 0/1 var (i.e. in orderA) return largest.
IlcInt ValSelectorA::select(IlcIntVar var) {
  if (var.getMax() == 1 && var.getMin() == 0)
	return 1 ;
  else
	return var.getMin() ;
}
