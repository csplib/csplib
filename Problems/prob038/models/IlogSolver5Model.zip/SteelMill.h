// SteelMill.h: interface for the SteelMill class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_STEELMILL_H__690040B6_A5BD_48EF_9B13_B7AE3B62CBF5__INCLUDED_)
#define AFX_STEELMILL_H__690040B6_A5BD_48EF_9B13_B7AE3B62CBF5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <ilsolver/ilosolver.h>
#include <ilsolver/ilctrace.h>
#include "ValSelectorA.h"

ILOSTLBEGIN

class SteelMill {
  IloEnv env ;
  IloModel model ;
  IloSolver solver ;
  IloNumVar optVar ;
  IloNumVarArray S, OA, wasteVars ;
  IloInt sigma, k, j ;
  IloNumArray sizes, orderWeights, orderColours ;
  void display() ;
  void initModel() ;
  IlcIntSelect SelectMaxA(IloSolver s) ;
public:
  SteelMill();
  virtual ~SteelMill() {}
  IloInt getTotalOrderWeight() ;
  bool readProblem(char *fname) ;
  void solve() ;
};

#endif // !defined(AFX_STEELMILL_H__690040B6_A5BD_48EF_9B13_B7AE3B62CBF5__INCLUDED_)

