// Fractions.h: interface for the Fractions class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FRACTIONS_H__BC403DDC_3348_4278_BF4B_AB654C7F0815__INCLUDED_)
#define AFX_FRACTIONS_H__BC403DDC_3348_4278_BF4B_AB654C7F0815__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <ilsolver/ilosolver.h>
#include <ilsolver/ilctrace.h>

ILOSTLBEGIN

class Fractions {
  IloEnv env ;
  IloModel model ;
  IloSolver solver ;
  IloNumVarArray digits ;
  void display(int n) ;
  void modelA() ;
  void modelB() ;
  void initModel(int n) ;
public:
  Fractions();
  virtual ~Fractions() {}
  void solve(int n) ;
};

#endif // !defined(AFX_FRACTIONS_H__BC403DDC_3348_4278_BF4B_AB654C7F0815__INCLUDED_)
