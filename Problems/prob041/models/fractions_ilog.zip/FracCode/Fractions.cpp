// Fractions.cpp: implementation of the Fractions class.
//
//////////////////////////////////////////////////////////////////////

#include "Fractions.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

Fractions::Fractions() {
  model = IloModel(env) ;
  solver = IloSolver(env) ;
}

// ===================================================================
// Display()
void Fractions::display(int n) {
  for (int i = 0; i < n; i++) {
	if (i > 0) cout << " + " ;
	cout << solver.getValue(digits[3*i]) << "/" <<
	        solver.getValue(digits[3*i+1]) <<
		    solver.getValue(digits[3*i+2]) ;
  }
  cout << " == 1 " << endl ;
}

// ===================================================================
// modelA()
// Basic version.
void Fractions::modelA() {
  digits = IloNumVarArray(env, 9, 1, 9, ILOINT) ;
  model.add(IloAllDiff(env, digits)) ;
  model.add((10*digits[1]+digits[2])*(10*digits[4]+digits[5])*(10*digits[7]+digits[8])
	        ==
	        digits[0]*(10*digits[4]+digits[5])*(10*digits[7]+digits[8]) +
            digits[3]*(10*digits[1]+digits[2])*(10*digits[7]+digits[8]) +
            digits[6]*(10*digits[1]+digits[2])*(10*digits[4]+digits[5])) ;
  solver.extract(model) ;
}

// ===================================================================
// modelB()
// with fractions-based symm-breaking and ICs.
void Fractions::modelB() {
  digits = IloNumVarArray(env, 9, 1, 9, ILOINT) ;
  model.add(IloAllDiff(env, digits)) ;
  model.add((10*digits[1]+digits[2])*(10*digits[4]+digits[5])*(10*digits[7]+digits[8])
	        ==
	        digits[0]*(10*digits[4]+digits[5])*(10*digits[7]+digits[8]) +
            digits[3]*(10*digits[1]+digits[2])*(10*digits[7]+digits[8]) +
            digits[6]*(10*digits[1]+digits[2])*(10*digits[4]+digits[5])) ;
  // sym breaking: A/BC <= D/EF, D/EF <= G/HI
  model.add(digits[0]*(10*digits[4]+digits[5]) <=
	        digits[3]*(10*digits[1]+digits[2])) ;
  model.add(digits[3]*(10*digits[7]+digits[8]) <=
	        digits[6]*(10*digits[4]+digits[5])) ;
  // G >= 4
  model.add(digits[6] >= 4) ;
  // 3G >= 10H+I, 3A <= 10B+C
  model.add(3*digits[6] >= 10*digits[7]+digits[8]) ;
  model.add(3*digits[0] <= 10*digits[1]+digits[2]) ;
  solver.extract(model) ;
}

//////////////////////////////////////////////////////////////////////
// initModel() Sum_{i = 1 .. n} x_i/(10y_i+z_i) == 1
// n: number of fractions.
// NB If n <= 3, use allDiff
void Fractions::initModel(int n) {
  digits = IloNumVarArray(env, n*3, 1, 9, ILOINT) ;
  if (n <= 3) model.add (IloAllDiff(env, digits)) ;
  else {
    int maxOccs = (n/3 < n/3.0) ? n/3+1 : n/3 ;
    cout << "maxOccs: " << maxOccs << endl ;
    IloIntVarArray cards(env, 9, 1, maxOccs) ;
    IloNumArray values(env) ;
    for (int i = 1; i <= 9; i++) values.add(i) ;
    model.add(IloDistribute(env, cards, values, digits)) ;
  }
  IloIntVarArray denoms(env, n, 12, 98) ;
  for (int i = 0; i < n; i++)
	model.add(denoms[i] == 10*digits[i*3+1]+digits[i*3+2]) ;
  IloExpr lhs = 0 ;
  bool first = true ;
  for (i = 0; i < n; i++) {
    IloExpr sub = digits[3*i] ;
    for (int i2 = 0; i2 < n; i2++)
	  if (i != i2) sub = sub * denoms[i2] ;
	if (first) {
	  lhs = sub ;
	  first = false ;
	}
	else lhs = lhs +  sub ;
  }
  IloExpr rhs = denoms[0] ;
  for (i = 1; i < n; i++) 
	rhs = rhs * denoms[i] ;
  model.add(lhs == rhs) ;
  // Symm-breaking.
  for (i = 0; i < n-1; i++) 
	model.add(digits[3*i] <= digits[3*(i+1)]) ;
  solver.extract(model) ;  
}

// ===================================================================
// solve()
void Fractions::solve(int n) {
  try {
    initModel(n) ;

    IloGoal goal = IloGenerate(env, digits, IlcChooseMinSizeInt) ;
	solver.startNewSearch(goal);

	cout << "Starting search" << endl ;
	while (solver.next()) {
      display(n) ;
	}
	solver.printInformation() ;
  }
  catch (IloException& ex) {
    cerr << "Error: " << ex << endl;
  }
  env.end();
}


// ===================================================================
// main()
int main(int argc, char* argv[]) {
  if (argc != 2) {
    cout << "Usage: Fractions <n>" << endl
		 << "n is number of fractions" << endl ;
    return 0 ;
  }
  Fractions * f = new Fractions() ;
  f->solve(atoi(argv[1])) ;
  return 0;
}