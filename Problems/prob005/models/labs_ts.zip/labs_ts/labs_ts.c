/*
This source code (labs_ts.c) is used in the following paper:
S. Halim, R.H.C. Yap, F. Halim,
"Engineering Stochastic Local Search for the Low Autocorrelation Binary Sequence Problem",
Principles and Practice of Constraint Programming 2008, 640-645

Any scientific (or commercial usage) of this code must cite the abovementioned paper.

For any enquiry about the code, please contact the authors:
1. Steven Halim (stevenha at comp.nus.edu.sg) *main contact author*
2. Dr Roland Yap Hock Chuan (ryap at comp.nus.edu.sg)
3. Felix Halim (halim at comp.nus.edu.sg)

Our experiments are conducted on:
2.00 GHz Centrino Duo laptop for 21 <= n <= 60
2.33 GHz Core2 Duo PC for 61 <= n <= 77

Remember that different compiler settings may produce different timings!
Although this labs_ts.c should be compileable in other c/c++ compilers,
we have included our Visual Studio project settings too (for replicability).

The default output of this program is a list of the individual timings of the
20 repeats and the average runtime. To output the actual LABS, you need to
modify some parts of the code.

This source code is last updated on 12 September 2008.
*/

#define _CRT_SECURE_NO_DEPRECATE /* to avoid Visual Studio 2005 to display unnecessary warnings... */
#define TSv1 0
#define TSv7 7

#include <stdio.h>
#include <assert.h>
#include <time.h>
#include <stdlib.h>
#include <string.h>

#define MAXN 80         /* we have tried up to 77 */

int n;                  /* Instance Size                                */
int solution[MAXN];     /* Indices are always from [0..n-1]             */
int bestSolution[MAXN];
int refSolution[MAXN];  /* In care we need to revert back, e.g. ILS     */
int tabu[MAXN];         /* tabu table, O(1)                             */
int T[MAXN][MAXN];      /* to store solution[i]*solution[i+k]           */
int T2[MAXN][MAXN];     /* data structure for temporary calculation     */
int C[MAXN];            /* to store C[k]                                */
int Cur_OV;             /* Current Objective Value                      */
int BF_OV;              /* Best Found Objective Value in this run       */
int bestIdx[MAXN], bestIdxID, bestNeighborOV;

int BK_OV[MAXN] = {     /* Best Known (optimal up to n = 60) Objective Value for this instance */
  0,0,0,1,2,2,7,3,8,12,13,                  /* 0-10  */
  5,10,6,19,15,24,32,25,29,26,              /* 11-20 */
  26,39,47,36,36,45,37,50,62,59,            /* 21-30 */
  67,64,64,65,73,82,86,87,99,108,           /* 31-40 */
  108,101,109,122,118,131,135,140,136,153,  /* 41-50 */
  153,166,170,175,171,192,188,197,205,218,  /* 51-60 */
  226,235,207,208,240,265,241,250,274,295,  /* 61-70 (not yet proven to be optimal) */
  275,300,308,349,341,338,366               /* 71-77 (not yet proven to be optimal) */
};

/* Efficient incremental objective value calculation of a LABS solution
* after flipping just one bit at index 'i'.
* Inspired by [Gallardo et al., 2007]
* Complexity : O(n)
*/
int ValueFlip(int i) {
  int f = 0, p, v;
  for (p = 1; p < n; p++) {
    v = C[p] - T2[p][i];
    f += v*v;
  }
  return f;
}

/* This is similar as above, but the internal data structure is updated
* after computation. This function is used after best move is selected.
* Inspired by [Gallardo et al., 2007]
* Complexity : O(n)
*/
int ValueFlipAndUpdate(int i) {
  int f = 0, p, v;
  for (p = 1; p < n; p++) {
    v = C[p];
    if (i+p < n) {      /* update right side */
      v -= 2*T[p][i];
      T2[p][i] -= 4*T[p][i];
      T2[p][i+p] -= 4*T[p][i];
      T[p][i] *= -1;    /* flip the value */
    }
    if (0 <= i-p) {     /* update left side */
      v -= 2*T[p][i-p];
      T2[p][i] -= 4*T[p][i-p];
      T2[p][i-p] -= 4*T[p][i-p];
      T[p][i-p] *= -1; /* flip */
    }
    f += v*v;
    C[p] = v;           /* update C[p] */
  }
  return f;
}

/* Recomputes all internal data structure as well as computing the OV
* Complexity : O(n^2)
*/
void RecomputeDataStructure() {
  int i, k;
  Cur_OV = 0;
  for (k = 1; k <= n-1; k++) {
    C[k] = 0;
    for (i = 0; i < n-k; i++) {
      T[k][i] = solution[i]*solution[i+k];
      C[k] += T[k][i];
    }
    Cur_OV += C[k]*C[k];
  }

  memset(T2,0,sizeof(T2));
  for (i=0; i<n; i++){
    for (k=1; ; k++) {
      T2[k][i] = 0;
      if (i+k < n)
        T2[k][i] += 2*T[k][i];
      if (0 <= i-k)
        T2[k][i] += 2*T[k][i-k];
      if (i-k < 0 && n <= i+k)
        break;
    }
  }
}

/* Compute the OV in absolute manner, non-incremental!
* Complexity : O(n^2)
*/
int EvaluateAbsolute() {
  int E = 0, k, i;
  for (k = 1; k < n; k++) {
    int Ck = 0;
    for (i = 0; i < n-k; i++)
      Ck += solution[i]*solution[i+k];
    E += Ck*Ck;
  }
  return E;
}

/* Given any solution, quickly brings it down to 1-bit flip local optima
* Complexity : O(c*n), where c is the average basin length...
* (the precise complexity is hard to compute)
*/
void LocalOptima() {
  int idx, bI;
  while (1) {
    bestNeighborOV = 2147483647;
    bestIdxID = -1;

    for (idx = 0; idx < n; idx++) {
      int neighborOV = ValueFlip(idx);
      if (neighborOV < bestNeighborOV) {
        bestNeighborOV = neighborOV;
        bestIdxID = 0;
      }

      if (neighborOV == bestNeighborOV)
        bestIdx[bestIdxID++] = idx;
    }

    if (bestNeighborOV >= Cur_OV)
      break;            /* no longer improving... a local optima */

    bI = bestIdx[rand()%bestIdxID];
    Cur_OV = ValueFlipAndUpdate(bI);
    solution[bI] = -1*solution[bI];
  }
}

/* Create random solution
* Complexity : O(n)
*/
void RandomConfiguration() {
  int i;
  for (i = 0; i < n; i++)
    solution[i] = (rand()%2 ? 1 : -1); /* randomly set -1 or 1 */
  RecomputeDataStructure();
}

/* This is a key method in TSv7: local restart in bid to hit the nearest global optima
* Complexity : O(n^2)
*/
void LocalRestartAndPerturbABit(int PUTT) { /* PUTT is a golf term for a 'gentle' shot */
  int i, d=0;

  for (i = 0; i < n; i++)
    solution[i] = refSolution[i]; /* local restart to reference solution (a local optima) */

  /* then resume Tabu Search from about PUTT bits away from the reference solution */
  while (d < PUTT) {
    int randIndex = rand()%n;
    if (solution[randIndex] == refSolution[randIndex]) {
      solution[randIndex] = -1*solution[randIndex];
      d++;
    }
  }

  RecomputeDataStructure();
}

/* Trivial */
void SaveBest() {
  int i;
  if (Cur_OV <= BF_OV) { /* '<=' so we can 'slide' along plateau region */
    BF_OV = Cur_OV;
    for (i = 0; i < n; i++)
      refSolution[i] = bestSolution[i] = solution[i];
  }
}

/* Trivial */
void ClearTabuTable() {
  int i;
  for (i = 0; i < n; i++)
    tabu[i] = -2147483647; /* clear tabu status */
}

/* Main program */
int main(int argc,char** argv) {
  int MAX_REPEAT = 20;            /* number of test for a particular instance n */
  int STRATEGY = TSv7;            /* strategy (0/TSv1: our implementation of original Dotu/vanHentenryck 2006|1/TSv7) */
  int ASPIRATION_CRITERIA;        /* TSV1 only: aspiration criteria (0: not used|1: used) */
  int MAX_STABLE;                 /* TSV1 only: max stable (100: more diversification|1000: original Dotu/vanHentenryck 2006|10000: more TS) */
  int PUTT;                       /* TSV7 only: percent of n to do local restart */
  int THRESHOLD;                  /* TSV7 only: percent of n to revise local anchor */
  int TABU_TENURE_LOW;            /* TSV7 only: tabu tenure low */
  int TABU_TENURE_DELTA;          /* TSV7 only: tabu tenure delta */
  int TABU_TENURE;                /* in TSv1, this is static; in TSv7, this will be between [tabu tenure low ... tabu tenure low + delta] */
  int r,k,s,i,idx,bI,localRestartCounter;

  printf("You are running %s for 21 <= n <= 77 (20 repeats).\n", (STRATEGY == TSv1 ? "TSv1" : "TSv7"));
  printf("The output is the individual timings of the 20 repeats and the average running time.\n");
  printf("It will take hours to complete large n!\n");
  printf("Press Ctrl+C to terminate.\n");
  printf("\n");
  printf("S. Halim, R.H.C. Yap, F. Halim\n");
  printf("Engineering Stochastic Local Search for the Low Autocorrelation Binary Sequence Problem\n");
  printf("Principles and Practice of Constraint Programming 2008, 640-645\n");
  printf("\n");

  for (n=21; n<=77; n++) { /* n < 21 is simply too fast in today's machines */
    double totalTime = 0, theTime;
    srand(1); /* for replicable results */

    /* These are our best parameter settings so far! Perhaps can still be improved */
    if (STRATEGY == TSv1){
      MAX_STABLE = 1000;
      /* This is a different setting with Dotu/vanHentenryck 2006,
      we set it static and low, 20%*n of 0.2*n! */
      TABU_TENURE = n/5;
      ASPIRATION_CRITERIA = 1;
    } else if (STRATEGY == TSv7) {
      MAX_STABLE = 10*n;
      PUTT = n/4;
      THRESHOLD = 2*n;
      TABU_TENURE_LOW = 1+n/20;
      TABU_TENURE_DELTA = n/10;
    }

    for (r=0; r<MAX_REPEAT; r++){
      double startTime = clock();

      Cur_OV = BF_OV = 2147483647;
      ClearTabuTable();

                              /* 1. LABS-TS() // side by side comparison with pseudo-code in Dotu/vanHentenryck, 2006 */
      RandomConfiguration();  /* 2.   solution = random configuration; */
      SaveBest();             /* 3.   solution* = solution; including BK_OV = Cur_OV; */
      k = 0;                  /* 4.   k = 0; k is iterations */
      s = 0;                  /* 5.   s = 0; s is non improving move counter */
      localRestartCounter = 0; /* Additional counter */

      while (1) {             /* 6.   while (1) do */
        bestIdxID = 0;
        bestNeighborOV = 2147483647;

        for (idx=0; idx<n; idx++) { /* 7.     select solution' element M*(solution,bestSolution*) minimizing E(solution'); */
          int OK = 0;

          if (STRATEGY == TSv1) {
            Cur_OV = ValueFlip(idx);
            if (k >= tabu[idx] || (ASPIRATION_CRITERIA && Cur_OV < BF_OV)) 
              OK = 1; /* only if (non tabu) or (tabu but aspired) */
          } else if (STRATEGY == TSv7) {
            if (k >= tabu[idx]) {
              Cur_OV = ValueFlip(idx); /* do O(n) incremental calculation after knowing flipping bit idx is not tabu */
              OK = 1;
            }
          }

          if (OK) {
            if (Cur_OV < bestNeighborOV) {
              bestNeighborOV = Cur_OV;
              bestIdxID = 0;
            }
            if (Cur_OV == bestNeighborOV)
              bestIdx[bestIdxID++] = idx;
          }
        }

        bI = bestIdx[rand()%bestIdxID];
        Cur_OV = ValueFlipAndUpdate(bI); /* fix the data structure for next iteration, do this first before actually flipping solution[bI] */
        solution[bI] = -1*solution[bI]; /* 8.     solution = solution'; */

        if (STRATEGY == TSv1)
          TABU_TENURE = TABU_TENURE; /* no change */
        else /* tabu tenure is a robust value between tabu tenure low until (tabu tenure low + delta) */
          TABU_TENURE = TABU_TENURE_LOW + rand()%TABU_TENURE_DELTA;

        tabu[bI] = k+TABU_TENURE; /* has just been flipped at this iteration k, do not do it again for the next TABU_TENURE iterations */

        if ((STRATEGY == TSv1 && Cur_OV < BF_OV) || (STRATEGY == TSv7 && Cur_OV <= BF_OV)) {
                        /* 9.     if (E(solution) < E(bestSolution)) then */
          SaveBest();   /* 10.      solution* = solution; including BF_OV = Cur_OV */
          /* plateaux move is counted as non improving moves */
          if (STRATEGY == TSv7 && Cur_OV == BF_OV)
            s++;
          else {
            s = 0;      /* 11.      s = 0; */
            localRestartCounter = 0;
          }
        } else if (s > MAX_STABLE) { /* 12.    else if (s > maxStable) then */
          if (STRATEGY == TSv1) {
            RandomConfiguration(); /* 13.      solution = random configuration; (original from Dotu/vanHentenryck 2006) */
            ClearTabuTable();
          } else if (STRATEGY == TSv7) { /* our key improvement is here */
            localRestartCounter++; /* how many time we have done local restarts? */
            if (localRestartCounter > THRESHOLD) { /* okay, give up, this region is already saturated */
              localRestartCounter = 0; /* reset the counter */
              LocalRestartAndPerturbABit(PUTT/2); /* do a small diversification... */
              LocalOptima(); /* then get the 1-bit local optima */
              for (i = 0; i < n; i++)
                refSolution[i] = solution[i]; /* now concentrate here */
            } else /* still within threshold, keep searching locally in bid to get the nearest global optima */
              LocalRestartAndPerturbABit(PUTT); /* intensify around current reference solution by PUTT bits away */
            ClearTabuTable();
          }
          s = 0;        /* 14.      s = 0; */
        } else          /* 15.    else */
          s++;          /* 16.      s++; */
        k++;            /* 17.    k++; */

        SaveBest();     /* sometimes the diversification itself is already lucky */

        if (BF_OV <= BK_OV[n]) { /* reach goal, please change this condition for n > 60! */
          if (BF_OV < BK_OV[n])
            printf("New Best Known Value Found\n"); /* impossible for n <= 60, possible for 61 <= n <= 77 */
          break;
        }
      }

      theTime = (double)(clock()-startTime)/CLOCKS_PER_SEC;
      totalTime += theTime;
      printf("%.2lf ", theTime);

      /* These assertions are just for confirmation */
      assert(Cur_OV == EvaluateAbsolute());
      for (i=0; i<n; i++)
        solution[i] = bestSolution[i];
      assert(BF_OV == EvaluateAbsolute());
      assert(BF_OV == BK_OV[n]);
    }

    printf("> %.2lf (%d)\n",totalTime/MAX_REPEAT,n); /* this is the reported average time in our paper */
  }
}
