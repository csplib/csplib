All but one of these instances are converted from the data.txt file on CSPLib.
ReginPuget0 is not included in that file, it is taken directly from the paper (by Peter Nightingale)

Thanks to Peter Nightingale and James Wetter for converting the data format.

-- Özgür Akgün.
