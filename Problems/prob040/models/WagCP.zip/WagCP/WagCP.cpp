// WagCP.cpp: implementation of the WagCP class.
//
//////////////////////////////////////////////////////////////////////

#include "WagCP.h"

//////////////////////////////////////////////////////////////////////
// Constructor/Main/Read /////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////
// Construction
WagCP::WagCP(int modelChoice, int dr, int t) {
  model = IloModel(env) ;
  solver = IloSolver(env) ;
  usingConventional = (modelChoice == 1) ;
  cout << ((usingConventional) ? "Using Conv model" : "Using echelon model") << endl ;
  usingDomainRedn = (dr == 1) ;
  cout << ((usingDomainRedn) ? "Using DRedn" : "Not using DRedn") << endl ;
  timeLimit = t ;
}

///////////////////////////////////////////////////////////////////////
// main()
// model param
int main(int argc, char* argv[]) {
  if (argc != 5) {
    cout << "Usage: WagCP <fn> <model> <dr> <time>" << endl
		 << "Model: (1: conventional, 2: echelon)" << endl 
	     << "DRedn: (1: on, else off)" << endl 
		 << endl ;
    return 0 ;
  }
  cout << "Solving: " << argv[1] << endl ;
  WagCP * test = new WagCP(atoi(argv[2]), atoi(argv[3]),
	                       atoi(argv[4])) ;
  test->solve(argv[1]) ;
  return 0;
}

//////////////////////////////////////////////////////////////////////
// readProblem()
// Expects: nodes to be labelled 0, 1, 2, ...
//          leaves to be contiguous and at the head of this list.
// Format:
//   treeSize T
//   [parent, child]   << (treeSize-1) of these>>
//   c                 << treeSize of these>>
//   procurement costs << treeSize of these>>
//   demands           << noLeaves*T of these>>
bool WagCP::readProblem(char *fname) {
  IloInt node, i, t ;
  smallestNonLeaf = -1 ;
  ifstream infile ;
  infile.open(fname) ;
  if (!infile.good()) {
	cout << "Could not open " << fname << endl ;
	return false ;
  }
  infile >> treeSize >> T;
  cout << "Tree has " << treeSize << " nodes " << endl ;
  cout << "Number of time periods: " << T << endl ;
  tree = IloNumArray(env, (treeSize-1)*2) ;
  for (i = 0; i < treeSize-1; i++) {    //1 parent per node except root
    infile >> tree[2*i] >> tree[2*i+1] ;
	if (smallestNonLeaf == -1) smallestNonLeaf = tree[2*i] ;
    else if (tree[2*i] < smallestNonLeaf) smallestNonLeaf = tree[2*i] ;
	cout << tree[2*i] << " is parent of " << tree[2*i+1] << endl ;
  }
  cout << "Smallest internal node in tree is: " << smallestNonLeaf << endl ;
  // read c (holding cost):
  c = IloNumArray(env, treeSize) ;
  for (i = 0; i < treeSize; i++) {
    infile >> c[i] ;
	cout << "Holding cost for node " << i << " is: " << c[i] << endl ;
  }
  // read procurement costs
  procurementCosts = IloNumArray(env, treeSize) ;
  for (i = 0; i < treeSize; i++) {
    infile >> procurementCosts[i] ;
	cout << "Procurement cost for node " << i << " is: " << 
		 procurementCosts[i] << endl ;
  }
  // read demands
  demands = IloNumArray(env) ;
  int singleDemand = 0 ;
  for (i = 0; i < smallestNonLeaf; i++) {
	cout << "Demands for node " << i << ": " ;
	for (t = 0; t < T; t++) {
      infile >> singleDemand ;
      demands.add(singleDemand) ;
	  cout << singleDemand << " " ;
	}
	cout << endl ;
  }
  infile.close() ;
  cout << "Problem read successfully" << endl ;
  // determine branching factor.
  maxBranching = -1 ;
  for (node = 0; node < treeSize; node++) {
	int branching = 0 ;
    for (i = 0; i < treeSize-1; i++)
	  if (tree[2*i] == node) 
		branching++ ;
    if (maxBranching == -1) maxBranching = branching ;
	else if (maxBranching < branching) maxBranching = branching ;
  }
  cout << "Max branching factor: " << maxBranching << endl ;
  return true ;
}

//////////////////////////////////////////////////////////////////////
// End of Constructor/Main/Read //////////////////////////////////////
//////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////
// Basic Modelling ///////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////
// contains()
// Returns true if n is contained in `in'.
bool WagCP::contains(IloNumArray &in, int n) {
  for (IloInt i = 0; i < in.getSize(); i++)
	if (in[i] == n) return true ;
  return false ;
}

///////////////////////////////////////////////////////////////////////
// echelonCost()
// conventional holding(child) - conventional holding(parent)
int WagCP::echelonCost(int node) {
  if (node == treeSize-1) return c[node] ;
  int parent ;
  for (int node2 = 1; node2 < (2*treeSize)-1; node2+= 2)
    if (tree[node2] == node) parent = tree[node2-1] ;
  return c[node] - c[parent] ;
}

///////////////////////////////////////////////////////////////////////
// genDomain()
// When a tuple is complete, it should be added to dom, then call
//  genDomain at the next time-step.
// Flags: 0 is `unused', 1 is `in use', 2 is `used at t', 3 is `stopped'
// NB at initial time period, need at least a 1-tuple. Otherwise also
//    consider 0-tuples.
void WagCP::genDomain(int t, int i, int toDo, int subSum,
							 IloNumArray &flags, IloNumArray &dom,
							 int tOrig) {
  //cout << "gD. t: " << t << ", i: " << i << ", toDo: " << toDo <<
	//   ", subSum: " << subSum << ", flags: " << flags << ", dom: " << dom << endl ;
  // Base case: no more periods.
  if (t == T) return ;
  // Base case: tuple done. Recurse to next period.
  if (toDo == 0) {
    if (!contains(dom, subSum)) dom.add(subSum) ;
	IloNumArray flagsClone(env) ;
	flagsClone.add(flags) ;
	for (int f = 1; f < flagsClone.getSize(); f += 2)
	  if (flagsClone[f] == 1) flagsClone[f] = 3 ;
	  else if (flagsClone[f] == 2) flagsClone[f] = 1 ;
	genDomain(t+1, 0, 0, subSum, flagsClone, dom, tOrig) ;
	flagsClone.end() ;
  }
  // Stop j going too far using toDo
  else {
    for (IloInt j = i; j < (flags.getSize()/2)-(toDo-1); j++) {
	  //cout << "Trying to add node: " << flags[2*j] << " to tuple @ " << t << endl ;
	  // only add if flags permit.
	  if (flags[2*j+1] <= 2) {
	    int oldFlag = flags[2*j+1] ;
        flags[2*j+1] = 2 ;            //using this leaf now.
        genDomain(t, j+1, toDo-1, subSum+demands[flags[2*j]*T+t], flags, dom, tOrig) ;
        flags[2*j+1] = oldFlag ;
	  }
	  //cout << "Finished with adding node: " << flags[2*j] << " to tuple @ " << t << endl ;
	}
  }
  // If done with all n-tuples, do (n+1)-tuples
  // pass subSum through, since when i == 0 it is the subSum from
  //  t-1, or 0 if at initial t.
  if ((i == 0) && (toDo+1 <= (flags.getSize()/2))) {
	//cout << "increasing tuple size to " << toDo+1 << " @ " << t << endl ;
	genDomain(t, 0, toDo+1, subSum, flags, dom, tOrig) ;
  }
}

///////////////////////////////////////////////////////////////////////
// genX()
// X is arranged node1period1, node2period1, ...
// generate discrete possibilities for X
void WagCP::genX() {
  IloInt node, t, t2, leafUb ;
  X = IloNumVarArray(env) ;
  for (t = 0; t < T; t++) {
	//cout << "t: " << t << endl ;
	for (node = 0; node < treeSize; node++) {
	  // cout << "generating domain for node: " << node << endl ;
	  // Perform domain reduction.
	  if (node < smallestNonLeaf) leafUb = leafXUB(node, t) ;
	  else leafUb = -1 ;
      if (usingDomainRedn && (maxBranching <= 2)) {
		//cout << "Using DR" << endl ;
	    IloNumArray flags(env) ;
	    initFlags(node, flags) ;
	    IloNumArray dom(env) ;
	    if (t > 0) dom.add(0) ;
	    genDomain(t, 0, 1, 0, flags, dom, t) ;
	    sortIlo(dom) ;
		if ((leafUb != -1) && (leafUb < dom[dom.getSize()-1])) {
		  IloNumArray prunedDom(env) ;
          for (IloInt i = 0; i < dom.getSize(); i++)
		    if (dom[i] <= leafUb) prunedDom.add(dom[i]) ;
		    else break ;
		  dom.end() ;
		  dom = prunedDom ;
		}
		int ub = 0 ;
		for (t2 = t; t2 < T; t2++) ub += suppliedLeaf(node, t2) ;
		if ((leafUb != -1) && (leafUb < ub)) ub = leafUb ;
		X.add(IloNumVar(env, 0, ub, ILOINT)) ;
		IloInt i1 = 0, i2 = 0 ;
        for (; i2 < dom.getSize(); i1++)
		  if (i1 == dom[i2]) i2++ ;
		  else model.add(X[t*treeSize+node] != i1) ;
		//if (node < smallestNonLeaf)
	      //cout << "X: " << node << "@" << t <<" : " << dom <<  endl ;
	  }
	  // Branching factor too high for domain reduction, or not using.
	  // NB at t=0 lb is min of leaves.
	  else {
		int ub = 0 ;
		for (t2 = t; t2 < T; t2++) ub += suppliedLeaf(node, t2) ;
		if ((leafUb != -1) && (leafUb < ub)) ub = leafUb ;
		X.add(IloNumVar(env, 0, ub, ILOINT)) ;
		//if (node < smallestNonLeaf)
		  //cout << "Node: " << node << " : " << X[t*treeSize+node] << endl ;
	  }
	}
  }
}

///////////////////////////////////////////////////////////////////////
// initFlags()
// format: [<leaf, flag>, ... ]
// Record which leaves have been `used' in creating a domain element.
//  Prevents sub-optimal gaps in the ordering scheme.
void WagCP::initFlags(int node, IloNumArray &flags) {
  if (node < smallestNonLeaf) {
    flags.add(node) ;
	flags.add(0) ;
	return ;
  }
  for (IloInt node2 = 0; node2 < treeSize-1; node2++)
	if (tree[2*node2] == node)
	  initFlags(tree[2*node2+1], flags) ;
}

//////////////////////////////////////////////////////////////////////
// leafXUB()
// For each leaf, can set an ub on demand for each period.
int WagCP::leafXUB(int node, int t) {
  IloInt node2, parent, tMax, t2, demandSum, bestub = -1, ub ;
  for (node2 = 1; node2 < (2*treeSize)-1; node2+= 2)
    if (tree[node2] == node) parent = tree[node2-1] ;
  for (tMax = t; tMax < T; tMax++) {
	demandSum = 0 ; 
	for (t2 = t; t2 <= tMax; t2++)
      demandSum += demands[node*T+t2] ;
	if (bestub == -1) bestub = procurementCosts[node]/
	  ((tMax-t+1)*(c[node]-c[parent])) + demandSum ;
	else {
      ub = procurementCosts[node]/ ((tMax-t+1)*(c[node]-c[parent])) + demandSum ;
	  if (ub < bestub) bestub = ub ;
	}
  }
  return bestub ;
}

//////////////////////////////////////////////////////////////////////
// modelConventional()
// I, X, are arranged node1period1, node2period1, ...
void WagCP::modelConventional() {
  IloInt t, node ;
  I = IloNumVarArray(env, treeSize*T, 0, 1000000, ILOINT) ;
  genX() ;

  optVar = IloNumVar(env, 0, 1000000, ILOINT) ;

  // Period Total Holding Cost.
  holdingCosts = IloNumVarArray(env) ;
  for (t = 0; t < T; t++) {
	for (node = 0; node < treeSize; node++) {
	  IloNumVar holdingCost(env, 0, 1000000, ILOINT) ;
	  holdingCosts.add(holdingCost) ;
	  model.add(holdingCost == (c[node]*I[t*treeSize+node]+
		procurementCosts[node]*(X[t*treeSize+node]>0))) ;
	}
  }
  model.add(optVar == IloSum(holdingCosts)) ;
  model.add(IloMinimize(env, optVar)) ;

  //Inventory constraints
  for (t = 0; t < T; t++) {
	for (node = 0; node < treeSize; node++) {
	  if (node < smallestNonLeaf) {
		if (t == 0)
		  model.add(I[node] == X[node] - demands[node*T]) ;
        else 
		  model.add(I[t*treeSize+node] == I[(t-1)*treeSize+node] + 
		            X[t*treeSize+node] - demands[node*T+t]) ;
	  }
	  else {
		if (t == 0)
          model.add(I[node] == X[node] - supplied(node, 0)) ;
        else
          model.add(I[t*treeSize+node] == I[(t-1)*treeSize+node] +
		            X[t*treeSize+node] - supplied(node, t)) ;
	  }
	}
  }

  //ICs ===============================================================
  setInvUB() ;
  // inventory is 0 at end of last period.
  for (node = 0; node < treeSize; node++)
	model.add(I[treeSize*(T-1)+node] == 0) ;
  setXUB() ;
  orderIC() ;
  // zero ordering IC
  for (t = 1; t < T; t++)
	for (node = 0; node < treeSize; node++)
      model.add(IloIfThen(env, X[t*treeSize+node] > 0, 
		        I[(t-1)*treeSize+node] == 0)) ;
  // End of ICs ======================================================

  solver.extract(model) ;
  cout << "Conventional model created & extracted successfully" << endl ;
}

//////////////////////////////////////////////////////////////////////
// modelEchelon()
void WagCP::modelEchelon() {
  IloInt t, node, node2 ;
  E = IloNumVarArray(env, treeSize*T, 0, 1000000, ILOINT) ;
  genX() ;

  // Period Total Holding Cost.
  holdingCosts = IloNumVarArray(env) ;
  for (t = 0; t < T; t++) {
	for (node = 0; node < treeSize; node++) {
	  IloNumVar holdingCost(env, 0, 1000000, ILOINT) ;
	  holdingCosts.add(holdingCost) ;
	  model.add(holdingCost == (echelonCost(node)*E[t*treeSize+node]+
		procurementCosts[node]*(X[t*treeSize+node]>0))) ;
	}
  }

  // Optimisation
  optVar = IloNumVar(env, 0, 1000000, ILOINT) ;
  model.add(optVar == IloSum(holdingCosts)) ;
  model.add(IloMinimize(env, optVar)) ;          //IloLinC gets objective from here.

  //Echelon Inventory constraints
  for (t = 0; t < T; t++) {
	for (node = 0; node < treeSize; node++) {
	  if (node < smallestNonLeaf) {
		if (t == 0)
		  model.add(E[node] == X[node] - demands[node*T]) ;
        else 
		  model.add(E[t*treeSize+node] == E[(t-1)*treeSize+node] + 
		            X[t*treeSize+node] - demands[node*T+t]) ;
	  }
	  else {
		if (t == 0)
          model.add(E[node] == X[node] - suppliedLeaf(node, 0)) ;
        else
          model.add(E[t*treeSize+node] == E[(t-1)*treeSize+node] +
		            X[t*treeSize+node] - suppliedLeaf(node, t)) ;
	  }
	}
  }

  // Echelon constraints: Echelon inventory >= sum of children.
  for (node = smallestNonLeaf; node < treeSize; node++) {
	for (t = 0; t < T; t++) {
      IloNumVarArray children(env) ;
	  for (node2 = 0; node2 < (2*treeSize); node2 += 2)
		if (tree[node2] == node)
		  children.add(E[t*treeSize+tree[node2+1]]) ;
	  model.add(E[t*treeSize+node] >= IloSum(children)) ;
	}
  }

  // ICs =============================================================
  setInvUB() ;  //big improvement.
  // inventory is 0 at end of last period.
  for (node = 0; node < treeSize; node++)
	model.add(E[treeSize*(T-1)+node] == 0) ;
  setXUB() ;  //seems to give no improvement? On testprob 2, not as
                //tight as the subsum combinations.
  orderIC() ;
  // 0-ordering property: only order at a stocking pt if previous
  // inventory is 0. To obtain prev inventory subtract children.
  for (t = 1; t < T; t++)
	for (node = 0; node < treeSize; node++) {
	  if (node < smallestNonLeaf) 
        model.add(IloIfThen(env, X[t*treeSize+node] > 0, 
		          E[(t-1)*treeSize+node] == 0)) ;
	  else {
        IloNumVarArray children(env) ;
	    for (node2 = 0; node2 < (2*treeSize); node2 += 2)
		  if (tree[node2] == node)
		    children.add(E[(t-1)*treeSize+tree[node2+1]]) ;
        model.add(IloIfThen(env, X[t*treeSize+node] > 0, 
		          E[(t-1)*treeSize+node]-IloSum(children) == 0)) ;
	  }
	}
  // End of ICs ======================================================

  solver.extract(model) ;
  //cout << "Echelon model created and extracted successfully" << endl ;
}

//////////////////////////////////////////////////////////////////////
// sortIlo()
// copies n to an ordinary array. Sorts it, then copies it back.
void WagCP::sortIlo(IloNumArray &in) {
  int * copy = new int[in.getSize()] ;
  int i ;
  for (i = 0; i < in.getSize() ; i++)
	copy[i] = in[i] ;
  sort(&copy[0], &copy[in.getSize()]) ;
  for (i = 0; i < in.getSize() ; i++)
	in[i] = copy[i] ;
  delete copy ;
}

//////////////////////////////////////////////////////////////////////
// supplied()
// generate sub-constraint representing how much a node has supplied
//  either to its children or at the leaves.
// traverse tree[]. Look for [node, X] pairs. For each, add to the sum.
IloExprBase WagCP::supplied(IloInt node, IloInt t) {
  IloNumVarArray supplied(env) ;
  for (IloInt node2 = 0; node2 < (treeSize-1)*2; node2+= 2)
	if (tree[node2] == node)
      supplied.add(X[t*treeSize+tree[node2+1]]) ;
  return IloSum(supplied) ;
}

//////////////////////////////////////////////////////////////////////
// suppliedLeaf()
// return sum of demands at the leaves under the input node @t
// NB Dont worry about duplicates: each node has 1 parent.
// Used for: conservative estimate of X UB.
int WagCP::suppliedLeaf(IloInt node, IloInt t) {
  //Base case: leaf
  if (node < smallestNonLeaf)
	return demands[node*T+t] ;
  //General case: sum demands for leaves under each child.
  int result = 0 ;
  for (IloInt node2 = 0; node2 < (treeSize-1)*2; node2+= 2)
	if (tree[node2] == node)
	  result += suppliedLeaf(tree[node2+1], t) ;
  return result ;
}

//////////////////////////////////////////////////////////////////////
// End of Basic Modelling ////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////
// ICs ///////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////
// orderIC()
// If higher echelon places an order, at least one of children must.
void WagCP::orderIC() {
  IloInt node, node2, t ;
  for (node = smallestNonLeaf; node < treeSize; node++) {
	for (t = 0; t < T; t++) {
      IloNumVarArray children(env) ;
	  for (node2 = 0; node2 < (2*treeSize); node2 += 2)
		if (tree[node2] == node)
		  children.add(X[t*treeSize+tree[node2+1]]) ;
	  model.add(IloIfThen(env, X[t*treeSize+node] > 0, IloSum(children) > 0)) ;
	}
  }
}

//////////////////////////////////////////////////////////////////////
// setInvUB()
// for root: inv <= procurement/holding
// else: inv <= 
// Foreach node, find parent. This gives parent holding cost.
// Assumption: last node is the root.
void WagCP::setInvUB() {
  IloInt node, node2, parent, t ;
  for (node = 0; node < treeSize-1; node++) { //dont do root
	for (node2 = 1; node2 < (2*treeSize)-1; node2+= 2)
      if (tree[node2] == node) parent = tree[node2-1] ;
	for (t = 0; t < T; t++) {
	  if (usingConventional) {
	    model.add(I[t*treeSize+node] <=
	              procurementCosts[node]/(c[node] - c[parent])) ;
	    //cout << "I[" << t*treeSize+node << "] <= " <<
          //        procurementCosts[node]/(c[node] - c[parent]) << endl ;
	  }
	  else {
		if (node < smallestNonLeaf) {
	      model.add(E[t*treeSize+node] <=
	                procurementCosts[node]/(c[node] - c[parent])) ;
	      //cout << "E[" << t*treeSize+node << "] - children <= " <<
            //       procurementCosts[node]/(c[node] - c[parent]) << endl ;
		}
		else {
          IloNumVarArray children(env) ;
	      for (node2 = 0; node2 < (2*treeSize); node2 += 2)
		    if (tree[node2] == node)
		      children.add(E[t*treeSize+tree[node2+1]]) ;
	      model.add(E[t*treeSize+node] - IloSum(children) <=
	                procurementCosts[node]/(c[node] - c[parent])) ;
	      //cout << "E[" << t*treeSize+node << "] - children <= " <<
            //       procurementCosts[node]/(c[node] - c[parent]) << endl ;
		}
	  }
	}
  }
  // do root separately here.
  for (t = 0; t < T; t++) {
	if (usingConventional) {
	  model.add(I[t*treeSize+treeSize-1] <=
	            procurementCosts[treeSize-1]/c[treeSize-1]) ;
	  //cout << "I["<<t*treeSize+treeSize-1<<"] <= " << 
	  	//      procurementCosts[treeSize-1]/c[treeSize-1] << endl ;
	}
	else {
      IloNumVarArray children(env) ;
	  for (node2 = 0; node2 < (2*treeSize); node2 += 2)
		if (tree[node2] == node)
		  children.add(E[t*treeSize+tree[node2+1]]) ;
	  model.add(E[t*treeSize+treeSize-1] - IloSum(children) <=
	            procurementCosts[treeSize-1]/(c[treeSize-1])) ;
	  //cout << "E[" << t*treeSize+treeSize-1 << "] - children <= " <<
        //   procurementCosts[treeSize-1]/(c[treeSize-1]) << endl ;
	}
  }
}

//////////////////////////////////////////////////////////////////////
// setXUB()
// For each leaf, can set an ub on demand for each period.
void WagCP::setXUB() {
  IloInt node, node2, parent, t, tMax, t2, demandSum, bestub, ub ;
  for (node = 0; node < smallestNonLeaf; node++) {
	for (node2 = 1; node2 < (2*treeSize)-1; node2+= 2)
      if (tree[node2] == node) parent = tree[node2-1] ;
	for (t = 0; t < T; t++) {
      bestub = -1 ;
      for (tMax = t; tMax < T; tMax++) {
	    demandSum = 0 ; 
		for (t2 = t; t2 <= tMax; t2++)
          demandSum += demands[node*T+t2] ;
		if (bestub == -1) bestub = procurementCosts[node]/
			((tMax-t+1)*(c[node]-c[parent])) + demandSum ;
		else {
          ub = procurementCosts[node]/ ((tMax-t+1)*(c[node]-c[parent]))
			   + demandSum ;
		  if (ub < bestub) bestub = ub ;
		}
	  }
	  model.add(X[t*treeSize+node] <= bestub) ;
	  cout << "UB for X: " << node << " @" << t << " is: " << bestub << endl ;
	}
  }
}

//////////////////////////////////////////////////////////////////////
// End of ICs ////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////
// Solution/Display/VarOrdering //////////////////////////////////////
//////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////
// display()
void WagCP::display() {
  IloInt node, t ;
  if (usingConventional) cout << "Conventional model." << endl ;
  else cout << "Echelon model." << endl ;
  cout << "OptVar: " << solver.getIntVar(optVar) << endl ;
  cout << "X: " << endl ;
  for (node = 0; node < treeSize; node++) {
    cout << "Node: " << node << " ";
	for (t = 0; t < T; t++)
	  //cout << solver.getIntVar(X[t*treeSize+node]) << " " ;
	  cout << solver.getValue(X[t*treeSize+node]) << " " ;
    cout << endl ;
  }
  if (usingConventional) {
    cout << "I: " << endl ;
    for (node = 0; node < treeSize; node++) {
      cout << "Node: " << node << " ";
	  for (t = 0; t < T; t++)
	    cout << solver.getValue(I[t*treeSize+node]) << " " ;
      cout << endl ;
	}
  }
  else {
    cout << "E: " << endl ;
    for (node = 0; node < treeSize; node++) {
      cout << "Node: " << node << " ";
	  for (t = 0; t < T; t++)
        //cout << solver.getIntVar(E[t*treeSize+node]) << " " ;
	    cout << solver.getValue(E[t*treeSize+node]) << " " ;
      cout << endl ;
	}
  }
}

//////////////////////////////////////////////////////////////////////
// solve()
void WagCP::solve(char* fn) {
  try {
	if (readProblem(fn)) {
	  if (usingConventional) modelConventional() ; 
	  else modelEchelon() ;
	  IloNumVarArray goalVars(env) ;

	  //Tracing:
	  /*(solver.getIntVar(optVar)).setName("optVar") ;
	  char buffer[50] ;
      IlcIntVarArray sX = solver.getIntVarArray(X),
		             sD = solver.getIntVarArray(delta) ;
      for (IloInt i = 0; i < X.getSize(); i++) {
        itoa(i,buffer,10) ;
	    sX[i].setName(strcat(buffer, "X")) ;
		itoa(i,buffer,10) ;
		sD[i].setName(strcat(buffer, "delta")) ;
	  }
	  if (usingConventional) {
	    IlcIntVarArray sI = solver.getIntVarArray(I) ;
        for (i = 0; i < I.getSize(); i++) {
          itoa(i,buffer,10) ;
	      sI[i].setName(strcat(buffer, "I")) ;
		}
	  }
	  else {
	    IlcIntVarArray sE = solver.getIntVarArray(E) ;
        for (i = 0; i < E.getSize(); i++) {
          itoa(i,buffer,10) ;
	      sE[i].setName(strcat(buffer, "E")) ;
		}
	  }
	  solver.getManager().setTraceMode(IlcTrue) ;
	  IlcPrintTrace trace(solver.getManager(), IlcTraceVars+IlcTraceFail) ;
	  //IlcPrintTrace trace(solver.getManager(), IlcTraceAllEvent) ;
	  solver.getManager().setTrace(trace) ;*/

	  cout << "Starting search" << endl ;

	  solver.startNewSearch(IloLimitSearch(env,
		                    IloGenerate(env, X),
							IloTimeLimit(env, timeLimit))) ;
	  
      while (solver.next()) {
	    display() ;
	    solver.printInformation() ;
	  }
	  if (solver.getTime() <= timeLimit) {
	    cout << endl << endl << "Proven Optimal:" << endl ;
	    solver.printInformation() ;
 	  }
	  else cout << "Time expired" << endl ;
	  cout << "++++++++++++++++++++++++++++++++++++++++++++++++++++++++" << endl ;
	  solver.end() ; //IloLin will crash at env.end() without this.
	}
  }
  catch (IloException& ex) {
    cerr << "Error: " << ex << endl;
  }
  env.end() ;
}