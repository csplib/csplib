// WagCP.h: interface for the WagCP class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_WAGCP_H__528E6472_9951_4553_B2F9_091579CB225D__INCLUDED_)
#define AFX_WAGCP_H__528E6472_9951_4553_B2F9_091579CB225D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <ilconcert/ilomodel.h>
#include <ilsolver/ilosolver.h>
#include <ilsolver/ilctrace.h>
#include <vector>
#include <algorithm>
ILOSTLBEGIN

class WagCP {
  IloEnv env ;
  IloModel model ;
  IloSolver solver ;
  IloInt T ;            // # time periods
  IloInt treeSize ;
  IloInt smallestNonLeaf ;
  IloInt maxBranching ;
  IloNumArray c ;       // conventional unit inventory holding cos
  IloNumArray demands ; // per leaf node, per period.
  IloNumArray procurementCosts ;
  IloNumArray tree ;    // [parent, child] pairs.
  IloNumVarArray I ;    // Closing conventional inventory
  IloNumVarArray E ;    // Closing echelon inventory
  IloNumVarArray X ;    // Amount ordered (and received) during t.
  IloNumVarArray holdingCosts ; //per period.
  IloNumVar optVar ;
  bool usingConventional, usingDomainRedn ;
  int timeLimit ;
  bool contains(IloNumArray &in, int n) ;
  void display() ;
  int echelonCost(int node) ;
  void genDomain(int t, int i, int toDo, int subSum,
	             IloNumArray &flags, IloNumArray &res,
				 int tOrig) ;
  void genX() ;
  void initFlags(int node, IloNumArray &flags) ;
  int leafXUB(int, int) ;
  void modelConventional() ;
  void modelEchelon() ;
  void orderIC() ;
  bool readProblem(char *fname) ;
  void setInvUB() ;
  void setXUB() ;
  void sortIlo(IloNumArray &in) ;
  IloExprBase supplied(IloInt node, IloInt t) ;
  int suppliedLeaf(IloInt node, IloInt t) ;
  IloGoal varOrder(IloNumVarArray & goalVars) ;
  void varOrderDepthFirst(IloNumVarArray & goalVars, int node) ;
public:
  WagCP(int modelChoice, int dr, int t);
  virtual ~WagCP() {}
  void solve(char* fn) ;
};

#endif // !defined(AFX_WAGCP_H__528E6472_9951_4553_B2F9_091579CB225D__INCLUDED_)
