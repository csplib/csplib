// WagHybrid.h: interface for the WagHybrid class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_WAGHYBRID_H__99CFA6C3_AA42_47C4_A423_C28F12BC7A6F__INCLUDED_)
#define AFX_WAGHYBRID_H__99CFA6C3_AA42_47C4_A423_C28F12BC7A6F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <ilconcert/ilomodel.h>
#include <ilsolver/ilosolver.h>
#include <ilsolver/ilctrace.h>
#include <ilhybrid/ilohybrid.h>
#include <ilcplex/ilocplex.h>
#include <vector>
#include <algorithm>
ILOSTLBEGIN

class WagHybrid {
  IloEnv env ;
  IloModel model ;
  IloSolver solver ;
  IloLinConstraint lc ;
  IloInt T ;            // # time periods
  IloInt treeSize ;
  IloInt smallestNonLeaf ;
  IloInt maxBranching ;
  IloNumArray c ;       // conventional unit inventory holding cost [i,j]
  IloNumArray demands ; // per leaf node, per period.
  IloNumArray procurementCosts ;
  IloNumArray tree ;    // [parent, child] pairs.
  IloNumVarArray I ;    // closing conventional inventory.
  IloNumVarArray E ;    // closing echelon inventory.
  IloNumVarArray XLin ; // amount ordered (and received).
  IloNumVarArray delta ; //ordered in this period?
  IloNumVarArray holdingCosts ; //per period.
  IloNumVar optVar ;
  bool usingConventional, usingDomainRedn ;
  int timeLimit ;
  bool contains(IloNumArray &in, int n) ;
  void display() ;
  int echelonCost(int node) ;
  void genDomain(int t, int i, int toDo, int subSum,
	             IloNumArray &flags, IloNumArray &res,
				 int tOrig) ;
  void genX() ;
  void initFlags(int node, IloNumArray &flags) ;
  int leafXUB(int, int) ;
  void modelConventional() ;
  void modelEchelon() ;
  void orderIC() ;
  bool readProblem(char *fname) ;
  void setInvUB() ;
  void setXUB() ;
  void sortIlo(IloNumArray &in) ;
  IloExprBase supplied(IloInt node, IloInt t) ;
  int suppliedLeaf(IloInt node, IloInt t) ;
public:
  WagHybrid(int modelChoice, int dr, int lh, int t) ;
  virtual ~WagHybrid() {}
  void solve(char* fn) ;
};

#endif // !defined(AFX_WAGHYBRID_H__99CFA6C3_AA42_47C4_A423_C28F12BC7A6F__INCLUDED_)
