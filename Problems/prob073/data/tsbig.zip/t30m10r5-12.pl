%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 186, ['m10','m6','m1'], [], 'fam1', 1 ).
test( 't2', 388, [], ['r5','r3','r1','r4','r2'], 'fam1', 1 ).
test( 't3', 660, [], [], 'fam1', 1 ).
test( 't4', 428, [], [], 'fam1', 1 ).
test( 't5', 792, [], [], 'fam1', 1 ).
test( 't6', 254, [], ['r1','r3','r4','r5'], 'fam1', 1 ).
test( 't7', 293, [], [], 'fam1', 1 ).
test( 't8', 627, [], [], 'fam1', 1 ).
test( 't9', 241, [], [], 'fam1', 1 ).
test( 't10', 617, ['m2','m5','m9'], [], 'fam1', 1 ).
test( 't11', 758, [], ['r5','r1','r4','r2'], 'fam1', 1 ).
test( 't12', 580, ['m6'], [], 'fam1', 1 ).
test( 't13', 574, [], [], 'fam1', 1 ).
test( 't14', 708, [], [], 'fam1', 1 ).
test( 't15', 193, [], [], 'fam1', 1 ).
test( 't16', 556, ['m2'], [], 'fam1', 1 ).
test( 't17', 508, [], ['r1','r3'], 'fam1', 1 ).
test( 't18', 434, [], [], 'fam1', 1 ).
test( 't19', 567, ['m7','m3','m9'], [], 'fam1', 1 ).
test( 't20', 518, [], [], 'fam1', 1 ).
test( 't21', 286, [], [], 'fam1', 1 ).
test( 't22', 345, ['m10'], [], 'fam1', 1 ).
test( 't23', 148, [], ['r4','r2','r1','r3'], 'fam1', 1 ).
test( 't24', 235, [], [], 'fam1', 1 ).
test( 't25', 502, [], [], 'fam1', 1 ).
test( 't26', 195, [], ['r4','r2','r1','r5'], 'fam1', 1 ).
test( 't27', 523, ['m6'], [], 'fam1', 1 ).
test( 't28', 374, [], [], 'fam1', 1 ).
test( 't29', 360, [], [], 'fam1', 1 ).
test( 't30', 219, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
