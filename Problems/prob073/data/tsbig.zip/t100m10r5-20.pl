%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 18, ['m2','m10','m7','m8'], [], 'fam1', 1 ).
test( 't2', 185, [], ['r3','r1','r5'], 'fam1', 1 ).
test( 't3', 761, [], [], 'fam1', 1 ).
test( 't4', 101, [], [], 'fam1', 1 ).
test( 't5', 125, [], [], 'fam1', 1 ).
test( 't6', 629, [], [], 'fam1', 1 ).
test( 't7', 706, ['m8','m9','m4'], [], 'fam1', 1 ).
test( 't8', 291, ['m9','m1','m7','m8'], [], 'fam1', 1 ).
test( 't9', 739, [], ['r2','r4','r3','r5','r1'], 'fam1', 1 ).
test( 't10', 649, ['m9','m5'], [], 'fam1', 1 ).
test( 't11', 412, [], [], 'fam1', 1 ).
test( 't12', 494, [], [], 'fam1', 1 ).
test( 't13', 668, [], [], 'fam1', 1 ).
test( 't14', 651, [], [], 'fam1', 1 ).
test( 't15', 671, ['m8','m4','m9'], [], 'fam1', 1 ).
test( 't16', 270, [], ['r1','r3','r5','r2'], 'fam1', 1 ).
test( 't17', 225, [], [], 'fam1', 1 ).
test( 't18', 387, [], [], 'fam1', 1 ).
test( 't19', 313, [], ['r2'], 'fam1', 1 ).
test( 't20', 293, [], [], 'fam1', 1 ).
test( 't21', 124, [], [], 'fam1', 1 ).
test( 't22', 338, [], [], 'fam1', 1 ).
test( 't23', 719, [], ['r1'], 'fam1', 1 ).
test( 't24', 118, [], ['r5','r2','r3'], 'fam1', 1 ).
test( 't25', 504, [], [], 'fam1', 1 ).
test( 't26', 70, [], [], 'fam1', 1 ).
test( 't27', 6, [], [], 'fam1', 1 ).
test( 't28', 347, ['m3','m4'], [], 'fam1', 1 ).
test( 't29', 703, [], ['r5','r4','r2'], 'fam1', 1 ).
test( 't30', 549, ['m8'], [], 'fam1', 1 ).
test( 't31', 424, [], [], 'fam1', 1 ).
test( 't32', 23, ['m3'], [], 'fam1', 1 ).
test( 't33', 627, [], ['r1','r5','r3','r2'], 'fam1', 1 ).
test( 't34', 174, ['m10'], [], 'fam1', 1 ).
test( 't35', 545, [], [], 'fam1', 1 ).
test( 't36', 130, ['m2','m3'], [], 'fam1', 1 ).
test( 't37', 30, [], [], 'fam1', 1 ).
test( 't38', 314, [], ['r3'], 'fam1', 1 ).
test( 't39', 144, ['m4','m1','m6','m7'], [], 'fam1', 1 ).
test( 't40', 338, ['m7','m6'], [], 'fam1', 1 ).
test( 't41', 725, [], ['r1'], 'fam1', 1 ).
test( 't42', 455, [], ['r4'], 'fam1', 1 ).
test( 't43', 394, [], [], 'fam1', 1 ).
test( 't44', 240, ['m6','m7'], [], 'fam1', 1 ).
test( 't45', 141, [], [], 'fam1', 1 ).
test( 't46', 334, ['m10'], [], 'fam1', 1 ).
test( 't47', 146, [], ['r1'], 'fam1', 1 ).
test( 't48', 439, [], [], 'fam1', 1 ).
test( 't49', 721, [], [], 'fam1', 1 ).
test( 't50', 800, ['m2','m4','m3','m7'], [], 'fam1', 1 ).
test( 't51', 8, [], [], 'fam1', 1 ).
test( 't52', 566, [], [], 'fam1', 1 ).
test( 't53', 520, [], ['r2','r5','r4'], 'fam1', 1 ).
test( 't54', 165, [], [], 'fam1', 1 ).
test( 't55', 575, ['m1'], [], 'fam1', 1 ).
test( 't56', 533, [], [], 'fam1', 1 ).
test( 't57', 48, [], [], 'fam1', 1 ).
test( 't58', 800, [], [], 'fam1', 1 ).
test( 't59', 578, [], ['r3','r4','r5'], 'fam1', 1 ).
test( 't60', 326, [], [], 'fam1', 1 ).
test( 't61', 786, [], [], 'fam1', 1 ).
test( 't62', 331, [], [], 'fam1', 1 ).
test( 't63', 437, [], ['r3'], 'fam1', 1 ).
test( 't64', 750, [], [], 'fam1', 1 ).
test( 't65', 358, [], [], 'fam1', 1 ).
test( 't66', 431, [], ['r5'], 'fam1', 1 ).
test( 't67', 528, [], [], 'fam1', 1 ).
test( 't68', 152, [], [], 'fam1', 1 ).
test( 't69', 447, [], [], 'fam1', 1 ).
test( 't70', 410, [], ['r5','r3','r4','r1','r2'], 'fam1', 1 ).
test( 't71', 716, [], [], 'fam1', 1 ).
test( 't72', 486, [], ['r4','r2','r3','r5','r1'], 'fam1', 1 ).
test( 't73', 702, [], [], 'fam1', 1 ).
test( 't74', 738, [], [], 'fam1', 1 ).
test( 't75', 444, [], ['r5','r4','r2','r1'], 'fam1', 1 ).
test( 't76', 254, [], ['r5'], 'fam1', 1 ).
test( 't77', 620, ['m7','m2','m10','m1'], ['r4','r3','r1'], 'fam1', 1 ).
test( 't78', 232, [], ['r1','r3','r5','r4','r2'], 'fam1', 1 ).
test( 't79', 149, [], [], 'fam1', 1 ).
test( 't80', 591, ['m5'], [], 'fam1', 1 ).
test( 't81', 212, [], ['r4','r3','r5'], 'fam1', 1 ).
test( 't82', 631, [], [], 'fam1', 1 ).
test( 't83', 503, [], ['r2','r3','r4'], 'fam1', 1 ).
test( 't84', 17, [], [], 'fam1', 1 ).
test( 't85', 348, [], [], 'fam1', 1 ).
test( 't86', 731, [], [], 'fam1', 1 ).
test( 't87', 745, [], [], 'fam1', 1 ).
test( 't88', 260, [], [], 'fam1', 1 ).
test( 't89', 448, [], [], 'fam1', 1 ).
test( 't90', 723, [], [], 'fam1', 1 ).
test( 't91', 602, [], [], 'fam1', 1 ).
test( 't92', 550, [], ['r4'], 'fam1', 1 ).
test( 't93', 474, [], ['r5'], 'fam1', 1 ).
test( 't94', 587, [], [], 'fam1', 1 ).
test( 't95', 563, [], [], 'fam1', 1 ).
test( 't96', 770, [], [], 'fam1', 1 ).
test( 't97', 339, [], ['r5','r3'], 'fam1', 1 ).
test( 't98', 443, [], [], 'fam1', 1 ).
test( 't99', 19, [], ['r4','r3'], 'fam1', 1 ).
test( 't100', 415, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
