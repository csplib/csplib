%% ****  Testsuite  ****
% Number of tests                  : 20
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 757, ['m7','m8','m1','m6'], ['r2'], 'fam1', 1 ).
test( 't2', 391, ['m1','m7','m2','m4'], [], 'fam1', 1 ).
test( 't3', 334, [], ['r5','r2','r1','r4'], 'fam1', 1 ).
test( 't4', 296, [], [], 'fam1', 1 ).
test( 't5', 696, ['m1','m4','m8'], [], 'fam1', 1 ).
test( 't6', 379, ['m4'], [], 'fam1', 1 ).
test( 't7', 637, [], [], 'fam1', 1 ).
test( 't8', 794, [], [], 'fam1', 1 ).
test( 't9', 701, [], ['r4'], 'fam1', 1 ).
test( 't10', 740, [], [], 'fam1', 1 ).
test( 't11', 205, [], ['r3','r2'], 'fam1', 1 ).
test( 't12', 582, [], [], 'fam1', 1 ).
test( 't13', 370, [], [], 'fam1', 1 ).
test( 't14', 394, [], ['r1','r3','r4'], 'fam1', 1 ).
test( 't15', 306, ['m6','m7','m10','m5'], ['r5','r1','r2','r3','r4'], 'fam1', 1 ).
test( 't16', 483, [], ['r4','r5','r2','r3','r1'], 'fam1', 1 ).
test( 't17', 414, [], [], 'fam1', 1 ).
test( 't18', 351, [], [], 'fam1', 1 ).
test( 't19', 119, [], ['r1','r4','r3','r5','r2'], 'fam1', 1 ).
test( 't20', 689, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
