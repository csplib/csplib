%% ****  Testsuite  ****
% Number of tests                  : 20
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 631, [], [], 'fam1', 1 ).
test( 't2', 664, [], ['r2','r4'], 'fam1', 1 ).
test( 't3', 419, [], ['r2'], 'fam1', 1 ).
test( 't4', 485, [], [], 'fam1', 1 ).
test( 't5', 401, [], ['r3','r1','r4','r2'], 'fam1', 1 ).
test( 't6', 616, [], ['r4'], 'fam1', 1 ).
test( 't7', 439, [], [], 'fam1', 1 ).
test( 't8', 425, [], [], 'fam1', 1 ).
test( 't9', 331, [], [], 'fam1', 1 ).
test( 't10', 397, [], ['r2','r5'], 'fam1', 1 ).
test( 't11', 474, ['m6'], [], 'fam1', 1 ).
test( 't12', 310, [], ['r1','r2','r5','r3'], 'fam1', 1 ).
test( 't13', 407, [], [], 'fam1', 1 ).
test( 't14', 246, [], [], 'fam1', 1 ).
test( 't15', 121, ['m2'], [], 'fam1', 1 ).
test( 't16', 363, [], [], 'fam1', 1 ).
test( 't17', 134, [], [], 'fam1', 1 ).
test( 't18', 291, [], ['r1','r2'], 'fam1', 1 ).
test( 't19', 178, [], ['r2','r3','r4'], 'fam1', 1 ).
test( 't20', 266, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
