%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 20
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 533, [], ['r1','r2'], 'fam1', 1 ).
test( 't2', 541, [], ['r1'], 'fam1', 1 ).
test( 't3', 457, [], ['r1','r2'], 'fam1', 1 ).
test( 't4', 233, ['m6','m18','m14','m19','m16','m15','m1','m11'], [], 'fam1', 1 ).
test( 't5', 575, ['m15'], [], 'fam1', 1 ).
test( 't6', 636, [], [], 'fam1', 1 ).
test( 't7', 108, ['m16','m14'], [], 'fam1', 1 ).
test( 't8', 443, [], [], 'fam1', 1 ).
test( 't9', 288, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't10', 117, ['m4','m12','m3','m7'], [], 'fam1', 1 ).
test( 't11', 441, [], [], 'fam1', 1 ).
test( 't12', 275, [], [], 'fam1', 1 ).
test( 't13', 227, [], [], 'fam1', 1 ).
test( 't14', 672, ['m4','m14'], [], 'fam1', 1 ).
test( 't15', 121, [], ['r1'], 'fam1', 1 ).
test( 't16', 328, [], [], 'fam1', 1 ).
test( 't17', 269, [], ['r1','r2'], 'fam1', 1 ).
test( 't18', 183, [], [], 'fam1', 1 ).
test( 't19', 600, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't20', 364, [], [], 'fam1', 1 ).
test( 't21', 120, ['m6','m20'], ['r1'], 'fam1', 1 ).
test( 't22', 513, [], [], 'fam1', 1 ).
test( 't23', 579, [], [], 'fam1', 1 ).
test( 't24', 534, [], [], 'fam1', 1 ).
test( 't25', 178, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't26', 576, [], [], 'fam1', 1 ).
test( 't27', 360, ['m18','m6','m8','m17','m1','m12'], ['r2'], 'fam1', 1 ).
test( 't28', 688, [], [], 'fam1', 1 ).
test( 't29', 76, [], [], 'fam1', 1 ).
test( 't30', 167, [], [], 'fam1', 1 ).
test( 't31', 516, [], [], 'fam1', 1 ).
test( 't32', 743, [], [], 'fam1', 1 ).
test( 't33', 799, [], [], 'fam1', 1 ).
test( 't34', 780, [], ['r3'], 'fam1', 1 ).
test( 't35', 757, ['m18','m7','m3','m8'], [], 'fam1', 1 ).
test( 't36', 300, ['m12','m16'], [], 'fam1', 1 ).
test( 't37', 23, [], [], 'fam1', 1 ).
test( 't38', 656, [], [], 'fam1', 1 ).
test( 't39', 205, [], ['r1','r2'], 'fam1', 1 ).
test( 't40', 480, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
