%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 125, ['m4'], [], 'fam1', 1 ).
test( 't2', 216, [], ['r3'], 'fam1', 1 ).
test( 't3', 236, [], [], 'fam1', 1 ).
test( 't4', 63, [], ['r2'], 'fam1', 1 ).
test( 't5', 710, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't6', 142, ['m9'], [], 'fam1', 1 ).
test( 't7', 697, [], ['r1','r2'], 'fam1', 1 ).
test( 't8', 575, [], [], 'fam1', 1 ).
test( 't9', 324, [], [], 'fam1', 1 ).
test( 't10', 647, [], ['r3','r2'], 'fam1', 1 ).
test( 't11', 566, ['m4','m9'], [], 'fam1', 1 ).
test( 't12', 740, [], [], 'fam1', 1 ).
test( 't13', 94, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't14', 498, [], [], 'fam1', 1 ).
test( 't15', 143, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't16', 622, ['m1','m10','m9'], [], 'fam1', 1 ).
test( 't17', 498, [], ['r2','r3'], 'fam1', 1 ).
test( 't18', 575, ['m7','m4','m2','m8'], [], 'fam1', 1 ).
test( 't19', 716, [], [], 'fam1', 1 ).
test( 't20', 487, ['m5','m3','m4','m9'], ['r2','r3'], 'fam1', 1 ).
test( 't21', 455, [], ['r2'], 'fam1', 1 ).
test( 't22', 651, [], [], 'fam1', 1 ).
test( 't23', 777, [], ['r2'], 'fam1', 1 ).
test( 't24', 294, [], [], 'fam1', 1 ).
test( 't25', 734, [], [], 'fam1', 1 ).
test( 't26', 284, [], [], 'fam1', 1 ).
test( 't27', 769, [], [], 'fam1', 1 ).
test( 't28', 106, ['m7','m8','m3','m1'], ['r3','r2'], 'fam1', 1 ).
test( 't29', 428, [], [], 'fam1', 1 ).
test( 't30', 317, ['m5'], [], 'fam1', 1 ).
test( 't31', 414, ['m1','m2','m7','m6'], [], 'fam1', 1 ).
test( 't32', 572, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't33', 71, [], [], 'fam1', 1 ).
test( 't34', 746, [], [], 'fam1', 1 ).
test( 't35', 266, [], [], 'fam1', 1 ).
test( 't36', 659, [], [], 'fam1', 1 ).
test( 't37', 727, [], [], 'fam1', 1 ).
test( 't38', 257, [], ['r2','r1'], 'fam1', 1 ).
test( 't39', 189, [], [], 'fam1', 1 ).
test( 't40', 62, ['m5','m3','m8','m7'], ['r3'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
