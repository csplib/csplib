%% ****  Testsuite  ****
% Number of tests                  : 20
% Number of machines               : 10
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 425, [], [], 'fam1', 1 ).
test( 't2', 439, [], [], 'fam1', 1 ).
test( 't3', 555, [], [], 'fam1', 1 ).
test( 't4', 701, ['m8'], [], 'fam1', 1 ).
test( 't5', 256, ['m1','m9'], ['r8','r4','r9'], 'fam1', 1 ).
test( 't6', 744, [], [], 'fam1', 1 ).
test( 't7', 597, ['m1','m7','m2'], [], 'fam1', 1 ).
test( 't8', 530, ['m5','m8','m9','m7'], ['r6','r5','r4','r7'], 'fam1', 1 ).
test( 't9', 317, [], ['r4','r3','r8','r7','r10','r6','r1','r2'], 'fam1', 1 ).
test( 't10', 141, [], [], 'fam1', 1 ).
test( 't11', 203, [], [], 'fam1', 1 ).
test( 't12', 281, [], [], 'fam1', 1 ).
test( 't13', 390, [], ['r5','r7','r3','r9','r2','r8','r10','r1','r6'], 'fam1', 1 ).
test( 't14', 138, ['m6','m8'], [], 'fam1', 1 ).
test( 't15', 746, [], [], 'fam1', 1 ).
test( 't16', 760, [], [], 'fam1', 1 ).
test( 't17', 724, [], ['r2','r9','r10','r3','r8','r5','r4'], 'fam1', 1 ).
test( 't18', 312, ['m3','m4','m8'], [], 'fam1', 1 ).
test( 't19', 329, [], ['r2','r5','r8','r3','r7','r1','r10','r9'], 'fam1', 1 ).
test( 't20', 528, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
