%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 20
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 738, [], ['r10','r3','r8','r9','r5'], 'fam1', 1 ).
test( 't2', 114, ['m3','m15','m12','m1','m5'], [], 'fam1', 1 ).
test( 't3', 360, [], [], 'fam1', 1 ).
test( 't4', 46, [], [], 'fam1', 1 ).
test( 't5', 330, ['m13','m8','m17','m1'], [], 'fam1', 1 ).
test( 't6', 674, ['m17','m19','m18','m9','m8','m3','m4'], [], 'fam1', 1 ).
test( 't7', 267, [], [], 'fam1', 1 ).
test( 't8', 757, [], [], 'fam1', 1 ).
test( 't9', 3, [], [], 'fam1', 1 ).
test( 't10', 625, [], [], 'fam1', 1 ).
test( 't11', 494, ['m7'], [], 'fam1', 1 ).
test( 't12', 422, [], ['r3','r9','r1','r7','r5','r6','r2','r10','r4'], 'fam1', 1 ).
test( 't13', 567, [], ['r7','r1','r5','r2','r3','r8'], 'fam1', 1 ).
test( 't14', 761, [], [], 'fam1', 1 ).
test( 't15', 602, ['m3','m7','m5','m8','m10','m15','m18','m1'], [], 'fam1', 1 ).
test( 't16', 45, [], [], 'fam1', 1 ).
test( 't17', 252, [], [], 'fam1', 1 ).
test( 't18', 379, [], [], 'fam1', 1 ).
test( 't19', 66, [], [], 'fam1', 1 ).
test( 't20', 482, [], [], 'fam1', 1 ).
test( 't21', 395, ['m4','m18','m14','m20','m11','m6','m12','m3'], [], 'fam1', 1 ).
test( 't22', 790, [], ['r6','r5','r7','r4','r1','r2'], 'fam1', 1 ).
test( 't23', 589, ['m16','m15','m11','m2','m3','m7'], [], 'fam1', 1 ).
test( 't24', 601, ['m4','m11','m12','m3','m5'], ['r6','r2','r1'], 'fam1', 1 ).
test( 't25', 113, ['m4','m8'], [], 'fam1', 1 ).
test( 't26', 463, ['m11','m9','m20','m7'], [], 'fam1', 1 ).
test( 't27', 518, [], ['r8','r3'], 'fam1', 1 ).
test( 't28', 61, [], [], 'fam1', 1 ).
test( 't29', 230, [], ['r4','r2','r1','r7'], 'fam1', 1 ).
test( 't30', 582, [], [], 'fam1', 1 ).
test( 't31', 74, [], ['r7','r4','r1','r6','r5'], 'fam1', 1 ).
test( 't32', 489, ['m11','m8','m7'], [], 'fam1', 1 ).
test( 't33', 340, [], [], 'fam1', 1 ).
test( 't34', 445, [], [], 'fam1', 1 ).
test( 't35', 793, [], [], 'fam1', 1 ).
test( 't36', 87, ['m5','m6','m10','m7','m18','m8','m16'], ['r3','r9','r2','r6','r1','r7','r5','r8'], 'fam1', 1 ).
test( 't37', 526, [], [], 'fam1', 1 ).
test( 't38', 465, [], [], 'fam1', 1 ).
test( 't39', 334, [], ['r3','r4','r1'], 'fam1', 1 ).
test( 't40', 234, [], [], 'fam1', 1 ).
test( 't41', 407, [], [], 'fam1', 1 ).
test( 't42', 550, [], ['r3','r10'], 'fam1', 1 ).
test( 't43', 774, [], [], 'fam1', 1 ).
test( 't44', 391, [], [], 'fam1', 1 ).
test( 't45', 715, [], [], 'fam1', 1 ).
test( 't46', 85, [], [], 'fam1', 1 ).
test( 't47', 623, [], ['r3','r4','r8','r9','r10'], 'fam1', 1 ).
test( 't48', 379, [], [], 'fam1', 1 ).
test( 't49', 35, ['m15','m11','m3','m2','m4','m19'], [], 'fam1', 1 ).
test( 't50', 706, [], [], 'fam1', 1 ).
test( 't51', 113, [], [], 'fam1', 1 ).
test( 't52', 133, ['m19','m16'], [], 'fam1', 1 ).
test( 't53', 330, ['m20','m17','m15','m1','m2','m3','m18','m7'], [], 'fam1', 1 ).
test( 't54', 669, [], ['r3','r6','r5','r4','r8'], 'fam1', 1 ).
test( 't55', 742, [], [], 'fam1', 1 ).
test( 't56', 253, [], [], 'fam1', 1 ).
test( 't57', 463, [], [], 'fam1', 1 ).
test( 't58', 273, [], ['r7','r8','r5','r3'], 'fam1', 1 ).
test( 't59', 715, [], [], 'fam1', 1 ).
test( 't60', 332, [], [], 'fam1', 1 ).
test( 't61', 455, [], [], 'fam1', 1 ).
test( 't62', 755, [], [], 'fam1', 1 ).
test( 't63', 758, [], [], 'fam1', 1 ).
test( 't64', 468, ['m16','m8','m20','m12','m15','m1','m17'], [], 'fam1', 1 ).
test( 't65', 617, [], [], 'fam1', 1 ).
test( 't66', 600, ['m7','m17','m3','m14','m11','m12'], [], 'fam1', 1 ).
test( 't67', 412, ['m9','m11','m4','m16'], ['r1','r6','r5','r4','r2','r10'], 'fam1', 1 ).
test( 't68', 119, [], [], 'fam1', 1 ).
test( 't69', 763, [], ['r7','r1','r5','r4','r8','r10'], 'fam1', 1 ).
test( 't70', 386, [], ['r10'], 'fam1', 1 ).
test( 't71', 229, [], [], 'fam1', 1 ).
test( 't72', 487, [], [], 'fam1', 1 ).
test( 't73', 446, [], [], 'fam1', 1 ).
test( 't74', 622, [], ['r9','r8'], 'fam1', 1 ).
test( 't75', 233, [], [], 'fam1', 1 ).
test( 't76', 309, [], [], 'fam1', 1 ).
test( 't77', 314, [], [], 'fam1', 1 ).
test( 't78', 440, [], ['r1','r5','r9','r10','r4'], 'fam1', 1 ).
test( 't79', 792, [], [], 'fam1', 1 ).
test( 't80', 489, [], ['r2','r10','r7','r9','r3'], 'fam1', 1 ).
test( 't81', 410, [], [], 'fam1', 1 ).
test( 't82', 487, ['m4','m16','m18','m17','m6','m3','m19','m7'], ['r4','r2'], 'fam1', 1 ).
test( 't83', 165, ['m4','m12','m19','m20','m15','m7','m14','m6'], [], 'fam1', 1 ).
test( 't84', 382, ['m17','m15','m1','m6'], [], 'fam1', 1 ).
test( 't85', 626, [], [], 'fam1', 1 ).
test( 't86', 703, [], [], 'fam1', 1 ).
test( 't87', 119, ['m11'], ['r4','r10','r8','r7','r1','r5','r9'], 'fam1', 1 ).
test( 't88', 721, [], [], 'fam1', 1 ).
test( 't89', 252, [], [], 'fam1', 1 ).
test( 't90', 562, [], ['r2','r4','r5','r3'], 'fam1', 1 ).
test( 't91', 505, [], [], 'fam1', 1 ).
test( 't92', 713, [], [], 'fam1', 1 ).
test( 't93', 690, [], [], 'fam1', 1 ).
test( 't94', 431, ['m20','m7','m2','m17','m16','m14','m13'], ['r2'], 'fam1', 1 ).
test( 't95', 687, [], ['r9','r4'], 'fam1', 1 ).
test( 't96', 456, [], [], 'fam1', 1 ).
test( 't97', 100, [], ['r8','r1','r2','r7','r6'], 'fam1', 1 ).
test( 't98', 203, [], [], 'fam1', 1 ).
test( 't99', 278, [], ['r4','r5','r1','r6','r9','r8','r7','r2','r10','r3'], 'fam1', 1 ).
test( 't100', 199, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
