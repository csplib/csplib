%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 701, [], ['r1','r3','r2','r4','r5'], 'fam1', 1 ).
test( 't2', 69, [], ['r4'], 'fam1', 1 ).
test( 't3', 339, [], ['r1'], 'fam1', 1 ).
test( 't4', 262, [], [], 'fam1', 1 ).
test( 't5', 689, [], [], 'fam1', 1 ).
test( 't6', 798, [], [], 'fam1', 1 ).
test( 't7', 425, [], [], 'fam1', 1 ).
test( 't8', 700, ['m3'], [], 'fam1', 1 ).
test( 't9', 442, [], [], 'fam1', 1 ).
test( 't10', 397, [], [], 'fam1', 1 ).
test( 't11', 279, [], [], 'fam1', 1 ).
test( 't12', 49, [], [], 'fam1', 1 ).
test( 't13', 424, [], [], 'fam1', 1 ).
test( 't14', 511, ['m3','m7','m1'], [], 'fam1', 1 ).
test( 't15', 135, [], [], 'fam1', 1 ).
test( 't16', 284, [], [], 'fam1', 1 ).
test( 't17', 384, [], ['r5','r1','r3','r4','r2'], 'fam1', 1 ).
test( 't18', 202, ['m8','m1','m6'], [], 'fam1', 1 ).
test( 't19', 166, [], [], 'fam1', 1 ).
test( 't20', 357, ['m9'], [], 'fam1', 1 ).
test( 't21', 188, [], [], 'fam1', 1 ).
test( 't22', 694, [], [], 'fam1', 1 ).
test( 't23', 245, [], [], 'fam1', 1 ).
test( 't24', 758, ['m9','m5','m4'], [], 'fam1', 1 ).
test( 't25', 361, [], [], 'fam1', 1 ).
test( 't26', 227, [], ['r4','r1','r2','r3','r5'], 'fam1', 1 ).
test( 't27', 261, [], [], 'fam1', 1 ).
test( 't28', 527, [], ['r4','r5','r2','r1','r3'], 'fam1', 1 ).
test( 't29', 252, [], ['r2'], 'fam1', 1 ).
test( 't30', 293, [], ['r4','r5'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
