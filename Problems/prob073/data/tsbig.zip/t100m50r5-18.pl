%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 50
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 36, ['m17','m38','m34','m4','m14','m15','m22','m16','m37','m27','m2','m44','m31','m50','m42','m47','m30'], [], 'fam1', 1 ).
test( 't2', 88, [], ['r2','r3','r5','r4'], 'fam1', 1 ).
test( 't3', 127, [], [], 'fam1', 1 ).
test( 't4', 370, ['m5'], ['r4','r3','r1','r5'], 'fam1', 1 ).
test( 't5', 551, [], [], 'fam1', 1 ).
test( 't6', 692, [], [], 'fam1', 1 ).
test( 't7', 416, ['m21','m6','m8','m27','m13','m50','m14','m41','m10','m25','m46','m3','m28','m22','m4','m44'], ['r1','r5','r4'], 'fam1', 1 ).
test( 't8', 268, [], [], 'fam1', 1 ).
test( 't9', 491, ['m7','m23','m36','m49','m42','m21','m9','m46','m37','m20','m3'], [], 'fam1', 1 ).
test( 't10', 507, ['m38','m32','m11','m10','m50'], [], 'fam1', 1 ).
test( 't11', 229, [], [], 'fam1', 1 ).
test( 't12', 442, [], ['r2','r1'], 'fam1', 1 ).
test( 't13', 380, [], [], 'fam1', 1 ).
test( 't14', 761, ['m47','m8','m9','m23','m5','m39','m32','m14','m42','m16'], [], 'fam1', 1 ).
test( 't15', 97, [], [], 'fam1', 1 ).
test( 't16', 120, [], [], 'fam1', 1 ).
test( 't17', 301, ['m27','m43','m39','m20','m24','m29','m47','m37','m42','m14','m45','m32','m31','m26','m41','m18','m44','m22','m35','m4'], [], 'fam1', 1 ).
test( 't18', 700, [], [], 'fam1', 1 ).
test( 't19', 587, [], ['r2','r5','r1','r4','r3'], 'fam1', 1 ).
test( 't20', 716, [], [], 'fam1', 1 ).
test( 't21', 346, [], ['r4','r1','r5','r2','r3'], 'fam1', 1 ).
test( 't22', 291, [], [], 'fam1', 1 ).
test( 't23', 566, [], [], 'fam1', 1 ).
test( 't24', 394, [], [], 'fam1', 1 ).
test( 't25', 236, [], [], 'fam1', 1 ).
test( 't26', 430, [], ['r2','r1'], 'fam1', 1 ).
test( 't27', 276, [], [], 'fam1', 1 ).
test( 't28', 200, [], ['r4','r2','r3'], 'fam1', 1 ).
test( 't29', 28, ['m21','m37','m5','m8','m33','m18','m29','m32','m44','m11','m30','m39','m7'], [], 'fam1', 1 ).
test( 't30', 455, [], ['r4','r1','r5','r2'], 'fam1', 1 ).
test( 't31', 539, ['m5','m41','m49','m26','m44','m23','m24','m35','m28'], ['r1','r4','r2','r5','r3'], 'fam1', 1 ).
test( 't32', 342, [], [], 'fam1', 1 ).
test( 't33', 134, [], [], 'fam1', 1 ).
test( 't34', 61, ['m37','m1','m25','m36','m21','m38','m39','m50','m23'], [], 'fam1', 1 ).
test( 't35', 281, [], [], 'fam1', 1 ).
test( 't36', 794, [], [], 'fam1', 1 ).
test( 't37', 509, [], [], 'fam1', 1 ).
test( 't38', 120, [], [], 'fam1', 1 ).
test( 't39', 142, [], [], 'fam1', 1 ).
test( 't40', 359, [], [], 'fam1', 1 ).
test( 't41', 719, [], [], 'fam1', 1 ).
test( 't42', 466, [], ['r2','r1','r3','r5','r4'], 'fam1', 1 ).
test( 't43', 509, [], ['r1','r5','r4','r3','r2'], 'fam1', 1 ).
test( 't44', 588, [], [], 'fam1', 1 ).
test( 't45', 407, ['m13','m41','m17','m33','m44','m39','m4'], [], 'fam1', 1 ).
test( 't46', 197, [], [], 'fam1', 1 ).
test( 't47', 258, [], ['r2','r1','r5','r3','r4'], 'fam1', 1 ).
test( 't48', 41, [], [], 'fam1', 1 ).
test( 't49', 521, [], [], 'fam1', 1 ).
test( 't50', 266, [], ['r4'], 'fam1', 1 ).
test( 't51', 695, ['m45','m9','m39','m15','m40','m24','m48','m20','m36','m35','m21','m23','m7','m34','m22'], ['r2','r3','r5','r4'], 'fam1', 1 ).
test( 't52', 406, [], ['r4','r5'], 'fam1', 1 ).
test( 't53', 731, [], [], 'fam1', 1 ).
test( 't54', 331, [], [], 'fam1', 1 ).
test( 't55', 238, [], ['r4','r1','r2'], 'fam1', 1 ).
test( 't56', 577, ['m15','m20','m24','m35','m45','m33','m37','m8','m41','m7','m27','m34','m50','m3','m22','m16','m49','m39','m12','m38'], [], 'fam1', 1 ).
test( 't57', 668, [], [], 'fam1', 1 ).
test( 't58', 392, [], ['r2','r3','r1','r5'], 'fam1', 1 ).
test( 't59', 653, [], [], 'fam1', 1 ).
test( 't60', 451, [], [], 'fam1', 1 ).
test( 't61', 576, ['m7','m23','m2','m20','m30'], [], 'fam1', 1 ).
test( 't62', 697, [], [], 'fam1', 1 ).
test( 't63', 679, ['m36','m11','m1','m15','m12','m26','m16','m41','m31','m23','m13','m24','m40','m30','m20','m14','m3','m39','m8','m9'], [], 'fam1', 1 ).
test( 't64', 773, ['m40','m45'], ['r1','r2','r4','r3'], 'fam1', 1 ).
test( 't65', 107, [], [], 'fam1', 1 ).
test( 't66', 53, [], [], 'fam1', 1 ).
test( 't67', 22, [], [], 'fam1', 1 ).
test( 't68', 531, [], [], 'fam1', 1 ).
test( 't69', 77, [], [], 'fam1', 1 ).
test( 't70', 13, [], ['r2','r5','r3','r1'], 'fam1', 1 ).
test( 't71', 502, [], ['r2','r1','r4','r3','r5'], 'fam1', 1 ).
test( 't72', 767, [], [], 'fam1', 1 ).
test( 't73', 620, ['m19','m42','m12','m24','m30'], ['r2','r5','r4','r1','r3'], 'fam1', 1 ).
test( 't74', 260, [], [], 'fam1', 1 ).
test( 't75', 70, [], ['r1','r5'], 'fam1', 1 ).
test( 't76', 352, [], [], 'fam1', 1 ).
test( 't77', 702, [], ['r3'], 'fam1', 1 ).
test( 't78', 780, [], [], 'fam1', 1 ).
test( 't79', 398, [], [], 'fam1', 1 ).
test( 't80', 91, [], [], 'fam1', 1 ).
test( 't81', 94, [], [], 'fam1', 1 ).
test( 't82', 479, [], [], 'fam1', 1 ).
test( 't83', 327, [], ['r5'], 'fam1', 1 ).
test( 't84', 81, [], [], 'fam1', 1 ).
test( 't85', 37, [], [], 'fam1', 1 ).
test( 't86', 130, [], [], 'fam1', 1 ).
test( 't87', 554, ['m18','m15','m47','m14','m38','m35','m48','m12','m41'], [], 'fam1', 1 ).
test( 't88', 685, [], [], 'fam1', 1 ).
test( 't89', 444, [], [], 'fam1', 1 ).
test( 't90', 158, ['m12','m44','m42','m41','m23','m46'], ['r2','r1'], 'fam1', 1 ).
test( 't91', 523, ['m22','m2','m36','m6','m35','m21','m40','m13','m15','m20'], [], 'fam1', 1 ).
test( 't92', 313, [], [], 'fam1', 1 ).
test( 't93', 758, [], [], 'fam1', 1 ).
test( 't94', 329, [], [], 'fam1', 1 ).
test( 't95', 1, ['m1','m32','m37','m24','m22','m30','m3'], [], 'fam1', 1 ).
test( 't96', 427, [], [], 'fam1', 1 ).
test( 't97', 123, [], [], 'fam1', 1 ).
test( 't98', 603, ['m28','m11','m46','m38'], ['r4','r3','r2','r5','r1'], 'fam1', 1 ).
test( 't99', 732, [], [], 'fam1', 1 ).
test( 't100', 528, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').
embedded_board( 'm21').
embedded_board( 'm22').
embedded_board( 'm23').
embedded_board( 'm24').
embedded_board( 'm25').
embedded_board( 'm26').
embedded_board( 'm27').
embedded_board( 'm28').
embedded_board( 'm29').
embedded_board( 'm30').
embedded_board( 'm31').
embedded_board( 'm32').
embedded_board( 'm33').
embedded_board( 'm34').
embedded_board( 'm35').
embedded_board( 'm36').
embedded_board( 'm37').
embedded_board( 'm38').
embedded_board( 'm39').
embedded_board( 'm40').
embedded_board( 'm41').
embedded_board( 'm42').
embedded_board( 'm43').
embedded_board( 'm44').
embedded_board( 'm45').
embedded_board( 'm46').
embedded_board( 'm47').
embedded_board( 'm48').
embedded_board( 'm49').
embedded_board( 'm50').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
