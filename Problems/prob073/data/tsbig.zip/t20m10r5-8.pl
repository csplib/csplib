%% ****  Testsuite  ****
% Number of tests                  : 20
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 19, [], [], 'fam1', 1 ).
test( 't2', 154, [], ['r5','r2','r3'], 'fam1', 1 ).
test( 't3', 628, [], [], 'fam1', 1 ).
test( 't4', 40, [], ['r4'], 'fam1', 1 ).
test( 't5', 697, [], [], 'fam1', 1 ).
test( 't6', 747, [], [], 'fam1', 1 ).
test( 't7', 288, ['m2','m10','m9','m7'], [], 'fam1', 1 ).
test( 't8', 590, ['m5'], ['r1','r2','r4','r3'], 'fam1', 1 ).
test( 't9', 259, [], [], 'fam1', 1 ).
test( 't10', 668, [], [], 'fam1', 1 ).
test( 't11', 260, [], [], 'fam1', 1 ).
test( 't12', 52, [], [], 'fam1', 1 ).
test( 't13', 118, [], [], 'fam1', 1 ).
test( 't14', 585, [], [], 'fam1', 1 ).
test( 't15', 232, [], ['r2','r1','r4','r3','r5'], 'fam1', 1 ).
test( 't16', 290, [], [], 'fam1', 1 ).
test( 't17', 487, [], [], 'fam1', 1 ).
test( 't18', 658, [], [], 'fam1', 1 ).
test( 't19', 514, [], [], 'fam1', 1 ).
test( 't20', 192, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
