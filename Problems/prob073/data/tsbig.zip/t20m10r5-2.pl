%% ****  Testsuite  ****
% Number of tests                  : 20
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 1, [], [], 'fam1', 1 ).
test( 't2', 219, ['m8','m9','m5','m7'], [], 'fam1', 1 ).
test( 't3', 39, ['m5','m8','m2','m7'], [], 'fam1', 1 ).
test( 't4', 419, [], [], 'fam1', 1 ).
test( 't5', 231, ['m4','m5','m3','m8'], ['r5','r2','r1'], 'fam1', 1 ).
test( 't6', 521, [], [], 'fam1', 1 ).
test( 't7', 689, ['m2','m10','m5'], [], 'fam1', 1 ).
test( 't8', 797, [], [], 'fam1', 1 ).
test( 't9', 120, [], [], 'fam1', 1 ).
test( 't10', 105, [], [], 'fam1', 1 ).
test( 't11', 221, ['m9','m8','m2','m10'], [], 'fam1', 1 ).
test( 't12', 183, [], [], 'fam1', 1 ).
test( 't13', 482, [], [], 'fam1', 1 ).
test( 't14', 764, [], ['r1','r4','r2'], 'fam1', 1 ).
test( 't15', 56, [], [], 'fam1', 1 ).
test( 't16', 253, [], ['r1','r3','r5','r2','r4'], 'fam1', 1 ).
test( 't17', 303, [], [], 'fam1', 1 ).
test( 't18', 673, [], [], 'fam1', 1 ).
test( 't19', 622, [], ['r4','r3'], 'fam1', 1 ).
test( 't20', 462, ['m6'], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
