%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 50
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 692, [], ['r3','r4','r1','r5'], 'fam1', 1 ).
test( 't2', 619, ['m27','m50','m42','m21','m22','m31','m45','m38','m16','m8','m20','m36','m46'], [], 'fam1', 1 ).
test( 't3', 177, [], [], 'fam1', 1 ).
test( 't4', 267, [], ['r5','r1','r2','r3'], 'fam1', 1 ).
test( 't5', 143, ['m3','m13','m7','m37','m10','m28','m17'], [], 'fam1', 1 ).
test( 't6', 483, [], ['r3','r2','r4','r1','r5'], 'fam1', 1 ).
test( 't7', 617, [], [], 'fam1', 1 ).
test( 't8', 453, [], [], 'fam1', 1 ).
test( 't9', 614, [], ['r5'], 'fam1', 1 ).
test( 't10', 198, [], ['r2','r1','r5','r4','r3'], 'fam1', 1 ).
test( 't11', 541, [], [], 'fam1', 1 ).
test( 't12', 198, [], ['r4','r5','r3'], 'fam1', 1 ).
test( 't13', 570, ['m29','m19','m37','m1','m40','m36','m47','m49','m28','m24','m20','m25','m3','m43','m41','m18','m35','m21','m42'], [], 'fam1', 1 ).
test( 't14', 620, ['m4','m47','m23','m48','m27','m42','m16','m11','m3','m10','m25','m12'], ['r2','r1'], 'fam1', 1 ).
test( 't15', 168, [], [], 'fam1', 1 ).
test( 't16', 400, [], ['r2'], 'fam1', 1 ).
test( 't17', 375, [], ['r5','r2','r4','r1','r3'], 'fam1', 1 ).
test( 't18', 648, [], ['r1','r3'], 'fam1', 1 ).
test( 't19', 448, [], [], 'fam1', 1 ).
test( 't20', 538, [], ['r1','r5','r3','r4','r2'], 'fam1', 1 ).
test( 't21', 780, [], [], 'fam1', 1 ).
test( 't22', 696, [], [], 'fam1', 1 ).
test( 't23', 747, ['m30','m31','m46','m17','m29','m24','m27','m38','m1','m36','m26','m32','m23','m35'], [], 'fam1', 1 ).
test( 't24', 297, [], [], 'fam1', 1 ).
test( 't25', 164, [], [], 'fam1', 1 ).
test( 't26', 535, [], [], 'fam1', 1 ).
test( 't27', 652, [], [], 'fam1', 1 ).
test( 't28', 363, [], ['r1','r2'], 'fam1', 1 ).
test( 't29', 407, [], [], 'fam1', 1 ).
test( 't30', 534, [], [], 'fam1', 1 ).
test( 't31', 493, [], [], 'fam1', 1 ).
test( 't32', 179, [], [], 'fam1', 1 ).
test( 't33', 30, ['m39','m4','m36','m33','m35','m47','m11'], ['r1'], 'fam1', 1 ).
test( 't34', 11, [], [], 'fam1', 1 ).
test( 't35', 707, [], ['r5'], 'fam1', 1 ).
test( 't36', 654, ['m34','m11','m19','m25','m31'], [], 'fam1', 1 ).
test( 't37', 449, ['m49','m3','m21','m26','m45'], [], 'fam1', 1 ).
test( 't38', 778, [], [], 'fam1', 1 ).
test( 't39', 651, [], [], 'fam1', 1 ).
test( 't40', 560, [], [], 'fam1', 1 ).
test( 't41', 736, ['m19','m28','m23','m31','m3','m10','m34','m16','m32','m20','m44'], [], 'fam1', 1 ).
test( 't42', 389, [], [], 'fam1', 1 ).
test( 't43', 776, [], [], 'fam1', 1 ).
test( 't44', 359, [], ['r5','r2','r1','r4'], 'fam1', 1 ).
test( 't45', 661, [], ['r5','r2','r4'], 'fam1', 1 ).
test( 't46', 1, [], ['r5','r4'], 'fam1', 1 ).
test( 't47', 140, [], [], 'fam1', 1 ).
test( 't48', 716, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't49', 783, [], [], 'fam1', 1 ).
test( 't50', 419, [], [], 'fam1', 1 ).
test( 't51', 459, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't52', 374, [], [], 'fam1', 1 ).
test( 't53', 151, [], [], 'fam1', 1 ).
test( 't54', 459, ['m46','m8','m37','m4','m43','m36','m48','m38','m2'], [], 'fam1', 1 ).
test( 't55', 89, [], [], 'fam1', 1 ).
test( 't56', 126, [], [], 'fam1', 1 ).
test( 't57', 473, ['m5','m4','m45','m8','m19','m21'], [], 'fam1', 1 ).
test( 't58', 213, ['m46','m22','m43','m40','m10','m4','m16','m5'], ['r3','r1','r5'], 'fam1', 1 ).
test( 't59', 137, [], ['r5','r1','r2','r4','r3'], 'fam1', 1 ).
test( 't60', 801, [], [], 'fam1', 1 ).
test( 't61', 765, [], ['r5'], 'fam1', 1 ).
test( 't62', 613, [], [], 'fam1', 1 ).
test( 't63', 796, [], [], 'fam1', 1 ).
test( 't64', 720, [], [], 'fam1', 1 ).
test( 't65', 786, [], [], 'fam1', 1 ).
test( 't66', 750, [], [], 'fam1', 1 ).
test( 't67', 683, [], [], 'fam1', 1 ).
test( 't68', 433, [], ['r1'], 'fam1', 1 ).
test( 't69', 652, [], [], 'fam1', 1 ).
test( 't70', 370, [], [], 'fam1', 1 ).
test( 't71', 4, [], [], 'fam1', 1 ).
test( 't72', 33, ['m27','m17','m1','m43','m2'], [], 'fam1', 1 ).
test( 't73', 171, [], [], 'fam1', 1 ).
test( 't74', 574, [], [], 'fam1', 1 ).
test( 't75', 452, [], ['r3','r1','r4','r2','r5'], 'fam1', 1 ).
test( 't76', 309, [], [], 'fam1', 1 ).
test( 't77', 102, ['m32','m33','m14','m49','m13','m11'], ['r5'], 'fam1', 1 ).
test( 't78', 320, [], [], 'fam1', 1 ).
test( 't79', 658, [], ['r4','r2','r1'], 'fam1', 1 ).
test( 't80', 148, [], [], 'fam1', 1 ).
test( 't81', 7, [], [], 'fam1', 1 ).
test( 't82', 279, [], ['r1','r3','r5','r2'], 'fam1', 1 ).
test( 't83', 461, [], [], 'fam1', 1 ).
test( 't84', 677, ['m7','m23','m49','m46','m33','m26','m32','m4','m25','m42','m43','m18','m45','m40','m34','m29'], [], 'fam1', 1 ).
test( 't85', 600, [], [], 'fam1', 1 ).
test( 't86', 529, [], [], 'fam1', 1 ).
test( 't87', 647, ['m31','m6','m48','m36','m50','m38','m49','m37','m45','m4','m21','m7','m18','m46','m27','m3','m26','m33','m10','m9'], [], 'fam1', 1 ).
test( 't88', 511, [], ['r3','r1','r5','r4'], 'fam1', 1 ).
test( 't89', 336, [], ['r4','r3','r5'], 'fam1', 1 ).
test( 't90', 498, [], [], 'fam1', 1 ).
test( 't91', 629, [], ['r1','r2','r5'], 'fam1', 1 ).
test( 't92', 645, [], ['r5','r2','r1','r3','r4'], 'fam1', 1 ).
test( 't93', 151, ['m37','m40','m34','m41','m4','m15','m8','m18','m22','m23','m1','m25','m11','m32','m16','m27','m39'], [], 'fam1', 1 ).
test( 't94', 626, [], [], 'fam1', 1 ).
test( 't95', 482, [], ['r1','r3','r2','r4'], 'fam1', 1 ).
test( 't96', 151, ['m10','m25','m48','m22','m42','m30','m44','m45','m43','m36','m35','m32','m38','m18','m29','m21'], [], 'fam1', 1 ).
test( 't97', 27, [], [], 'fam1', 1 ).
test( 't98', 679, ['m33','m27','m20','m5','m30','m48','m16'], [], 'fam1', 1 ).
test( 't99', 717, [], ['r3','r4','r1','r2','r5'], 'fam1', 1 ).
test( 't100', 218, ['m44','m20','m25','m6','m27','m13','m35','m17','m29','m10','m42','m40','m5','m24','m46','m34','m43'], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').
embedded_board( 'm21').
embedded_board( 'm22').
embedded_board( 'm23').
embedded_board( 'm24').
embedded_board( 'm25').
embedded_board( 'm26').
embedded_board( 'm27').
embedded_board( 'm28').
embedded_board( 'm29').
embedded_board( 'm30').
embedded_board( 'm31').
embedded_board( 'm32').
embedded_board( 'm33').
embedded_board( 'm34').
embedded_board( 'm35').
embedded_board( 'm36').
embedded_board( 'm37').
embedded_board( 'm38').
embedded_board( 'm39').
embedded_board( 'm40').
embedded_board( 'm41').
embedded_board( 'm42').
embedded_board( 'm43').
embedded_board( 'm44').
embedded_board( 'm45').
embedded_board( 'm46').
embedded_board( 'm47').
embedded_board( 'm48').
embedded_board( 'm49').
embedded_board( 'm50').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
