%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 405, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't2', 2, [], [], 'fam1', 1 ).
test( 't3', 425, [], [], 'fam1', 1 ).
test( 't4', 537, [], [], 'fam1', 1 ).
test( 't5', 572, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't6', 487, [], [], 'fam1', 1 ).
test( 't7', 86, [], [], 'fam1', 1 ).
test( 't8', 714, ['m5','m8'], [], 'fam1', 1 ).
test( 't9', 215, [], [], 'fam1', 1 ).
test( 't10', 622, [], [], 'fam1', 1 ).
test( 't11', 571, [], ['r2','r3'], 'fam1', 1 ).
test( 't12', 286, [], [], 'fam1', 1 ).
test( 't13', 71, ['m4','m7','m3','m2'], [], 'fam1', 1 ).
test( 't14', 696, [], ['r1','r3'], 'fam1', 1 ).
test( 't15', 399, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't16', 562, [], [], 'fam1', 1 ).
test( 't17', 683, [], [], 'fam1', 1 ).
test( 't18', 731, [], ['r3','r1'], 'fam1', 1 ).
test( 't19', 532, [], [], 'fam1', 1 ).
test( 't20', 336, [], [], 'fam1', 1 ).
test( 't21', 488, [], [], 'fam1', 1 ).
test( 't22', 70, [], ['r2','r1'], 'fam1', 1 ).
test( 't23', 357, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't24', 199, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't25', 439, [], [], 'fam1', 1 ).
test( 't26', 318, [], [], 'fam1', 1 ).
test( 't27', 334, [], [], 'fam1', 1 ).
test( 't28', 512, [], ['r2'], 'fam1', 1 ).
test( 't29', 639, ['m9'], ['r2','r3'], 'fam1', 1 ).
test( 't30', 603, [], ['r2','r3'], 'fam1', 1 ).
test( 't31', 180, [], [], 'fam1', 1 ).
test( 't32', 355, [], [], 'fam1', 1 ).
test( 't33', 293, [], [], 'fam1', 1 ).
test( 't34', 565, ['m4','m3','m1'], [], 'fam1', 1 ).
test( 't35', 387, [], [], 'fam1', 1 ).
test( 't36', 701, [], [], 'fam1', 1 ).
test( 't37', 732, [], ['r3','r1'], 'fam1', 1 ).
test( 't38', 416, [], ['r1','r3'], 'fam1', 1 ).
test( 't39', 28, [], [], 'fam1', 1 ).
test( 't40', 306, ['m8','m7','m2','m10'], ['r2','r3','r1'], 'fam1', 1 ).
test( 't41', 111, [], [], 'fam1', 1 ).
test( 't42', 429, [], [], 'fam1', 1 ).
test( 't43', 406, [], [], 'fam1', 1 ).
test( 't44', 14, [], [], 'fam1', 1 ).
test( 't45', 356, [], [], 'fam1', 1 ).
test( 't46', 533, [], [], 'fam1', 1 ).
test( 't47', 257, ['m9','m4','m3'], [], 'fam1', 1 ).
test( 't48', 756, [], [], 'fam1', 1 ).
test( 't49', 771, [], [], 'fam1', 1 ).
test( 't50', 216, [], [], 'fam1', 1 ).
test( 't51', 654, [], [], 'fam1', 1 ).
test( 't52', 148, [], ['r1'], 'fam1', 1 ).
test( 't53', 224, ['m4'], [], 'fam1', 1 ).
test( 't54', 82, [], [], 'fam1', 1 ).
test( 't55', 617, [], ['r1','r2'], 'fam1', 1 ).
test( 't56', 459, [], [], 'fam1', 1 ).
test( 't57', 446, [], [], 'fam1', 1 ).
test( 't58', 665, ['m8','m9'], [], 'fam1', 1 ).
test( 't59', 539, [], [], 'fam1', 1 ).
test( 't60', 663, ['m2','m9','m7','m5'], [], 'fam1', 1 ).
test( 't61', 43, [], [], 'fam1', 1 ).
test( 't62', 683, ['m5','m2','m7','m8'], ['r2'], 'fam1', 1 ).
test( 't63', 738, [], [], 'fam1', 1 ).
test( 't64', 467, [], [], 'fam1', 1 ).
test( 't65', 667, ['m7'], [], 'fam1', 1 ).
test( 't66', 614, ['m5','m7'], [], 'fam1', 1 ).
test( 't67', 57, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't68', 181, [], ['r2'], 'fam1', 1 ).
test( 't69', 37, [], [], 'fam1', 1 ).
test( 't70', 425, [], [], 'fam1', 1 ).
test( 't71', 501, [], [], 'fam1', 1 ).
test( 't72', 444, [], [], 'fam1', 1 ).
test( 't73', 504, ['m10','m9'], [], 'fam1', 1 ).
test( 't74', 519, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't75', 781, [], ['r1','r2'], 'fam1', 1 ).
test( 't76', 42, [], [], 'fam1', 1 ).
test( 't77', 297, [], [], 'fam1', 1 ).
test( 't78', 587, [], ['r2','r3'], 'fam1', 1 ).
test( 't79', 56, [], ['r3'], 'fam1', 1 ).
test( 't80', 572, [], ['r3'], 'fam1', 1 ).
test( 't81', 573, [], [], 'fam1', 1 ).
test( 't82', 478, [], [], 'fam1', 1 ).
test( 't83', 123, [], [], 'fam1', 1 ).
test( 't84', 13, [], [], 'fam1', 1 ).
test( 't85', 718, [], [], 'fam1', 1 ).
test( 't86', 271, [], [], 'fam1', 1 ).
test( 't87', 542, [], [], 'fam1', 1 ).
test( 't88', 664, [], ['r2'], 'fam1', 1 ).
test( 't89', 417, [], [], 'fam1', 1 ).
test( 't90', 713, [], [], 'fam1', 1 ).
test( 't91', 346, [], [], 'fam1', 1 ).
test( 't92', 396, [], ['r2','r1'], 'fam1', 1 ).
test( 't93', 737, [], ['r3'], 'fam1', 1 ).
test( 't94', 350, [], [], 'fam1', 1 ).
test( 't95', 206, [], [], 'fam1', 1 ).
test( 't96', 330, [], [], 'fam1', 1 ).
test( 't97', 93, ['m3'], ['r2'], 'fam1', 1 ).
test( 't98', 723, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't99', 53, [], [], 'fam1', 1 ).
test( 't100', 75, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
