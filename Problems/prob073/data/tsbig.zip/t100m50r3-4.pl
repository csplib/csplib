%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 50
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 9, [], [], 'fam1', 1 ).
test( 't2', 767, [], [], 'fam1', 1 ).
test( 't3', 408, ['m19','m1','m35','m32','m8','m34','m16','m37','m48','m14','m26','m22','m40','m18','m15','m27','m44','m45'], ['r3','r2'], 'fam1', 1 ).
test( 't4', 529, [], [], 'fam1', 1 ).
test( 't5', 753, [], ['r2','r3'], 'fam1', 1 ).
test( 't6', 441, [], ['r2','r3'], 'fam1', 1 ).
test( 't7', 438, [], ['r2','r3'], 'fam1', 1 ).
test( 't8', 375, [], [], 'fam1', 1 ).
test( 't9', 105, [], [], 'fam1', 1 ).
test( 't10', 519, [], [], 'fam1', 1 ).
test( 't11', 799, ['m20','m6','m26','m23'], [], 'fam1', 1 ).
test( 't12', 541, [], [], 'fam1', 1 ).
test( 't13', 638, [], ['r1','r3'], 'fam1', 1 ).
test( 't14', 72, [], [], 'fam1', 1 ).
test( 't15', 226, [], [], 'fam1', 1 ).
test( 't16', 231, [], [], 'fam1', 1 ).
test( 't17', 766, ['m17','m32','m4','m20','m8'], [], 'fam1', 1 ).
test( 't18', 436, [], ['r1'], 'fam1', 1 ).
test( 't19', 738, ['m50','m16','m32','m42','m47','m26','m35','m1','m18','m34'], ['r3','r1','r2'], 'fam1', 1 ).
test( 't20', 156, [], [], 'fam1', 1 ).
test( 't21', 71, [], [], 'fam1', 1 ).
test( 't22', 660, ['m16','m22','m45','m24','m18','m3','m39','m1','m12','m50','m30'], [], 'fam1', 1 ).
test( 't23', 617, ['m32','m28','m36','m13','m7','m39','m1','m50','m48','m10'], [], 'fam1', 1 ).
test( 't24', 10, [], [], 'fam1', 1 ).
test( 't25', 396, ['m22','m32','m10','m26','m50','m16','m6','m49','m27','m29','m37','m28'], [], 'fam1', 1 ).
test( 't26', 305, ['m13','m43','m16','m29','m49','m4','m26','m21','m22','m42','m14','m40','m25'], [], 'fam1', 1 ).
test( 't27', 716, [], [], 'fam1', 1 ).
test( 't28', 397, ['m28','m1','m33','m20','m24'], [], 'fam1', 1 ).
test( 't29', 251, [], [], 'fam1', 1 ).
test( 't30', 509, [], ['r3'], 'fam1', 1 ).
test( 't31', 280, [], [], 'fam1', 1 ).
test( 't32', 133, [], [], 'fam1', 1 ).
test( 't33', 156, [], [], 'fam1', 1 ).
test( 't34', 514, [], [], 'fam1', 1 ).
test( 't35', 713, ['m28','m1','m44','m34','m23','m10','m42','m20','m9','m46','m32','m36','m18','m43','m40','m24','m4','m41','m3','m15'], [], 'fam1', 1 ).
test( 't36', 479, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't37', 186, [], [], 'fam1', 1 ).
test( 't38', 139, [], [], 'fam1', 1 ).
test( 't39', 467, [], [], 'fam1', 1 ).
test( 't40', 622, ['m9','m50','m41','m42','m27','m29','m32','m44','m48','m20','m26','m15','m11','m7','m37'], [], 'fam1', 1 ).
test( 't41', 210, [], [], 'fam1', 1 ).
test( 't42', 224, [], [], 'fam1', 1 ).
test( 't43', 477, ['m42','m49','m10','m27','m19','m39','m47'], [], 'fam1', 1 ).
test( 't44', 411, ['m42','m25','m1','m12','m5'], [], 'fam1', 1 ).
test( 't45', 510, [], ['r2','r1'], 'fam1', 1 ).
test( 't46', 467, [], [], 'fam1', 1 ).
test( 't47', 384, [], [], 'fam1', 1 ).
test( 't48', 559, ['m18','m46','m27','m4','m11','m42','m26','m50','m33','m9'], ['r1'], 'fam1', 1 ).
test( 't49', 413, [], [], 'fam1', 1 ).
test( 't50', 559, [], ['r3'], 'fam1', 1 ).
test( 't51', 400, ['m24','m6','m34','m5','m19'], [], 'fam1', 1 ).
test( 't52', 574, [], [], 'fam1', 1 ).
test( 't53', 745, [], [], 'fam1', 1 ).
test( 't54', 98, [], [], 'fam1', 1 ).
test( 't55', 255, ['m11','m46','m42','m49','m9','m8','m15','m38','m35','m13','m19','m39','m43'], [], 'fam1', 1 ).
test( 't56', 201, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't57', 537, ['m43','m47','m26','m14','m37','m42','m46','m38','m12','m18','m40','m50','m35','m13','m1','m19','m23'], [], 'fam1', 1 ).
test( 't58', 73, [], [], 'fam1', 1 ).
test( 't59', 114, [], [], 'fam1', 1 ).
test( 't60', 418, ['m38','m26','m24','m35','m15','m48','m12','m27','m34','m46','m18','m39','m23','m22','m16','m28','m41','m11','m47','m31'], [], 'fam1', 1 ).
test( 't61', 666, [], ['r2','r1'], 'fam1', 1 ).
test( 't62', 105, ['m45','m26','m18','m11','m34','m32','m1','m2','m10'], ['r2','r1'], 'fam1', 1 ).
test( 't63', 662, ['m9','m4','m32','m18','m37','m36'], [], 'fam1', 1 ).
test( 't64', 730, ['m19','m37','m9','m21','m14','m17','m7','m40','m12','m5','m49','m27','m25','m41'], [], 'fam1', 1 ).
test( 't65', 14, [], ['r2'], 'fam1', 1 ).
test( 't66', 657, [], [], 'fam1', 1 ).
test( 't67', 254, [], [], 'fam1', 1 ).
test( 't68', 501, [], ['r3','r2'], 'fam1', 1 ).
test( 't69', 193, [], ['r2','r3'], 'fam1', 1 ).
test( 't70', 769, [], [], 'fam1', 1 ).
test( 't71', 698, [], [], 'fam1', 1 ).
test( 't72', 336, [], [], 'fam1', 1 ).
test( 't73', 636, ['m30','m31','m49','m36','m5','m15','m2','m13','m7','m42','m12','m37','m44','m22'], [], 'fam1', 1 ).
test( 't74', 172, [], [], 'fam1', 1 ).
test( 't75', 527, [], [], 'fam1', 1 ).
test( 't76', 171, ['m50','m47','m46','m37','m16','m40','m42','m13','m10','m25','m11'], ['r2','r1','r3'], 'fam1', 1 ).
test( 't77', 597, ['m2','m36','m12'], ['r1','r3'], 'fam1', 1 ).
test( 't78', 301, [], [], 'fam1', 1 ).
test( 't79', 159, [], [], 'fam1', 1 ).
test( 't80', 191, ['m20','m41','m6','m36','m10','m48','m26','m31','m42','m50','m2','m12','m3','m11','m22','m24','m49','m39'], [], 'fam1', 1 ).
test( 't81', 782, [], [], 'fam1', 1 ).
test( 't82', 449, [], ['r3','r2'], 'fam1', 1 ).
test( 't83', 767, [], [], 'fam1', 1 ).
test( 't84', 742, [], ['r2'], 'fam1', 1 ).
test( 't85', 82, [], [], 'fam1', 1 ).
test( 't86', 713, [], [], 'fam1', 1 ).
test( 't87', 457, ['m21','m45','m41','m4','m28','m39','m24','m43','m11','m36','m6','m46','m33','m13','m32','m22','m37','m3','m20'], ['r1'], 'fam1', 1 ).
test( 't88', 314, [], [], 'fam1', 1 ).
test( 't89', 270, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't90', 86, [], ['r2','r3'], 'fam1', 1 ).
test( 't91', 246, [], [], 'fam1', 1 ).
test( 't92', 787, [], [], 'fam1', 1 ).
test( 't93', 352, [], ['r3'], 'fam1', 1 ).
test( 't94', 378, [], [], 'fam1', 1 ).
test( 't95', 184, ['m12','m16','m23','m9','m19','m17','m33'], [], 'fam1', 1 ).
test( 't96', 786, [], [], 'fam1', 1 ).
test( 't97', 581, ['m13','m9'], [], 'fam1', 1 ).
test( 't98', 65, [], [], 'fam1', 1 ).
test( 't99', 17, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't100', 254, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').
embedded_board( 'm21').
embedded_board( 'm22').
embedded_board( 'm23').
embedded_board( 'm24').
embedded_board( 'm25').
embedded_board( 'm26').
embedded_board( 'm27').
embedded_board( 'm28').
embedded_board( 'm29').
embedded_board( 'm30').
embedded_board( 'm31').
embedded_board( 'm32').
embedded_board( 'm33').
embedded_board( 'm34').
embedded_board( 'm35').
embedded_board( 'm36').
embedded_board( 'm37').
embedded_board( 'm38').
embedded_board( 'm39').
embedded_board( 'm40').
embedded_board( 'm41').
embedded_board( 'm42').
embedded_board( 'm43').
embedded_board( 'm44').
embedded_board( 'm45').
embedded_board( 'm46').
embedded_board( 'm47').
embedded_board( 'm48').
embedded_board( 'm49').
embedded_board( 'm50').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
