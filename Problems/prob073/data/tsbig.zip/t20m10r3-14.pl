%% ****  Testsuite  ****
% Number of tests                  : 20
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 29, [], [], 'fam1', 1 ).
test( 't2', 237, [], [], 'fam1', 1 ).
test( 't3', 14, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't4', 556, [], ['r3','r1'], 'fam1', 1 ).
test( 't5', 669, [], [], 'fam1', 1 ).
test( 't6', 562, ['m9'], ['r3','r1','r2'], 'fam1', 1 ).
test( 't7', 369, [], [], 'fam1', 1 ).
test( 't8', 626, ['m4','m5'], ['r2','r3'], 'fam1', 1 ).
test( 't9', 748, [], [], 'fam1', 1 ).
test( 't10', 371, [], ['r1','r2'], 'fam1', 1 ).
test( 't11', 632, [], [], 'fam1', 1 ).
test( 't12', 665, [], ['r1','r3'], 'fam1', 1 ).
test( 't13', 30, [], [], 'fam1', 1 ).
test( 't14', 415, [], ['r2','r3'], 'fam1', 1 ).
test( 't15', 438, ['m4','m10'], [], 'fam1', 1 ).
test( 't16', 352, [], [], 'fam1', 1 ).
test( 't17', 275, [], ['r1','r3'], 'fam1', 1 ).
test( 't18', 158, [], [], 'fam1', 1 ).
test( 't19', 407, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't20', 344, ['m10','m2','m9','m7'], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
