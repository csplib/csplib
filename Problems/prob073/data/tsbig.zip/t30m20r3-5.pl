%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 20
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 104, [], [], 'fam1', 1 ).
test( 't2', 471, ['m8','m15'], [], 'fam1', 1 ).
test( 't3', 494, [], [], 'fam1', 1 ).
test( 't4', 395, [], ['r1','r2'], 'fam1', 1 ).
test( 't5', 480, [], [], 'fam1', 1 ).
test( 't6', 201, ['m5','m6','m11','m14','m7','m10','m16'], [], 'fam1', 1 ).
test( 't7', 461, [], [], 'fam1', 1 ).
test( 't8', 716, [], [], 'fam1', 1 ).
test( 't9', 490, ['m8','m3','m11','m9','m20','m12','m6'], [], 'fam1', 1 ).
test( 't10', 498, [], [], 'fam1', 1 ).
test( 't11', 297, [], [], 'fam1', 1 ).
test( 't12', 304, ['m10','m1','m7','m8','m9'], ['r1','r3'], 'fam1', 1 ).
test( 't13', 350, ['m12','m14','m16','m5','m13','m6'], ['r1','r2'], 'fam1', 1 ).
test( 't14', 602, [], [], 'fam1', 1 ).
test( 't15', 619, [], [], 'fam1', 1 ).
test( 't16', 386, ['m7','m3','m5'], ['r2','r3','r1'], 'fam1', 1 ).
test( 't17', 386, [], [], 'fam1', 1 ).
test( 't18', 658, [], [], 'fam1', 1 ).
test( 't19', 341, [], [], 'fam1', 1 ).
test( 't20', 99, [], ['r3','r1'], 'fam1', 1 ).
test( 't21', 622, [], ['r3'], 'fam1', 1 ).
test( 't22', 332, [], [], 'fam1', 1 ).
test( 't23', 351, [], [], 'fam1', 1 ).
test( 't24', 5, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't25', 567, ['m11','m10','m14'], ['r2','r3','r1'], 'fam1', 1 ).
test( 't26', 345, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't27', 761, [], [], 'fam1', 1 ).
test( 't28', 771, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't29', 554, [], ['r2','r1'], 'fam1', 1 ).
test( 't30', 601, ['m6','m11','m7'], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
