%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 50
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 775, [], [], 'fam1', 1 ).
test( 't2', 569, [], [], 'fam1', 1 ).
test( 't3', 191, [], [], 'fam1', 1 ).
test( 't4', 562, [], [], 'fam1', 1 ).
test( 't5', 264, [], ['r1'], 'fam1', 1 ).
test( 't6', 136, [], [], 'fam1', 1 ).
test( 't7', 575, [], [], 'fam1', 1 ).
test( 't8', 333, ['m28'], [], 'fam1', 1 ).
test( 't9', 757, [], [], 'fam1', 1 ).
test( 't10', 775, [], [], 'fam1', 1 ).
test( 't11', 215, [], ['r3','r4'], 'fam1', 1 ).
test( 't12', 555, [], [], 'fam1', 1 ).
test( 't13', 312, ['m15','m32','m26','m43','m22','m18','m39','m31','m30','m7','m11','m20','m1','m9','m21','m16','m50','m4','m35','m45'], ['r3','r1'], 'fam1', 1 ).
test( 't14', 776, [], ['r4','r2'], 'fam1', 1 ).
test( 't15', 599, [], [], 'fam1', 1 ).
test( 't16', 215, [], [], 'fam1', 1 ).
test( 't17', 622, [], [], 'fam1', 1 ).
test( 't18', 33, [], [], 'fam1', 1 ).
test( 't19', 130, [], [], 'fam1', 1 ).
test( 't20', 137, [], [], 'fam1', 1 ).
test( 't21', 783, [], [], 'fam1', 1 ).
test( 't22', 528, [], ['r3','r1','r5','r2'], 'fam1', 1 ).
test( 't23', 775, ['m2','m20'], ['r2','r4','r3','r5','r1'], 'fam1', 1 ).
test( 't24', 417, ['m34','m50','m27','m42','m32','m16','m36','m33','m47','m6','m49','m25','m24','m10','m2','m21','m8','m7'], ['r1','r5','r3','r2'], 'fam1', 1 ).
test( 't25', 82, [], [], 'fam1', 1 ).
test( 't26', 611, [], [], 'fam1', 1 ).
test( 't27', 11, [], ['r3','r4','r1','r5','r2'], 'fam1', 1 ).
test( 't28', 38, [], ['r5','r1','r3','r4','r2'], 'fam1', 1 ).
test( 't29', 456, [], [], 'fam1', 1 ).
test( 't30', 171, ['m24','m34','m16','m28','m15','m20','m50','m18','m23','m43','m32','m8','m40','m26','m21','m22','m29','m17','m35','m30'], [], 'fam1', 1 ).
test( 't31', 143, [], [], 'fam1', 1 ).
test( 't32', 336, [], [], 'fam1', 1 ).
test( 't33', 199, ['m17','m3','m38','m29','m37','m5','m2','m4','m33'], ['r2'], 'fam1', 1 ).
test( 't34', 405, [], [], 'fam1', 1 ).
test( 't35', 688, [], [], 'fam1', 1 ).
test( 't36', 667, [], [], 'fam1', 1 ).
test( 't37', 610, [], [], 'fam1', 1 ).
test( 't38', 129, ['m27','m31','m14','m38','m22'], [], 'fam1', 1 ).
test( 't39', 265, ['m47','m7','m8','m14','m32','m9','m44','m25','m39','m12','m45','m41','m4','m42','m49','m23'], ['r4','r1','r5','r3'], 'fam1', 1 ).
test( 't40', 705, [], [], 'fam1', 1 ).
test( 't41', 618, ['m35','m3','m41','m49','m46','m45','m5'], [], 'fam1', 1 ).
test( 't42', 561, [], ['r4'], 'fam1', 1 ).
test( 't43', 683, ['m5','m18','m45','m17','m33','m43','m27'], [], 'fam1', 1 ).
test( 't44', 227, [], [], 'fam1', 1 ).
test( 't45', 104, [], [], 'fam1', 1 ).
test( 't46', 787, [], [], 'fam1', 1 ).
test( 't47', 267, [], [], 'fam1', 1 ).
test( 't48', 684, ['m39','m41'], [], 'fam1', 1 ).
test( 't49', 24, [], ['r2','r4','r3','r1','r5'], 'fam1', 1 ).
test( 't50', 547, [], [], 'fam1', 1 ).
test( 't51', 373, [], ['r2'], 'fam1', 1 ).
test( 't52', 103, [], [], 'fam1', 1 ).
test( 't53', 197, [], [], 'fam1', 1 ).
test( 't54', 410, ['m37','m49','m33','m12','m35','m38','m6','m42','m8','m25','m30','m32','m31','m46','m45','m29','m41','m9','m43'], ['r5'], 'fam1', 1 ).
test( 't55', 59, ['m49','m31','m38','m8','m40','m15','m39','m11','m35','m13','m21','m26','m36','m32','m44','m50','m16','m22','m2'], [], 'fam1', 1 ).
test( 't56', 510, [], [], 'fam1', 1 ).
test( 't57', 97, [], [], 'fam1', 1 ).
test( 't58', 307, [], [], 'fam1', 1 ).
test( 't59', 409, [], [], 'fam1', 1 ).
test( 't60', 788, ['m18','m3','m17','m30','m37','m39','m27','m22','m6','m50','m42','m32','m41','m19'], ['r5','r4','r3','r2','r1'], 'fam1', 1 ).
test( 't61', 633, [], [], 'fam1', 1 ).
test( 't62', 160, ['m43','m30','m37','m47','m45','m18','m34','m24','m48','m50','m9','m13'], [], 'fam1', 1 ).
test( 't63', 46, [], [], 'fam1', 1 ).
test( 't64', 520, [], [], 'fam1', 1 ).
test( 't65', 583, [], ['r1','r4'], 'fam1', 1 ).
test( 't66', 748, ['m26'], ['r2'], 'fam1', 1 ).
test( 't67', 42, ['m19','m2','m27','m15','m47','m22','m32','m7','m34','m28','m48','m20','m17','m42','m33','m10','m38'], [], 'fam1', 1 ).
test( 't68', 438, [], [], 'fam1', 1 ).
test( 't69', 461, [], [], 'fam1', 1 ).
test( 't70', 604, [], [], 'fam1', 1 ).
test( 't71', 462, [], [], 'fam1', 1 ).
test( 't72', 155, [], [], 'fam1', 1 ).
test( 't73', 477, [], [], 'fam1', 1 ).
test( 't74', 506, [], ['r3'], 'fam1', 1 ).
test( 't75', 252, [], [], 'fam1', 1 ).
test( 't76', 247, ['m11','m13','m20','m1','m29','m46','m47','m39','m32','m16','m5','m44','m9','m23','m8'], ['r3','r2','r1'], 'fam1', 1 ).
test( 't77', 325, [], [], 'fam1', 1 ).
test( 't78', 481, [], [], 'fam1', 1 ).
test( 't79', 701, [], [], 'fam1', 1 ).
test( 't80', 545, [], ['r3','r1'], 'fam1', 1 ).
test( 't81', 475, [], ['r4','r2','r3'], 'fam1', 1 ).
test( 't82', 799, [], [], 'fam1', 1 ).
test( 't83', 70, [], [], 'fam1', 1 ).
test( 't84', 514, [], ['r4','r2'], 'fam1', 1 ).
test( 't85', 672, [], [], 'fam1', 1 ).
test( 't86', 571, [], ['r3','r4','r1'], 'fam1', 1 ).
test( 't87', 494, [], ['r2','r1','r3','r4'], 'fam1', 1 ).
test( 't88', 55, ['m46','m18'], ['r4','r1'], 'fam1', 1 ).
test( 't89', 461, ['m8','m6','m10','m42','m34','m50','m41','m27','m36','m45','m20','m2'], [], 'fam1', 1 ).
test( 't90', 476, ['m40','m45','m30','m39','m35'], [], 'fam1', 1 ).
test( 't91', 577, [], [], 'fam1', 1 ).
test( 't92', 26, [], [], 'fam1', 1 ).
test( 't93', 540, ['m7','m9','m24','m49','m13','m3','m39','m12','m38','m8','m45','m15','m43','m32','m16','m6','m29','m17'], [], 'fam1', 1 ).
test( 't94', 132, [], [], 'fam1', 1 ).
test( 't95', 348, [], [], 'fam1', 1 ).
test( 't96', 499, [], [], 'fam1', 1 ).
test( 't97', 566, [], [], 'fam1', 1 ).
test( 't98', 272, ['m18','m16','m44','m8','m1','m2','m21','m32','m11','m39','m45','m22','m23','m49','m29'], [], 'fam1', 1 ).
test( 't99', 246, [], [], 'fam1', 1 ).
test( 't100', 727, ['m25','m6','m34','m22','m49','m24','m46','m41','m48','m32','m31','m1','m30','m44','m7'], ['r3','r2','r1','r4'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').
embedded_board( 'm21').
embedded_board( 'm22').
embedded_board( 'm23').
embedded_board( 'm24').
embedded_board( 'm25').
embedded_board( 'm26').
embedded_board( 'm27').
embedded_board( 'm28').
embedded_board( 'm29').
embedded_board( 'm30').
embedded_board( 'm31').
embedded_board( 'm32').
embedded_board( 'm33').
embedded_board( 'm34').
embedded_board( 'm35').
embedded_board( 'm36').
embedded_board( 'm37').
embedded_board( 'm38').
embedded_board( 'm39').
embedded_board( 'm40').
embedded_board( 'm41').
embedded_board( 'm42').
embedded_board( 'm43').
embedded_board( 'm44').
embedded_board( 'm45').
embedded_board( 'm46').
embedded_board( 'm47').
embedded_board( 'm48').
embedded_board( 'm49').
embedded_board( 'm50').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
