%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 50
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 603, [], [], 'fam1', 1 ).
test( 't2', 319, [], ['r5','r9','r1','r8','r4','r3','r2','r7','r10'], 'fam1', 1 ).
test( 't3', 752, [], [], 'fam1', 1 ).
test( 't4', 42, ['m32','m8','m42','m26','m5','m6','m4','m39','m24','m16','m2','m27','m33','m9','m25','m19'], [], 'fam1', 1 ).
test( 't5', 40, [], ['r10','r3','r1','r2','r4','r7','r5','r9','r6','r8'], 'fam1', 1 ).
test( 't6', 741, ['m34','m3','m24','m49','m42','m20','m47','m2','m10','m23','m11','m38'], ['r3'], 'fam1', 1 ).
test( 't7', 425, ['m42','m39','m24','m25','m4','m49','m30','m12','m26','m33','m2','m3','m41','m43','m5','m44','m48','m8','m45','m9'], [], 'fam1', 1 ).
test( 't8', 751, [], [], 'fam1', 1 ).
test( 't9', 279, ['m41','m45','m34','m36','m12','m15'], ['r4','r2','r10','r1','r9','r3','r8','r7','r6','r5'], 'fam1', 1 ).
test( 't10', 412, [], [], 'fam1', 1 ).
test( 't11', 735, [], [], 'fam1', 1 ).
test( 't12', 351, [], ['r1','r7','r4','r6'], 'fam1', 1 ).
test( 't13', 485, [], [], 'fam1', 1 ).
test( 't14', 319, [], [], 'fam1', 1 ).
test( 't15', 685, [], [], 'fam1', 1 ).
test( 't16', 73, [], [], 'fam1', 1 ).
test( 't17', 370, [], [], 'fam1', 1 ).
test( 't18', 148, [], ['r10','r9','r7','r1','r4','r3','r6','r8'], 'fam1', 1 ).
test( 't19', 50, ['m31','m13','m1','m50','m23','m5','m37'], [], 'fam1', 1 ).
test( 't20', 38, [], [], 'fam1', 1 ).
test( 't21', 117, ['m36','m16','m12','m26','m23','m29','m38','m6','m3','m30','m39'], [], 'fam1', 1 ).
test( 't22', 67, [], ['r1','r8','r4','r7','r10','r3','r2','r5','r6'], 'fam1', 1 ).
test( 't23', 252, [], [], 'fam1', 1 ).
test( 't24', 410, [], ['r8','r6','r5','r7','r2','r10','r9','r4','r3','r1'], 'fam1', 1 ).
test( 't25', 671, [], [], 'fam1', 1 ).
test( 't26', 312, ['m4','m22','m5','m10','m15','m31','m23'], ['r3','r2','r8','r6','r10','r7'], 'fam1', 1 ).
test( 't27', 765, [], [], 'fam1', 1 ).
test( 't28', 29, [], [], 'fam1', 1 ).
test( 't29', 18, [], [], 'fam1', 1 ).
test( 't30', 284, [], [], 'fam1', 1 ).
test( 't31', 193, [], [], 'fam1', 1 ).
test( 't32', 701, [], [], 'fam1', 1 ).
test( 't33', 703, [], [], 'fam1', 1 ).
test( 't34', 439, [], [], 'fam1', 1 ).
test( 't35', 536, [], [], 'fam1', 1 ).
test( 't36', 92, [], [], 'fam1', 1 ).
test( 't37', 648, ['m15','m19','m8','m23','m20','m35','m14','m29','m24','m5','m13'], [], 'fam1', 1 ).
test( 't38', 50, ['m5','m31','m12','m33','m48','m17','m14','m6','m21','m44','m27','m9','m1','m40','m4','m28','m49','m19','m7'], ['r9','r8','r10','r2','r4','r7','r1','r3','r5','r6'], 'fam1', 1 ).
test( 't39', 182, [], [], 'fam1', 1 ).
test( 't40', 118, [], [], 'fam1', 1 ).
test( 't41', 781, [], ['r2','r1','r7','r3','r8','r10','r9','r5'], 'fam1', 1 ).
test( 't42', 572, [], ['r6','r7','r1','r9','r8','r5','r10','r4'], 'fam1', 1 ).
test( 't43', 747, [], ['r7','r1','r2','r6','r8','r4','r3','r5','r10','r9'], 'fam1', 1 ).
test( 't44', 397, [], [], 'fam1', 1 ).
test( 't45', 688, [], ['r7','r10'], 'fam1', 1 ).
test( 't46', 432, [], [], 'fam1', 1 ).
test( 't47', 747, [], [], 'fam1', 1 ).
test( 't48', 245, [], ['r9','r10','r4','r5','r6','r3','r1'], 'fam1', 1 ).
test( 't49', 300, ['m8','m29','m11','m43','m39','m42','m33','m13','m16','m15','m10','m14'], [], 'fam1', 1 ).
test( 't50', 647, [], [], 'fam1', 1 ).
test( 't51', 372, [], [], 'fam1', 1 ).
test( 't52', 765, [], ['r10','r5','r6','r8','r3','r1','r9','r7'], 'fam1', 1 ).
test( 't53', 291, [], [], 'fam1', 1 ).
test( 't54', 742, [], ['r3'], 'fam1', 1 ).
test( 't55', 391, [], [], 'fam1', 1 ).
test( 't56', 635, [], [], 'fam1', 1 ).
test( 't57', 215, [], ['r6','r4','r10','r1','r3'], 'fam1', 1 ).
test( 't58', 294, [], ['r2','r10','r9','r7'], 'fam1', 1 ).
test( 't59', 441, ['m3','m19','m29','m49','m14','m43','m37','m46','m5','m8','m9','m21'], [], 'fam1', 1 ).
test( 't60', 110, [], ['r4','r3','r1','r7','r9','r10'], 'fam1', 1 ).
test( 't61', 649, [], [], 'fam1', 1 ).
test( 't62', 136, ['m24','m22','m37','m18','m11','m16','m43','m38','m30','m17','m10','m36','m47','m39','m32','m45','m20','m3'], ['r2','r8','r6','r3','r10'], 'fam1', 1 ).
test( 't63', 676, [], [], 'fam1', 1 ).
test( 't64', 551, [], [], 'fam1', 1 ).
test( 't65', 741, ['m23','m45','m48','m21','m17','m6','m19','m32','m33','m27','m12','m34','m11','m14','m18','m38','m25'], [], 'fam1', 1 ).
test( 't66', 282, ['m11','m23','m6','m9','m20','m49','m5','m34','m38'], ['r2','r6'], 'fam1', 1 ).
test( 't67', 531, [], [], 'fam1', 1 ).
test( 't68', 681, [], [], 'fam1', 1 ).
test( 't69', 745, [], ['r3','r6','r9','r10','r4'], 'fam1', 1 ).
test( 't70', 211, [], [], 'fam1', 1 ).
test( 't71', 665, [], [], 'fam1', 1 ).
test( 't72', 296, [], [], 'fam1', 1 ).
test( 't73', 737, [], [], 'fam1', 1 ).
test( 't74', 275, [], [], 'fam1', 1 ).
test( 't75', 575, ['m15','m14','m19','m50','m8','m27','m12','m22','m29','m9','m28'], [], 'fam1', 1 ).
test( 't76', 685, [], ['r7','r9','r5','r1','r2','r4'], 'fam1', 1 ).
test( 't77', 502, [], [], 'fam1', 1 ).
test( 't78', 620, [], ['r3'], 'fam1', 1 ).
test( 't79', 242, ['m1','m19','m12','m50','m34','m10','m5','m4','m21','m8','m48','m24','m42','m27','m2','m44'], [], 'fam1', 1 ).
test( 't80', 515, [], [], 'fam1', 1 ).
test( 't81', 680, [], [], 'fam1', 1 ).
test( 't82', 366, ['m24','m18','m19','m21','m32','m48','m40'], [], 'fam1', 1 ).
test( 't83', 127, [], [], 'fam1', 1 ).
test( 't84', 553, ['m24','m14','m34','m40','m33','m37'], [], 'fam1', 1 ).
test( 't85', 557, [], ['r2','r10','r8','r3','r4','r5'], 'fam1', 1 ).
test( 't86', 21, [], [], 'fam1', 1 ).
test( 't87', 237, [], [], 'fam1', 1 ).
test( 't88', 267, ['m24','m3','m41','m12','m50','m46','m38','m39','m10','m48','m25','m32','m35'], [], 'fam1', 1 ).
test( 't89', 236, ['m43','m14','m41'], [], 'fam1', 1 ).
test( 't90', 192, [], [], 'fam1', 1 ).
test( 't91', 696, [], ['r5','r10','r2','r8','r4','r1','r9','r6','r7'], 'fam1', 1 ).
test( 't92', 42, [], ['r1'], 'fam1', 1 ).
test( 't93', 613, [], [], 'fam1', 1 ).
test( 't94', 570, [], [], 'fam1', 1 ).
test( 't95', 230, [], [], 'fam1', 1 ).
test( 't96', 476, [], [], 'fam1', 1 ).
test( 't97', 554, ['m27','m6','m35','m48'], ['r6','r3','r5','r9','r4','r8','r2','r10'], 'fam1', 1 ).
test( 't98', 785, [], [], 'fam1', 1 ).
test( 't99', 15, [], [], 'fam1', 1 ).
test( 't100', 645, [], ['r9','r2','r1','r3','r4','r10','r7','r5','r8'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').
embedded_board( 'm21').
embedded_board( 'm22').
embedded_board( 'm23').
embedded_board( 'm24').
embedded_board( 'm25').
embedded_board( 'm26').
embedded_board( 'm27').
embedded_board( 'm28').
embedded_board( 'm29').
embedded_board( 'm30').
embedded_board( 'm31').
embedded_board( 'm32').
embedded_board( 'm33').
embedded_board( 'm34').
embedded_board( 'm35').
embedded_board( 'm36').
embedded_board( 'm37').
embedded_board( 'm38').
embedded_board( 'm39').
embedded_board( 'm40').
embedded_board( 'm41').
embedded_board( 'm42').
embedded_board( 'm43').
embedded_board( 'm44').
embedded_board( 'm45').
embedded_board( 'm46').
embedded_board( 'm47').
embedded_board( 'm48').
embedded_board( 'm49').
embedded_board( 'm50').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
