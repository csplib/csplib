%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 20
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 31, [], [], 'fam1', 1 ).
test( 't2', 83, [], [], 'fam1', 1 ).
test( 't3', 221, ['m19','m4','m1','m18','m2','m6','m8','m16'], ['r1','r6','r5','r9','r4','r3','r10','r7','r8','r2'], 'fam1', 1 ).
test( 't4', 658, [], [], 'fam1', 1 ).
test( 't5', 490, [], [], 'fam1', 1 ).
test( 't6', 650, [], [], 'fam1', 1 ).
test( 't7', 335, [], [], 'fam1', 1 ).
test( 't8', 53, [], [], 'fam1', 1 ).
test( 't9', 304, [], [], 'fam1', 1 ).
test( 't10', 379, [], ['r4'], 'fam1', 1 ).
test( 't11', 452, [], [], 'fam1', 1 ).
test( 't12', 552, [], [], 'fam1', 1 ).
test( 't13', 619, [], ['r5','r9','r1'], 'fam1', 1 ).
test( 't14', 568, [], [], 'fam1', 1 ).
test( 't15', 444, ['m4','m1','m13','m18','m9','m7','m12','m2'], [], 'fam1', 1 ).
test( 't16', 393, [], ['r5','r10'], 'fam1', 1 ).
test( 't17', 514, [], [], 'fam1', 1 ).
test( 't18', 559, [], [], 'fam1', 1 ).
test( 't19', 710, [], [], 'fam1', 1 ).
test( 't20', 555, [], ['r2','r8','r3','r9','r4','r7','r10','r6'], 'fam1', 1 ).
test( 't21', 225, [], [], 'fam1', 1 ).
test( 't22', 352, [], [], 'fam1', 1 ).
test( 't23', 790, [], ['r1','r6','r7','r3','r4','r5','r10','r2'], 'fam1', 1 ).
test( 't24', 796, [], [], 'fam1', 1 ).
test( 't25', 288, ['m16','m6','m15','m5','m14','m3'], [], 'fam1', 1 ).
test( 't26', 311, ['m13','m2','m14','m5','m18','m16','m4','m1'], [], 'fam1', 1 ).
test( 't27', 503, [], [], 'fam1', 1 ).
test( 't28', 460, [], [], 'fam1', 1 ).
test( 't29', 377, [], [], 'fam1', 1 ).
test( 't30', 563, [], ['r1','r4','r8','r2','r6','r5','r3','r10','r7'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
