%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 20
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 128, [], [], 'fam1', 1 ).
test( 't2', 520, [], [], 'fam1', 1 ).
test( 't3', 415, [], [], 'fam1', 1 ).
test( 't4', 37, ['m1','m17','m18','m4','m9'], ['r2','r1','r8','r9','r10','r6','r4','r5','r3','r7'], 'fam1', 1 ).
test( 't5', 171, [], [], 'fam1', 1 ).
test( 't6', 511, [], [], 'fam1', 1 ).
test( 't7', 691, [], [], 'fam1', 1 ).
test( 't8', 297, [], [], 'fam1', 1 ).
test( 't9', 673, [], [], 'fam1', 1 ).
test( 't10', 115, [], [], 'fam1', 1 ).
test( 't11', 10, [], [], 'fam1', 1 ).
test( 't12', 3, [], [], 'fam1', 1 ).
test( 't13', 382, [], [], 'fam1', 1 ).
test( 't14', 31, ['m20','m13','m19','m2','m12','m17','m8'], ['r3','r2','r9','r4','r8','r7','r5','r1','r6','r10'], 'fam1', 1 ).
test( 't15', 172, [], [], 'fam1', 1 ).
test( 't16', 77, [], [], 'fam1', 1 ).
test( 't17', 280, [], ['r2','r7','r10','r8','r4','r6','r9','r1'], 'fam1', 1 ).
test( 't18', 259, ['m19','m8','m7','m12','m15','m9','m20','m1'], [], 'fam1', 1 ).
test( 't19', 42, [], ['r1','r10'], 'fam1', 1 ).
test( 't20', 505, [], [], 'fam1', 1 ).
test( 't21', 49, [], ['r2','r1','r5'], 'fam1', 1 ).
test( 't22', 798, [], ['r7','r2'], 'fam1', 1 ).
test( 't23', 345, [], [], 'fam1', 1 ).
test( 't24', 777, ['m13','m3','m8','m18','m2'], [], 'fam1', 1 ).
test( 't25', 331, [], [], 'fam1', 1 ).
test( 't26', 370, [], ['r6','r3'], 'fam1', 1 ).
test( 't27', 738, [], ['r10','r9','r8','r3','r2','r7'], 'fam1', 1 ).
test( 't28', 28, [], [], 'fam1', 1 ).
test( 't29', 605, [], [], 'fam1', 1 ).
test( 't30', 263, [], ['r7','r1','r4','r8','r10','r6','r9','r3','r2','r5'], 'fam1', 1 ).
test( 't31', 178, [], ['r2','r9','r10','r6','r7','r5','r4'], 'fam1', 1 ).
test( 't32', 693, [], [], 'fam1', 1 ).
test( 't33', 659, [], ['r3','r7','r10'], 'fam1', 1 ).
test( 't34', 612, [], [], 'fam1', 1 ).
test( 't35', 612, [], [], 'fam1', 1 ).
test( 't36', 280, [], [], 'fam1', 1 ).
test( 't37', 509, [], [], 'fam1', 1 ).
test( 't38', 134, [], [], 'fam1', 1 ).
test( 't39', 426, [], [], 'fam1', 1 ).
test( 't40', 578, [], [], 'fam1', 1 ).
test( 't41', 294, [], [], 'fam1', 1 ).
test( 't42', 89, [], [], 'fam1', 1 ).
test( 't43', 490, [], [], 'fam1', 1 ).
test( 't44', 657, [], [], 'fam1', 1 ).
test( 't45', 739, ['m20','m5','m14','m15'], ['r4','r5','r8','r1','r6','r7','r3','r2','r9'], 'fam1', 1 ).
test( 't46', 75, [], ['r7','r2','r1','r4','r5'], 'fam1', 1 ).
test( 't47', 99, [], [], 'fam1', 1 ).
test( 't48', 210, [], ['r9','r2','r1','r10','r3','r6','r8','r7','r5'], 'fam1', 1 ).
test( 't49', 512, [], ['r3','r9','r6','r10','r8','r4'], 'fam1', 1 ).
test( 't50', 762, [], [], 'fam1', 1 ).
test( 't51', 83, [], [], 'fam1', 1 ).
test( 't52', 54, [], [], 'fam1', 1 ).
test( 't53', 283, [], [], 'fam1', 1 ).
test( 't54', 169, [], [], 'fam1', 1 ).
test( 't55', 441, ['m15'], [], 'fam1', 1 ).
test( 't56', 449, [], [], 'fam1', 1 ).
test( 't57', 674, [], [], 'fam1', 1 ).
test( 't58', 602, ['m18','m15','m8','m19','m9'], [], 'fam1', 1 ).
test( 't59', 718, [], ['r1','r10','r4','r3','r7','r2','r6','r9','r8','r5'], 'fam1', 1 ).
test( 't60', 593, [], ['r6','r9','r2','r7','r10','r1','r4','r3'], 'fam1', 1 ).
test( 't61', 588, ['m7','m15','m12','m13','m1','m18'], [], 'fam1', 1 ).
test( 't62', 750, [], ['r8','r6','r5'], 'fam1', 1 ).
test( 't63', 556, [], [], 'fam1', 1 ).
test( 't64', 483, [], [], 'fam1', 1 ).
test( 't65', 250, [], [], 'fam1', 1 ).
test( 't66', 54, [], [], 'fam1', 1 ).
test( 't67', 458, [], ['r3','r7'], 'fam1', 1 ).
test( 't68', 353, ['m18','m7','m11','m17','m6','m12','m5','m14'], ['r3','r8','r6','r4','r7','r1','r10','r9','r2','r5'], 'fam1', 1 ).
test( 't69', 493, [], [], 'fam1', 1 ).
test( 't70', 257, [], [], 'fam1', 1 ).
test( 't71', 83, ['m12','m6','m10','m17'], ['r10'], 'fam1', 1 ).
test( 't72', 520, [], [], 'fam1', 1 ).
test( 't73', 547, [], [], 'fam1', 1 ).
test( 't74', 219, [], ['r2','r9','r3','r4'], 'fam1', 1 ).
test( 't75', 780, [], ['r6','r4'], 'fam1', 1 ).
test( 't76', 30, ['m17','m12','m5','m19','m8','m10','m20'], [], 'fam1', 1 ).
test( 't77', 610, [], ['r1','r4','r2','r3'], 'fam1', 1 ).
test( 't78', 66, ['m2','m3','m19','m9','m6','m18'], [], 'fam1', 1 ).
test( 't79', 537, [], ['r1','r6'], 'fam1', 1 ).
test( 't80', 336, ['m9','m18'], [], 'fam1', 1 ).
test( 't81', 378, [], ['r3','r9','r5','r4','r6','r2','r10','r8','r1','r7'], 'fam1', 1 ).
test( 't82', 546, [], [], 'fam1', 1 ).
test( 't83', 776, [], [], 'fam1', 1 ).
test( 't84', 70, [], [], 'fam1', 1 ).
test( 't85', 754, ['m20','m19','m16','m1','m8','m13'], ['r9','r1','r4','r3','r5','r10','r2','r6','r8','r7'], 'fam1', 1 ).
test( 't86', 509, ['m1'], [], 'fam1', 1 ).
test( 't87', 385, [], ['r8','r7','r5','r6'], 'fam1', 1 ).
test( 't88', 336, ['m8','m9','m14','m4','m12','m1','m15'], [], 'fam1', 1 ).
test( 't89', 771, [], ['r2','r9','r3','r5'], 'fam1', 1 ).
test( 't90', 595, [], [], 'fam1', 1 ).
test( 't91', 560, [], [], 'fam1', 1 ).
test( 't92', 255, [], [], 'fam1', 1 ).
test( 't93', 247, [], [], 'fam1', 1 ).
test( 't94', 524, ['m6','m16','m10','m12','m11','m3','m7'], [], 'fam1', 1 ).
test( 't95', 573, [], [], 'fam1', 1 ).
test( 't96', 639, [], ['r8','r7','r3','r5','r1','r6','r2','r10'], 'fam1', 1 ).
test( 't97', 407, [], ['r5','r8','r10','r9','r4'], 'fam1', 1 ).
test( 't98', 29, [], ['r5','r2','r9','r10','r1'], 'fam1', 1 ).
test( 't99', 222, [], ['r10','r5','r9','r1'], 'fam1', 1 ).
test( 't100', 431, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
