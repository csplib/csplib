%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 587, [], ['r3','r1'], 'fam1', 1 ).
test( 't2', 53, [], [], 'fam1', 1 ).
test( 't3', 465, [], [], 'fam1', 1 ).
test( 't4', 190, ['m9','m7','m4','m3'], [], 'fam1', 1 ).
test( 't5', 109, [], [], 'fam1', 1 ).
test( 't6', 794, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't7', 618, [], [], 'fam1', 1 ).
test( 't8', 475, [], [], 'fam1', 1 ).
test( 't9', 88, [], ['r1'], 'fam1', 1 ).
test( 't10', 541, [], ['r2'], 'fam1', 1 ).
test( 't11', 7, [], [], 'fam1', 1 ).
test( 't12', 154, [], [], 'fam1', 1 ).
test( 't13', 30, [], [], 'fam1', 1 ).
test( 't14', 443, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't15', 58, [], [], 'fam1', 1 ).
test( 't16', 69, [], [], 'fam1', 1 ).
test( 't17', 743, [], [], 'fam1', 1 ).
test( 't18', 685, [], ['r3'], 'fam1', 1 ).
test( 't19', 568, [], [], 'fam1', 1 ).
test( 't20', 423, ['m4','m5','m3'], [], 'fam1', 1 ).
test( 't21', 795, ['m9','m6','m2'], [], 'fam1', 1 ).
test( 't22', 409, [], [], 'fam1', 1 ).
test( 't23', 315, ['m8','m7','m2','m4'], [], 'fam1', 1 ).
test( 't24', 57, ['m6','m1','m3'], [], 'fam1', 1 ).
test( 't25', 740, [], [], 'fam1', 1 ).
test( 't26', 661, ['m10','m1'], [], 'fam1', 1 ).
test( 't27', 660, ['m5','m1','m4'], [], 'fam1', 1 ).
test( 't28', 282, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't29', 256, [], [], 'fam1', 1 ).
test( 't30', 787, ['m9'], ['r3','r2','r1'], 'fam1', 1 ).
test( 't31', 415, [], [], 'fam1', 1 ).
test( 't32', 486, [], [], 'fam1', 1 ).
test( 't33', 495, [], ['r1','r2'], 'fam1', 1 ).
test( 't34', 110, [], [], 'fam1', 1 ).
test( 't35', 801, [], [], 'fam1', 1 ).
test( 't36', 700, [], ['r3'], 'fam1', 1 ).
test( 't37', 605, [], [], 'fam1', 1 ).
test( 't38', 220, [], [], 'fam1', 1 ).
test( 't39', 727, [], ['r3','r1'], 'fam1', 1 ).
test( 't40', 480, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
