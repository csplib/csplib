%% ****  Testsuite  ****
% Number of tests                  : 20
% Number of machines               : 10
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 334, [], [], 'fam1', 1 ).
test( 't2', 259, [], [], 'fam1', 1 ).
test( 't3', 651, [], [], 'fam1', 1 ).
test( 't4', 148, ['m7','m5','m1','m3'], ['r8','r4','r10','r9','r5'], 'fam1', 1 ).
test( 't5', 636, ['m8'], [], 'fam1', 1 ).
test( 't6', 131, [], [], 'fam1', 1 ).
test( 't7', 671, [], [], 'fam1', 1 ).
test( 't8', 216, [], [], 'fam1', 1 ).
test( 't9', 377, [], [], 'fam1', 1 ).
test( 't10', 366, [], [], 'fam1', 1 ).
test( 't11', 316, [], [], 'fam1', 1 ).
test( 't12', 247, [], [], 'fam1', 1 ).
test( 't13', 247, [], [], 'fam1', 1 ).
test( 't14', 551, [], [], 'fam1', 1 ).
test( 't15', 527, [], ['r4','r3','r6','r2','r10','r9','r5','r8'], 'fam1', 1 ).
test( 't16', 512, [], [], 'fam1', 1 ).
test( 't17', 317, [], [], 'fam1', 1 ).
test( 't18', 771, [], [], 'fam1', 1 ).
test( 't19', 403, [], [], 'fam1', 1 ).
test( 't20', 249, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
