%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 310, [], [], 'fam1', 1 ).
test( 't2', 697, [], ['r1','r5','r4'], 'fam1', 1 ).
test( 't3', 186, [], [], 'fam1', 1 ).
test( 't4', 581, [], [], 'fam1', 1 ).
test( 't5', 771, ['m1','m5','m8'], ['r2'], 'fam1', 1 ).
test( 't6', 425, [], [], 'fam1', 1 ).
test( 't7', 751, [], [], 'fam1', 1 ).
test( 't8', 656, [], ['r1','r3','r5'], 'fam1', 1 ).
test( 't9', 748, [], [], 'fam1', 1 ).
test( 't10', 159, ['m6'], [], 'fam1', 1 ).
test( 't11', 52, ['m4','m9','m10','m7'], [], 'fam1', 1 ).
test( 't12', 775, [], ['r2','r3','r5','r1','r4'], 'fam1', 1 ).
test( 't13', 72, ['m2','m1','m9','m7'], ['r2','r3','r5','r1'], 'fam1', 1 ).
test( 't14', 628, [], [], 'fam1', 1 ).
test( 't15', 249, [], [], 'fam1', 1 ).
test( 't16', 286, [], ['r2','r4','r5'], 'fam1', 1 ).
test( 't17', 173, [], [], 'fam1', 1 ).
test( 't18', 596, [], [], 'fam1', 1 ).
test( 't19', 462, [], ['r1','r3','r5','r4','r2'], 'fam1', 1 ).
test( 't20', 116, [], ['r3','r1','r5','r2','r4'], 'fam1', 1 ).
test( 't21', 236, [], [], 'fam1', 1 ).
test( 't22', 751, ['m6','m4'], [], 'fam1', 1 ).
test( 't23', 454, [], [], 'fam1', 1 ).
test( 't24', 348, [], [], 'fam1', 1 ).
test( 't25', 556, [], [], 'fam1', 1 ).
test( 't26', 67, ['m4','m6'], [], 'fam1', 1 ).
test( 't27', 325, ['m3','m7'], [], 'fam1', 1 ).
test( 't28', 20, [], ['r2'], 'fam1', 1 ).
test( 't29', 635, [], ['r1','r3','r4','r5','r2'], 'fam1', 1 ).
test( 't30', 553, [], [], 'fam1', 1 ).
test( 't31', 607, [], [], 'fam1', 1 ).
test( 't32', 755, [], [], 'fam1', 1 ).
test( 't33', 306, [], ['r2','r3','r5','r4'], 'fam1', 1 ).
test( 't34', 787, [], ['r5'], 'fam1', 1 ).
test( 't35', 424, ['m4','m9','m6','m3'], ['r2','r5','r3','r4','r1'], 'fam1', 1 ).
test( 't36', 796, [], [], 'fam1', 1 ).
test( 't37', 636, [], ['r2'], 'fam1', 1 ).
test( 't38', 473, [], [], 'fam1', 1 ).
test( 't39', 116, [], [], 'fam1', 1 ).
test( 't40', 669, [], ['r1','r3','r4','r2'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
