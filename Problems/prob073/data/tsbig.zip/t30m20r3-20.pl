%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 20
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 233, ['m10'], [], 'fam1', 1 ).
test( 't2', 99, ['m9','m7','m1','m13','m2','m20','m11','m4'], ['r3','r2','r1'], 'fam1', 1 ).
test( 't3', 481, ['m11'], [], 'fam1', 1 ).
test( 't4', 185, [], [], 'fam1', 1 ).
test( 't5', 168, ['m11','m15'], [], 'fam1', 1 ).
test( 't6', 105, [], [], 'fam1', 1 ).
test( 't7', 376, [], [], 'fam1', 1 ).
test( 't8', 730, [], [], 'fam1', 1 ).
test( 't9', 695, [], ['r2','r3'], 'fam1', 1 ).
test( 't10', 103, [], ['r2','r3'], 'fam1', 1 ).
test( 't11', 567, ['m17','m5','m7','m19','m4','m15'], ['r2','r1','r3'], 'fam1', 1 ).
test( 't12', 741, [], [], 'fam1', 1 ).
test( 't13', 330, [], [], 'fam1', 1 ).
test( 't14', 290, ['m13','m19','m11','m9','m3'], [], 'fam1', 1 ).
test( 't15', 275, ['m19','m11','m18','m9','m7','m15','m10','m17'], ['r3','r2'], 'fam1', 1 ).
test( 't16', 198, [], [], 'fam1', 1 ).
test( 't17', 197, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't18', 609, [], [], 'fam1', 1 ).
test( 't19', 603, [], [], 'fam1', 1 ).
test( 't20', 532, [], [], 'fam1', 1 ).
test( 't21', 105, [], [], 'fam1', 1 ).
test( 't22', 8, [], [], 'fam1', 1 ).
test( 't23', 358, [], [], 'fam1', 1 ).
test( 't24', 143, [], ['r3','r1'], 'fam1', 1 ).
test( 't25', 184, ['m13','m6','m12','m20'], ['r3'], 'fam1', 1 ).
test( 't26', 447, [], [], 'fam1', 1 ).
test( 't27', 46, [], [], 'fam1', 1 ).
test( 't28', 279, ['m11','m9','m16','m14','m18','m1','m12','m17'], [], 'fam1', 1 ).
test( 't29', 666, [], ['r2','r1'], 'fam1', 1 ).
test( 't30', 770, ['m20','m8','m6','m15','m11'], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
