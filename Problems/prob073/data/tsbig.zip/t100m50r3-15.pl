%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 50
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 329, [], ['r1'], 'fam1', 1 ).
test( 't2', 250, ['m4','m9','m36','m31','m13','m37','m38','m46','m33','m45','m15','m2','m14','m39','m48','m16','m49','m7'], ['r3','r1','r2'], 'fam1', 1 ).
test( 't3', 246, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't4', 497, [], ['r1'], 'fam1', 1 ).
test( 't5', 252, [], [], 'fam1', 1 ).
test( 't6', 788, [], [], 'fam1', 1 ).
test( 't7', 689, ['m35'], [], 'fam1', 1 ).
test( 't8', 123, ['m26','m38','m28','m12','m17','m1','m43','m5'], [], 'fam1', 1 ).
test( 't9', 34, [], [], 'fam1', 1 ).
test( 't10', 235, [], ['r1','r2'], 'fam1', 1 ).
test( 't11', 255, [], [], 'fam1', 1 ).
test( 't12', 262, [], [], 'fam1', 1 ).
test( 't13', 6, [], ['r3'], 'fam1', 1 ).
test( 't14', 176, ['m22','m19','m49'], [], 'fam1', 1 ).
test( 't15', 19, [], [], 'fam1', 1 ).
test( 't16', 127, [], ['r3','r1'], 'fam1', 1 ).
test( 't17', 552, [], [], 'fam1', 1 ).
test( 't18', 106, [], [], 'fam1', 1 ).
test( 't19', 184, [], [], 'fam1', 1 ).
test( 't20', 109, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't21', 138, [], [], 'fam1', 1 ).
test( 't22', 539, [], [], 'fam1', 1 ).
test( 't23', 664, [], [], 'fam1', 1 ).
test( 't24', 70, [], ['r2','r3'], 'fam1', 1 ).
test( 't25', 355, [], [], 'fam1', 1 ).
test( 't26', 174, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't27', 118, [], [], 'fam1', 1 ).
test( 't28', 528, [], [], 'fam1', 1 ).
test( 't29', 623, [], ['r2','r1'], 'fam1', 1 ).
test( 't30', 444, [], [], 'fam1', 1 ).
test( 't31', 251, [], ['r1'], 'fam1', 1 ).
test( 't32', 472, ['m14','m44','m8','m21','m40','m34','m38','m46','m35'], ['r3','r1','r2'], 'fam1', 1 ).
test( 't33', 319, [], ['r3','r2'], 'fam1', 1 ).
test( 't34', 376, [], [], 'fam1', 1 ).
test( 't35', 686, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't36', 713, ['m47','m9'], [], 'fam1', 1 ).
test( 't37', 306, [], [], 'fam1', 1 ).
test( 't38', 274, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't39', 280, [], [], 'fam1', 1 ).
test( 't40', 655, [], [], 'fam1', 1 ).
test( 't41', 112, ['m36','m2','m33','m20','m49'], [], 'fam1', 1 ).
test( 't42', 538, [], [], 'fam1', 1 ).
test( 't43', 501, [], [], 'fam1', 1 ).
test( 't44', 161, [], [], 'fam1', 1 ).
test( 't45', 6, [], [], 'fam1', 1 ).
test( 't46', 68, [], [], 'fam1', 1 ).
test( 't47', 705, [], [], 'fam1', 1 ).
test( 't48', 44, ['m27','m39','m30'], [], 'fam1', 1 ).
test( 't49', 446, [], ['r1','r2'], 'fam1', 1 ).
test( 't50', 688, [], [], 'fam1', 1 ).
test( 't51', 444, [], ['r2','r3'], 'fam1', 1 ).
test( 't52', 352, [], [], 'fam1', 1 ).
test( 't53', 705, ['m49','m7','m1','m3','m20','m24','m29','m17','m16','m37','m13','m47'], [], 'fam1', 1 ).
test( 't54', 72, ['m50','m27','m2'], [], 'fam1', 1 ).
test( 't55', 207, [], [], 'fam1', 1 ).
test( 't56', 559, [], ['r1'], 'fam1', 1 ).
test( 't57', 201, ['m6','m5','m40','m11','m37','m30','m21','m35','m38','m49','m2','m43','m24','m28'], ['r2','r1','r3'], 'fam1', 1 ).
test( 't58', 365, [], [], 'fam1', 1 ).
test( 't59', 162, [], [], 'fam1', 1 ).
test( 't60', 95, [], [], 'fam1', 1 ).
test( 't61', 151, [], [], 'fam1', 1 ).
test( 't62', 231, [], ['r1'], 'fam1', 1 ).
test( 't63', 321, ['m5'], ['r3','r1','r2'], 'fam1', 1 ).
test( 't64', 241, [], ['r3'], 'fam1', 1 ).
test( 't65', 119, ['m19','m47','m46','m36','m8','m13','m44','m45','m12','m35','m38','m21','m37','m22','m2','m41','m29','m42','m5','m40'], [], 'fam1', 1 ).
test( 't66', 497, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't67', 520, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't68', 470, [], [], 'fam1', 1 ).
test( 't69', 81, [], [], 'fam1', 1 ).
test( 't70', 70, [], [], 'fam1', 1 ).
test( 't71', 730, [], ['r3','r2'], 'fam1', 1 ).
test( 't72', 591, ['m4','m7','m38','m12','m26','m16','m47','m3','m42','m20'], [], 'fam1', 1 ).
test( 't73', 302, ['m11','m13','m31','m18','m28','m27','m32','m38','m5','m15','m44','m29','m48'], [], 'fam1', 1 ).
test( 't74', 773, [], [], 'fam1', 1 ).
test( 't75', 751, [], [], 'fam1', 1 ).
test( 't76', 184, [], [], 'fam1', 1 ).
test( 't77', 635, ['m41','m15','m43','m30','m25','m7','m45','m20','m40','m42','m14','m49','m21','m27'], [], 'fam1', 1 ).
test( 't78', 8, [], [], 'fam1', 1 ).
test( 't79', 458, [], [], 'fam1', 1 ).
test( 't80', 711, [], [], 'fam1', 1 ).
test( 't81', 799, ['m48','m10','m25','m17','m16','m9','m39','m30','m45','m42','m5','m40','m27','m4','m6'], ['r2'], 'fam1', 1 ).
test( 't82', 716, [], [], 'fam1', 1 ).
test( 't83', 256, [], [], 'fam1', 1 ).
test( 't84', 548, [], ['r3','r2'], 'fam1', 1 ).
test( 't85', 542, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't86', 224, [], [], 'fam1', 1 ).
test( 't87', 403, [], ['r1','r3'], 'fam1', 1 ).
test( 't88', 210, ['m49','m42','m40','m46','m30','m12','m27','m24','m28','m48','m33','m43','m18','m39','m6','m25','m45','m50','m15'], [], 'fam1', 1 ).
test( 't89', 105, [], [], 'fam1', 1 ).
test( 't90', 292, [], [], 'fam1', 1 ).
test( 't91', 68, [], [], 'fam1', 1 ).
test( 't92', 489, [], [], 'fam1', 1 ).
test( 't93', 384, [], [], 'fam1', 1 ).
test( 't94', 377, [], [], 'fam1', 1 ).
test( 't95', 59, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't96', 531, [], ['r3'], 'fam1', 1 ).
test( 't97', 440, [], ['r3'], 'fam1', 1 ).
test( 't98', 612, [], [], 'fam1', 1 ).
test( 't99', 356, [], ['r2','r1'], 'fam1', 1 ).
test( 't100', 135, [], ['r2','r1','r3'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').
embedded_board( 'm21').
embedded_board( 'm22').
embedded_board( 'm23').
embedded_board( 'm24').
embedded_board( 'm25').
embedded_board( 'm26').
embedded_board( 'm27').
embedded_board( 'm28').
embedded_board( 'm29').
embedded_board( 'm30').
embedded_board( 'm31').
embedded_board( 'm32').
embedded_board( 'm33').
embedded_board( 'm34').
embedded_board( 'm35').
embedded_board( 'm36').
embedded_board( 'm37').
embedded_board( 'm38').
embedded_board( 'm39').
embedded_board( 'm40').
embedded_board( 'm41').
embedded_board( 'm42').
embedded_board( 'm43').
embedded_board( 'm44').
embedded_board( 'm45').
embedded_board( 'm46').
embedded_board( 'm47').
embedded_board( 'm48').
embedded_board( 'm49').
embedded_board( 'm50').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
