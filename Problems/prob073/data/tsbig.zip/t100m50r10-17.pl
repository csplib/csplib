%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 50
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 280, [], ['r1','r4'], 'fam1', 1 ).
test( 't2', 72, [], [], 'fam1', 1 ).
test( 't3', 113, [], ['r1','r10','r6','r2','r8','r5','r3','r7','r4'], 'fam1', 1 ).
test( 't4', 686, [], [], 'fam1', 1 ).
test( 't5', 253, [], [], 'fam1', 1 ).
test( 't6', 362, [], ['r9','r1','r3','r10','r5','r2','r7','r4','r6'], 'fam1', 1 ).
test( 't7', 209, ['m4'], [], 'fam1', 1 ).
test( 't8', 62, [], [], 'fam1', 1 ).
test( 't9', 403, [], [], 'fam1', 1 ).
test( 't10', 290, ['m23','m36','m4','m24','m3','m32','m45','m44','m13','m29','m9','m25','m2','m21','m31','m11','m46','m50'], [], 'fam1', 1 ).
test( 't11', 744, ['m13','m30','m5','m33','m29','m3','m19','m10','m7','m36','m38','m24','m11','m15'], [], 'fam1', 1 ).
test( 't12', 454, [], [], 'fam1', 1 ).
test( 't13', 752, [], [], 'fam1', 1 ).
test( 't14', 298, [], [], 'fam1', 1 ).
test( 't15', 347, [], [], 'fam1', 1 ).
test( 't16', 531, [], [], 'fam1', 1 ).
test( 't17', 649, [], [], 'fam1', 1 ).
test( 't18', 688, [], [], 'fam1', 1 ).
test( 't19', 246, ['m11','m20','m45','m24','m15','m39','m23'], [], 'fam1', 1 ).
test( 't20', 677, [], [], 'fam1', 1 ).
test( 't21', 581, [], ['r1'], 'fam1', 1 ).
test( 't22', 447, ['m49','m11','m8','m48','m29','m50','m5','m36','m9','m3'], ['r10','r1','r8','r4','r2'], 'fam1', 1 ).
test( 't23', 122, [], ['r2','r7'], 'fam1', 1 ).
test( 't24', 323, ['m22','m20','m36','m15','m19','m39'], ['r1','r6','r10','r3','r2','r5','r7','r9','r8'], 'fam1', 1 ).
test( 't25', 566, [], ['r8','r10','r3','r5','r9','r1','r2'], 'fam1', 1 ).
test( 't26', 540, [], [], 'fam1', 1 ).
test( 't27', 233, ['m32','m14','m31','m19','m5','m44','m8','m39','m23','m47','m28','m25','m4','m48','m35','m26','m45'], ['r8','r9','r10','r1'], 'fam1', 1 ).
test( 't28', 270, [], ['r9','r4','r1','r2','r3','r7','r8'], 'fam1', 1 ).
test( 't29', 697, [], [], 'fam1', 1 ).
test( 't30', 656, ['m32','m8','m18','m16','m19','m40','m20','m50','m38'], [], 'fam1', 1 ).
test( 't31', 538, [], [], 'fam1', 1 ).
test( 't32', 424, [], [], 'fam1', 1 ).
test( 't33', 348, [], [], 'fam1', 1 ).
test( 't34', 337, [], ['r5','r2','r7','r10','r1','r9','r4','r6'], 'fam1', 1 ).
test( 't35', 297, [], [], 'fam1', 1 ).
test( 't36', 768, [], [], 'fam1', 1 ).
test( 't37', 183, [], ['r9','r4','r1','r6','r2','r3'], 'fam1', 1 ).
test( 't38', 82, ['m10'], [], 'fam1', 1 ).
test( 't39', 632, [], [], 'fam1', 1 ).
test( 't40', 360, [], [], 'fam1', 1 ).
test( 't41', 540, [], ['r3','r1','r2','r7','r4','r10','r8'], 'fam1', 1 ).
test( 't42', 239, ['m9','m42','m12','m27','m24','m18','m8','m39','m48','m2','m30'], [], 'fam1', 1 ).
test( 't43', 490, [], ['r4','r10','r7','r2','r1','r9'], 'fam1', 1 ).
test( 't44', 338, [], [], 'fam1', 1 ).
test( 't45', 568, [], [], 'fam1', 1 ).
test( 't46', 111, [], ['r6','r10','r1','r4','r8','r9','r2','r7'], 'fam1', 1 ).
test( 't47', 114, [], [], 'fam1', 1 ).
test( 't48', 308, [], ['r2','r10','r1','r9','r3','r4'], 'fam1', 1 ).
test( 't49', 454, [], [], 'fam1', 1 ).
test( 't50', 318, [], ['r10','r9'], 'fam1', 1 ).
test( 't51', 408, [], ['r1','r6','r9','r2'], 'fam1', 1 ).
test( 't52', 600, [], [], 'fam1', 1 ).
test( 't53', 156, [], [], 'fam1', 1 ).
test( 't54', 780, [], ['r3','r10','r5','r1','r2'], 'fam1', 1 ).
test( 't55', 625, [], [], 'fam1', 1 ).
test( 't56', 75, ['m40','m3','m11','m25','m32','m45','m8','m1','m27','m39','m34','m7','m38','m28','m33','m37','m21','m15'], ['r5','r6','r2','r7','r1'], 'fam1', 1 ).
test( 't57', 723, ['m38','m32','m35','m17'], [], 'fam1', 1 ).
test( 't58', 527, [], [], 'fam1', 1 ).
test( 't59', 201, [], [], 'fam1', 1 ).
test( 't60', 432, [], ['r7','r9','r3'], 'fam1', 1 ).
test( 't61', 413, [], [], 'fam1', 1 ).
test( 't62', 432, ['m10','m7','m25','m41','m8','m40','m44','m31','m26','m33','m45','m46','m2','m20','m24','m16'], ['r9','r1','r10','r5','r3','r8','r2','r4','r7'], 'fam1', 1 ).
test( 't63', 107, ['m11','m1','m40','m45','m15','m24','m4','m44','m43','m32','m21','m22','m35'], ['r7','r6','r2','r8','r4','r5','r10','r1'], 'fam1', 1 ).
test( 't64', 534, [], [], 'fam1', 1 ).
test( 't65', 40, [], [], 'fam1', 1 ).
test( 't66', 688, [], ['r3'], 'fam1', 1 ).
test( 't67', 199, [], [], 'fam1', 1 ).
test( 't68', 510, [], ['r5','r9','r6','r7'], 'fam1', 1 ).
test( 't69', 465, [], [], 'fam1', 1 ).
test( 't70', 552, [], [], 'fam1', 1 ).
test( 't71', 706, [], [], 'fam1', 1 ).
test( 't72', 254, ['m4','m42','m14','m48','m13','m21','m28','m36','m18','m1','m35'], [], 'fam1', 1 ).
test( 't73', 524, ['m3','m48'], [], 'fam1', 1 ).
test( 't74', 370, [], ['r7','r1'], 'fam1', 1 ).
test( 't75', 747, [], [], 'fam1', 1 ).
test( 't76', 569, [], [], 'fam1', 1 ).
test( 't77', 153, [], ['r7','r3','r1','r5','r8','r9'], 'fam1', 1 ).
test( 't78', 349, [], [], 'fam1', 1 ).
test( 't79', 445, ['m41','m1','m21','m33','m28','m29'], [], 'fam1', 1 ).
test( 't80', 300, [], ['r8','r9','r2','r3','r1','r7','r6','r10','r5','r4'], 'fam1', 1 ).
test( 't81', 331, ['m33','m21','m1','m12','m26','m18','m35','m11','m40','m16','m29','m8','m41','m38','m49','m4'], [], 'fam1', 1 ).
test( 't82', 204, [], [], 'fam1', 1 ).
test( 't83', 751, ['m1','m24','m3','m25','m16','m9','m20','m36','m5','m41','m15'], [], 'fam1', 1 ).
test( 't84', 421, [], [], 'fam1', 1 ).
test( 't85', 406, [], ['r7','r1','r2','r5','r6','r4','r3','r9'], 'fam1', 1 ).
test( 't86', 714, ['m31','m46','m7','m50','m39','m1','m17','m8','m36','m41','m28','m18','m12'], ['r2'], 'fam1', 1 ).
test( 't87', 773, [], ['r3','r2','r6','r9','r8','r4','r7'], 'fam1', 1 ).
test( 't88', 615, [], ['r6','r9','r10'], 'fam1', 1 ).
test( 't89', 454, [], ['r2','r1','r5'], 'fam1', 1 ).
test( 't90', 477, [], ['r7','r8'], 'fam1', 1 ).
test( 't91', 791, [], [], 'fam1', 1 ).
test( 't92', 426, ['m6','m24','m1','m50','m39','m10'], [], 'fam1', 1 ).
test( 't93', 58, [], [], 'fam1', 1 ).
test( 't94', 530, [], ['r6','r5','r7','r4','r10','r8','r2','r3'], 'fam1', 1 ).
test( 't95', 462, [], [], 'fam1', 1 ).
test( 't96', 186, ['m30','m14','m3','m21','m8','m22','m29','m36','m45'], [], 'fam1', 1 ).
test( 't97', 395, [], [], 'fam1', 1 ).
test( 't98', 473, [], [], 'fam1', 1 ).
test( 't99', 35, ['m18','m9','m6','m38'], [], 'fam1', 1 ).
test( 't100', 559, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').
embedded_board( 'm21').
embedded_board( 'm22').
embedded_board( 'm23').
embedded_board( 'm24').
embedded_board( 'm25').
embedded_board( 'm26').
embedded_board( 'm27').
embedded_board( 'm28').
embedded_board( 'm29').
embedded_board( 'm30').
embedded_board( 'm31').
embedded_board( 'm32').
embedded_board( 'm33').
embedded_board( 'm34').
embedded_board( 'm35').
embedded_board( 'm36').
embedded_board( 'm37').
embedded_board( 'm38').
embedded_board( 'm39').
embedded_board( 'm40').
embedded_board( 'm41').
embedded_board( 'm42').
embedded_board( 'm43').
embedded_board( 'm44').
embedded_board( 'm45').
embedded_board( 'm46').
embedded_board( 'm47').
embedded_board( 'm48').
embedded_board( 'm49').
embedded_board( 'm50').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
