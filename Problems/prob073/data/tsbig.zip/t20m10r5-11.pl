%% ****  Testsuite  ****
% Number of tests                  : 20
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 482, [], [], 'fam1', 1 ).
test( 't2', 132, [], ['r5','r2','r4','r1','r3'], 'fam1', 1 ).
test( 't3', 165, [], [], 'fam1', 1 ).
test( 't4', 744, [], ['r5','r2','r3','r4'], 'fam1', 1 ).
test( 't5', 490, [], ['r2'], 'fam1', 1 ).
test( 't6', 298, [], ['r2'], 'fam1', 1 ).
test( 't7', 475, ['m2','m5'], ['r3','r1','r5'], 'fam1', 1 ).
test( 't8', 88, [], ['r4','r5','r2','r1','r3'], 'fam1', 1 ).
test( 't9', 469, [], [], 'fam1', 1 ).
test( 't10', 726, [], ['r1','r3','r4','r5','r2'], 'fam1', 1 ).
test( 't11', 107, [], [], 'fam1', 1 ).
test( 't12', 638, [], [], 'fam1', 1 ).
test( 't13', 258, [], [], 'fam1', 1 ).
test( 't14', 62, [], [], 'fam1', 1 ).
test( 't15', 505, [], [], 'fam1', 1 ).
test( 't16', 283, [], ['r2','r3','r4','r5'], 'fam1', 1 ).
test( 't17', 796, [], [], 'fam1', 1 ).
test( 't18', 309, [], [], 'fam1', 1 ).
test( 't19', 688, [], ['r1','r2','r5','r3','r4'], 'fam1', 1 ).
test( 't20', 38, [], ['r2'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
