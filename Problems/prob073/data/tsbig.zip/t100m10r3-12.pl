%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 356, [], [], 'fam1', 1 ).
test( 't2', 769, ['m1','m4','m6','m2'], [], 'fam1', 1 ).
test( 't3', 548, [], [], 'fam1', 1 ).
test( 't4', 643, [], ['r2'], 'fam1', 1 ).
test( 't5', 353, [], ['r1','r2'], 'fam1', 1 ).
test( 't6', 315, [], [], 'fam1', 1 ).
test( 't7', 709, [], ['r1'], 'fam1', 1 ).
test( 't8', 123, [], [], 'fam1', 1 ).
test( 't9', 32, [], [], 'fam1', 1 ).
test( 't10', 571, ['m7','m5','m1','m2'], ['r3'], 'fam1', 1 ).
test( 't11', 380, ['m5'], [], 'fam1', 1 ).
test( 't12', 382, [], [], 'fam1', 1 ).
test( 't13', 14, [], [], 'fam1', 1 ).
test( 't14', 188, [], [], 'fam1', 1 ).
test( 't15', 736, ['m5','m10','m3','m4'], [], 'fam1', 1 ).
test( 't16', 684, [], [], 'fam1', 1 ).
test( 't17', 90, [], [], 'fam1', 1 ).
test( 't18', 8, [], [], 'fam1', 1 ).
test( 't19', 22, ['m3','m8'], [], 'fam1', 1 ).
test( 't20', 637, [], [], 'fam1', 1 ).
test( 't21', 208, ['m10','m5','m8'], [], 'fam1', 1 ).
test( 't22', 121, [], [], 'fam1', 1 ).
test( 't23', 586, [], [], 'fam1', 1 ).
test( 't24', 203, [], [], 'fam1', 1 ).
test( 't25', 282, [], [], 'fam1', 1 ).
test( 't26', 728, [], [], 'fam1', 1 ).
test( 't27', 732, [], [], 'fam1', 1 ).
test( 't28', 407, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't29', 795, [], [], 'fam1', 1 ).
test( 't30', 339, [], ['r3','r1'], 'fam1', 1 ).
test( 't31', 780, [], [], 'fam1', 1 ).
test( 't32', 451, [], ['r3','r2'], 'fam1', 1 ).
test( 't33', 775, ['m3','m10'], [], 'fam1', 1 ).
test( 't34', 222, [], ['r2','r3'], 'fam1', 1 ).
test( 't35', 463, [], [], 'fam1', 1 ).
test( 't36', 520, ['m9','m2','m1'], [], 'fam1', 1 ).
test( 't37', 202, [], [], 'fam1', 1 ).
test( 't38', 677, ['m9','m8','m10'], [], 'fam1', 1 ).
test( 't39', 413, [], ['r2'], 'fam1', 1 ).
test( 't40', 654, [], [], 'fam1', 1 ).
test( 't41', 252, ['m8','m1','m10'], [], 'fam1', 1 ).
test( 't42', 640, ['m10','m2','m5'], ['r1','r3'], 'fam1', 1 ).
test( 't43', 66, [], [], 'fam1', 1 ).
test( 't44', 8, ['m2','m5','m3','m6'], ['r1','r2'], 'fam1', 1 ).
test( 't45', 628, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't46', 789, [], [], 'fam1', 1 ).
test( 't47', 194, [], [], 'fam1', 1 ).
test( 't48', 413, [], [], 'fam1', 1 ).
test( 't49', 83, ['m10','m2','m7','m6'], [], 'fam1', 1 ).
test( 't50', 94, [], ['r3'], 'fam1', 1 ).
test( 't51', 746, [], [], 'fam1', 1 ).
test( 't52', 774, ['m9','m2'], ['r1'], 'fam1', 1 ).
test( 't53', 446, [], [], 'fam1', 1 ).
test( 't54', 477, [], [], 'fam1', 1 ).
test( 't55', 560, [], [], 'fam1', 1 ).
test( 't56', 745, ['m10','m4'], [], 'fam1', 1 ).
test( 't57', 511, [], [], 'fam1', 1 ).
test( 't58', 122, [], [], 'fam1', 1 ).
test( 't59', 554, [], [], 'fam1', 1 ).
test( 't60', 575, [], [], 'fam1', 1 ).
test( 't61', 509, [], [], 'fam1', 1 ).
test( 't62', 767, [], [], 'fam1', 1 ).
test( 't63', 470, [], [], 'fam1', 1 ).
test( 't64', 230, ['m4'], [], 'fam1', 1 ).
test( 't65', 416, ['m1','m7','m9','m10'], ['r1','r3','r2'], 'fam1', 1 ).
test( 't66', 119, [], [], 'fam1', 1 ).
test( 't67', 12, ['m1','m5','m4'], [], 'fam1', 1 ).
test( 't68', 221, [], [], 'fam1', 1 ).
test( 't69', 78, [], [], 'fam1', 1 ).
test( 't70', 634, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't71', 715, ['m8'], [], 'fam1', 1 ).
test( 't72', 607, ['m8'], [], 'fam1', 1 ).
test( 't73', 196, [], [], 'fam1', 1 ).
test( 't74', 708, [], [], 'fam1', 1 ).
test( 't75', 562, [], [], 'fam1', 1 ).
test( 't76', 653, [], [], 'fam1', 1 ).
test( 't77', 691, [], [], 'fam1', 1 ).
test( 't78', 451, ['m10'], [], 'fam1', 1 ).
test( 't79', 671, [], ['r1'], 'fam1', 1 ).
test( 't80', 548, [], [], 'fam1', 1 ).
test( 't81', 405, [], [], 'fam1', 1 ).
test( 't82', 587, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't83', 170, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't84', 28, ['m4'], [], 'fam1', 1 ).
test( 't85', 196, ['m1'], [], 'fam1', 1 ).
test( 't86', 687, [], [], 'fam1', 1 ).
test( 't87', 572, ['m5','m3','m9'], ['r1','r2','r3'], 'fam1', 1 ).
test( 't88', 491, [], [], 'fam1', 1 ).
test( 't89', 132, [], [], 'fam1', 1 ).
test( 't90', 291, [], [], 'fam1', 1 ).
test( 't91', 288, [], [], 'fam1', 1 ).
test( 't92', 732, ['m8','m7','m3'], [], 'fam1', 1 ).
test( 't93', 539, [], [], 'fam1', 1 ).
test( 't94', 368, [], [], 'fam1', 1 ).
test( 't95', 513, [], [], 'fam1', 1 ).
test( 't96', 496, ['m4','m9','m3','m1'], [], 'fam1', 1 ).
test( 't97', 732, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't98', 456, [], [], 'fam1', 1 ).
test( 't99', 782, [], [], 'fam1', 1 ).
test( 't100', 252, [], ['r2','r3','r1'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
