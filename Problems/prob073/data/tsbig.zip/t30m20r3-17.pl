%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 20
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 225, [], ['r3','r2'], 'fam1', 1 ).
test( 't2', 161, [], [], 'fam1', 1 ).
test( 't3', 208, [], [], 'fam1', 1 ).
test( 't4', 405, [], [], 'fam1', 1 ).
test( 't5', 154, [], [], 'fam1', 1 ).
test( 't6', 161, [], [], 'fam1', 1 ).
test( 't7', 352, [], ['r2'], 'fam1', 1 ).
test( 't8', 360, ['m20','m2','m1'], [], 'fam1', 1 ).
test( 't9', 225, [], [], 'fam1', 1 ).
test( 't10', 458, [], [], 'fam1', 1 ).
test( 't11', 183, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't12', 140, [], [], 'fam1', 1 ).
test( 't13', 96, [], [], 'fam1', 1 ).
test( 't14', 265, ['m7','m17','m3'], ['r2','r3'], 'fam1', 1 ).
test( 't15', 400, ['m14','m12'], [], 'fam1', 1 ).
test( 't16', 432, [], ['r1'], 'fam1', 1 ).
test( 't17', 167, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't18', 362, [], ['r2'], 'fam1', 1 ).
test( 't19', 768, [], [], 'fam1', 1 ).
test( 't20', 75, ['m12','m3','m16','m8','m11','m15','m18'], [], 'fam1', 1 ).
test( 't21', 27, [], [], 'fam1', 1 ).
test( 't22', 325, [], ['r3','r1'], 'fam1', 1 ).
test( 't23', 283, [], [], 'fam1', 1 ).
test( 't24', 523, [], [], 'fam1', 1 ).
test( 't25', 326, [], [], 'fam1', 1 ).
test( 't26', 338, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't27', 288, [], [], 'fam1', 1 ).
test( 't28', 521, [], [], 'fam1', 1 ).
test( 't29', 73, ['m10','m5','m8'], [], 'fam1', 1 ).
test( 't30', 718, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
