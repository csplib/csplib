%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 10
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 670, ['m2','m8','m1','m10'], [], 'fam1', 1 ).
test( 't2', 744, ['m7','m2','m5'], [], 'fam1', 1 ).
test( 't3', 65, [], [], 'fam1', 1 ).
test( 't4', 410, [], [], 'fam1', 1 ).
test( 't5', 122, [], ['r10','r1','r8','r3','r9'], 'fam1', 1 ).
test( 't6', 620, [], [], 'fam1', 1 ).
test( 't7', 249, [], [], 'fam1', 1 ).
test( 't8', 676, ['m5'], ['r1','r5','r2','r6','r8','r3','r4','r10','r7'], 'fam1', 1 ).
test( 't9', 421, [], [], 'fam1', 1 ).
test( 't10', 298, [], [], 'fam1', 1 ).
test( 't11', 749, [], [], 'fam1', 1 ).
test( 't12', 312, [], [], 'fam1', 1 ).
test( 't13', 552, [], [], 'fam1', 1 ).
test( 't14', 137, [], [], 'fam1', 1 ).
test( 't15', 507, [], [], 'fam1', 1 ).
test( 't16', 167, ['m10','m8','m6','m7'], [], 'fam1', 1 ).
test( 't17', 591, ['m8'], [], 'fam1', 1 ).
test( 't18', 268, [], [], 'fam1', 1 ).
test( 't19', 211, ['m7','m3','m1','m4'], [], 'fam1', 1 ).
test( 't20', 206, [], [], 'fam1', 1 ).
test( 't21', 406, [], ['r6','r4','r5','r9','r3','r8','r2','r1'], 'fam1', 1 ).
test( 't22', 342, [], [], 'fam1', 1 ).
test( 't23', 552, [], [], 'fam1', 1 ).
test( 't24', 571, [], [], 'fam1', 1 ).
test( 't25', 597, [], [], 'fam1', 1 ).
test( 't26', 369, [], [], 'fam1', 1 ).
test( 't27', 217, ['m1','m6'], [], 'fam1', 1 ).
test( 't28', 325, [], [], 'fam1', 1 ).
test( 't29', 522, [], [], 'fam1', 1 ).
test( 't30', 300, [], ['r9','r1'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
