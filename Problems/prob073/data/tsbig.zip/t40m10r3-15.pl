%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 444, [], [], 'fam1', 1 ).
test( 't2', 171, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't3', 503, ['m9'], ['r2','r1','r3'], 'fam1', 1 ).
test( 't4', 732, [], [], 'fam1', 1 ).
test( 't5', 385, [], [], 'fam1', 1 ).
test( 't6', 292, [], [], 'fam1', 1 ).
test( 't7', 118, [], ['r3'], 'fam1', 1 ).
test( 't8', 589, [], [], 'fam1', 1 ).
test( 't9', 762, [], ['r1'], 'fam1', 1 ).
test( 't10', 337, [], ['r2'], 'fam1', 1 ).
test( 't11', 264, [], [], 'fam1', 1 ).
test( 't12', 79, [], [], 'fam1', 1 ).
test( 't13', 657, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't14', 371, [], [], 'fam1', 1 ).
test( 't15', 640, [], ['r2','r3'], 'fam1', 1 ).
test( 't16', 466, [], [], 'fam1', 1 ).
test( 't17', 647, [], ['r1'], 'fam1', 1 ).
test( 't18', 397, [], [], 'fam1', 1 ).
test( 't19', 354, [], ['r2','r3'], 'fam1', 1 ).
test( 't20', 606, [], [], 'fam1', 1 ).
test( 't21', 787, [], [], 'fam1', 1 ).
test( 't22', 353, [], ['r1','r2'], 'fam1', 1 ).
test( 't23', 144, [], [], 'fam1', 1 ).
test( 't24', 34, [], [], 'fam1', 1 ).
test( 't25', 258, [], ['r2'], 'fam1', 1 ).
test( 't26', 190, [], ['r3'], 'fam1', 1 ).
test( 't27', 374, [], ['r3','r2'], 'fam1', 1 ).
test( 't28', 211, [], [], 'fam1', 1 ).
test( 't29', 220, ['m9','m10','m7','m3'], [], 'fam1', 1 ).
test( 't30', 652, [], [], 'fam1', 1 ).
test( 't31', 698, [], [], 'fam1', 1 ).
test( 't32', 335, [], [], 'fam1', 1 ).
test( 't33', 599, [], [], 'fam1', 1 ).
test( 't34', 581, ['m9'], ['r1'], 'fam1', 1 ).
test( 't35', 673, ['m6','m3','m1'], [], 'fam1', 1 ).
test( 't36', 212, [], [], 'fam1', 1 ).
test( 't37', 138, [], ['r2'], 'fam1', 1 ).
test( 't38', 245, [], [], 'fam1', 1 ).
test( 't39', 552, [], [], 'fam1', 1 ).
test( 't40', 421, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
