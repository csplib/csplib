%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 20
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 630, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't2', 665, [], ['r2'], 'fam1', 1 ).
test( 't3', 801, ['m20','m5','m14'], [], 'fam1', 1 ).
test( 't4', 527, [], [], 'fam1', 1 ).
test( 't5', 361, [], [], 'fam1', 1 ).
test( 't6', 310, [], [], 'fam1', 1 ).
test( 't7', 437, [], [], 'fam1', 1 ).
test( 't8', 101, [], [], 'fam1', 1 ).
test( 't9', 778, ['m5','m13','m17','m2','m1','m20','m8','m19'], [], 'fam1', 1 ).
test( 't10', 780, ['m8','m18','m12','m11','m10'], [], 'fam1', 1 ).
test( 't11', 76, [], [], 'fam1', 1 ).
test( 't12', 45, [], [], 'fam1', 1 ).
test( 't13', 531, ['m8','m19','m13','m17','m11','m1','m7','m14'], ['r3'], 'fam1', 1 ).
test( 't14', 565, [], [], 'fam1', 1 ).
test( 't15', 164, [], ['r2','r1'], 'fam1', 1 ).
test( 't16', 118, [], ['r1','r2'], 'fam1', 1 ).
test( 't17', 499, [], [], 'fam1', 1 ).
test( 't18', 558, [], [], 'fam1', 1 ).
test( 't19', 679, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't20', 119, [], ['r2','r1'], 'fam1', 1 ).
test( 't21', 120, [], [], 'fam1', 1 ).
test( 't22', 224, [], [], 'fam1', 1 ).
test( 't23', 669, ['m1','m2','m5','m3'], [], 'fam1', 1 ).
test( 't24', 157, [], [], 'fam1', 1 ).
test( 't25', 366, [], ['r2','r1'], 'fam1', 1 ).
test( 't26', 14, [], [], 'fam1', 1 ).
test( 't27', 626, [], [], 'fam1', 1 ).
test( 't28', 320, [], [], 'fam1', 1 ).
test( 't29', 470, [], [], 'fam1', 1 ).
test( 't30', 444, [], [], 'fam1', 1 ).
test( 't31', 427, [], ['r2','r3'], 'fam1', 1 ).
test( 't32', 709, [], [], 'fam1', 1 ).
test( 't33', 506, [], [], 'fam1', 1 ).
test( 't34', 705, [], [], 'fam1', 1 ).
test( 't35', 597, [], [], 'fam1', 1 ).
test( 't36', 583, [], [], 'fam1', 1 ).
test( 't37', 527, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't38', 481, ['m6'], [], 'fam1', 1 ).
test( 't39', 35, [], [], 'fam1', 1 ).
test( 't40', 223, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
