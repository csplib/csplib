%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 10
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 127, [], [], 'fam1', 1 ).
test( 't2', 418, ['m3','m10','m2','m1'], [], 'fam1', 1 ).
test( 't3', 785, [], ['r1','r4','r6','r8','r3','r7','r10','r2'], 'fam1', 1 ).
test( 't4', 497, ['m3','m5','m9'], ['r1','r7','r3'], 'fam1', 1 ).
test( 't5', 537, [], [], 'fam1', 1 ).
test( 't6', 147, [], ['r6','r1','r5','r3'], 'fam1', 1 ).
test( 't7', 151, [], [], 'fam1', 1 ).
test( 't8', 579, [], [], 'fam1', 1 ).
test( 't9', 183, [], ['r7','r3','r10','r6','r2','r5','r1','r9'], 'fam1', 1 ).
test( 't10', 652, ['m2','m9','m1','m6'], [], 'fam1', 1 ).
test( 't11', 70, [], [], 'fam1', 1 ).
test( 't12', 606, [], [], 'fam1', 1 ).
test( 't13', 664, [], [], 'fam1', 1 ).
test( 't14', 436, [], ['r10','r7','r6','r2','r4','r1'], 'fam1', 1 ).
test( 't15', 294, [], ['r9','r2','r7','r4','r6','r5'], 'fam1', 1 ).
test( 't16', 553, ['m8','m7','m9','m1'], [], 'fam1', 1 ).
test( 't17', 130, ['m3'], [], 'fam1', 1 ).
test( 't18', 543, [], ['r8','r10','r9','r6'], 'fam1', 1 ).
test( 't19', 640, [], ['r2','r1','r3','r7','r4','r9','r5','r10','r8'], 'fam1', 1 ).
test( 't20', 613, ['m5','m4'], [], 'fam1', 1 ).
test( 't21', 448, [], [], 'fam1', 1 ).
test( 't22', 654, [], ['r4','r2','r5','r1','r10','r6','r9','r3'], 'fam1', 1 ).
test( 't23', 735, ['m4','m8'], [], 'fam1', 1 ).
test( 't24', 441, ['m9'], [], 'fam1', 1 ).
test( 't25', 267, [], ['r6','r10','r9','r3','r1','r7','r2','r4','r8'], 'fam1', 1 ).
test( 't26', 243, [], [], 'fam1', 1 ).
test( 't27', 181, [], ['r1','r8','r5','r9','r4','r6','r7','r2','r10'], 'fam1', 1 ).
test( 't28', 612, [], [], 'fam1', 1 ).
test( 't29', 7, [], [], 'fam1', 1 ).
test( 't30', 649, ['m10','m7','m4'], [], 'fam1', 1 ).
test( 't31', 279, [], ['r9','r4','r8','r10','r5','r1','r6'], 'fam1', 1 ).
test( 't32', 742, [], [], 'fam1', 1 ).
test( 't33', 193, [], ['r2','r1','r5','r4'], 'fam1', 1 ).
test( 't34', 349, [], [], 'fam1', 1 ).
test( 't35', 782, [], [], 'fam1', 1 ).
test( 't36', 162, ['m6','m4'], [], 'fam1', 1 ).
test( 't37', 84, [], [], 'fam1', 1 ).
test( 't38', 610, [], [], 'fam1', 1 ).
test( 't39', 708, [], [], 'fam1', 1 ).
test( 't40', 197, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
