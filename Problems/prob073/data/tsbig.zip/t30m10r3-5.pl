%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 690, [], ['r3','r2'], 'fam1', 1 ).
test( 't2', 18, ['m10','m7','m4','m8'], ['r1','r3'], 'fam1', 1 ).
test( 't3', 405, ['m6','m7','m5'], [], 'fam1', 1 ).
test( 't4', 160, [], [], 'fam1', 1 ).
test( 't5', 633, ['m1'], ['r2'], 'fam1', 1 ).
test( 't6', 336, ['m5','m7'], ['r1','r2','r3'], 'fam1', 1 ).
test( 't7', 40, [], [], 'fam1', 1 ).
test( 't8', 347, [], [], 'fam1', 1 ).
test( 't9', 43, [], ['r2'], 'fam1', 1 ).
test( 't10', 230, [], [], 'fam1', 1 ).
test( 't11', 780, [], ['r1','r2'], 'fam1', 1 ).
test( 't12', 508, ['m10','m5'], [], 'fam1', 1 ).
test( 't13', 431, [], [], 'fam1', 1 ).
test( 't14', 505, [], [], 'fam1', 1 ).
test( 't15', 477, [], [], 'fam1', 1 ).
test( 't16', 607, [], [], 'fam1', 1 ).
test( 't17', 493, ['m7','m1','m10','m2'], [], 'fam1', 1 ).
test( 't18', 348, ['m5','m7','m10','m9'], ['r1'], 'fam1', 1 ).
test( 't19', 350, [], ['r1','r2'], 'fam1', 1 ).
test( 't20', 527, [], [], 'fam1', 1 ).
test( 't21', 464, [], [], 'fam1', 1 ).
test( 't22', 513, [], ['r2','r3'], 'fam1', 1 ).
test( 't23', 413, [], ['r3','r2'], 'fam1', 1 ).
test( 't24', 489, [], [], 'fam1', 1 ).
test( 't25', 253, [], [], 'fam1', 1 ).
test( 't26', 492, [], ['r1','r3'], 'fam1', 1 ).
test( 't27', 583, [], [], 'fam1', 1 ).
test( 't28', 755, [], [], 'fam1', 1 ).
test( 't29', 721, [], [], 'fam1', 1 ).
test( 't30', 519, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
