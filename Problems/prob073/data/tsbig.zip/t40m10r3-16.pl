%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 522, [], [], 'fam1', 1 ).
test( 't2', 118, [], ['r1','r3'], 'fam1', 1 ).
test( 't3', 678, ['m5'], [], 'fam1', 1 ).
test( 't4', 72, ['m9','m8','m5'], [], 'fam1', 1 ).
test( 't5', 765, [], ['r3'], 'fam1', 1 ).
test( 't6', 231, [], ['r2','r3'], 'fam1', 1 ).
test( 't7', 317, [], [], 'fam1', 1 ).
test( 't8', 24, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't9', 644, [], [], 'fam1', 1 ).
test( 't10', 463, [], [], 'fam1', 1 ).
test( 't11', 138, ['m3','m1','m6'], [], 'fam1', 1 ).
test( 't12', 343, [], [], 'fam1', 1 ).
test( 't13', 687, [], [], 'fam1', 1 ).
test( 't14', 530, [], [], 'fam1', 1 ).
test( 't15', 762, [], [], 'fam1', 1 ).
test( 't16', 199, ['m6','m8'], [], 'fam1', 1 ).
test( 't17', 478, [], ['r1'], 'fam1', 1 ).
test( 't18', 170, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't19', 424, [], [], 'fam1', 1 ).
test( 't20', 576, [], [], 'fam1', 1 ).
test( 't21', 496, [], [], 'fam1', 1 ).
test( 't22', 429, [], [], 'fam1', 1 ).
test( 't23', 797, [], [], 'fam1', 1 ).
test( 't24', 746, [], [], 'fam1', 1 ).
test( 't25', 468, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't26', 256, [], [], 'fam1', 1 ).
test( 't27', 542, [], [], 'fam1', 1 ).
test( 't28', 558, ['m1','m2'], [], 'fam1', 1 ).
test( 't29', 582, [], [], 'fam1', 1 ).
test( 't30', 641, [], [], 'fam1', 1 ).
test( 't31', 310, ['m3','m1'], ['r3','r1','r2'], 'fam1', 1 ).
test( 't32', 523, [], ['r2','r1'], 'fam1', 1 ).
test( 't33', 547, ['m9','m4','m10'], [], 'fam1', 1 ).
test( 't34', 223, [], [], 'fam1', 1 ).
test( 't35', 589, ['m4','m9','m6'], ['r3','r2','r1'], 'fam1', 1 ).
test( 't36', 788, [], [], 'fam1', 1 ).
test( 't37', 326, [], [], 'fam1', 1 ).
test( 't38', 567, [], [], 'fam1', 1 ).
test( 't39', 160, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't40', 798, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
