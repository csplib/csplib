%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 20
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 162, [], [], 'fam1', 1 ).
test( 't2', 24, [], [], 'fam1', 1 ).
test( 't3', 61, [], ['r3','r1','r5','r4','r2'], 'fam1', 1 ).
test( 't4', 161, [], [], 'fam1', 1 ).
test( 't5', 706, [], ['r3','r1','r4'], 'fam1', 1 ).
test( 't6', 71, [], ['r1','r2','r4','r5','r3'], 'fam1', 1 ).
test( 't7', 132, [], [], 'fam1', 1 ).
test( 't8', 622, [], ['r4','r5','r1','r3'], 'fam1', 1 ).
test( 't9', 798, [], [], 'fam1', 1 ).
test( 't10', 727, [], [], 'fam1', 1 ).
test( 't11', 143, [], [], 'fam1', 1 ).
test( 't12', 760, [], [], 'fam1', 1 ).
test( 't13', 138, [], [], 'fam1', 1 ).
test( 't14', 201, [], [], 'fam1', 1 ).
test( 't15', 312, [], [], 'fam1', 1 ).
test( 't16', 711, [], [], 'fam1', 1 ).
test( 't17', 697, [], [], 'fam1', 1 ).
test( 't18', 142, ['m7'], [], 'fam1', 1 ).
test( 't19', 16, [], ['r4','r5','r2'], 'fam1', 1 ).
test( 't20', 472, [], ['r3','r5','r1','r2'], 'fam1', 1 ).
test( 't21', 520, [], [], 'fam1', 1 ).
test( 't22', 527, [], [], 'fam1', 1 ).
test( 't23', 675, ['m18','m4','m10','m19','m5','m8'], [], 'fam1', 1 ).
test( 't24', 617, [], ['r5'], 'fam1', 1 ).
test( 't25', 140, [], [], 'fam1', 1 ).
test( 't26', 246, [], [], 'fam1', 1 ).
test( 't27', 746, ['m11'], ['r4','r2'], 'fam1', 1 ).
test( 't28', 14, [], [], 'fam1', 1 ).
test( 't29', 107, [], ['r2','r4','r5','r3','r1'], 'fam1', 1 ).
test( 't30', 290, ['m6','m13','m18','m11','m1','m5'], ['r5'], 'fam1', 1 ).
test( 't31', 672, [], [], 'fam1', 1 ).
test( 't32', 173, [], [], 'fam1', 1 ).
test( 't33', 223, [], [], 'fam1', 1 ).
test( 't34', 100, [], [], 'fam1', 1 ).
test( 't35', 637, ['m12','m18','m5','m3'], [], 'fam1', 1 ).
test( 't36', 150, [], [], 'fam1', 1 ).
test( 't37', 129, [], [], 'fam1', 1 ).
test( 't38', 189, ['m9','m4','m5','m10','m19'], [], 'fam1', 1 ).
test( 't39', 1, [], ['r3'], 'fam1', 1 ).
test( 't40', 42, [], [], 'fam1', 1 ).
test( 't41', 133, [], [], 'fam1', 1 ).
test( 't42', 15, [], [], 'fam1', 1 ).
test( 't43', 489, [], [], 'fam1', 1 ).
test( 't44', 376, ['m15','m1','m11','m10','m13','m2','m19','m7'], [], 'fam1', 1 ).
test( 't45', 383, [], [], 'fam1', 1 ).
test( 't46', 789, [], ['r5','r4','r2','r3'], 'fam1', 1 ).
test( 't47', 563, [], ['r1'], 'fam1', 1 ).
test( 't48', 424, [], [], 'fam1', 1 ).
test( 't49', 489, ['m8','m15','m1','m6','m5'], [], 'fam1', 1 ).
test( 't50', 8, [], [], 'fam1', 1 ).
test( 't51', 338, [], [], 'fam1', 1 ).
test( 't52', 309, [], [], 'fam1', 1 ).
test( 't53', 656, ['m13','m5','m14'], [], 'fam1', 1 ).
test( 't54', 392, [], [], 'fam1', 1 ).
test( 't55', 764, [], ['r3','r4','r1','r2'], 'fam1', 1 ).
test( 't56', 159, [], ['r5','r2'], 'fam1', 1 ).
test( 't57', 588, ['m6','m4','m13','m10'], ['r5','r1','r3','r2','r4'], 'fam1', 1 ).
test( 't58', 428, [], [], 'fam1', 1 ).
test( 't59', 281, [], [], 'fam1', 1 ).
test( 't60', 96, ['m7','m20','m19','m3','m13'], ['r4'], 'fam1', 1 ).
test( 't61', 382, [], ['r3','r4','r1'], 'fam1', 1 ).
test( 't62', 776, ['m12','m9','m6','m14'], ['r5','r4','r1','r3','r2'], 'fam1', 1 ).
test( 't63', 551, [], [], 'fam1', 1 ).
test( 't64', 315, [], [], 'fam1', 1 ).
test( 't65', 671, [], [], 'fam1', 1 ).
test( 't66', 683, [], [], 'fam1', 1 ).
test( 't67', 626, [], [], 'fam1', 1 ).
test( 't68', 349, ['m18','m1','m9','m7','m14','m15','m20'], [], 'fam1', 1 ).
test( 't69', 102, [], [], 'fam1', 1 ).
test( 't70', 2, [], [], 'fam1', 1 ).
test( 't71', 656, ['m20','m3','m6','m7','m14','m12'], [], 'fam1', 1 ).
test( 't72', 150, [], ['r1'], 'fam1', 1 ).
test( 't73', 21, [], [], 'fam1', 1 ).
test( 't74', 108, [], [], 'fam1', 1 ).
test( 't75', 641, [], ['r4','r3'], 'fam1', 1 ).
test( 't76', 129, [], [], 'fam1', 1 ).
test( 't77', 613, ['m7','m2'], [], 'fam1', 1 ).
test( 't78', 499, ['m17','m6','m14','m1','m20'], [], 'fam1', 1 ).
test( 't79', 100, [], [], 'fam1', 1 ).
test( 't80', 300, [], [], 'fam1', 1 ).
test( 't81', 168, [], ['r1','r5','r3','r4','r2'], 'fam1', 1 ).
test( 't82', 148, ['m16','m1','m14'], [], 'fam1', 1 ).
test( 't83', 507, ['m11','m20','m9','m16'], [], 'fam1', 1 ).
test( 't84', 700, ['m1'], ['r5','r4','r1','r3'], 'fam1', 1 ).
test( 't85', 4, [], ['r3','r1','r5','r4'], 'fam1', 1 ).
test( 't86', 760, [], [], 'fam1', 1 ).
test( 't87', 266, [], ['r5','r1','r3'], 'fam1', 1 ).
test( 't88', 1, [], [], 'fam1', 1 ).
test( 't89', 695, [], [], 'fam1', 1 ).
test( 't90', 96, ['m10','m11','m2','m19','m6','m14','m12','m15'], [], 'fam1', 1 ).
test( 't91', 727, [], ['r4','r2','r3','r1','r5'], 'fam1', 1 ).
test( 't92', 591, [], [], 'fam1', 1 ).
test( 't93', 298, [], [], 'fam1', 1 ).
test( 't94', 535, [], [], 'fam1', 1 ).
test( 't95', 164, [], [], 'fam1', 1 ).
test( 't96', 127, [], [], 'fam1', 1 ).
test( 't97', 215, [], [], 'fam1', 1 ).
test( 't98', 530, [], [], 'fam1', 1 ).
test( 't99', 111, [], [], 'fam1', 1 ).
test( 't100', 386, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
