%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 10
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 187, [], [], 'fam1', 1 ).
test( 't2', 208, [], [], 'fam1', 1 ).
test( 't3', 675, [], [], 'fam1', 1 ).
test( 't4', 570, [], ['r10','r2','r7','r6','r3','r4','r1','r9','r8'], 'fam1', 1 ).
test( 't5', 192, [], [], 'fam1', 1 ).
test( 't6', 43, [], [], 'fam1', 1 ).
test( 't7', 351, [], [], 'fam1', 1 ).
test( 't8', 342, [], [], 'fam1', 1 ).
test( 't9', 273, [], ['r3','r7'], 'fam1', 1 ).
test( 't10', 756, [], [], 'fam1', 1 ).
test( 't11', 668, [], [], 'fam1', 1 ).
test( 't12', 646, [], [], 'fam1', 1 ).
test( 't13', 739, [], [], 'fam1', 1 ).
test( 't14', 409, [], [], 'fam1', 1 ).
test( 't15', 386, [], ['r9','r1','r5','r6','r2'], 'fam1', 1 ).
test( 't16', 550, [], [], 'fam1', 1 ).
test( 't17', 259, [], [], 'fam1', 1 ).
test( 't18', 613, [], [], 'fam1', 1 ).
test( 't19', 421, ['m9','m7','m1'], [], 'fam1', 1 ).
test( 't20', 772, [], [], 'fam1', 1 ).
test( 't21', 652, [], [], 'fam1', 1 ).
test( 't22', 50, [], ['r1','r6','r8','r2','r3','r5'], 'fam1', 1 ).
test( 't23', 434, [], ['r5'], 'fam1', 1 ).
test( 't24', 35, [], [], 'fam1', 1 ).
test( 't25', 436, [], ['r9','r5','r2','r1','r4'], 'fam1', 1 ).
test( 't26', 741, [], [], 'fam1', 1 ).
test( 't27', 410, ['m5'], ['r4','r6','r9','r2','r10'], 'fam1', 1 ).
test( 't28', 374, [], [], 'fam1', 1 ).
test( 't29', 364, [], [], 'fam1', 1 ).
test( 't30', 228, [], [], 'fam1', 1 ).
test( 't31', 424, [], ['r9','r2','r4','r6','r8','r5'], 'fam1', 1 ).
test( 't32', 378, [], [], 'fam1', 1 ).
test( 't33', 499, [], [], 'fam1', 1 ).
test( 't34', 424, [], [], 'fam1', 1 ).
test( 't35', 258, [], [], 'fam1', 1 ).
test( 't36', 656, ['m1','m7'], [], 'fam1', 1 ).
test( 't37', 704, [], [], 'fam1', 1 ).
test( 't38', 67, [], [], 'fam1', 1 ).
test( 't39', 87, [], ['r4','r2','r3','r9','r5','r6','r10','r8'], 'fam1', 1 ).
test( 't40', 589, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
