%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 20
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 292, [], [], 'fam1', 1 ).
test( 't2', 697, [], [], 'fam1', 1 ).
test( 't3', 87, [], [], 'fam1', 1 ).
test( 't4', 170, ['m8','m1','m6','m17'], [], 'fam1', 1 ).
test( 't5', 404, [], [], 'fam1', 1 ).
test( 't6', 367, ['m20'], ['r2','r3'], 'fam1', 1 ).
test( 't7', 178, [], [], 'fam1', 1 ).
test( 't8', 228, [], [], 'fam1', 1 ).
test( 't9', 296, [], ['r3','r2'], 'fam1', 1 ).
test( 't10', 76, [], [], 'fam1', 1 ).
test( 't11', 749, [], [], 'fam1', 1 ).
test( 't12', 339, [], [], 'fam1', 1 ).
test( 't13', 345, [], [], 'fam1', 1 ).
test( 't14', 405, [], [], 'fam1', 1 ).
test( 't15', 660, [], [], 'fam1', 1 ).
test( 't16', 168, ['m17','m19','m4','m3','m15','m10','m7'], ['r3','r2','r1'], 'fam1', 1 ).
test( 't17', 86, [], ['r1','r3'], 'fam1', 1 ).
test( 't18', 768, [], [], 'fam1', 1 ).
test( 't19', 670, [], [], 'fam1', 1 ).
test( 't20', 771, [], [], 'fam1', 1 ).
test( 't21', 215, [], [], 'fam1', 1 ).
test( 't22', 615, ['m13','m19'], [], 'fam1', 1 ).
test( 't23', 789, [], [], 'fam1', 1 ).
test( 't24', 3, ['m7','m18','m8','m6','m13','m1'], [], 'fam1', 1 ).
test( 't25', 197, [], [], 'fam1', 1 ).
test( 't26', 460, [], [], 'fam1', 1 ).
test( 't27', 213, [], [], 'fam1', 1 ).
test( 't28', 393, [], [], 'fam1', 1 ).
test( 't29', 716, [], [], 'fam1', 1 ).
test( 't30', 529, [], ['r3','r2'], 'fam1', 1 ).
test( 't31', 726, ['m6','m14','m1','m11','m19','m15','m2'], [], 'fam1', 1 ).
test( 't32', 60, [], [], 'fam1', 1 ).
test( 't33', 447, ['m15','m13','m7','m9','m8','m5','m12'], [], 'fam1', 1 ).
test( 't34', 176, [], [], 'fam1', 1 ).
test( 't35', 539, [], ['r3'], 'fam1', 1 ).
test( 't36', 568, [], [], 'fam1', 1 ).
test( 't37', 744, [], [], 'fam1', 1 ).
test( 't38', 662, [], ['r1','r2'], 'fam1', 1 ).
test( 't39', 371, [], [], 'fam1', 1 ).
test( 't40', 521, [], [], 'fam1', 1 ).
test( 't41', 246, [], [], 'fam1', 1 ).
test( 't42', 161, [], ['r2'], 'fam1', 1 ).
test( 't43', 800, ['m4'], ['r2'], 'fam1', 1 ).
test( 't44', 205, [], [], 'fam1', 1 ).
test( 't45', 690, [], [], 'fam1', 1 ).
test( 't46', 213, [], ['r3','r1'], 'fam1', 1 ).
test( 't47', 367, [], [], 'fam1', 1 ).
test( 't48', 692, [], [], 'fam1', 1 ).
test( 't49', 73, [], [], 'fam1', 1 ).
test( 't50', 298, [], [], 'fam1', 1 ).
test( 't51', 794, [], [], 'fam1', 1 ).
test( 't52', 654, [], [], 'fam1', 1 ).
test( 't53', 393, [], [], 'fam1', 1 ).
test( 't54', 773, [], [], 'fam1', 1 ).
test( 't55', 224, [], [], 'fam1', 1 ).
test( 't56', 563, [], [], 'fam1', 1 ).
test( 't57', 101, ['m16','m9','m1','m2'], ['r2','r1'], 'fam1', 1 ).
test( 't58', 725, ['m19','m13','m15','m14','m10','m1','m3'], [], 'fam1', 1 ).
test( 't59', 558, [], [], 'fam1', 1 ).
test( 't60', 98, [], ['r3'], 'fam1', 1 ).
test( 't61', 579, [], [], 'fam1', 1 ).
test( 't62', 468, [], [], 'fam1', 1 ).
test( 't63', 496, [], [], 'fam1', 1 ).
test( 't64', 500, ['m14','m9','m17','m2','m6','m10','m4','m1'], [], 'fam1', 1 ).
test( 't65', 510, [], [], 'fam1', 1 ).
test( 't66', 451, [], [], 'fam1', 1 ).
test( 't67', 14, [], [], 'fam1', 1 ).
test( 't68', 366, [], [], 'fam1', 1 ).
test( 't69', 645, ['m15','m16','m19','m3','m18','m6','m5'], ['r1','r2','r3'], 'fam1', 1 ).
test( 't70', 535, [], [], 'fam1', 1 ).
test( 't71', 271, [], [], 'fam1', 1 ).
test( 't72', 24, [], [], 'fam1', 1 ).
test( 't73', 291, [], [], 'fam1', 1 ).
test( 't74', 295, [], [], 'fam1', 1 ).
test( 't75', 132, ['m17'], [], 'fam1', 1 ).
test( 't76', 101, [], ['r1','r3'], 'fam1', 1 ).
test( 't77', 161, [], ['r2','r3'], 'fam1', 1 ).
test( 't78', 579, [], [], 'fam1', 1 ).
test( 't79', 259, ['m16','m9'], [], 'fam1', 1 ).
test( 't80', 631, [], ['r2','r3'], 'fam1', 1 ).
test( 't81', 687, [], [], 'fam1', 1 ).
test( 't82', 187, [], [], 'fam1', 1 ).
test( 't83', 440, [], [], 'fam1', 1 ).
test( 't84', 480, ['m8','m11','m7','m15','m12','m19'], ['r1','r3'], 'fam1', 1 ).
test( 't85', 498, [], [], 'fam1', 1 ).
test( 't86', 251, [], [], 'fam1', 1 ).
test( 't87', 633, [], [], 'fam1', 1 ).
test( 't88', 800, [], [], 'fam1', 1 ).
test( 't89', 688, ['m18','m1','m4','m12','m11','m16','m6','m14'], ['r1','r2'], 'fam1', 1 ).
test( 't90', 267, [], [], 'fam1', 1 ).
test( 't91', 466, [], [], 'fam1', 1 ).
test( 't92', 134, [], [], 'fam1', 1 ).
test( 't93', 546, [], [], 'fam1', 1 ).
test( 't94', 247, [], [], 'fam1', 1 ).
test( 't95', 78, [], [], 'fam1', 1 ).
test( 't96', 191, ['m13','m20','m8','m3'], [], 'fam1', 1 ).
test( 't97', 297, [], [], 'fam1', 1 ).
test( 't98', 509, [], [], 'fam1', 1 ).
test( 't99', 491, [], [], 'fam1', 1 ).
test( 't100', 242, [], ['r3','r2'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
