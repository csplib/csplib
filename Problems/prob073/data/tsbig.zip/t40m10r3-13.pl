%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 30, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't2', 656, [], [], 'fam1', 1 ).
test( 't3', 490, [], [], 'fam1', 1 ).
test( 't4', 170, [], [], 'fam1', 1 ).
test( 't5', 325, [], [], 'fam1', 1 ).
test( 't6', 203, [], [], 'fam1', 1 ).
test( 't7', 327, [], [], 'fam1', 1 ).
test( 't8', 102, [], [], 'fam1', 1 ).
test( 't9', 409, [], [], 'fam1', 1 ).
test( 't10', 338, [], [], 'fam1', 1 ).
test( 't11', 239, ['m9','m7','m5'], [], 'fam1', 1 ).
test( 't12', 315, [], [], 'fam1', 1 ).
test( 't13', 754, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't14', 687, [], [], 'fam1', 1 ).
test( 't15', 273, ['m9','m5','m6','m8'], [], 'fam1', 1 ).
test( 't16', 582, ['m10'], [], 'fam1', 1 ).
test( 't17', 315, [], [], 'fam1', 1 ).
test( 't18', 152, [], [], 'fam1', 1 ).
test( 't19', 611, [], [], 'fam1', 1 ).
test( 't20', 598, [], [], 'fam1', 1 ).
test( 't21', 766, [], [], 'fam1', 1 ).
test( 't22', 422, [], ['r2'], 'fam1', 1 ).
test( 't23', 707, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't24', 631, [], ['r1'], 'fam1', 1 ).
test( 't25', 326, [], [], 'fam1', 1 ).
test( 't26', 39, [], [], 'fam1', 1 ).
test( 't27', 37, [], [], 'fam1', 1 ).
test( 't28', 453, [], [], 'fam1', 1 ).
test( 't29', 787, [], ['r2','r3'], 'fam1', 1 ).
test( 't30', 546, [], [], 'fam1', 1 ).
test( 't31', 233, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't32', 347, ['m7'], [], 'fam1', 1 ).
test( 't33', 243, [], ['r3'], 'fam1', 1 ).
test( 't34', 307, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't35', 73, ['m7','m8'], [], 'fam1', 1 ).
test( 't36', 607, [], [], 'fam1', 1 ).
test( 't37', 43, [], ['r1'], 'fam1', 1 ).
test( 't38', 324, [], ['r2'], 'fam1', 1 ).
test( 't39', 1, [], [], 'fam1', 1 ).
test( 't40', 421, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
