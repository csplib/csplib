%% ****  Testsuite  ****
% Number of tests                  : 20
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 78, ['m5'], ['r1','r3'], 'fam1', 1 ).
test( 't2', 514, ['m3','m10','m7'], [], 'fam1', 1 ).
test( 't3', 38, [], [], 'fam1', 1 ).
test( 't4', 177, [], [], 'fam1', 1 ).
test( 't5', 203, [], [], 'fam1', 1 ).
test( 't6', 360, [], [], 'fam1', 1 ).
test( 't7', 731, ['m7','m6','m1','m2'], [], 'fam1', 1 ).
test( 't8', 231, [], ['r1','r3','r2','r4','r5'], 'fam1', 1 ).
test( 't9', 121, [], [], 'fam1', 1 ).
test( 't10', 207, [], [], 'fam1', 1 ).
test( 't11', 520, [], [], 'fam1', 1 ).
test( 't12', 188, [], [], 'fam1', 1 ).
test( 't13', 460, [], [], 'fam1', 1 ).
test( 't14', 731, [], ['r3'], 'fam1', 1 ).
test( 't15', 456, [], [], 'fam1', 1 ).
test( 't16', 505, [], ['r3','r4','r2','r5','r1'], 'fam1', 1 ).
test( 't17', 725, ['m2','m7','m4'], [], 'fam1', 1 ).
test( 't18', 372, [], [], 'fam1', 1 ).
test( 't19', 14, ['m4','m7'], ['r3'], 'fam1', 1 ).
test( 't20', 363, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
