%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 20
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 199, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't2', 536, [], ['r3'], 'fam1', 1 ).
test( 't3', 525, ['m11','m7','m18','m17','m20'], [], 'fam1', 1 ).
test( 't4', 796, [], [], 'fam1', 1 ).
test( 't5', 333, [], [], 'fam1', 1 ).
test( 't6', 171, [], [], 'fam1', 1 ).
test( 't7', 340, [], ['r3','r2'], 'fam1', 1 ).
test( 't8', 575, ['m13','m2','m16','m5','m11'], ['r2'], 'fam1', 1 ).
test( 't9', 20, [], [], 'fam1', 1 ).
test( 't10', 364, [], [], 'fam1', 1 ).
test( 't11', 223, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't12', 175, [], [], 'fam1', 1 ).
test( 't13', 610, [], ['r2','r3'], 'fam1', 1 ).
test( 't14', 780, [], [], 'fam1', 1 ).
test( 't15', 4, [], [], 'fam1', 1 ).
test( 't16', 449, ['m17'], ['r2','r1'], 'fam1', 1 ).
test( 't17', 666, [], ['r3'], 'fam1', 1 ).
test( 't18', 363, [], [], 'fam1', 1 ).
test( 't19', 614, [], [], 'fam1', 1 ).
test( 't20', 168, ['m9','m11','m2','m15','m4','m17'], ['r1','r3','r2'], 'fam1', 1 ).
test( 't21', 565, [], [], 'fam1', 1 ).
test( 't22', 302, [], [], 'fam1', 1 ).
test( 't23', 195, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't24', 154, [], [], 'fam1', 1 ).
test( 't25', 41, ['m12','m6','m8','m1','m2','m17','m10'], [], 'fam1', 1 ).
test( 't26', 381, ['m18','m2','m9'], [], 'fam1', 1 ).
test( 't27', 23, [], [], 'fam1', 1 ).
test( 't28', 673, [], ['r2'], 'fam1', 1 ).
test( 't29', 703, [], [], 'fam1', 1 ).
test( 't30', 716, ['m6','m5','m15'], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
