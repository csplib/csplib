%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 730, [], ['r3','r5','r4','r1','r2'], 'fam1', 1 ).
test( 't2', 355, [], ['r3','r2'], 'fam1', 1 ).
test( 't3', 706, ['m8'], [], 'fam1', 1 ).
test( 't4', 142, [], ['r2','r5','r4','r1','r3'], 'fam1', 1 ).
test( 't5', 437, [], [], 'fam1', 1 ).
test( 't6', 53, [], [], 'fam1', 1 ).
test( 't7', 633, [], [], 'fam1', 1 ).
test( 't8', 137, ['m7','m10','m4','m1'], [], 'fam1', 1 ).
test( 't9', 33, [], [], 'fam1', 1 ).
test( 't10', 21, [], [], 'fam1', 1 ).
test( 't11', 218, [], ['r3'], 'fam1', 1 ).
test( 't12', 632, [], ['r3','r1'], 'fam1', 1 ).
test( 't13', 359, ['m4'], [], 'fam1', 1 ).
test( 't14', 103, [], [], 'fam1', 1 ).
test( 't15', 440, [], ['r4','r2','r3'], 'fam1', 1 ).
test( 't16', 678, [], [], 'fam1', 1 ).
test( 't17', 635, [], [], 'fam1', 1 ).
test( 't18', 787, ['m7','m5','m3'], [], 'fam1', 1 ).
test( 't19', 415, [], [], 'fam1', 1 ).
test( 't20', 91, ['m5','m3','m8','m6'], [], 'fam1', 1 ).
test( 't21', 600, [], [], 'fam1', 1 ).
test( 't22', 400, [], [], 'fam1', 1 ).
test( 't23', 202, [], [], 'fam1', 1 ).
test( 't24', 452, [], [], 'fam1', 1 ).
test( 't25', 691, [], [], 'fam1', 1 ).
test( 't26', 40, ['m3','m7'], [], 'fam1', 1 ).
test( 't27', 696, [], [], 'fam1', 1 ).
test( 't28', 336, [], [], 'fam1', 1 ).
test( 't29', 137, [], [], 'fam1', 1 ).
test( 't30', 637, [], [], 'fam1', 1 ).
test( 't31', 290, [], [], 'fam1', 1 ).
test( 't32', 346, [], ['r3','r2'], 'fam1', 1 ).
test( 't33', 411, [], [], 'fam1', 1 ).
test( 't34', 36, [], ['r1','r3','r4'], 'fam1', 1 ).
test( 't35', 384, [], [], 'fam1', 1 ).
test( 't36', 570, [], [], 'fam1', 1 ).
test( 't37', 722, [], ['r2'], 'fam1', 1 ).
test( 't38', 600, [], [], 'fam1', 1 ).
test( 't39', 748, [], ['r1','r4'], 'fam1', 1 ).
test( 't40', 274, [], ['r3','r1','r2','r5','r4'], 'fam1', 1 ).
test( 't41', 82, ['m7','m1','m2','m4'], ['r4','r3','r5','r2','r1'], 'fam1', 1 ).
test( 't42', 786, ['m2','m6','m10','m4'], ['r4','r2','r5','r3','r1'], 'fam1', 1 ).
test( 't43', 77, [], [], 'fam1', 1 ).
test( 't44', 277, [], [], 'fam1', 1 ).
test( 't45', 785, ['m1'], ['r3','r2','r1'], 'fam1', 1 ).
test( 't46', 443, [], [], 'fam1', 1 ).
test( 't47', 88, ['m4','m8'], [], 'fam1', 1 ).
test( 't48', 612, ['m1','m2','m10'], [], 'fam1', 1 ).
test( 't49', 145, [], [], 'fam1', 1 ).
test( 't50', 352, [], [], 'fam1', 1 ).
test( 't51', 166, [], ['r4','r2'], 'fam1', 1 ).
test( 't52', 60, [], [], 'fam1', 1 ).
test( 't53', 629, ['m4','m1'], [], 'fam1', 1 ).
test( 't54', 199, ['m5','m2','m6','m10'], [], 'fam1', 1 ).
test( 't55', 40, [], ['r3','r2'], 'fam1', 1 ).
test( 't56', 583, [], [], 'fam1', 1 ).
test( 't57', 610, [], ['r1','r4','r3'], 'fam1', 1 ).
test( 't58', 729, [], [], 'fam1', 1 ).
test( 't59', 136, [], [], 'fam1', 1 ).
test( 't60', 9, [], [], 'fam1', 1 ).
test( 't61', 298, [], ['r4','r3','r2','r1','r5'], 'fam1', 1 ).
test( 't62', 209, ['m2'], ['r1'], 'fam1', 1 ).
test( 't63', 712, [], [], 'fam1', 1 ).
test( 't64', 427, [], [], 'fam1', 1 ).
test( 't65', 282, [], [], 'fam1', 1 ).
test( 't66', 408, [], [], 'fam1', 1 ).
test( 't67', 299, [], ['r4','r3'], 'fam1', 1 ).
test( 't68', 727, [], [], 'fam1', 1 ).
test( 't69', 675, [], [], 'fam1', 1 ).
test( 't70', 704, [], [], 'fam1', 1 ).
test( 't71', 358, [], [], 'fam1', 1 ).
test( 't72', 439, [], [], 'fam1', 1 ).
test( 't73', 241, [], ['r3','r1','r2','r5'], 'fam1', 1 ).
test( 't74', 269, [], ['r5','r3'], 'fam1', 1 ).
test( 't75', 305, [], ['r2'], 'fam1', 1 ).
test( 't76', 630, ['m8','m7','m10','m9'], [], 'fam1', 1 ).
test( 't77', 642, [], [], 'fam1', 1 ).
test( 't78', 543, [], [], 'fam1', 1 ).
test( 't79', 297, [], ['r2','r3'], 'fam1', 1 ).
test( 't80', 175, [], [], 'fam1', 1 ).
test( 't81', 542, ['m1','m2','m4'], ['r1','r3','r4','r5','r2'], 'fam1', 1 ).
test( 't82', 550, ['m7','m8','m4','m2'], [], 'fam1', 1 ).
test( 't83', 773, [], ['r1','r5','r2','r3','r4'], 'fam1', 1 ).
test( 't84', 627, [], ['r2','r5'], 'fam1', 1 ).
test( 't85', 517, [], [], 'fam1', 1 ).
test( 't86', 295, [], [], 'fam1', 1 ).
test( 't87', 17, [], [], 'fam1', 1 ).
test( 't88', 563, [], [], 'fam1', 1 ).
test( 't89', 782, [], ['r5','r1'], 'fam1', 1 ).
test( 't90', 494, [], [], 'fam1', 1 ).
test( 't91', 106, ['m3'], [], 'fam1', 1 ).
test( 't92', 359, [], ['r5','r3','r1','r4','r2'], 'fam1', 1 ).
test( 't93', 380, [], [], 'fam1', 1 ).
test( 't94', 353, [], [], 'fam1', 1 ).
test( 't95', 752, [], ['r1'], 'fam1', 1 ).
test( 't96', 314, [], ['r4','r5','r3'], 'fam1', 1 ).
test( 't97', 229, [], ['r4','r5','r2','r1'], 'fam1', 1 ).
test( 't98', 289, [], [], 'fam1', 1 ).
test( 't99', 570, [], [], 'fam1', 1 ).
test( 't100', 506, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
