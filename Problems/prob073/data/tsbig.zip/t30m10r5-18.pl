%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 707, [], [], 'fam1', 1 ).
test( 't2', 734, [], [], 'fam1', 1 ).
test( 't3', 529, [], [], 'fam1', 1 ).
test( 't4', 432, [], ['r5','r4','r3','r2','r1'], 'fam1', 1 ).
test( 't5', 669, [], [], 'fam1', 1 ).
test( 't6', 801, [], [], 'fam1', 1 ).
test( 't7', 794, ['m5'], [], 'fam1', 1 ).
test( 't8', 407, [], ['r1'], 'fam1', 1 ).
test( 't9', 375, [], [], 'fam1', 1 ).
test( 't10', 566, [], [], 'fam1', 1 ).
test( 't11', 582, [], ['r4','r2','r3','r5','r1'], 'fam1', 1 ).
test( 't12', 457, [], ['r4'], 'fam1', 1 ).
test( 't13', 27, [], [], 'fam1', 1 ).
test( 't14', 344, [], [], 'fam1', 1 ).
test( 't15', 504, ['m8'], ['r3','r5'], 'fam1', 1 ).
test( 't16', 775, [], [], 'fam1', 1 ).
test( 't17', 688, [], [], 'fam1', 1 ).
test( 't18', 404, ['m10'], [], 'fam1', 1 ).
test( 't19', 722, [], [], 'fam1', 1 ).
test( 't20', 484, [], [], 'fam1', 1 ).
test( 't21', 342, [], ['r4'], 'fam1', 1 ).
test( 't22', 88, [], [], 'fam1', 1 ).
test( 't23', 54, [], [], 'fam1', 1 ).
test( 't24', 492, [], ['r5','r1','r3'], 'fam1', 1 ).
test( 't25', 227, [], [], 'fam1', 1 ).
test( 't26', 449, [], [], 'fam1', 1 ).
test( 't27', 23, [], [], 'fam1', 1 ).
test( 't28', 385, [], [], 'fam1', 1 ).
test( 't29', 159, [], ['r4','r5','r2'], 'fam1', 1 ).
test( 't30', 537, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
