%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 20
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 474, [], [], 'fam1', 1 ).
test( 't2', 405, ['m9','m10','m4','m12','m5','m18','m8','m1'], [], 'fam1', 1 ).
test( 't3', 667, [], [], 'fam1', 1 ).
test( 't4', 368, [], ['r3','r1'], 'fam1', 1 ).
test( 't5', 355, [], [], 'fam1', 1 ).
test( 't6', 46, [], ['r1'], 'fam1', 1 ).
test( 't7', 582, ['m2','m6'], [], 'fam1', 1 ).
test( 't8', 564, [], [], 'fam1', 1 ).
test( 't9', 419, ['m17','m1','m14'], [], 'fam1', 1 ).
test( 't10', 48, [], [], 'fam1', 1 ).
test( 't11', 475, [], [], 'fam1', 1 ).
test( 't12', 187, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't13', 177, ['m12','m10','m17','m19','m9'], [], 'fam1', 1 ).
test( 't14', 425, [], [], 'fam1', 1 ).
test( 't15', 789, [], ['r1'], 'fam1', 1 ).
test( 't16', 624, ['m10'], [], 'fam1', 1 ).
test( 't17', 104, [], ['r3'], 'fam1', 1 ).
test( 't18', 574, ['m7','m17','m8','m20'], [], 'fam1', 1 ).
test( 't19', 328, [], [], 'fam1', 1 ).
test( 't20', 658, [], [], 'fam1', 1 ).
test( 't21', 568, ['m9','m19','m10','m16','m7','m18','m14','m8'], ['r2','r3'], 'fam1', 1 ).
test( 't22', 703, [], [], 'fam1', 1 ).
test( 't23', 182, [], [], 'fam1', 1 ).
test( 't24', 357, [], [], 'fam1', 1 ).
test( 't25', 573, [], [], 'fam1', 1 ).
test( 't26', 664, ['m5','m19','m1','m20'], [], 'fam1', 1 ).
test( 't27', 232, ['m6'], [], 'fam1', 1 ).
test( 't28', 167, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't29', 481, [], ['r1'], 'fam1', 1 ).
test( 't30', 349, [], ['r3'], 'fam1', 1 ).
test( 't31', 394, ['m17','m3','m6','m7','m2','m20','m11','m18'], [], 'fam1', 1 ).
test( 't32', 531, [], ['r2'], 'fam1', 1 ).
test( 't33', 650, [], [], 'fam1', 1 ).
test( 't34', 520, [], [], 'fam1', 1 ).
test( 't35', 36, [], [], 'fam1', 1 ).
test( 't36', 395, [], [], 'fam1', 1 ).
test( 't37', 398, [], ['r3','r1'], 'fam1', 1 ).
test( 't38', 155, [], ['r2','r3'], 'fam1', 1 ).
test( 't39', 307, ['m14','m20','m4','m7','m10'], [], 'fam1', 1 ).
test( 't40', 143, [], [], 'fam1', 1 ).
test( 't41', 788, ['m19'], [], 'fam1', 1 ).
test( 't42', 623, ['m3','m11','m13','m8','m2','m1','m10','m4'], [], 'fam1', 1 ).
test( 't43', 712, [], [], 'fam1', 1 ).
test( 't44', 735, ['m19','m12','m1','m7','m9','m11','m16','m10'], [], 'fam1', 1 ).
test( 't45', 772, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't46', 381, [], [], 'fam1', 1 ).
test( 't47', 527, ['m15','m12','m10'], [], 'fam1', 1 ).
test( 't48', 489, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't49', 263, [], [], 'fam1', 1 ).
test( 't50', 386, [], [], 'fam1', 1 ).
test( 't51', 763, [], [], 'fam1', 1 ).
test( 't52', 418, [], [], 'fam1', 1 ).
test( 't53', 209, [], [], 'fam1', 1 ).
test( 't54', 380, [], ['r1'], 'fam1', 1 ).
test( 't55', 680, [], ['r1','r3'], 'fam1', 1 ).
test( 't56', 569, [], [], 'fam1', 1 ).
test( 't57', 744, [], [], 'fam1', 1 ).
test( 't58', 178, [], [], 'fam1', 1 ).
test( 't59', 537, [], [], 'fam1', 1 ).
test( 't60', 155, ['m8','m6','m10','m17','m5','m15','m16'], [], 'fam1', 1 ).
test( 't61', 506, ['m16','m13','m20','m4'], [], 'fam1', 1 ).
test( 't62', 468, [], [], 'fam1', 1 ).
test( 't63', 562, [], [], 'fam1', 1 ).
test( 't64', 710, ['m12','m9','m20','m11','m4','m1'], [], 'fam1', 1 ).
test( 't65', 747, ['m12','m6','m3'], [], 'fam1', 1 ).
test( 't66', 440, ['m5','m12','m9','m14','m1','m11','m16'], [], 'fam1', 1 ).
test( 't67', 642, [], [], 'fam1', 1 ).
test( 't68', 716, ['m7','m12','m11','m17','m2','m16','m6','m10'], [], 'fam1', 1 ).
test( 't69', 135, [], ['r2','r3'], 'fam1', 1 ).
test( 't70', 336, [], [], 'fam1', 1 ).
test( 't71', 344, [], [], 'fam1', 1 ).
test( 't72', 587, [], ['r2'], 'fam1', 1 ).
test( 't73', 733, ['m6','m9'], [], 'fam1', 1 ).
test( 't74', 379, [], [], 'fam1', 1 ).
test( 't75', 790, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't76', 719, ['m8','m5','m16','m13','m20','m14','m10'], [], 'fam1', 1 ).
test( 't77', 777, [], [], 'fam1', 1 ).
test( 't78', 717, [], [], 'fam1', 1 ).
test( 't79', 769, [], ['r3','r1'], 'fam1', 1 ).
test( 't80', 481, [], [], 'fam1', 1 ).
test( 't81', 171, [], [], 'fam1', 1 ).
test( 't82', 624, [], [], 'fam1', 1 ).
test( 't83', 109, ['m9','m12','m1','m20','m13','m15','m2'], ['r1'], 'fam1', 1 ).
test( 't84', 648, ['m12','m2','m14','m16','m11'], [], 'fam1', 1 ).
test( 't85', 681, [], [], 'fam1', 1 ).
test( 't86', 309, [], [], 'fam1', 1 ).
test( 't87', 438, [], [], 'fam1', 1 ).
test( 't88', 681, [], [], 'fam1', 1 ).
test( 't89', 366, [], [], 'fam1', 1 ).
test( 't90', 66, ['m20','m19','m7','m1','m10','m9','m8','m12'], ['r1'], 'fam1', 1 ).
test( 't91', 331, [], [], 'fam1', 1 ).
test( 't92', 142, ['m19'], [], 'fam1', 1 ).
test( 't93', 358, [], [], 'fam1', 1 ).
test( 't94', 374, [], [], 'fam1', 1 ).
test( 't95', 241, [], [], 'fam1', 1 ).
test( 't96', 321, [], [], 'fam1', 1 ).
test( 't97', 21, ['m17','m18','m5','m3','m6','m20','m14','m11'], ['r2','r3','r1'], 'fam1', 1 ).
test( 't98', 793, [], [], 'fam1', 1 ).
test( 't99', 535, ['m10','m8','m12','m6','m4','m17','m16','m18'], [], 'fam1', 1 ).
test( 't100', 647, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
