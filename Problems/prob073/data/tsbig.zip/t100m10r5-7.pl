%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 544, ['m8'], [], 'fam1', 1 ).
test( 't2', 511, [], ['r5','r2'], 'fam1', 1 ).
test( 't3', 764, [], [], 'fam1', 1 ).
test( 't4', 416, ['m2'], [], 'fam1', 1 ).
test( 't5', 557, [], ['r3','r1'], 'fam1', 1 ).
test( 't6', 325, [], [], 'fam1', 1 ).
test( 't7', 360, ['m8','m10'], [], 'fam1', 1 ).
test( 't8', 695, ['m2','m9'], [], 'fam1', 1 ).
test( 't9', 46, [], [], 'fam1', 1 ).
test( 't10', 20, ['m8','m1','m10'], [], 'fam1', 1 ).
test( 't11', 431, [], [], 'fam1', 1 ).
test( 't12', 428, [], ['r4','r1'], 'fam1', 1 ).
test( 't13', 357, [], [], 'fam1', 1 ).
test( 't14', 75, [], [], 'fam1', 1 ).
test( 't15', 468, ['m1','m2'], ['r5','r1'], 'fam1', 1 ).
test( 't16', 285, [], [], 'fam1', 1 ).
test( 't17', 506, [], [], 'fam1', 1 ).
test( 't18', 770, [], ['r2','r3'], 'fam1', 1 ).
test( 't19', 211, [], [], 'fam1', 1 ).
test( 't20', 116, [], [], 'fam1', 1 ).
test( 't21', 55, [], [], 'fam1', 1 ).
test( 't22', 250, ['m4'], [], 'fam1', 1 ).
test( 't23', 136, [], [], 'fam1', 1 ).
test( 't24', 307, [], [], 'fam1', 1 ).
test( 't25', 687, [], ['r4','r2','r5','r1'], 'fam1', 1 ).
test( 't26', 83, [], [], 'fam1', 1 ).
test( 't27', 334, [], [], 'fam1', 1 ).
test( 't28', 707, [], ['r3'], 'fam1', 1 ).
test( 't29', 124, [], [], 'fam1', 1 ).
test( 't30', 511, [], [], 'fam1', 1 ).
test( 't31', 753, [], [], 'fam1', 1 ).
test( 't32', 786, [], [], 'fam1', 1 ).
test( 't33', 421, [], ['r5'], 'fam1', 1 ).
test( 't34', 766, [], [], 'fam1', 1 ).
test( 't35', 312, [], [], 'fam1', 1 ).
test( 't36', 699, [], [], 'fam1', 1 ).
test( 't37', 560, ['m4','m5'], [], 'fam1', 1 ).
test( 't38', 399, [], [], 'fam1', 1 ).
test( 't39', 280, [], [], 'fam1', 1 ).
test( 't40', 449, [], [], 'fam1', 1 ).
test( 't41', 686, [], [], 'fam1', 1 ).
test( 't42', 493, [], [], 'fam1', 1 ).
test( 't43', 333, [], ['r4','r2','r1'], 'fam1', 1 ).
test( 't44', 520, [], [], 'fam1', 1 ).
test( 't45', 475, [], ['r1','r2'], 'fam1', 1 ).
test( 't46', 347, [], [], 'fam1', 1 ).
test( 't47', 114, ['m10','m4','m7','m3'], ['r4','r1','r5','r3'], 'fam1', 1 ).
test( 't48', 120, [], [], 'fam1', 1 ).
test( 't49', 515, [], [], 'fam1', 1 ).
test( 't50', 607, [], [], 'fam1', 1 ).
test( 't51', 724, [], ['r2','r3'], 'fam1', 1 ).
test( 't52', 659, [], [], 'fam1', 1 ).
test( 't53', 151, [], [], 'fam1', 1 ).
test( 't54', 586, [], [], 'fam1', 1 ).
test( 't55', 617, [], [], 'fam1', 1 ).
test( 't56', 189, [], ['r2','r1','r3','r4'], 'fam1', 1 ).
test( 't57', 43, [], ['r2','r3','r5'], 'fam1', 1 ).
test( 't58', 680, [], ['r1','r5','r4','r2','r3'], 'fam1', 1 ).
test( 't59', 243, [], [], 'fam1', 1 ).
test( 't60', 192, [], [], 'fam1', 1 ).
test( 't61', 413, [], [], 'fam1', 1 ).
test( 't62', 316, [], ['r4','r5','r2','r1','r3'], 'fam1', 1 ).
test( 't63', 248, [], ['r1','r3'], 'fam1', 1 ).
test( 't64', 593, [], [], 'fam1', 1 ).
test( 't65', 472, [], ['r3','r5','r2','r4'], 'fam1', 1 ).
test( 't66', 25, [], [], 'fam1', 1 ).
test( 't67', 358, [], [], 'fam1', 1 ).
test( 't68', 61, [], [], 'fam1', 1 ).
test( 't69', 788, [], [], 'fam1', 1 ).
test( 't70', 269, [], [], 'fam1', 1 ).
test( 't71', 635, [], ['r3','r5'], 'fam1', 1 ).
test( 't72', 71, [], [], 'fam1', 1 ).
test( 't73', 89, [], [], 'fam1', 1 ).
test( 't74', 406, [], ['r4','r3'], 'fam1', 1 ).
test( 't75', 540, [], ['r5','r4','r3'], 'fam1', 1 ).
test( 't76', 197, ['m10'], ['r1'], 'fam1', 1 ).
test( 't77', 402, [], [], 'fam1', 1 ).
test( 't78', 527, [], [], 'fam1', 1 ).
test( 't79', 458, ['m10','m1','m7'], [], 'fam1', 1 ).
test( 't80', 282, [], [], 'fam1', 1 ).
test( 't81', 159, [], ['r3','r1','r4','r2'], 'fam1', 1 ).
test( 't82', 533, [], ['r2','r4','r1'], 'fam1', 1 ).
test( 't83', 240, [], ['r1','r5','r2','r4'], 'fam1', 1 ).
test( 't84', 110, [], [], 'fam1', 1 ).
test( 't85', 596, [], [], 'fam1', 1 ).
test( 't86', 483, ['m10','m9','m1'], ['r5','r2','r3'], 'fam1', 1 ).
test( 't87', 525, [], [], 'fam1', 1 ).
test( 't88', 384, [], [], 'fam1', 1 ).
test( 't89', 71, ['m9','m6','m1'], ['r1','r4','r2','r5'], 'fam1', 1 ).
test( 't90', 606, [], [], 'fam1', 1 ).
test( 't91', 32, [], ['r3','r5','r2','r1','r4'], 'fam1', 1 ).
test( 't92', 45, [], ['r4','r1'], 'fam1', 1 ).
test( 't93', 589, [], ['r3','r1','r4','r5','r2'], 'fam1', 1 ).
test( 't94', 555, [], [], 'fam1', 1 ).
test( 't95', 75, [], [], 'fam1', 1 ).
test( 't96', 433, ['m7','m2','m4'], ['r4','r1'], 'fam1', 1 ).
test( 't97', 319, [], [], 'fam1', 1 ).
test( 't98', 721, [], [], 'fam1', 1 ).
test( 't99', 689, [], [], 'fam1', 1 ).
test( 't100', 79, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
