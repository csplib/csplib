%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 383, ['m5','m10','m7'], ['r1'], 'fam1', 1 ).
test( 't2', 645, [], [], 'fam1', 1 ).
test( 't3', 25, [], [], 'fam1', 1 ).
test( 't4', 591, ['m1','m2','m3'], [], 'fam1', 1 ).
test( 't5', 634, [], [], 'fam1', 1 ).
test( 't6', 707, [], [], 'fam1', 1 ).
test( 't7', 702, [], ['r2','r3'], 'fam1', 1 ).
test( 't8', 268, [], [], 'fam1', 1 ).
test( 't9', 313, [], [], 'fam1', 1 ).
test( 't10', 657, [], [], 'fam1', 1 ).
test( 't11', 83, [], [], 'fam1', 1 ).
test( 't12', 584, [], [], 'fam1', 1 ).
test( 't13', 173, [], [], 'fam1', 1 ).
test( 't14', 630, [], [], 'fam1', 1 ).
test( 't15', 727, [], ['r1'], 'fam1', 1 ).
test( 't16', 286, ['m2'], [], 'fam1', 1 ).
test( 't17', 574, [], [], 'fam1', 1 ).
test( 't18', 99, [], [], 'fam1', 1 ).
test( 't19', 420, [], [], 'fam1', 1 ).
test( 't20', 516, [], [], 'fam1', 1 ).
test( 't21', 63, ['m1','m4','m7','m6'], ['r3','r2','r1'], 'fam1', 1 ).
test( 't22', 156, ['m5'], [], 'fam1', 1 ).
test( 't23', 492, ['m2','m8'], [], 'fam1', 1 ).
test( 't24', 314, [], [], 'fam1', 1 ).
test( 't25', 329, [], [], 'fam1', 1 ).
test( 't26', 548, [], ['r2','r3'], 'fam1', 1 ).
test( 't27', 584, [], [], 'fam1', 1 ).
test( 't28', 7, [], [], 'fam1', 1 ).
test( 't29', 309, [], ['r3','r2'], 'fam1', 1 ).
test( 't30', 405, [], ['r3','r1','r2'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
