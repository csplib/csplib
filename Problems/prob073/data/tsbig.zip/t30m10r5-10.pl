%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 693, [], ['r2','r5','r3','r1'], 'fam1', 1 ).
test( 't2', 297, ['m5','m9'], ['r4'], 'fam1', 1 ).
test( 't3', 169, [], [], 'fam1', 1 ).
test( 't4', 683, [], [], 'fam1', 1 ).
test( 't5', 321, ['m2'], [], 'fam1', 1 ).
test( 't6', 229, ['m4','m5','m1','m10'], [], 'fam1', 1 ).
test( 't7', 574, ['m5','m3','m6','m1'], [], 'fam1', 1 ).
test( 't8', 780, [], ['r3','r4','r1','r2','r5'], 'fam1', 1 ).
test( 't9', 220, [], [], 'fam1', 1 ).
test( 't10', 677, ['m7'], [], 'fam1', 1 ).
test( 't11', 671, [], [], 'fam1', 1 ).
test( 't12', 8, ['m8','m4'], ['r4','r2','r5','r3'], 'fam1', 1 ).
test( 't13', 681, [], [], 'fam1', 1 ).
test( 't14', 26, ['m8'], [], 'fam1', 1 ).
test( 't15', 327, [], [], 'fam1', 1 ).
test( 't16', 18, [], ['r5','r4','r2','r3','r1'], 'fam1', 1 ).
test( 't17', 732, [], ['r2','r5','r1'], 'fam1', 1 ).
test( 't18', 377, [], ['r4','r5','r3','r1'], 'fam1', 1 ).
test( 't19', 108, ['m1','m6','m4'], [], 'fam1', 1 ).
test( 't20', 395, ['m1','m4','m7','m2'], ['r1'], 'fam1', 1 ).
test( 't21', 629, [], [], 'fam1', 1 ).
test( 't22', 702, ['m6','m8','m10'], [], 'fam1', 1 ).
test( 't23', 493, ['m10','m4','m5'], [], 'fam1', 1 ).
test( 't24', 417, ['m9','m2','m6','m10'], [], 'fam1', 1 ).
test( 't25', 571, [], [], 'fam1', 1 ).
test( 't26', 161, [], [], 'fam1', 1 ).
test( 't27', 748, ['m4','m10'], ['r5','r2','r1'], 'fam1', 1 ).
test( 't28', 207, ['m5','m6','m2'], [], 'fam1', 1 ).
test( 't29', 283, [], [], 'fam1', 1 ).
test( 't30', 760, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
