%% ****  Testsuite  ****
% Number of tests                  : 20
% Number of machines               : 10
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 258, [], [], 'fam1', 1 ).
test( 't2', 696, [], ['r2','r4','r8','r10','r1'], 'fam1', 1 ).
test( 't3', 228, [], [], 'fam1', 1 ).
test( 't4', 479, [], [], 'fam1', 1 ).
test( 't5', 211, [], [], 'fam1', 1 ).
test( 't6', 701, [], ['r4','r3','r7','r9','r8','r10','r5'], 'fam1', 1 ).
test( 't7', 219, [], [], 'fam1', 1 ).
test( 't8', 280, ['m1','m4','m9','m6'], ['r2'], 'fam1', 1 ).
test( 't9', 121, [], [], 'fam1', 1 ).
test( 't10', 98, [], [], 'fam1', 1 ).
test( 't11', 20, [], ['r3','r10','r2','r7','r6'], 'fam1', 1 ).
test( 't12', 470, [], [], 'fam1', 1 ).
test( 't13', 620, [], [], 'fam1', 1 ).
test( 't14', 359, [], ['r9','r5','r4'], 'fam1', 1 ).
test( 't15', 623, [], [], 'fam1', 1 ).
test( 't16', 16, ['m9','m4','m2','m3'], [], 'fam1', 1 ).
test( 't17', 558, [], [], 'fam1', 1 ).
test( 't18', 354, [], ['r7','r10','r9','r1','r8','r4','r3'], 'fam1', 1 ).
test( 't19', 226, ['m9'], ['r10','r7'], 'fam1', 1 ).
test( 't20', 504, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
