%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 20
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 294, [], [], 'fam1', 1 ).
test( 't2', 333, ['m16','m13','m8','m15','m3','m19'], ['r4','r5','r2','r3','r1'], 'fam1', 1 ).
test( 't3', 161, [], [], 'fam1', 1 ).
test( 't4', 63, [], ['r3','r5','r2','r4'], 'fam1', 1 ).
test( 't5', 38, ['m5','m7','m14','m9'], ['r2','r3'], 'fam1', 1 ).
test( 't6', 477, [], [], 'fam1', 1 ).
test( 't7', 260, [], [], 'fam1', 1 ).
test( 't8', 194, [], [], 'fam1', 1 ).
test( 't9', 298, [], [], 'fam1', 1 ).
test( 't10', 95, ['m13','m20','m16','m18','m3','m8','m7'], [], 'fam1', 1 ).
test( 't11', 641, [], [], 'fam1', 1 ).
test( 't12', 214, [], ['r2','r5','r1','r3','r4'], 'fam1', 1 ).
test( 't13', 508, ['m15'], ['r1','r4','r3','r2','r5'], 'fam1', 1 ).
test( 't14', 586, [], [], 'fam1', 1 ).
test( 't15', 68, [], [], 'fam1', 1 ).
test( 't16', 196, [], [], 'fam1', 1 ).
test( 't17', 28, [], [], 'fam1', 1 ).
test( 't18', 386, [], [], 'fam1', 1 ).
test( 't19', 302, [], [], 'fam1', 1 ).
test( 't20', 446, [], [], 'fam1', 1 ).
test( 't21', 534, [], [], 'fam1', 1 ).
test( 't22', 221, [], [], 'fam1', 1 ).
test( 't23', 369, [], [], 'fam1', 1 ).
test( 't24', 249, [], ['r5','r2','r4'], 'fam1', 1 ).
test( 't25', 695, [], [], 'fam1', 1 ).
test( 't26', 458, [], ['r4'], 'fam1', 1 ).
test( 't27', 176, [], [], 'fam1', 1 ).
test( 't28', 622, ['m3','m5','m16','m20','m15','m17','m4'], [], 'fam1', 1 ).
test( 't29', 340, [], [], 'fam1', 1 ).
test( 't30', 549, [], [], 'fam1', 1 ).
test( 't31', 792, [], [], 'fam1', 1 ).
test( 't32', 100, [], [], 'fam1', 1 ).
test( 't33', 17, [], [], 'fam1', 1 ).
test( 't34', 453, [], ['r3','r2','r5'], 'fam1', 1 ).
test( 't35', 440, ['m8','m20','m6','m7','m11','m12','m4'], [], 'fam1', 1 ).
test( 't36', 578, [], [], 'fam1', 1 ).
test( 't37', 6, [], [], 'fam1', 1 ).
test( 't38', 28, [], [], 'fam1', 1 ).
test( 't39', 789, [], [], 'fam1', 1 ).
test( 't40', 358, [], ['r2','r4','r5'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
