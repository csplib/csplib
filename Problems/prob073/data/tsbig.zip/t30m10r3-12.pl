%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 373, [], [], 'fam1', 1 ).
test( 't2', 674, [], [], 'fam1', 1 ).
test( 't3', 677, [], [], 'fam1', 1 ).
test( 't4', 741, [], [], 'fam1', 1 ).
test( 't5', 643, [], [], 'fam1', 1 ).
test( 't6', 7, ['m1'], [], 'fam1', 1 ).
test( 't7', 706, [], [], 'fam1', 1 ).
test( 't8', 504, [], [], 'fam1', 1 ).
test( 't9', 125, [], [], 'fam1', 1 ).
test( 't10', 97, [], [], 'fam1', 1 ).
test( 't11', 254, ['m10','m2','m8'], [], 'fam1', 1 ).
test( 't12', 242, [], [], 'fam1', 1 ).
test( 't13', 4, [], [], 'fam1', 1 ).
test( 't14', 722, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't15', 590, [], [], 'fam1', 1 ).
test( 't16', 116, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't17', 270, [], ['r2'], 'fam1', 1 ).
test( 't18', 562, ['m7','m3','m1','m2'], ['r1'], 'fam1', 1 ).
test( 't19', 171, ['m6','m7','m5'], ['r2','r1','r3'], 'fam1', 1 ).
test( 't20', 86, ['m2','m3','m5','m1'], ['r1','r2'], 'fam1', 1 ).
test( 't21', 765, [], ['r2'], 'fam1', 1 ).
test( 't22', 694, ['m4','m5','m2','m7'], [], 'fam1', 1 ).
test( 't23', 21, [], [], 'fam1', 1 ).
test( 't24', 462, ['m10','m2','m5','m7'], [], 'fam1', 1 ).
test( 't25', 710, ['m6','m5','m4'], [], 'fam1', 1 ).
test( 't26', 556, [], [], 'fam1', 1 ).
test( 't27', 184, [], [], 'fam1', 1 ).
test( 't28', 450, [], [], 'fam1', 1 ).
test( 't29', 477, [], [], 'fam1', 1 ).
test( 't30', 791, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
