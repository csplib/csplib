%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 157, [], ['r5','r2','r4','r3','r1'], 'fam1', 1 ).
test( 't2', 234, [], [], 'fam1', 1 ).
test( 't3', 96, [], [], 'fam1', 1 ).
test( 't4', 687, [], [], 'fam1', 1 ).
test( 't5', 290, [], ['r2','r4','r3'], 'fam1', 1 ).
test( 't6', 169, [], [], 'fam1', 1 ).
test( 't7', 752, ['m7'], [], 'fam1', 1 ).
test( 't8', 472, [], [], 'fam1', 1 ).
test( 't9', 783, [], ['r4'], 'fam1', 1 ).
test( 't10', 269, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't11', 609, [], [], 'fam1', 1 ).
test( 't12', 215, [], [], 'fam1', 1 ).
test( 't13', 63, ['m2','m3'], [], 'fam1', 1 ).
test( 't14', 87, [], [], 'fam1', 1 ).
test( 't15', 7, [], [], 'fam1', 1 ).
test( 't16', 115, [], [], 'fam1', 1 ).
test( 't17', 130, [], [], 'fam1', 1 ).
test( 't18', 118, ['m10','m4','m9','m2'], [], 'fam1', 1 ).
test( 't19', 115, ['m5','m2','m7'], [], 'fam1', 1 ).
test( 't20', 59, [], ['r2','r4','r5'], 'fam1', 1 ).
test( 't21', 378, [], [], 'fam1', 1 ).
test( 't22', 431, [], [], 'fam1', 1 ).
test( 't23', 282, [], ['r5','r1','r3'], 'fam1', 1 ).
test( 't24', 29, [], [], 'fam1', 1 ).
test( 't25', 760, [], [], 'fam1', 1 ).
test( 't26', 252, [], [], 'fam1', 1 ).
test( 't27', 51, [], [], 'fam1', 1 ).
test( 't28', 672, ['m5','m1','m9','m10'], [], 'fam1', 1 ).
test( 't29', 458, ['m9','m6','m7'], [], 'fam1', 1 ).
test( 't30', 572, [], [], 'fam1', 1 ).
test( 't31', 138, [], [], 'fam1', 1 ).
test( 't32', 417, [], [], 'fam1', 1 ).
test( 't33', 457, ['m1','m10'], [], 'fam1', 1 ).
test( 't34', 404, [], ['r3','r2','r1','r5','r4'], 'fam1', 1 ).
test( 't35', 614, ['m4','m6','m10','m8'], ['r4','r2','r5','r1'], 'fam1', 1 ).
test( 't36', 648, [], [], 'fam1', 1 ).
test( 't37', 430, ['m4','m3','m1'], [], 'fam1', 1 ).
test( 't38', 85, ['m6','m9','m7','m2'], [], 'fam1', 1 ).
test( 't39', 173, [], ['r1'], 'fam1', 1 ).
test( 't40', 795, ['m3','m1'], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
