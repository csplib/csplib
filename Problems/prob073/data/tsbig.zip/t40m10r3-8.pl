%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 306, [], [], 'fam1', 1 ).
test( 't2', 89, [], [], 'fam1', 1 ).
test( 't3', 630, [], ['r3','r2'], 'fam1', 1 ).
test( 't4', 35, [], [], 'fam1', 1 ).
test( 't5', 75, [], [], 'fam1', 1 ).
test( 't6', 698, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't7', 529, [], [], 'fam1', 1 ).
test( 't8', 669, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't9', 521, [], [], 'fam1', 1 ).
test( 't10', 30, [], [], 'fam1', 1 ).
test( 't11', 184, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't12', 67, [], [], 'fam1', 1 ).
test( 't13', 417, ['m8','m3','m4','m10'], [], 'fam1', 1 ).
test( 't14', 797, ['m4','m2','m9','m1'], [], 'fam1', 1 ).
test( 't15', 229, [], [], 'fam1', 1 ).
test( 't16', 306, [], [], 'fam1', 1 ).
test( 't17', 143, [], [], 'fam1', 1 ).
test( 't18', 427, [], ['r3'], 'fam1', 1 ).
test( 't19', 717, [], [], 'fam1', 1 ).
test( 't20', 701, [], [], 'fam1', 1 ).
test( 't21', 163, ['m1','m5'], [], 'fam1', 1 ).
test( 't22', 781, [], [], 'fam1', 1 ).
test( 't23', 82, [], [], 'fam1', 1 ).
test( 't24', 416, ['m4'], [], 'fam1', 1 ).
test( 't25', 554, ['m1','m5','m3'], ['r2','r3','r1'], 'fam1', 1 ).
test( 't26', 695, ['m2','m8'], [], 'fam1', 1 ).
test( 't27', 290, [], [], 'fam1', 1 ).
test( 't28', 691, [], [], 'fam1', 1 ).
test( 't29', 606, [], [], 'fam1', 1 ).
test( 't30', 447, [], ['r2'], 'fam1', 1 ).
test( 't31', 736, [], [], 'fam1', 1 ).
test( 't32', 182, [], [], 'fam1', 1 ).
test( 't33', 153, [], [], 'fam1', 1 ).
test( 't34', 511, [], [], 'fam1', 1 ).
test( 't35', 692, [], [], 'fam1', 1 ).
test( 't36', 380, [], ['r3','r2'], 'fam1', 1 ).
test( 't37', 399, [], [], 'fam1', 1 ).
test( 't38', 685, [], [], 'fam1', 1 ).
test( 't39', 744, [], [], 'fam1', 1 ).
test( 't40', 96, [], ['r3','r2','r1'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
