%% ****  Testsuite  ****
% Number of tests                  : 20
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 779, [], ['r3'], 'fam1', 1 ).
test( 't2', 209, [], [], 'fam1', 1 ).
test( 't3', 56, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't4', 294, [], [], 'fam1', 1 ).
test( 't5', 320, ['m6','m9'], [], 'fam1', 1 ).
test( 't6', 629, [], [], 'fam1', 1 ).
test( 't7', 87, ['m10','m3','m9'], ['r2','r1'], 'fam1', 1 ).
test( 't8', 472, [], [], 'fam1', 1 ).
test( 't9', 455, [], [], 'fam1', 1 ).
test( 't10', 92, [], [], 'fam1', 1 ).
test( 't11', 353, ['m7','m1'], [], 'fam1', 1 ).
test( 't12', 479, ['m2','m7','m8'], [], 'fam1', 1 ).
test( 't13', 738, [], [], 'fam1', 1 ).
test( 't14', 500, ['m8'], [], 'fam1', 1 ).
test( 't15', 563, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't16', 758, [], [], 'fam1', 1 ).
test( 't17', 554, [], [], 'fam1', 1 ).
test( 't18', 52, [], [], 'fam1', 1 ).
test( 't19', 433, ['m8','m7','m3','m6'], [], 'fam1', 1 ).
test( 't20', 242, [], ['r2','r1','r3'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
