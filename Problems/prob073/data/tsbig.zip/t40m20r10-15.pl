%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 20
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 710, [], [], 'fam1', 1 ).
test( 't2', 2, [], [], 'fam1', 1 ).
test( 't3', 176, [], [], 'fam1', 1 ).
test( 't4', 525, [], [], 'fam1', 1 ).
test( 't5', 289, [], [], 'fam1', 1 ).
test( 't6', 411, ['m13','m11','m12'], [], 'fam1', 1 ).
test( 't7', 638, [], [], 'fam1', 1 ).
test( 't8', 118, [], ['r7','r2','r5','r3','r9','r4','r1'], 'fam1', 1 ).
test( 't9', 761, [], ['r5','r9','r3'], 'fam1', 1 ).
test( 't10', 702, [], [], 'fam1', 1 ).
test( 't11', 369, ['m2','m18','m15','m19'], ['r3','r5','r9','r7','r10','r2'], 'fam1', 1 ).
test( 't12', 649, [], ['r10','r5'], 'fam1', 1 ).
test( 't13', 680, [], [], 'fam1', 1 ).
test( 't14', 134, [], ['r5','r4','r3','r8'], 'fam1', 1 ).
test( 't15', 683, [], [], 'fam1', 1 ).
test( 't16', 328, [], [], 'fam1', 1 ).
test( 't17', 492, [], [], 'fam1', 1 ).
test( 't18', 767, [], [], 'fam1', 1 ).
test( 't19', 407, [], [], 'fam1', 1 ).
test( 't20', 411, [], [], 'fam1', 1 ).
test( 't21', 734, [], ['r4'], 'fam1', 1 ).
test( 't22', 364, [], [], 'fam1', 1 ).
test( 't23', 80, ['m12','m13','m16','m5','m6','m1','m14','m2'], ['r9','r3','r6','r7','r10','r4'], 'fam1', 1 ).
test( 't24', 799, [], [], 'fam1', 1 ).
test( 't25', 373, [], [], 'fam1', 1 ).
test( 't26', 478, [], [], 'fam1', 1 ).
test( 't27', 429, [], [], 'fam1', 1 ).
test( 't28', 121, [], [], 'fam1', 1 ).
test( 't29', 79, [], ['r3','r6','r5','r8','r9','r7','r1','r2'], 'fam1', 1 ).
test( 't30', 594, [], ['r6','r3','r7','r1','r10','r2','r5','r9'], 'fam1', 1 ).
test( 't31', 676, ['m19','m18','m10','m6','m16'], [], 'fam1', 1 ).
test( 't32', 215, [], [], 'fam1', 1 ).
test( 't33', 288, [], [], 'fam1', 1 ).
test( 't34', 647, [], [], 'fam1', 1 ).
test( 't35', 340, [], [], 'fam1', 1 ).
test( 't36', 790, [], [], 'fam1', 1 ).
test( 't37', 788, [], [], 'fam1', 1 ).
test( 't38', 384, ['m15','m4','m18','m7','m17'], ['r7','r4','r8','r10','r3','r5','r1','r9'], 'fam1', 1 ).
test( 't39', 432, [], [], 'fam1', 1 ).
test( 't40', 132, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
