%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 31, [], [], 'fam1', 1 ).
test( 't2', 397, ['m7','m6','m4','m9'], [], 'fam1', 1 ).
test( 't3', 599, ['m8'], [], 'fam1', 1 ).
test( 't4', 693, ['m6'], [], 'fam1', 1 ).
test( 't5', 166, [], [], 'fam1', 1 ).
test( 't6', 576, [], [], 'fam1', 1 ).
test( 't7', 625, [], [], 'fam1', 1 ).
test( 't8', 374, [], [], 'fam1', 1 ).
test( 't9', 453, [], [], 'fam1', 1 ).
test( 't10', 636, [], [], 'fam1', 1 ).
test( 't11', 678, ['m3','m1','m5','m9'], [], 'fam1', 1 ).
test( 't12', 67, [], ['r1','r3','r5'], 'fam1', 1 ).
test( 't13', 75, [], ['r4','r1','r5'], 'fam1', 1 ).
test( 't14', 33, ['m2','m7','m4'], [], 'fam1', 1 ).
test( 't15', 519, [], [], 'fam1', 1 ).
test( 't16', 783, [], [], 'fam1', 1 ).
test( 't17', 469, [], [], 'fam1', 1 ).
test( 't18', 31, [], [], 'fam1', 1 ).
test( 't19', 543, [], [], 'fam1', 1 ).
test( 't20', 445, [], ['r1'], 'fam1', 1 ).
test( 't21', 368, [], [], 'fam1', 1 ).
test( 't22', 666, [], ['r5','r2','r1'], 'fam1', 1 ).
test( 't23', 196, [], ['r4','r2','r5','r3','r1'], 'fam1', 1 ).
test( 't24', 398, [], [], 'fam1', 1 ).
test( 't25', 718, ['m9'], ['r1'], 'fam1', 1 ).
test( 't26', 341, [], [], 'fam1', 1 ).
test( 't27', 207, ['m2','m3','m4','m10'], [], 'fam1', 1 ).
test( 't28', 454, [], ['r1','r3','r4'], 'fam1', 1 ).
test( 't29', 645, [], ['r5','r3','r2','r1'], 'fam1', 1 ).
test( 't30', 423, [], ['r1','r5','r3','r4'], 'fam1', 1 ).
test( 't31', 21, [], [], 'fam1', 1 ).
test( 't32', 345, [], [], 'fam1', 1 ).
test( 't33', 501, [], [], 'fam1', 1 ).
test( 't34', 690, ['m7','m9'], ['r5'], 'fam1', 1 ).
test( 't35', 113, [], [], 'fam1', 1 ).
test( 't36', 660, [], [], 'fam1', 1 ).
test( 't37', 135, [], [], 'fam1', 1 ).
test( 't38', 424, [], [], 'fam1', 1 ).
test( 't39', 270, [], [], 'fam1', 1 ).
test( 't40', 295, [], [], 'fam1', 1 ).
test( 't41', 604, [], ['r2','r1'], 'fam1', 1 ).
test( 't42', 404, [], ['r4','r5','r2','r1'], 'fam1', 1 ).
test( 't43', 538, ['m2','m1','m5','m7'], [], 'fam1', 1 ).
test( 't44', 202, [], [], 'fam1', 1 ).
test( 't45', 652, [], [], 'fam1', 1 ).
test( 't46', 463, [], ['r2','r5','r3'], 'fam1', 1 ).
test( 't47', 300, [], [], 'fam1', 1 ).
test( 't48', 85, [], [], 'fam1', 1 ).
test( 't49', 190, [], [], 'fam1', 1 ).
test( 't50', 356, [], [], 'fam1', 1 ).
test( 't51', 142, [], [], 'fam1', 1 ).
test( 't52', 687, [], [], 'fam1', 1 ).
test( 't53', 531, [], [], 'fam1', 1 ).
test( 't54', 636, [], [], 'fam1', 1 ).
test( 't55', 770, [], ['r4','r2','r5','r3','r1'], 'fam1', 1 ).
test( 't56', 334, [], [], 'fam1', 1 ).
test( 't57', 254, [], [], 'fam1', 1 ).
test( 't58', 528, [], [], 'fam1', 1 ).
test( 't59', 357, [], [], 'fam1', 1 ).
test( 't60', 732, [], [], 'fam1', 1 ).
test( 't61', 681, [], ['r4','r2','r5'], 'fam1', 1 ).
test( 't62', 281, [], ['r3','r5','r2','r1','r4'], 'fam1', 1 ).
test( 't63', 110, [], [], 'fam1', 1 ).
test( 't64', 595, [], [], 'fam1', 1 ).
test( 't65', 542, [], ['r1','r2','r3','r4','r5'], 'fam1', 1 ).
test( 't66', 196, [], [], 'fam1', 1 ).
test( 't67', 355, [], [], 'fam1', 1 ).
test( 't68', 718, [], [], 'fam1', 1 ).
test( 't69', 651, [], [], 'fam1', 1 ).
test( 't70', 271, ['m4','m6'], ['r3','r4','r1','r5'], 'fam1', 1 ).
test( 't71', 391, [], [], 'fam1', 1 ).
test( 't72', 343, [], ['r5','r1'], 'fam1', 1 ).
test( 't73', 128, ['m1','m5','m6'], [], 'fam1', 1 ).
test( 't74', 395, ['m3','m7','m5'], [], 'fam1', 1 ).
test( 't75', 631, ['m10','m7'], ['r3','r1'], 'fam1', 1 ).
test( 't76', 189, ['m2','m1','m3','m9'], [], 'fam1', 1 ).
test( 't77', 779, [], [], 'fam1', 1 ).
test( 't78', 603, [], [], 'fam1', 1 ).
test( 't79', 483, [], [], 'fam1', 1 ).
test( 't80', 249, [], [], 'fam1', 1 ).
test( 't81', 512, [], [], 'fam1', 1 ).
test( 't82', 527, [], ['r4','r3','r1','r5','r2'], 'fam1', 1 ).
test( 't83', 30, [], [], 'fam1', 1 ).
test( 't84', 256, [], [], 'fam1', 1 ).
test( 't85', 75, ['m6','m7'], [], 'fam1', 1 ).
test( 't86', 483, [], [], 'fam1', 1 ).
test( 't87', 41, ['m3','m10','m4','m1'], [], 'fam1', 1 ).
test( 't88', 502, [], ['r2','r1','r5','r3','r4'], 'fam1', 1 ).
test( 't89', 402, ['m9'], ['r1'], 'fam1', 1 ).
test( 't90', 178, [], ['r3','r2'], 'fam1', 1 ).
test( 't91', 103, ['m10','m7'], ['r2','r5'], 'fam1', 1 ).
test( 't92', 738, [], [], 'fam1', 1 ).
test( 't93', 505, [], [], 'fam1', 1 ).
test( 't94', 220, [], ['r2'], 'fam1', 1 ).
test( 't95', 9, [], [], 'fam1', 1 ).
test( 't96', 727, [], [], 'fam1', 1 ).
test( 't97', 318, [], [], 'fam1', 1 ).
test( 't98', 6, [], ['r2','r3','r4','r1','r5'], 'fam1', 1 ).
test( 't99', 678, [], [], 'fam1', 1 ).
test( 't100', 788, [], ['r3','r5'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
