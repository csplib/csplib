%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 50
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 513, [], ['r8','r9','r4','r10','r7','r3','r6','r1','r5','r2'], 'fam1', 1 ).
test( 't2', 507, ['m23','m31','m18'], [], 'fam1', 1 ).
test( 't3', 719, [], [], 'fam1', 1 ).
test( 't4', 38, [], [], 'fam1', 1 ).
test( 't5', 127, [], [], 'fam1', 1 ).
test( 't6', 361, [], ['r8','r1','r4','r3'], 'fam1', 1 ).
test( 't7', 482, [], [], 'fam1', 1 ).
test( 't8', 474, [], ['r6'], 'fam1', 1 ).
test( 't9', 185, ['m9','m19','m12','m25','m26','m28'], [], 'fam1', 1 ).
test( 't10', 68, [], ['r3','r2','r4','r7','r10','r8','r6'], 'fam1', 1 ).
test( 't11', 77, ['m30','m42','m18','m43'], [], 'fam1', 1 ).
test( 't12', 392, ['m36','m44','m22','m26','m37','m23','m9','m11','m46','m18','m12','m47','m34','m39','m42','m28','m4','m20','m10','m40'], [], 'fam1', 1 ).
test( 't13', 436, [], [], 'fam1', 1 ).
test( 't14', 415, [], [], 'fam1', 1 ).
test( 't15', 668, [], ['r10','r1'], 'fam1', 1 ).
test( 't16', 352, [], [], 'fam1', 1 ).
test( 't17', 184, [], [], 'fam1', 1 ).
test( 't18', 612, [], [], 'fam1', 1 ).
test( 't19', 552, [], [], 'fam1', 1 ).
test( 't20', 501, [], [], 'fam1', 1 ).
test( 't21', 748, [], [], 'fam1', 1 ).
test( 't22', 47, [], [], 'fam1', 1 ).
test( 't23', 605, [], [], 'fam1', 1 ).
test( 't24', 632, [], [], 'fam1', 1 ).
test( 't25', 27, [], [], 'fam1', 1 ).
test( 't26', 716, [], [], 'fam1', 1 ).
test( 't27', 41, [], [], 'fam1', 1 ).
test( 't28', 189, [], [], 'fam1', 1 ).
test( 't29', 517, [], [], 'fam1', 1 ).
test( 't30', 678, [], [], 'fam1', 1 ).
test( 't31', 385, [], ['r4','r6','r10','r7'], 'fam1', 1 ).
test( 't32', 601, ['m9','m8'], [], 'fam1', 1 ).
test( 't33', 192, [], [], 'fam1', 1 ).
test( 't34', 409, ['m24','m11'], [], 'fam1', 1 ).
test( 't35', 55, [], [], 'fam1', 1 ).
test( 't36', 237, [], ['r5','r10','r7','r9','r1'], 'fam1', 1 ).
test( 't37', 121, [], [], 'fam1', 1 ).
test( 't38', 35, [], ['r9','r10','r8'], 'fam1', 1 ).
test( 't39', 589, [], [], 'fam1', 1 ).
test( 't40', 622, ['m1','m46'], [], 'fam1', 1 ).
test( 't41', 705, [], ['r9','r4','r5','r10','r8','r3','r2','r7','r1'], 'fam1', 1 ).
test( 't42', 244, [], ['r6','r3','r9','r5','r1','r8','r7','r4','r2','r10'], 'fam1', 1 ).
test( 't43', 269, ['m32','m6','m37','m43','m3','m42','m21','m5','m8','m27','m29','m19','m48','m10'], [], 'fam1', 1 ).
test( 't44', 667, [], ['r6','r9','r3','r2','r7','r8','r1','r5','r10','r4'], 'fam1', 1 ).
test( 't45', 149, [], ['r3'], 'fam1', 1 ).
test( 't46', 576, ['m33','m18','m43','m45','m28','m32','m46'], [], 'fam1', 1 ).
test( 't47', 633, [], [], 'fam1', 1 ).
test( 't48', 797, [], ['r8','r6','r7','r5'], 'fam1', 1 ).
test( 't49', 391, [], [], 'fam1', 1 ).
test( 't50', 413, [], [], 'fam1', 1 ).
test( 't51', 437, [], [], 'fam1', 1 ).
test( 't52', 71, [], [], 'fam1', 1 ).
test( 't53', 434, [], ['r6'], 'fam1', 1 ).
test( 't54', 217, ['m25','m4','m43','m7','m29','m2','m30','m10','m19','m20','m31','m41','m5','m46','m14','m34','m39','m23'], [], 'fam1', 1 ).
test( 't55', 252, [], [], 'fam1', 1 ).
test( 't56', 133, [], ['r4'], 'fam1', 1 ).
test( 't57', 681, [], [], 'fam1', 1 ).
test( 't58', 167, [], ['r10','r8','r6','r4','r5','r7','r1','r9','r2'], 'fam1', 1 ).
test( 't59', 544, [], [], 'fam1', 1 ).
test( 't60', 67, ['m17','m15','m31','m30','m9','m47','m4','m28','m23','m46','m3','m37','m20','m29','m12','m39','m1','m24','m33','m19'], [], 'fam1', 1 ).
test( 't61', 683, [], [], 'fam1', 1 ).
test( 't62', 307, [], [], 'fam1', 1 ).
test( 't63', 147, [], [], 'fam1', 1 ).
test( 't64', 195, [], [], 'fam1', 1 ).
test( 't65', 167, ['m14','m34','m37','m26','m1','m46','m31','m41','m21','m44','m32','m47','m45','m5','m6','m24','m33','m43'], [], 'fam1', 1 ).
test( 't66', 718, [], [], 'fam1', 1 ).
test( 't67', 415, [], ['r2','r5','r8','r1','r3','r10','r9','r6','r7'], 'fam1', 1 ).
test( 't68', 771, [], [], 'fam1', 1 ).
test( 't69', 34, [], [], 'fam1', 1 ).
test( 't70', 612, [], [], 'fam1', 1 ).
test( 't71', 460, [], [], 'fam1', 1 ).
test( 't72', 92, [], ['r1','r5','r7'], 'fam1', 1 ).
test( 't73', 126, [], [], 'fam1', 1 ).
test( 't74', 63, ['m31','m5','m20','m15','m30','m17','m21','m40','m11','m10','m36','m13','m14'], ['r6'], 'fam1', 1 ).
test( 't75', 313, [], [], 'fam1', 1 ).
test( 't76', 421, ['m9','m23','m21','m27','m12','m42','m46','m41','m28','m5','m26','m10','m11','m29','m14','m4','m17'], ['r6','r9','r2','r1','r10','r5','r8','r7','r3'], 'fam1', 1 ).
test( 't77', 751, [], [], 'fam1', 1 ).
test( 't78', 720, [], ['r5','r7','r4','r6','r1'], 'fam1', 1 ).
test( 't79', 221, [], ['r5','r7','r6','r8','r3','r4','r2','r10','r1','r9'], 'fam1', 1 ).
test( 't80', 350, [], [], 'fam1', 1 ).
test( 't81', 566, ['m31','m42','m27','m21'], [], 'fam1', 1 ).
test( 't82', 64, [], [], 'fam1', 1 ).
test( 't83', 793, [], [], 'fam1', 1 ).
test( 't84', 41, ['m20','m12','m36','m35'], ['r6','r5','r4','r3','r1','r7','r10','r2','r9'], 'fam1', 1 ).
test( 't85', 517, [], [], 'fam1', 1 ).
test( 't86', 788, [], ['r8','r7','r3','r9','r6'], 'fam1', 1 ).
test( 't87', 618, [], [], 'fam1', 1 ).
test( 't88', 667, ['m40'], [], 'fam1', 1 ).
test( 't89', 560, [], ['r1','r9','r3','r10','r7','r2','r4','r8','r6','r5'], 'fam1', 1 ).
test( 't90', 150, [], ['r7','r4','r8','r10','r9','r3'], 'fam1', 1 ).
test( 't91', 385, [], ['r4'], 'fam1', 1 ).
test( 't92', 4, [], [], 'fam1', 1 ).
test( 't93', 509, [], ['r6','r2','r3','r9'], 'fam1', 1 ).
test( 't94', 689, [], [], 'fam1', 1 ).
test( 't95', 213, [], [], 'fam1', 1 ).
test( 't96', 171, [], ['r2','r7','r10','r9','r6','r8'], 'fam1', 1 ).
test( 't97', 478, [], [], 'fam1', 1 ).
test( 't98', 378, [], [], 'fam1', 1 ).
test( 't99', 468, [], [], 'fam1', 1 ).
test( 't100', 281, [], ['r2','r7','r5','r9','r1','r6','r3','r8'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').
embedded_board( 'm21').
embedded_board( 'm22').
embedded_board( 'm23').
embedded_board( 'm24').
embedded_board( 'm25').
embedded_board( 'm26').
embedded_board( 'm27').
embedded_board( 'm28').
embedded_board( 'm29').
embedded_board( 'm30').
embedded_board( 'm31').
embedded_board( 'm32').
embedded_board( 'm33').
embedded_board( 'm34').
embedded_board( 'm35').
embedded_board( 'm36').
embedded_board( 'm37').
embedded_board( 'm38').
embedded_board( 'm39').
embedded_board( 'm40').
embedded_board( 'm41').
embedded_board( 'm42').
embedded_board( 'm43').
embedded_board( 'm44').
embedded_board( 'm45').
embedded_board( 'm46').
embedded_board( 'm47').
embedded_board( 'm48').
embedded_board( 'm49').
embedded_board( 'm50').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
