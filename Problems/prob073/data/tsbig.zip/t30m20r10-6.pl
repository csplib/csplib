%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 20
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 488, [], ['r1','r2','r10','r9','r4','r8','r5'], 'fam1', 1 ).
test( 't2', 503, [], [], 'fam1', 1 ).
test( 't3', 184, [], ['r5','r8'], 'fam1', 1 ).
test( 't4', 119, [], [], 'fam1', 1 ).
test( 't5', 715, [], [], 'fam1', 1 ).
test( 't6', 174, ['m4','m7','m16','m12','m6','m2','m11','m1'], ['r5','r9','r6','r1','r4','r2','r7','r8','r3'], 'fam1', 1 ).
test( 't7', 407, [], ['r8','r10','r1','r7','r3','r4','r6','r5','r2'], 'fam1', 1 ).
test( 't8', 391, [], ['r8','r7','r10','r6','r4','r9','r2'], 'fam1', 1 ).
test( 't9', 76, [], ['r7','r2','r5','r8','r1'], 'fam1', 1 ).
test( 't10', 128, [], [], 'fam1', 1 ).
test( 't11', 236, [], [], 'fam1', 1 ).
test( 't12', 161, [], [], 'fam1', 1 ).
test( 't13', 774, [], ['r7'], 'fam1', 1 ).
test( 't14', 349, [], [], 'fam1', 1 ).
test( 't15', 467, ['m10','m7','m11','m4','m14'], [], 'fam1', 1 ).
test( 't16', 8, [], [], 'fam1', 1 ).
test( 't17', 261, [], [], 'fam1', 1 ).
test( 't18', 594, [], [], 'fam1', 1 ).
test( 't19', 597, [], ['r4','r10','r7','r5','r9','r3'], 'fam1', 1 ).
test( 't20', 158, ['m16','m5'], [], 'fam1', 1 ).
test( 't21', 340, [], [], 'fam1', 1 ).
test( 't22', 465, ['m8','m3'], ['r6','r9','r10','r3'], 'fam1', 1 ).
test( 't23', 402, [], [], 'fam1', 1 ).
test( 't24', 583, [], ['r6','r8','r1','r7','r2','r4','r9','r3'], 'fam1', 1 ).
test( 't25', 70, [], [], 'fam1', 1 ).
test( 't26', 632, ['m8','m16','m3'], ['r8'], 'fam1', 1 ).
test( 't27', 67, [], [], 'fam1', 1 ).
test( 't28', 126, [], [], 'fam1', 1 ).
test( 't29', 180, [], ['r4','r6','r7','r8','r9','r2','r10'], 'fam1', 1 ).
test( 't30', 485, [], ['r3','r9','r6','r8'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
