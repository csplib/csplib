%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 50
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 519, [], [], 'fam1', 1 ).
test( 't2', 401, [], [], 'fam1', 1 ).
test( 't3', 562, [], [], 'fam1', 1 ).
test( 't4', 218, ['m37','m50','m34','m27','m16','m42','m38','m21','m11','m4','m31','m14','m15','m47','m9','m45'], ['r2','r1','r9','r5','r6','r7','r8','r3','r10','r4'], 'fam1', 1 ).
test( 't5', 255, [], ['r9','r6','r2','r5','r1'], 'fam1', 1 ).
test( 't6', 506, [], ['r7'], 'fam1', 1 ).
test( 't7', 325, [], [], 'fam1', 1 ).
test( 't8', 394, ['m19','m42','m33','m29','m11','m3','m34','m16','m27','m40','m2','m41'], [], 'fam1', 1 ).
test( 't9', 330, [], [], 'fam1', 1 ).
test( 't10', 260, ['m8','m17','m36','m49','m33','m44','m48','m46','m50','m42','m12','m22','m3','m37','m20','m40','m39'], ['r9','r6','r1','r2','r10','r8','r5','r3','r7'], 'fam1', 1 ).
test( 't11', 591, [], [], 'fam1', 1 ).
test( 't12', 762, [], [], 'fam1', 1 ).
test( 't13', 632, ['m43','m19','m2','m46','m40'], [], 'fam1', 1 ).
test( 't14', 63, [], [], 'fam1', 1 ).
test( 't15', 572, ['m39'], ['r10','r5','r2','r4','r1'], 'fam1', 1 ).
test( 't16', 739, [], [], 'fam1', 1 ).
test( 't17', 538, [], [], 'fam1', 1 ).
test( 't18', 292, [], ['r6','r5'], 'fam1', 1 ).
test( 't19', 677, [], [], 'fam1', 1 ).
test( 't20', 576, [], [], 'fam1', 1 ).
test( 't21', 233, [], [], 'fam1', 1 ).
test( 't22', 44, [], ['r3','r10','r1','r9','r5','r4'], 'fam1', 1 ).
test( 't23', 422, ['m50','m40','m39','m31','m26','m48','m30','m9','m32','m45'], [], 'fam1', 1 ).
test( 't24', 393, [], [], 'fam1', 1 ).
test( 't25', 773, [], [], 'fam1', 1 ).
test( 't26', 551, [], [], 'fam1', 1 ).
test( 't27', 428, ['m20','m16','m27','m40','m39','m9','m49','m29','m1','m50','m19','m6','m11'], [], 'fam1', 1 ).
test( 't28', 145, [], [], 'fam1', 1 ).
test( 't29', 690, [], [], 'fam1', 1 ).
test( 't30', 552, [], [], 'fam1', 1 ).
test( 't31', 362, [], [], 'fam1', 1 ).
test( 't32', 517, [], [], 'fam1', 1 ).
test( 't33', 123, [], [], 'fam1', 1 ).
test( 't34', 438, ['m32','m6','m23','m46','m4','m30','m2','m34','m39'], ['r10','r2','r7','r4','r6'], 'fam1', 1 ).
test( 't35', 325, ['m42','m13','m16','m7','m31','m11','m27','m32'], [], 'fam1', 1 ).
test( 't36', 726, [], [], 'fam1', 1 ).
test( 't37', 507, [], ['r7'], 'fam1', 1 ).
test( 't38', 504, [], ['r8'], 'fam1', 1 ).
test( 't39', 751, [], [], 'fam1', 1 ).
test( 't40', 478, [], ['r10','r8','r7'], 'fam1', 1 ).
test( 't41', 232, [], [], 'fam1', 1 ).
test( 't42', 411, [], [], 'fam1', 1 ).
test( 't43', 511, ['m33','m11','m44'], [], 'fam1', 1 ).
test( 't44', 429, [], ['r2','r10','r8','r1','r7','r6','r3','r5','r9','r4'], 'fam1', 1 ).
test( 't45', 193, [], ['r7','r4','r6','r8','r2','r10'], 'fam1', 1 ).
test( 't46', 31, [], [], 'fam1', 1 ).
test( 't47', 53, [], [], 'fam1', 1 ).
test( 't48', 625, ['m48','m42','m4','m40','m2','m28','m13','m7','m12','m46','m45','m17','m14','m3','m18','m23'], [], 'fam1', 1 ).
test( 't49', 301, ['m49','m46','m22','m40','m28','m29','m37','m1'], [], 'fam1', 1 ).
test( 't50', 276, [], ['r10','r6'], 'fam1', 1 ).
test( 't51', 672, [], [], 'fam1', 1 ).
test( 't52', 634, [], ['r2','r6','r3','r4','r10','r9','r7'], 'fam1', 1 ).
test( 't53', 422, [], ['r3','r5'], 'fam1', 1 ).
test( 't54', 516, [], [], 'fam1', 1 ).
test( 't55', 478, [], ['r3','r5','r7','r6','r4','r8','r10','r2','r1'], 'fam1', 1 ).
test( 't56', 77, [], [], 'fam1', 1 ).
test( 't57', 590, [], [], 'fam1', 1 ).
test( 't58', 771, [], [], 'fam1', 1 ).
test( 't59', 732, [], [], 'fam1', 1 ).
test( 't60', 757, [], [], 'fam1', 1 ).
test( 't61', 735, [], [], 'fam1', 1 ).
test( 't62', 503, [], ['r5','r3','r6','r4','r9','r10','r8','r7'], 'fam1', 1 ).
test( 't63', 753, [], [], 'fam1', 1 ).
test( 't64', 103, [], [], 'fam1', 1 ).
test( 't65', 239, [], [], 'fam1', 1 ).
test( 't66', 547, [], [], 'fam1', 1 ).
test( 't67', 541, [], ['r10','r1'], 'fam1', 1 ).
test( 't68', 239, [], [], 'fam1', 1 ).
test( 't69', 531, [], [], 'fam1', 1 ).
test( 't70', 57, [], [], 'fam1', 1 ).
test( 't71', 347, [], ['r4','r6','r9'], 'fam1', 1 ).
test( 't72', 545, [], [], 'fam1', 1 ).
test( 't73', 182, ['m48','m29'], [], 'fam1', 1 ).
test( 't74', 689, [], [], 'fam1', 1 ).
test( 't75', 616, ['m24','m46','m36','m6','m21','m22','m8','m5','m38','m48','m3','m35','m50','m7','m12','m20','m29','m45'], [], 'fam1', 1 ).
test( 't76', 646, [], ['r10','r3','r1','r4','r5','r2','r6','r7','r8','r9'], 'fam1', 1 ).
test( 't77', 516, [], [], 'fam1', 1 ).
test( 't78', 170, [], [], 'fam1', 1 ).
test( 't79', 148, ['m11','m45','m3','m7','m2','m35','m37','m30','m18','m33','m40','m17','m31','m34','m44','m12','m42','m4'], [], 'fam1', 1 ).
test( 't80', 125, [], [], 'fam1', 1 ).
test( 't81', 555, ['m33','m18','m7','m27','m14','m1','m35','m37','m22','m49','m23','m3','m36','m9','m13','m5','m31','m41','m17','m39'], ['r8','r1','r2','r3'], 'fam1', 1 ).
test( 't82', 235, ['m12','m39','m5','m19','m42','m30','m24'], [], 'fam1', 1 ).
test( 't83', 313, [], ['r5','r7','r8','r9','r6'], 'fam1', 1 ).
test( 't84', 555, [], [], 'fam1', 1 ).
test( 't85', 743, [], ['r3','r5','r7','r1','r4'], 'fam1', 1 ).
test( 't86', 746, [], [], 'fam1', 1 ).
test( 't87', 622, [], ['r10'], 'fam1', 1 ).
test( 't88', 89, ['m29','m26','m16','m49','m41','m45','m50','m4'], [], 'fam1', 1 ).
test( 't89', 723, [], [], 'fam1', 1 ).
test( 't90', 143, [], ['r2','r5','r10'], 'fam1', 1 ).
test( 't91', 659, [], ['r4','r5','r8','r9','r3','r10','r7'], 'fam1', 1 ).
test( 't92', 642, [], [], 'fam1', 1 ).
test( 't93', 517, [], [], 'fam1', 1 ).
test( 't94', 540, [], [], 'fam1', 1 ).
test( 't95', 53, ['m3','m4','m6','m22','m20','m21','m2','m50','m39','m29','m49','m8','m32','m1'], ['r6','r5','r1','r10','r8','r9','r3'], 'fam1', 1 ).
test( 't96', 381, [], ['r10','r1','r8'], 'fam1', 1 ).
test( 't97', 438, [], [], 'fam1', 1 ).
test( 't98', 471, [], [], 'fam1', 1 ).
test( 't99', 339, ['m21','m2','m25','m10','m28','m33','m49','m47','m26','m16','m35','m17','m1','m14','m48','m23','m42'], [], 'fam1', 1 ).
test( 't100', 316, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').
embedded_board( 'm21').
embedded_board( 'm22').
embedded_board( 'm23').
embedded_board( 'm24').
embedded_board( 'm25').
embedded_board( 'm26').
embedded_board( 'm27').
embedded_board( 'm28').
embedded_board( 'm29').
embedded_board( 'm30').
embedded_board( 'm31').
embedded_board( 'm32').
embedded_board( 'm33').
embedded_board( 'm34').
embedded_board( 'm35').
embedded_board( 'm36').
embedded_board( 'm37').
embedded_board( 'm38').
embedded_board( 'm39').
embedded_board( 'm40').
embedded_board( 'm41').
embedded_board( 'm42').
embedded_board( 'm43').
embedded_board( 'm44').
embedded_board( 'm45').
embedded_board( 'm46').
embedded_board( 'm47').
embedded_board( 'm48').
embedded_board( 'm49').
embedded_board( 'm50').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
