%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 425, [], [], 'fam1', 1 ).
test( 't2', 780, ['m4'], ['r2','r5','r1'], 'fam1', 1 ).
test( 't3', 730, [], ['r5','r2','r3','r4'], 'fam1', 1 ).
test( 't4', 268, [], [], 'fam1', 1 ).
test( 't5', 395, [], [], 'fam1', 1 ).
test( 't6', 368, ['m8','m3','m9','m10'], [], 'fam1', 1 ).
test( 't7', 336, ['m1','m8'], [], 'fam1', 1 ).
test( 't8', 494, [], ['r1'], 'fam1', 1 ).
test( 't9', 144, [], ['r4','r5','r3'], 'fam1', 1 ).
test( 't10', 532, [], [], 'fam1', 1 ).
test( 't11', 512, [], [], 'fam1', 1 ).
test( 't12', 600, [], [], 'fam1', 1 ).
test( 't13', 654, [], ['r3','r4','r5','r1','r2'], 'fam1', 1 ).
test( 't14', 339, [], ['r3','r4'], 'fam1', 1 ).
test( 't15', 458, [], [], 'fam1', 1 ).
test( 't16', 706, ['m7','m9'], [], 'fam1', 1 ).
test( 't17', 467, ['m7','m5','m4','m3'], [], 'fam1', 1 ).
test( 't18', 39, [], [], 'fam1', 1 ).
test( 't19', 262, [], [], 'fam1', 1 ).
test( 't20', 491, [], [], 'fam1', 1 ).
test( 't21', 450, ['m8','m6','m7','m2'], [], 'fam1', 1 ).
test( 't22', 238, [], [], 'fam1', 1 ).
test( 't23', 490, ['m4','m7','m5','m1'], [], 'fam1', 1 ).
test( 't24', 581, [], [], 'fam1', 1 ).
test( 't25', 95, [], [], 'fam1', 1 ).
test( 't26', 711, [], ['r5','r2'], 'fam1', 1 ).
test( 't27', 177, [], [], 'fam1', 1 ).
test( 't28', 428, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't29', 587, ['m3','m6'], ['r3','r2'], 'fam1', 1 ).
test( 't30', 573, ['m5','m2'], ['r5','r2'], 'fam1', 1 ).
test( 't31', 443, [], ['r1'], 'fam1', 1 ).
test( 't32', 491, ['m7','m3'], [], 'fam1', 1 ).
test( 't33', 414, [], [], 'fam1', 1 ).
test( 't34', 739, [], [], 'fam1', 1 ).
test( 't35', 140, [], [], 'fam1', 1 ).
test( 't36', 778, [], [], 'fam1', 1 ).
test( 't37', 332, [], [], 'fam1', 1 ).
test( 't38', 11, ['m7'], ['r1'], 'fam1', 1 ).
test( 't39', 451, [], [], 'fam1', 1 ).
test( 't40', 292, [], ['r5','r1','r4','r2'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
