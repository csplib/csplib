%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 50
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 146, [], ['r9','r8','r6'], 'fam1', 1 ).
test( 't2', 796, [], ['r4'], 'fam1', 1 ).
test( 't3', 207, ['m48','m33','m21','m24'], [], 'fam1', 1 ).
test( 't4', 629, ['m37','m29','m12','m5','m46','m34','m1','m24','m44','m20','m38','m35'], ['r9','r7','r4','r1','r10','r8'], 'fam1', 1 ).
test( 't5', 598, [], [], 'fam1', 1 ).
test( 't6', 388, [], [], 'fam1', 1 ).
test( 't7', 430, ['m21','m35','m48','m7','m28','m8','m19','m1','m33','m14','m11','m6','m30','m50','m5'], ['r4'], 'fam1', 1 ).
test( 't8', 642, [], [], 'fam1', 1 ).
test( 't9', 148, [], [], 'fam1', 1 ).
test( 't10', 598, [], ['r7','r2','r5','r4','r6','r8'], 'fam1', 1 ).
test( 't11', 577, [], ['r9','r3','r4','r10','r5'], 'fam1', 1 ).
test( 't12', 216, [], [], 'fam1', 1 ).
test( 't13', 676, [], ['r6','r4','r7','r1','r9','r8','r2','r5','r3'], 'fam1', 1 ).
test( 't14', 415, [], [], 'fam1', 1 ).
test( 't15', 148, [], ['r6','r1','r3','r8','r5','r2','r7','r9','r4'], 'fam1', 1 ).
test( 't16', 672, [], [], 'fam1', 1 ).
test( 't17', 29, [], [], 'fam1', 1 ).
test( 't18', 771, ['m20','m43','m4','m9','m45','m40','m29','m32','m34','m22','m41','m10','m1','m44','m37','m33'], [], 'fam1', 1 ).
test( 't19', 565, [], [], 'fam1', 1 ).
test( 't20', 559, [], [], 'fam1', 1 ).
test( 't21', 2, [], [], 'fam1', 1 ).
test( 't22', 780, [], ['r3','r6','r10','r1'], 'fam1', 1 ).
test( 't23', 60, [], [], 'fam1', 1 ).
test( 't24', 338, ['m7','m22','m3','m21','m12','m18','m31','m45','m23','m25'], [], 'fam1', 1 ).
test( 't25', 201, [], [], 'fam1', 1 ).
test( 't26', 757, [], ['r9','r10','r4','r7','r2','r3','r5','r8'], 'fam1', 1 ).
test( 't27', 486, [], [], 'fam1', 1 ).
test( 't28', 671, ['m42','m22','m50','m11','m27','m24','m25','m9','m3','m45','m4','m20','m13','m5','m47','m26','m8','m12','m29','m36'], [], 'fam1', 1 ).
test( 't29', 193, ['m32','m30','m38','m12','m10','m26','m43','m1','m34','m47','m36','m40','m17','m49','m50','m31','m24','m14','m48'], [], 'fam1', 1 ).
test( 't30', 164, [], [], 'fam1', 1 ).
test( 't31', 434, [], [], 'fam1', 1 ).
test( 't32', 685, [], [], 'fam1', 1 ).
test( 't33', 782, [], [], 'fam1', 1 ).
test( 't34', 611, ['m28','m37','m24','m5','m19','m20','m23','m45','m22','m30','m44','m2','m36','m38','m26','m17','m10','m25'], [], 'fam1', 1 ).
test( 't35', 23, [], [], 'fam1', 1 ).
test( 't36', 796, [], [], 'fam1', 1 ).
test( 't37', 454, [], [], 'fam1', 1 ).
test( 't38', 779, [], ['r5','r8'], 'fam1', 1 ).
test( 't39', 307, [], ['r10','r5','r8','r4','r3','r9','r1'], 'fam1', 1 ).
test( 't40', 792, [], [], 'fam1', 1 ).
test( 't41', 501, ['m25','m46'], [], 'fam1', 1 ).
test( 't42', 58, [], [], 'fam1', 1 ).
test( 't43', 286, ['m25','m43','m38','m31','m40','m20','m5','m39','m30','m23','m33','m35','m47','m7','m29'], [], 'fam1', 1 ).
test( 't44', 508, [], [], 'fam1', 1 ).
test( 't45', 544, [], [], 'fam1', 1 ).
test( 't46', 289, [], [], 'fam1', 1 ).
test( 't47', 214, ['m11','m23','m20','m17'], ['r10','r7','r1','r3','r6'], 'fam1', 1 ).
test( 't48', 500, ['m50','m47','m3','m7','m1','m31','m20','m24','m25','m6','m49','m8','m42'], [], 'fam1', 1 ).
test( 't49', 592, [], ['r5','r7','r6','r8','r10','r1'], 'fam1', 1 ).
test( 't50', 313, [], [], 'fam1', 1 ).
test( 't51', 771, [], ['r8','r2','r3','r10','r4','r9','r6','r1','r7','r5'], 'fam1', 1 ).
test( 't52', 525, ['m10','m14','m39','m29','m15'], [], 'fam1', 1 ).
test( 't53', 27, [], [], 'fam1', 1 ).
test( 't54', 669, ['m48','m43','m9','m47','m22','m39','m21','m25','m7','m5','m24'], [], 'fam1', 1 ).
test( 't55', 727, [], [], 'fam1', 1 ).
test( 't56', 698, [], [], 'fam1', 1 ).
test( 't57', 417, [], [], 'fam1', 1 ).
test( 't58', 373, [], [], 'fam1', 1 ).
test( 't59', 166, [], [], 'fam1', 1 ).
test( 't60', 335, [], [], 'fam1', 1 ).
test( 't61', 676, [], ['r6','r10','r1','r8','r3','r7','r9','r4','r2'], 'fam1', 1 ).
test( 't62', 739, [], [], 'fam1', 1 ).
test( 't63', 53, [], [], 'fam1', 1 ).
test( 't64', 744, [], ['r9','r2'], 'fam1', 1 ).
test( 't65', 289, [], [], 'fam1', 1 ).
test( 't66', 194, [], [], 'fam1', 1 ).
test( 't67', 760, [], ['r5','r9'], 'fam1', 1 ).
test( 't68', 461, [], [], 'fam1', 1 ).
test( 't69', 761, [], [], 'fam1', 1 ).
test( 't70', 128, ['m23'], [], 'fam1', 1 ).
test( 't71', 13, [], [], 'fam1', 1 ).
test( 't72', 774, [], ['r5','r8','r7'], 'fam1', 1 ).
test( 't73', 480, ['m37','m23','m7','m40','m6','m38','m50','m36','m47','m29','m43','m42','m26'], ['r6','r8','r7','r5','r10','r4','r3','r1'], 'fam1', 1 ).
test( 't74', 5, [], [], 'fam1', 1 ).
test( 't75', 235, [], [], 'fam1', 1 ).
test( 't76', 670, [], [], 'fam1', 1 ).
test( 't77', 355, [], [], 'fam1', 1 ).
test( 't78', 48, [], [], 'fam1', 1 ).
test( 't79', 394, [], ['r5','r4','r3','r10','r7','r6','r9'], 'fam1', 1 ).
test( 't80', 581, [], [], 'fam1', 1 ).
test( 't81', 415, [], ['r10','r8','r9','r2'], 'fam1', 1 ).
test( 't82', 498, ['m15','m24','m50','m25','m41','m49','m10','m45'], [], 'fam1', 1 ).
test( 't83', 181, [], [], 'fam1', 1 ).
test( 't84', 576, [], [], 'fam1', 1 ).
test( 't85', 206, [], [], 'fam1', 1 ).
test( 't86', 717, [], [], 'fam1', 1 ).
test( 't87', 661, [], [], 'fam1', 1 ).
test( 't88', 329, [], [], 'fam1', 1 ).
test( 't89', 111, [], [], 'fam1', 1 ).
test( 't90', 199, [], ['r3','r8','r10','r4'], 'fam1', 1 ).
test( 't91', 492, [], [], 'fam1', 1 ).
test( 't92', 417, [], [], 'fam1', 1 ).
test( 't93', 286, [], [], 'fam1', 1 ).
test( 't94', 5, [], [], 'fam1', 1 ).
test( 't95', 439, ['m20','m18','m36'], ['r5','r3'], 'fam1', 1 ).
test( 't96', 354, [], ['r3','r10','r1'], 'fam1', 1 ).
test( 't97', 649, ['m37','m34','m9','m22'], [], 'fam1', 1 ).
test( 't98', 184, [], [], 'fam1', 1 ).
test( 't99', 473, ['m30','m48','m20'], ['r9','r4','r1','r3','r10','r5'], 'fam1', 1 ).
test( 't100', 109, ['m31','m11','m21','m32','m1','m4','m22','m8','m16','m38','m48','m14','m49','m17','m3','m18','m5','m29','m25'], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').
embedded_board( 'm21').
embedded_board( 'm22').
embedded_board( 'm23').
embedded_board( 'm24').
embedded_board( 'm25').
embedded_board( 'm26').
embedded_board( 'm27').
embedded_board( 'm28').
embedded_board( 'm29').
embedded_board( 'm30').
embedded_board( 'm31').
embedded_board( 'm32').
embedded_board( 'm33').
embedded_board( 'm34').
embedded_board( 'm35').
embedded_board( 'm36').
embedded_board( 'm37').
embedded_board( 'm38').
embedded_board( 'm39').
embedded_board( 'm40').
embedded_board( 'm41').
embedded_board( 'm42').
embedded_board( 'm43').
embedded_board( 'm44').
embedded_board( 'm45').
embedded_board( 'm46').
embedded_board( 'm47').
embedded_board( 'm48').
embedded_board( 'm49').
embedded_board( 'm50').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
