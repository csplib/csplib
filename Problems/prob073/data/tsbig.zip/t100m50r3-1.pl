%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 50
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 717, [], [], 'fam1', 1 ).
test( 't2', 53, [], [], 'fam1', 1 ).
test( 't3', 662, [], [], 'fam1', 1 ).
test( 't4', 576, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't5', 779, [], [], 'fam1', 1 ).
test( 't6', 203, [], [], 'fam1', 1 ).
test( 't7', 23, ['m18','m36','m12','m31','m35','m33','m30','m32','m9','m24','m22','m27','m15','m2','m34','m48'], [], 'fam1', 1 ).
test( 't8', 579, [], [], 'fam1', 1 ).
test( 't9', 705, [], [], 'fam1', 1 ).
test( 't10', 201, [], [], 'fam1', 1 ).
test( 't11', 284, [], [], 'fam1', 1 ).
test( 't12', 500, [], [], 'fam1', 1 ).
test( 't13', 434, [], [], 'fam1', 1 ).
test( 't14', 1, [], [], 'fam1', 1 ).
test( 't15', 787, ['m4','m29','m16','m22','m18','m41','m6','m45','m28','m33'], [], 'fam1', 1 ).
test( 't16', 140, [], ['r3','r1'], 'fam1', 1 ).
test( 't17', 544, [], [], 'fam1', 1 ).
test( 't18', 528, [], [], 'fam1', 1 ).
test( 't19', 229, [], ['r1','r3'], 'fam1', 1 ).
test( 't20', 330, [], ['r1'], 'fam1', 1 ).
test( 't21', 753, [], [], 'fam1', 1 ).
test( 't22', 117, [], [], 'fam1', 1 ).
test( 't23', 563, ['m22','m43','m38','m14','m11','m4','m28','m44','m32'], ['r3','r2','r1'], 'fam1', 1 ).
test( 't24', 289, ['m36','m21','m7','m14','m29','m3','m15','m39'], [], 'fam1', 1 ).
test( 't25', 790, [], ['r1'], 'fam1', 1 ).
test( 't26', 695, [], ['r1'], 'fam1', 1 ).
test( 't27', 479, ['m38','m34','m3','m16','m49','m47'], [], 'fam1', 1 ).
test( 't28', 784, [], [], 'fam1', 1 ).
test( 't29', 66, [], [], 'fam1', 1 ).
test( 't30', 73, ['m26','m17','m11','m36','m45','m32','m34','m25'], [], 'fam1', 1 ).
test( 't31', 146, ['m35','m49','m1','m34','m20','m28','m42','m47','m48','m41','m16','m36','m21','m10','m37'], [], 'fam1', 1 ).
test( 't32', 124, ['m38','m12','m24','m47','m43','m36','m14','m49','m25','m3'], [], 'fam1', 1 ).
test( 't33', 86, [], ['r3','r2'], 'fam1', 1 ).
test( 't34', 234, ['m24','m29','m14','m36','m33','m7','m46','m23','m6','m15','m27','m35'], [], 'fam1', 1 ).
test( 't35', 84, [], [], 'fam1', 1 ).
test( 't36', 661, [], [], 'fam1', 1 ).
test( 't37', 395, [], [], 'fam1', 1 ).
test( 't38', 651, [], ['r2','r3'], 'fam1', 1 ).
test( 't39', 76, [], [], 'fam1', 1 ).
test( 't40', 165, [], ['r2','r1'], 'fam1', 1 ).
test( 't41', 389, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't42', 726, [], ['r2'], 'fam1', 1 ).
test( 't43', 167, ['m44','m15','m28','m45','m17','m5','m47','m23','m33'], [], 'fam1', 1 ).
test( 't44', 21, [], [], 'fam1', 1 ).
test( 't45', 166, [], [], 'fam1', 1 ).
test( 't46', 564, [], [], 'fam1', 1 ).
test( 't47', 745, [], [], 'fam1', 1 ).
test( 't48', 736, [], [], 'fam1', 1 ).
test( 't49', 167, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't50', 264, [], [], 'fam1', 1 ).
test( 't51', 67, [], [], 'fam1', 1 ).
test( 't52', 28, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't53', 624, [], [], 'fam1', 1 ).
test( 't54', 196, ['m36','m7','m30','m44','m38','m11','m13','m22','m39','m14','m2','m4','m18','m42','m21','m23','m27'], [], 'fam1', 1 ).
test( 't55', 760, [], [], 'fam1', 1 ).
test( 't56', 532, [], [], 'fam1', 1 ).
test( 't57', 480, [], [], 'fam1', 1 ).
test( 't58', 153, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't59', 391, [], ['r3'], 'fam1', 1 ).
test( 't60', 156, [], [], 'fam1', 1 ).
test( 't61', 161, ['m46','m29'], [], 'fam1', 1 ).
test( 't62', 518, [], [], 'fam1', 1 ).
test( 't63', 141, [], [], 'fam1', 1 ).
test( 't64', 25, ['m11','m28','m50','m14','m16','m45','m21','m23','m44','m36','m5','m8','m12','m38','m2','m6'], ['r1','r2','r3'], 'fam1', 1 ).
test( 't65', 475, [], [], 'fam1', 1 ).
test( 't66', 581, ['m41','m32','m23','m19','m16','m43','m2','m21','m1','m29','m36','m47','m50','m40','m11','m31','m48'], [], 'fam1', 1 ).
test( 't67', 617, [], [], 'fam1', 1 ).
test( 't68', 440, [], ['r3','r2'], 'fam1', 1 ).
test( 't69', 41, [], [], 'fam1', 1 ).
test( 't70', 721, [], [], 'fam1', 1 ).
test( 't71', 433, ['m43','m33','m30','m42','m40','m14','m12','m4','m48','m16','m6','m39','m1','m9','m31','m45','m18','m23','m49','m22'], [], 'fam1', 1 ).
test( 't72', 676, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't73', 29, ['m46','m45','m19','m39','m11','m23','m40','m41','m15','m33','m13','m25'], [], 'fam1', 1 ).
test( 't74', 461, [], [], 'fam1', 1 ).
test( 't75', 369, ['m23','m19','m9','m42','m16','m50','m26','m38','m49','m43','m28','m30','m40','m33','m31'], [], 'fam1', 1 ).
test( 't76', 490, [], ['r3'], 'fam1', 1 ).
test( 't77', 506, [], [], 'fam1', 1 ).
test( 't78', 662, [], ['r3','r1'], 'fam1', 1 ).
test( 't79', 374, [], [], 'fam1', 1 ).
test( 't80', 241, [], [], 'fam1', 1 ).
test( 't81', 478, [], ['r2','r3'], 'fam1', 1 ).
test( 't82', 600, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't83', 215, [], [], 'fam1', 1 ).
test( 't84', 380, ['m8','m14','m20','m19','m16','m32','m6','m35','m41','m38','m36','m29','m50','m4'], ['r3'], 'fam1', 1 ).
test( 't85', 138, ['m44','m28','m2','m29','m40','m47','m43','m8','m31','m32','m42','m7','m18','m4','m22','m15','m36','m20'], ['r2','r3'], 'fam1', 1 ).
test( 't86', 489, ['m17','m37','m28','m43','m14','m19','m6','m15','m50','m47','m44','m36','m49','m22','m16','m40','m46','m11','m33'], [], 'fam1', 1 ).
test( 't87', 476, [], ['r2'], 'fam1', 1 ).
test( 't88', 464, ['m2','m16','m43','m22','m34','m4','m27','m35','m7','m29','m25'], [], 'fam1', 1 ).
test( 't89', 718, [], [], 'fam1', 1 ).
test( 't90', 733, ['m36','m29','m5','m49','m38','m34','m47','m7','m8','m3','m48','m35','m28','m21'], [], 'fam1', 1 ).
test( 't91', 689, [], ['r1','r3'], 'fam1', 1 ).
test( 't92', 17, [], [], 'fam1', 1 ).
test( 't93', 784, [], [], 'fam1', 1 ).
test( 't94', 285, [], [], 'fam1', 1 ).
test( 't95', 237, [], ['r3'], 'fam1', 1 ).
test( 't96', 131, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't97', 786, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't98', 302, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't99', 530, [], ['r3','r1'], 'fam1', 1 ).
test( 't100', 357, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').
embedded_board( 'm21').
embedded_board( 'm22').
embedded_board( 'm23').
embedded_board( 'm24').
embedded_board( 'm25').
embedded_board( 'm26').
embedded_board( 'm27').
embedded_board( 'm28').
embedded_board( 'm29').
embedded_board( 'm30').
embedded_board( 'm31').
embedded_board( 'm32').
embedded_board( 'm33').
embedded_board( 'm34').
embedded_board( 'm35').
embedded_board( 'm36').
embedded_board( 'm37').
embedded_board( 'm38').
embedded_board( 'm39').
embedded_board( 'm40').
embedded_board( 'm41').
embedded_board( 'm42').
embedded_board( 'm43').
embedded_board( 'm44').
embedded_board( 'm45').
embedded_board( 'm46').
embedded_board( 'm47').
embedded_board( 'm48').
embedded_board( 'm49').
embedded_board( 'm50').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
