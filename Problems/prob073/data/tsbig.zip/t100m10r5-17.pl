%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 496, [], [], 'fam1', 1 ).
test( 't2', 172, [], ['r2'], 'fam1', 1 ).
test( 't3', 439, [], [], 'fam1', 1 ).
test( 't4', 712, [], ['r4','r5','r3','r1'], 'fam1', 1 ).
test( 't5', 423, [], [], 'fam1', 1 ).
test( 't6', 162, [], [], 'fam1', 1 ).
test( 't7', 276, [], [], 'fam1', 1 ).
test( 't8', 250, [], [], 'fam1', 1 ).
test( 't9', 95, [], [], 'fam1', 1 ).
test( 't10', 454, [], [], 'fam1', 1 ).
test( 't11', 158, [], [], 'fam1', 1 ).
test( 't12', 320, [], [], 'fam1', 1 ).
test( 't13', 430, ['m5','m8','m4','m10'], ['r3','r2','r5','r1','r4'], 'fam1', 1 ).
test( 't14', 651, [], ['r5','r2','r4'], 'fam1', 1 ).
test( 't15', 183, [], [], 'fam1', 1 ).
test( 't16', 330, [], [], 'fam1', 1 ).
test( 't17', 526, [], [], 'fam1', 1 ).
test( 't18', 452, [], ['r5','r4','r2'], 'fam1', 1 ).
test( 't19', 60, [], ['r1'], 'fam1', 1 ).
test( 't20', 410, [], [], 'fam1', 1 ).
test( 't21', 700, ['m4','m6'], [], 'fam1', 1 ).
test( 't22', 376, [], [], 'fam1', 1 ).
test( 't23', 760, [], [], 'fam1', 1 ).
test( 't24', 257, ['m4','m5'], [], 'fam1', 1 ).
test( 't25', 634, [], [], 'fam1', 1 ).
test( 't26', 135, [], ['r4','r3','r5','r1'], 'fam1', 1 ).
test( 't27', 245, [], ['r1','r4','r2'], 'fam1', 1 ).
test( 't28', 317, [], [], 'fam1', 1 ).
test( 't29', 532, ['m8','m1'], [], 'fam1', 1 ).
test( 't30', 57, [], [], 'fam1', 1 ).
test( 't31', 608, [], [], 'fam1', 1 ).
test( 't32', 74, [], [], 'fam1', 1 ).
test( 't33', 681, [], [], 'fam1', 1 ).
test( 't34', 585, [], [], 'fam1', 1 ).
test( 't35', 739, [], [], 'fam1', 1 ).
test( 't36', 16, [], ['r4','r2','r1','r5'], 'fam1', 1 ).
test( 't37', 223, ['m2','m3','m9','m8'], ['r2','r1','r4','r3'], 'fam1', 1 ).
test( 't38', 632, ['m10','m3'], ['r4'], 'fam1', 1 ).
test( 't39', 299, [], [], 'fam1', 1 ).
test( 't40', 361, [], [], 'fam1', 1 ).
test( 't41', 168, [], [], 'fam1', 1 ).
test( 't42', 160, [], [], 'fam1', 1 ).
test( 't43', 279, [], [], 'fam1', 1 ).
test( 't44', 36, [], [], 'fam1', 1 ).
test( 't45', 197, ['m10'], [], 'fam1', 1 ).
test( 't46', 589, [], [], 'fam1', 1 ).
test( 't47', 422, [], [], 'fam1', 1 ).
test( 't48', 344, [], [], 'fam1', 1 ).
test( 't49', 29, [], [], 'fam1', 1 ).
test( 't50', 423, ['m4','m10','m3','m2'], [], 'fam1', 1 ).
test( 't51', 466, ['m4','m6','m7','m8'], ['r3','r5','r4','r2'], 'fam1', 1 ).
test( 't52', 611, [], [], 'fam1', 1 ).
test( 't53', 579, [], [], 'fam1', 1 ).
test( 't54', 520, [], [], 'fam1', 1 ).
test( 't55', 123, [], [], 'fam1', 1 ).
test( 't56', 314, ['m9','m6'], [], 'fam1', 1 ).
test( 't57', 350, [], [], 'fam1', 1 ).
test( 't58', 20, ['m8'], ['r5','r4','r3','r2','r1'], 'fam1', 1 ).
test( 't59', 591, [], [], 'fam1', 1 ).
test( 't60', 49, [], [], 'fam1', 1 ).
test( 't61', 222, [], [], 'fam1', 1 ).
test( 't62', 436, [], [], 'fam1', 1 ).
test( 't63', 193, [], [], 'fam1', 1 ).
test( 't64', 746, [], [], 'fam1', 1 ).
test( 't65', 473, [], ['r3','r4','r1'], 'fam1', 1 ).
test( 't66', 360, [], ['r1'], 'fam1', 1 ).
test( 't67', 271, [], ['r4','r3','r1'], 'fam1', 1 ).
test( 't68', 391, ['m7','m8','m10'], ['r4','r1','r3','r5','r2'], 'fam1', 1 ).
test( 't69', 169, [], [], 'fam1', 1 ).
test( 't70', 108, [], ['r4'], 'fam1', 1 ).
test( 't71', 505, [], [], 'fam1', 1 ).
test( 't72', 338, [], ['r4','r5','r1','r3'], 'fam1', 1 ).
test( 't73', 771, [], [], 'fam1', 1 ).
test( 't74', 551, ['m9'], [], 'fam1', 1 ).
test( 't75', 368, [], ['r2'], 'fam1', 1 ).
test( 't76', 757, [], ['r2','r3','r5','r1','r4'], 'fam1', 1 ).
test( 't77', 243, [], [], 'fam1', 1 ).
test( 't78', 487, ['m2','m3','m5','m7'], [], 'fam1', 1 ).
test( 't79', 50, [], ['r4'], 'fam1', 1 ).
test( 't80', 239, [], [], 'fam1', 1 ).
test( 't81', 242, [], ['r2','r3'], 'fam1', 1 ).
test( 't82', 342, ['m9','m7'], [], 'fam1', 1 ).
test( 't83', 587, [], [], 'fam1', 1 ).
test( 't84', 517, [], [], 'fam1', 1 ).
test( 't85', 613, [], [], 'fam1', 1 ).
test( 't86', 125, [], [], 'fam1', 1 ).
test( 't87', 310, ['m3','m4'], ['r3','r1','r4','r2','r5'], 'fam1', 1 ).
test( 't88', 755, [], [], 'fam1', 1 ).
test( 't89', 789, [], [], 'fam1', 1 ).
test( 't90', 56, [], [], 'fam1', 1 ).
test( 't91', 331, [], [], 'fam1', 1 ).
test( 't92', 385, ['m10','m1'], ['r1'], 'fam1', 1 ).
test( 't93', 697, ['m3','m8'], [], 'fam1', 1 ).
test( 't94', 275, [], [], 'fam1', 1 ).
test( 't95', 4, [], ['r1','r3','r5'], 'fam1', 1 ).
test( 't96', 48, [], ['r2','r5','r3','r4','r1'], 'fam1', 1 ).
test( 't97', 365, [], [], 'fam1', 1 ).
test( 't98', 106, [], [], 'fam1', 1 ).
test( 't99', 84, ['m6'], [], 'fam1', 1 ).
test( 't100', 73, ['m7'], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
