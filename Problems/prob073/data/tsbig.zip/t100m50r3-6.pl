%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 50
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 701, ['m38','m22'], [], 'fam1', 1 ).
test( 't2', 66, [], [], 'fam1', 1 ).
test( 't3', 464, ['m24','m49','m10','m46','m5'], [], 'fam1', 1 ).
test( 't4', 713, [], [], 'fam1', 1 ).
test( 't5', 25, [], ['r1'], 'fam1', 1 ).
test( 't6', 606, [], ['r3','r2'], 'fam1', 1 ).
test( 't7', 585, [], ['r3'], 'fam1', 1 ).
test( 't8', 538, [], [], 'fam1', 1 ).
test( 't9', 750, [], [], 'fam1', 1 ).
test( 't10', 259, [], [], 'fam1', 1 ).
test( 't11', 648, [], [], 'fam1', 1 ).
test( 't12', 281, [], [], 'fam1', 1 ).
test( 't13', 82, [], [], 'fam1', 1 ).
test( 't14', 101, [], [], 'fam1', 1 ).
test( 't15', 101, ['m1','m14','m36','m19','m28','m49','m5','m24','m2','m15','m45','m13'], [], 'fam1', 1 ).
test( 't16', 103, [], ['r3'], 'fam1', 1 ).
test( 't17', 272, ['m21','m35','m27','m33','m13','m5','m20','m17','m43','m38','m32','m31','m14','m49'], [], 'fam1', 1 ).
test( 't18', 534, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't19', 631, ['m28'], ['r2','r3','r1'], 'fam1', 1 ).
test( 't20', 156, [], [], 'fam1', 1 ).
test( 't21', 282, [], ['r1','r2'], 'fam1', 1 ).
test( 't22', 535, [], [], 'fam1', 1 ).
test( 't23', 225, [], [], 'fam1', 1 ).
test( 't24', 247, [], [], 'fam1', 1 ).
test( 't25', 420, [], [], 'fam1', 1 ).
test( 't26', 302, [], ['r1'], 'fam1', 1 ).
test( 't27', 578, [], ['r2'], 'fam1', 1 ).
test( 't28', 291, [], [], 'fam1', 1 ).
test( 't29', 111, [], [], 'fam1', 1 ).
test( 't30', 586, ['m19','m35','m15','m25'], [], 'fam1', 1 ).
test( 't31', 635, ['m10','m43','m27','m24','m30','m40','m33','m31','m14','m49','m3','m29'], [], 'fam1', 1 ).
test( 't32', 485, [], [], 'fam1', 1 ).
test( 't33', 308, [], [], 'fam1', 1 ).
test( 't34', 115, [], [], 'fam1', 1 ).
test( 't35', 237, [], [], 'fam1', 1 ).
test( 't36', 750, [], ['r2'], 'fam1', 1 ).
test( 't37', 129, [], [], 'fam1', 1 ).
test( 't38', 103, [], [], 'fam1', 1 ).
test( 't39', 556, [], [], 'fam1', 1 ).
test( 't40', 320, [], [], 'fam1', 1 ).
test( 't41', 368, [], [], 'fam1', 1 ).
test( 't42', 301, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't43', 442, ['m17','m33','m32','m48','m35','m43','m34','m30','m24','m37','m5','m18','m42','m20','m2','m22','m46','m1'], ['r3','r1'], 'fam1', 1 ).
test( 't44', 754, [], [], 'fam1', 1 ).
test( 't45', 301, [], [], 'fam1', 1 ).
test( 't46', 472, ['m15','m38','m49','m39','m30','m33','m18','m20','m35','m13','m31'], [], 'fam1', 1 ).
test( 't47', 641, [], [], 'fam1', 1 ).
test( 't48', 361, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't49', 412, ['m46','m49','m5','m25','m12','m29','m39','m41','m34','m45'], [], 'fam1', 1 ).
test( 't50', 587, [], ['r1','r3'], 'fam1', 1 ).
test( 't51', 217, [], [], 'fam1', 1 ).
test( 't52', 597, [], ['r2','r1'], 'fam1', 1 ).
test( 't53', 662, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't54', 624, [], [], 'fam1', 1 ).
test( 't55', 7, ['m45','m28','m21','m6','m17','m8','m33','m23','m2','m18','m31'], [], 'fam1', 1 ).
test( 't56', 657, [], ['r3','r2'], 'fam1', 1 ).
test( 't57', 188, ['m25','m19','m15','m9','m48','m18'], ['r3','r2'], 'fam1', 1 ).
test( 't58', 93, [], [], 'fam1', 1 ).
test( 't59', 634, [], [], 'fam1', 1 ).
test( 't60', 129, [], ['r1'], 'fam1', 1 ).
test( 't61', 180, [], [], 'fam1', 1 ).
test( 't62', 407, [], [], 'fam1', 1 ).
test( 't63', 650, [], [], 'fam1', 1 ).
test( 't64', 358, ['m42','m43','m24','m35','m20','m14','m36','m25','m18','m49','m47','m44','m23','m16'], ['r2','r1'], 'fam1', 1 ).
test( 't65', 150, ['m15','m43','m47','m41','m18'], ['r2','r3','r1'], 'fam1', 1 ).
test( 't66', 607, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't67', 738, ['m35','m12','m40','m50','m10','m24','m34','m15','m4','m21','m27','m46','m22'], [], 'fam1', 1 ).
test( 't68', 59, [], [], 'fam1', 1 ).
test( 't69', 765, ['m11','m8','m41','m4','m10','m13','m24'], ['r3','r1','r2'], 'fam1', 1 ).
test( 't70', 523, [], [], 'fam1', 1 ).
test( 't71', 50, [], [], 'fam1', 1 ).
test( 't72', 616, [], [], 'fam1', 1 ).
test( 't73', 286, [], ['r3','r2'], 'fam1', 1 ).
test( 't74', 249, ['m43','m3'], ['r1'], 'fam1', 1 ).
test( 't75', 28, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't76', 370, [], [], 'fam1', 1 ).
test( 't77', 791, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't78', 362, ['m9','m25','m30','m28','m24','m15','m7','m39','m3','m21','m6'], ['r1'], 'fam1', 1 ).
test( 't79', 695, [], ['r3'], 'fam1', 1 ).
test( 't80', 738, [], [], 'fam1', 1 ).
test( 't81', 374, [], [], 'fam1', 1 ).
test( 't82', 127, [], [], 'fam1', 1 ).
test( 't83', 294, [], [], 'fam1', 1 ).
test( 't84', 505, [], [], 'fam1', 1 ).
test( 't85', 789, [], ['r1'], 'fam1', 1 ).
test( 't86', 662, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't87', 344, [], [], 'fam1', 1 ).
test( 't88', 457, [], [], 'fam1', 1 ).
test( 't89', 18, [], [], 'fam1', 1 ).
test( 't90', 136, [], [], 'fam1', 1 ).
test( 't91', 220, [], [], 'fam1', 1 ).
test( 't92', 316, [], [], 'fam1', 1 ).
test( 't93', 688, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't94', 114, [], ['r3','r2'], 'fam1', 1 ).
test( 't95', 197, [], [], 'fam1', 1 ).
test( 't96', 753, [], [], 'fam1', 1 ).
test( 't97', 516, [], [], 'fam1', 1 ).
test( 't98', 680, [], [], 'fam1', 1 ).
test( 't99', 743, [], [], 'fam1', 1 ).
test( 't100', 438, ['m4','m18','m2','m44','m12','m47','m35','m8','m19','m5','m34','m6','m20'], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').
embedded_board( 'm21').
embedded_board( 'm22').
embedded_board( 'm23').
embedded_board( 'm24').
embedded_board( 'm25').
embedded_board( 'm26').
embedded_board( 'm27').
embedded_board( 'm28').
embedded_board( 'm29').
embedded_board( 'm30').
embedded_board( 'm31').
embedded_board( 'm32').
embedded_board( 'm33').
embedded_board( 'm34').
embedded_board( 'm35').
embedded_board( 'm36').
embedded_board( 'm37').
embedded_board( 'm38').
embedded_board( 'm39').
embedded_board( 'm40').
embedded_board( 'm41').
embedded_board( 'm42').
embedded_board( 'm43').
embedded_board( 'm44').
embedded_board( 'm45').
embedded_board( 'm46').
embedded_board( 'm47').
embedded_board( 'm48').
embedded_board( 'm49').
embedded_board( 'm50').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
