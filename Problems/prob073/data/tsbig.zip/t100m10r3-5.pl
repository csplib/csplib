%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 552, [], [], 'fam1', 1 ).
test( 't2', 47, [], ['r3'], 'fam1', 1 ).
test( 't3', 284, [], [], 'fam1', 1 ).
test( 't4', 410, ['m6','m7','m10','m1'], [], 'fam1', 1 ).
test( 't5', 224, ['m7','m3'], [], 'fam1', 1 ).
test( 't6', 437, ['m2','m6','m5'], [], 'fam1', 1 ).
test( 't7', 84, [], [], 'fam1', 1 ).
test( 't8', 614, [], ['r3','r1'], 'fam1', 1 ).
test( 't9', 207, [], ['r1','r2'], 'fam1', 1 ).
test( 't10', 167, [], ['r3'], 'fam1', 1 ).
test( 't11', 427, [], ['r3','r2'], 'fam1', 1 ).
test( 't12', 778, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't13', 262, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't14', 419, [], [], 'fam1', 1 ).
test( 't15', 245, [], [], 'fam1', 1 ).
test( 't16', 467, ['m1','m5','m6','m8'], [], 'fam1', 1 ).
test( 't17', 387, [], [], 'fam1', 1 ).
test( 't18', 339, [], [], 'fam1', 1 ).
test( 't19', 346, ['m3','m10','m8','m6'], [], 'fam1', 1 ).
test( 't20', 177, [], [], 'fam1', 1 ).
test( 't21', 594, ['m2'], [], 'fam1', 1 ).
test( 't22', 84, [], [], 'fam1', 1 ).
test( 't23', 251, [], [], 'fam1', 1 ).
test( 't24', 504, [], [], 'fam1', 1 ).
test( 't25', 626, [], [], 'fam1', 1 ).
test( 't26', 617, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't27', 730, [], [], 'fam1', 1 ).
test( 't28', 127, [], ['r3','r1'], 'fam1', 1 ).
test( 't29', 777, [], [], 'fam1', 1 ).
test( 't30', 713, [], [], 'fam1', 1 ).
test( 't31', 132, [], [], 'fam1', 1 ).
test( 't32', 297, [], [], 'fam1', 1 ).
test( 't33', 771, [], [], 'fam1', 1 ).
test( 't34', 695, [], [], 'fam1', 1 ).
test( 't35', 44, [], [], 'fam1', 1 ).
test( 't36', 457, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't37', 188, [], [], 'fam1', 1 ).
test( 't38', 286, [], ['r3','r1'], 'fam1', 1 ).
test( 't39', 208, [], ['r2','r3'], 'fam1', 1 ).
test( 't40', 273, ['m10','m3','m4'], [], 'fam1', 1 ).
test( 't41', 246, [], [], 'fam1', 1 ).
test( 't42', 75, [], [], 'fam1', 1 ).
test( 't43', 520, [], [], 'fam1', 1 ).
test( 't44', 734, [], [], 'fam1', 1 ).
test( 't45', 790, [], [], 'fam1', 1 ).
test( 't46', 561, [], [], 'fam1', 1 ).
test( 't47', 100, [], ['r1'], 'fam1', 1 ).
test( 't48', 165, [], [], 'fam1', 1 ).
test( 't49', 235, [], [], 'fam1', 1 ).
test( 't50', 278, [], [], 'fam1', 1 ).
test( 't51', 591, ['m1','m2','m8'], ['r3'], 'fam1', 1 ).
test( 't52', 175, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't53', 121, [], ['r3','r2'], 'fam1', 1 ).
test( 't54', 571, [], [], 'fam1', 1 ).
test( 't55', 85, ['m3','m2','m9','m7'], [], 'fam1', 1 ).
test( 't56', 504, [], [], 'fam1', 1 ).
test( 't57', 415, ['m4','m1'], [], 'fam1', 1 ).
test( 't58', 680, [], ['r2','r1'], 'fam1', 1 ).
test( 't59', 450, [], [], 'fam1', 1 ).
test( 't60', 577, [], [], 'fam1', 1 ).
test( 't61', 8, [], ['r1'], 'fam1', 1 ).
test( 't62', 327, [], [], 'fam1', 1 ).
test( 't63', 263, [], [], 'fam1', 1 ).
test( 't64', 331, [], [], 'fam1', 1 ).
test( 't65', 377, ['m4','m1'], [], 'fam1', 1 ).
test( 't66', 415, ['m6','m2'], ['r3','r2'], 'fam1', 1 ).
test( 't67', 235, [], [], 'fam1', 1 ).
test( 't68', 785, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't69', 321, [], [], 'fam1', 1 ).
test( 't70', 68, [], ['r3','r2'], 'fam1', 1 ).
test( 't71', 631, ['m8','m7'], [], 'fam1', 1 ).
test( 't72', 78, [], ['r1','r3'], 'fam1', 1 ).
test( 't73', 642, ['m8'], [], 'fam1', 1 ).
test( 't74', 358, [], [], 'fam1', 1 ).
test( 't75', 682, [], ['r2'], 'fam1', 1 ).
test( 't76', 595, ['m6','m3','m5','m4'], [], 'fam1', 1 ).
test( 't77', 476, [], ['r2'], 'fam1', 1 ).
test( 't78', 52, [], [], 'fam1', 1 ).
test( 't79', 381, [], [], 'fam1', 1 ).
test( 't80', 359, ['m6'], ['r2','r1'], 'fam1', 1 ).
test( 't81', 628, ['m7','m4','m5','m3'], [], 'fam1', 1 ).
test( 't82', 525, [], [], 'fam1', 1 ).
test( 't83', 161, [], ['r2','r1'], 'fam1', 1 ).
test( 't84', 297, [], [], 'fam1', 1 ).
test( 't85', 657, [], [], 'fam1', 1 ).
test( 't86', 702, [], [], 'fam1', 1 ).
test( 't87', 688, ['m9','m5'], [], 'fam1', 1 ).
test( 't88', 652, [], [], 'fam1', 1 ).
test( 't89', 521, [], [], 'fam1', 1 ).
test( 't90', 303, [], [], 'fam1', 1 ).
test( 't91', 272, [], [], 'fam1', 1 ).
test( 't92', 409, [], [], 'fam1', 1 ).
test( 't93', 103, [], [], 'fam1', 1 ).
test( 't94', 39, [], [], 'fam1', 1 ).
test( 't95', 61, [], ['r3'], 'fam1', 1 ).
test( 't96', 186, [], [], 'fam1', 1 ).
test( 't97', 453, ['m10'], [], 'fam1', 1 ).
test( 't98', 76, [], [], 'fam1', 1 ).
test( 't99', 65, [], ['r3'], 'fam1', 1 ).
test( 't100', 667, [], ['r3','r2','r1'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
