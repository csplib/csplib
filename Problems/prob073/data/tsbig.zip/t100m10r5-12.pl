%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 555, [], [], 'fam1', 1 ).
test( 't2', 230, [], [], 'fam1', 1 ).
test( 't3', 153, [], [], 'fam1', 1 ).
test( 't4', 124, ['m3'], ['r1','r2','r5','r3'], 'fam1', 1 ).
test( 't5', 674, [], [], 'fam1', 1 ).
test( 't6', 712, [], [], 'fam1', 1 ).
test( 't7', 640, [], [], 'fam1', 1 ).
test( 't8', 326, [], [], 'fam1', 1 ).
test( 't9', 737, ['m4'], [], 'fam1', 1 ).
test( 't10', 774, [], [], 'fam1', 1 ).
test( 't11', 19, [], ['r1','r2'], 'fam1', 1 ).
test( 't12', 255, [], [], 'fam1', 1 ).
test( 't13', 114, [], [], 'fam1', 1 ).
test( 't14', 267, [], [], 'fam1', 1 ).
test( 't15', 432, ['m3','m8'], ['r1','r2','r3','r5','r4'], 'fam1', 1 ).
test( 't16', 80, [], [], 'fam1', 1 ).
test( 't17', 347, [], ['r2','r5','r3','r4','r1'], 'fam1', 1 ).
test( 't18', 296, ['m3','m2','m5','m1'], [], 'fam1', 1 ).
test( 't19', 81, ['m8','m1','m2','m10'], [], 'fam1', 1 ).
test( 't20', 387, [], [], 'fam1', 1 ).
test( 't21', 274, [], [], 'fam1', 1 ).
test( 't22', 641, [], [], 'fam1', 1 ).
test( 't23', 257, [], ['r5','r4'], 'fam1', 1 ).
test( 't24', 666, [], [], 'fam1', 1 ).
test( 't25', 312, ['m7','m8','m6'], [], 'fam1', 1 ).
test( 't26', 670, ['m8','m6','m7'], [], 'fam1', 1 ).
test( 't27', 534, [], ['r1','r4'], 'fam1', 1 ).
test( 't28', 202, [], [], 'fam1', 1 ).
test( 't29', 623, ['m8','m7','m1','m5'], ['r3','r2','r5','r4'], 'fam1', 1 ).
test( 't30', 205, [], ['r3','r5','r1','r2','r4'], 'fam1', 1 ).
test( 't31', 16, [], [], 'fam1', 1 ).
test( 't32', 304, [], [], 'fam1', 1 ).
test( 't33', 176, [], [], 'fam1', 1 ).
test( 't34', 695, [], [], 'fam1', 1 ).
test( 't35', 675, [], [], 'fam1', 1 ).
test( 't36', 62, ['m7','m6','m9'], [], 'fam1', 1 ).
test( 't37', 594, [], ['r1','r2','r3','r4'], 'fam1', 1 ).
test( 't38', 532, [], [], 'fam1', 1 ).
test( 't39', 208, [], [], 'fam1', 1 ).
test( 't40', 293, [], ['r3','r4','r2','r5','r1'], 'fam1', 1 ).
test( 't41', 464, [], [], 'fam1', 1 ).
test( 't42', 745, ['m1','m3','m8','m9'], [], 'fam1', 1 ).
test( 't43', 215, [], ['r1'], 'fam1', 1 ).
test( 't44', 250, [], [], 'fam1', 1 ).
test( 't45', 208, ['m8','m1','m9','m3'], [], 'fam1', 1 ).
test( 't46', 111, [], ['r1','r5','r3','r2'], 'fam1', 1 ).
test( 't47', 466, [], [], 'fam1', 1 ).
test( 't48', 177, [], [], 'fam1', 1 ).
test( 't49', 144, [], [], 'fam1', 1 ).
test( 't50', 316, [], ['r5','r4','r1','r2','r3'], 'fam1', 1 ).
test( 't51', 424, [], ['r2','r1','r4','r3'], 'fam1', 1 ).
test( 't52', 265, [], [], 'fam1', 1 ).
test( 't53', 239, [], [], 'fam1', 1 ).
test( 't54', 323, ['m5','m1','m2','m4'], [], 'fam1', 1 ).
test( 't55', 491, ['m9','m5'], [], 'fam1', 1 ).
test( 't56', 481, [], ['r1','r3'], 'fam1', 1 ).
test( 't57', 16, [], [], 'fam1', 1 ).
test( 't58', 548, [], [], 'fam1', 1 ).
test( 't59', 635, [], [], 'fam1', 1 ).
test( 't60', 463, ['m1'], [], 'fam1', 1 ).
test( 't61', 554, [], [], 'fam1', 1 ).
test( 't62', 130, [], [], 'fam1', 1 ).
test( 't63', 156, [], ['r5','r4','r2','r3','r1'], 'fam1', 1 ).
test( 't64', 626, [], [], 'fam1', 1 ).
test( 't65', 495, [], ['r1','r5','r2','r4'], 'fam1', 1 ).
test( 't66', 783, ['m2','m3','m1'], [], 'fam1', 1 ).
test( 't67', 159, [], [], 'fam1', 1 ).
test( 't68', 357, [], [], 'fam1', 1 ).
test( 't69', 275, [], [], 'fam1', 1 ).
test( 't70', 492, [], [], 'fam1', 1 ).
test( 't71', 580, [], [], 'fam1', 1 ).
test( 't72', 219, [], [], 'fam1', 1 ).
test( 't73', 196, ['m8'], [], 'fam1', 1 ).
test( 't74', 589, [], ['r4'], 'fam1', 1 ).
test( 't75', 356, ['m5','m7'], ['r2','r5','r4'], 'fam1', 1 ).
test( 't76', 461, [], [], 'fam1', 1 ).
test( 't77', 763, [], [], 'fam1', 1 ).
test( 't78', 233, [], [], 'fam1', 1 ).
test( 't79', 81, [], [], 'fam1', 1 ).
test( 't80', 476, [], [], 'fam1', 1 ).
test( 't81', 17, ['m7'], [], 'fam1', 1 ).
test( 't82', 487, [], [], 'fam1', 1 ).
test( 't83', 424, [], [], 'fam1', 1 ).
test( 't84', 24, ['m9','m3'], ['r1','r4','r2','r3'], 'fam1', 1 ).
test( 't85', 575, [], [], 'fam1', 1 ).
test( 't86', 173, [], ['r2','r4','r1','r3'], 'fam1', 1 ).
test( 't87', 570, [], [], 'fam1', 1 ).
test( 't88', 415, [], [], 'fam1', 1 ).
test( 't89', 543, [], [], 'fam1', 1 ).
test( 't90', 480, [], [], 'fam1', 1 ).
test( 't91', 296, ['m2','m6','m9','m5'], [], 'fam1', 1 ).
test( 't92', 460, [], [], 'fam1', 1 ).
test( 't93', 504, [], [], 'fam1', 1 ).
test( 't94', 77, [], [], 'fam1', 1 ).
test( 't95', 449, ['m6','m9','m3','m2'], ['r3','r4','r2','r1'], 'fam1', 1 ).
test( 't96', 172, [], [], 'fam1', 1 ).
test( 't97', 114, ['m9','m1','m5','m10'], ['r1'], 'fam1', 1 ).
test( 't98', 656, ['m2','m7'], [], 'fam1', 1 ).
test( 't99', 271, [], ['r2','r4','r3','r1','r5'], 'fam1', 1 ).
test( 't100', 373, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
