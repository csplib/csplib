%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 50
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 608, [], [], 'fam1', 1 ).
test( 't2', 251, [], ['r2'], 'fam1', 1 ).
test( 't3', 313, [], [], 'fam1', 1 ).
test( 't4', 682, [], ['r2'], 'fam1', 1 ).
test( 't5', 392, [], [], 'fam1', 1 ).
test( 't6', 579, [], [], 'fam1', 1 ).
test( 't7', 521, [], [], 'fam1', 1 ).
test( 't8', 40, [], [], 'fam1', 1 ).
test( 't9', 750, [], [], 'fam1', 1 ).
test( 't10', 346, [], ['r2','r1','r5','r3','r4'], 'fam1', 1 ).
test( 't11', 539, [], [], 'fam1', 1 ).
test( 't12', 748, [], ['r5','r3'], 'fam1', 1 ).
test( 't13', 746, ['m6','m32','m10','m47','m12','m8','m29','m34','m33','m31','m11','m38','m24','m48'], [], 'fam1', 1 ).
test( 't14', 349, ['m32','m30','m41','m2','m45','m37','m40','m1','m42','m27','m46','m33','m44','m15','m34'], [], 'fam1', 1 ).
test( 't15', 229, [], [], 'fam1', 1 ).
test( 't16', 756, [], [], 'fam1', 1 ).
test( 't17', 441, [], ['r4','r2','r3','r1','r5'], 'fam1', 1 ).
test( 't18', 283, [], [], 'fam1', 1 ).
test( 't19', 487, ['m35','m33','m32'], ['r5','r2'], 'fam1', 1 ).
test( 't20', 135, [], [], 'fam1', 1 ).
test( 't21', 282, [], [], 'fam1', 1 ).
test( 't22', 475, [], [], 'fam1', 1 ).
test( 't23', 296, [], ['r5'], 'fam1', 1 ).
test( 't24', 801, [], [], 'fam1', 1 ).
test( 't25', 617, [], [], 'fam1', 1 ).
test( 't26', 379, [], [], 'fam1', 1 ).
test( 't27', 40, [], [], 'fam1', 1 ).
test( 't28', 84, [], ['r2','r1','r4','r5','r3'], 'fam1', 1 ).
test( 't29', 241, [], [], 'fam1', 1 ).
test( 't30', 47, ['m21'], [], 'fam1', 1 ).
test( 't31', 560, [], [], 'fam1', 1 ).
test( 't32', 128, [], [], 'fam1', 1 ).
test( 't33', 752, [], [], 'fam1', 1 ).
test( 't34', 541, ['m32','m23','m21','m38','m48','m44','m43','m19','m17','m7','m41','m5','m36'], ['r4','r5'], 'fam1', 1 ).
test( 't35', 389, [], [], 'fam1', 1 ).
test( 't36', 67, [], ['r2','r4'], 'fam1', 1 ).
test( 't37', 376, [], ['r1','r2'], 'fam1', 1 ).
test( 't38', 334, [], [], 'fam1', 1 ).
test( 't39', 556, [], ['r3','r2','r4','r1'], 'fam1', 1 ).
test( 't40', 578, [], [], 'fam1', 1 ).
test( 't41', 425, [], [], 'fam1', 1 ).
test( 't42', 179, ['m35','m8','m11','m20','m40','m2','m46','m41','m12','m21','m26','m34','m47','m15','m14','m28','m49','m23','m3'], [], 'fam1', 1 ).
test( 't43', 662, ['m16','m36','m20','m32','m31','m4','m8','m12','m14','m13','m42','m10','m27','m3'], ['r5','r3','r2','r4'], 'fam1', 1 ).
test( 't44', 131, [], [], 'fam1', 1 ).
test( 't45', 392, [], ['r1','r3','r2','r4'], 'fam1', 1 ).
test( 't46', 394, [], [], 'fam1', 1 ).
test( 't47', 300, [], [], 'fam1', 1 ).
test( 't48', 662, [], [], 'fam1', 1 ).
test( 't49', 712, [], ['r3','r5','r2','r4'], 'fam1', 1 ).
test( 't50', 588, [], [], 'fam1', 1 ).
test( 't51', 383, [], [], 'fam1', 1 ).
test( 't52', 585, [], ['r2','r4','r5'], 'fam1', 1 ).
test( 't53', 102, ['m15','m14','m47','m21','m19','m49','m37','m16','m11','m41','m22','m26','m44','m36','m24','m23','m20'], [], 'fam1', 1 ).
test( 't54', 441, ['m38','m3','m4','m18','m22','m34','m28'], [], 'fam1', 1 ).
test( 't55', 1, ['m1','m26','m10','m6','m49','m48','m29','m14','m44','m2','m5','m23','m40','m35','m18','m13','m36','m21','m47'], [], 'fam1', 1 ).
test( 't56', 533, [], [], 'fam1', 1 ).
test( 't57', 285, [], [], 'fam1', 1 ).
test( 't58', 760, [], [], 'fam1', 1 ).
test( 't59', 4, [], [], 'fam1', 1 ).
test( 't60', 531, [], ['r4','r3','r5','r1','r2'], 'fam1', 1 ).
test( 't61', 650, [], [], 'fam1', 1 ).
test( 't62', 663, ['m15','m48','m43','m21','m47'], ['r3','r2','r4'], 'fam1', 1 ).
test( 't63', 649, [], [], 'fam1', 1 ).
test( 't64', 624, [], [], 'fam1', 1 ).
test( 't65', 754, [], [], 'fam1', 1 ).
test( 't66', 763, ['m5','m46','m26','m32','m28','m40','m10','m38','m21','m50','m11','m3','m15','m6','m18','m44','m13'], ['r3'], 'fam1', 1 ).
test( 't67', 235, [], [], 'fam1', 1 ).
test( 't68', 2, [], [], 'fam1', 1 ).
test( 't69', 122, [], [], 'fam1', 1 ).
test( 't70', 153, [], ['r5','r2','r3','r1','r4'], 'fam1', 1 ).
test( 't71', 134, [], [], 'fam1', 1 ).
test( 't72', 426, [], [], 'fam1', 1 ).
test( 't73', 455, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't74', 89, [], [], 'fam1', 1 ).
test( 't75', 247, [], [], 'fam1', 1 ).
test( 't76', 317, [], [], 'fam1', 1 ).
test( 't77', 180, [], ['r2','r5','r1','r3'], 'fam1', 1 ).
test( 't78', 428, [], [], 'fam1', 1 ).
test( 't79', 625, [], [], 'fam1', 1 ).
test( 't80', 121, [], [], 'fam1', 1 ).
test( 't81', 55, [], [], 'fam1', 1 ).
test( 't82', 459, [], ['r5','r2'], 'fam1', 1 ).
test( 't83', 689, [], [], 'fam1', 1 ).
test( 't84', 245, [], [], 'fam1', 1 ).
test( 't85', 390, [], ['r1','r5','r3','r4','r2'], 'fam1', 1 ).
test( 't86', 274, [], [], 'fam1', 1 ).
test( 't87', 780, [], [], 'fam1', 1 ).
test( 't88', 464, [], ['r1','r4'], 'fam1', 1 ).
test( 't89', 256, [], [], 'fam1', 1 ).
test( 't90', 753, [], ['r2','r1','r5','r4'], 'fam1', 1 ).
test( 't91', 793, [], [], 'fam1', 1 ).
test( 't92', 752, [], ['r3','r5','r2'], 'fam1', 1 ).
test( 't93', 651, [], [], 'fam1', 1 ).
test( 't94', 488, [], [], 'fam1', 1 ).
test( 't95', 478, [], [], 'fam1', 1 ).
test( 't96', 492, [], [], 'fam1', 1 ).
test( 't97', 376, [], [], 'fam1', 1 ).
test( 't98', 133, [], [], 'fam1', 1 ).
test( 't99', 372, ['m19','m24','m16','m21','m36','m1','m18','m46','m30','m39','m13','m41','m35','m29'], [], 'fam1', 1 ).
test( 't100', 432, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').
embedded_board( 'm21').
embedded_board( 'm22').
embedded_board( 'm23').
embedded_board( 'm24').
embedded_board( 'm25').
embedded_board( 'm26').
embedded_board( 'm27').
embedded_board( 'm28').
embedded_board( 'm29').
embedded_board( 'm30').
embedded_board( 'm31').
embedded_board( 'm32').
embedded_board( 'm33').
embedded_board( 'm34').
embedded_board( 'm35').
embedded_board( 'm36').
embedded_board( 'm37').
embedded_board( 'm38').
embedded_board( 'm39').
embedded_board( 'm40').
embedded_board( 'm41').
embedded_board( 'm42').
embedded_board( 'm43').
embedded_board( 'm44').
embedded_board( 'm45').
embedded_board( 'm46').
embedded_board( 'm47').
embedded_board( 'm48').
embedded_board( 'm49').
embedded_board( 'm50').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
