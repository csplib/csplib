%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 565, [], ['r5','r1','r3','r2'], 'fam1', 1 ).
test( 't2', 69, [], [], 'fam1', 1 ).
test( 't3', 632, [], ['r1'], 'fam1', 1 ).
test( 't4', 386, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't5', 387, [], [], 'fam1', 1 ).
test( 't6', 533, [], ['r5','r3','r2','r1'], 'fam1', 1 ).
test( 't7', 548, [], [], 'fam1', 1 ).
test( 't8', 190, [], ['r2','r4','r1','r3','r5'], 'fam1', 1 ).
test( 't9', 218, [], [], 'fam1', 1 ).
test( 't10', 557, ['m9','m7'], [], 'fam1', 1 ).
test( 't11', 302, [], ['r3','r2','r1','r4'], 'fam1', 1 ).
test( 't12', 258, [], ['r1','r4','r3','r5'], 'fam1', 1 ).
test( 't13', 277, [], [], 'fam1', 1 ).
test( 't14', 660, ['m3','m2','m8','m4'], [], 'fam1', 1 ).
test( 't15', 381, [], [], 'fam1', 1 ).
test( 't16', 665, [], ['r1','r2'], 'fam1', 1 ).
test( 't17', 102, [], ['r5','r1','r2','r4','r3'], 'fam1', 1 ).
test( 't18', 636, [], ['r5','r1','r2'], 'fam1', 1 ).
test( 't19', 166, ['m9','m7','m6'], [], 'fam1', 1 ).
test( 't20', 774, [], [], 'fam1', 1 ).
test( 't21', 692, [], ['r1','r5','r4','r3','r2'], 'fam1', 1 ).
test( 't22', 726, [], [], 'fam1', 1 ).
test( 't23', 490, [], [], 'fam1', 1 ).
test( 't24', 11, [], ['r2','r1','r4','r5'], 'fam1', 1 ).
test( 't25', 705, ['m2','m1','m8','m7'], [], 'fam1', 1 ).
test( 't26', 515, ['m1'], [], 'fam1', 1 ).
test( 't27', 644, [], ['r4','r5','r1'], 'fam1', 1 ).
test( 't28', 758, ['m1'], [], 'fam1', 1 ).
test( 't29', 317, [], [], 'fam1', 1 ).
test( 't30', 423, ['m4','m8','m2'], [], 'fam1', 1 ).
test( 't31', 749, [], [], 'fam1', 1 ).
test( 't32', 648, ['m5','m2'], [], 'fam1', 1 ).
test( 't33', 340, ['m1','m10','m2'], ['r1','r3','r5','r4','r2'], 'fam1', 1 ).
test( 't34', 598, [], ['r4','r1','r5','r3','r2'], 'fam1', 1 ).
test( 't35', 100, [], [], 'fam1', 1 ).
test( 't36', 366, ['m8','m10','m1'], ['r5'], 'fam1', 1 ).
test( 't37', 8, [], [], 'fam1', 1 ).
test( 't38', 67, [], ['r2','r5','r3','r4'], 'fam1', 1 ).
test( 't39', 608, ['m10','m2','m7'], ['r1','r4'], 'fam1', 1 ).
test( 't40', 338, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
