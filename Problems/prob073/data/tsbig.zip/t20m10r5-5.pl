%% ****  Testsuite  ****
% Number of tests                  : 20
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 213, ['m4','m3','m9'], [], 'fam1', 1 ).
test( 't2', 136, [], [], 'fam1', 1 ).
test( 't3', 531, [], [], 'fam1', 1 ).
test( 't4', 675, [], [], 'fam1', 1 ).
test( 't5', 706, [], [], 'fam1', 1 ).
test( 't6', 138, [], [], 'fam1', 1 ).
test( 't7', 404, ['m7','m2'], [], 'fam1', 1 ).
test( 't8', 794, [], [], 'fam1', 1 ).
test( 't9', 63, [], [], 'fam1', 1 ).
test( 't10', 193, [], ['r3','r1'], 'fam1', 1 ).
test( 't11', 208, [], [], 'fam1', 1 ).
test( 't12', 83, ['m2','m4'], [], 'fam1', 1 ).
test( 't13', 212, [], [], 'fam1', 1 ).
test( 't14', 671, [], [], 'fam1', 1 ).
test( 't15', 599, [], [], 'fam1', 1 ).
test( 't16', 161, ['m8'], [], 'fam1', 1 ).
test( 't17', 171, [], [], 'fam1', 1 ).
test( 't18', 309, [], [], 'fam1', 1 ).
test( 't19', 133, [], [], 'fam1', 1 ).
test( 't20', 154, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
