%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 335, [], [], 'fam1', 1 ).
test( 't2', 50, [], [], 'fam1', 1 ).
test( 't3', 363, [], [], 'fam1', 1 ).
test( 't4', 143, [], [], 'fam1', 1 ).
test( 't5', 514, ['m8','m3','m7'], [], 'fam1', 1 ).
test( 't6', 184, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't7', 707, [], [], 'fam1', 1 ).
test( 't8', 132, ['m4','m6','m3'], [], 'fam1', 1 ).
test( 't9', 747, [], [], 'fam1', 1 ).
test( 't10', 603, ['m7','m3','m9','m6'], [], 'fam1', 1 ).
test( 't11', 273, [], [], 'fam1', 1 ).
test( 't12', 717, ['m2','m6','m10'], ['r2','r1'], 'fam1', 1 ).
test( 't13', 595, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't14', 656, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't15', 149, [], [], 'fam1', 1 ).
test( 't16', 310, [], [], 'fam1', 1 ).
test( 't17', 470, [], [], 'fam1', 1 ).
test( 't18', 657, [], [], 'fam1', 1 ).
test( 't19', 401, [], ['r1','r2'], 'fam1', 1 ).
test( 't20', 410, [], [], 'fam1', 1 ).
test( 't21', 708, [], [], 'fam1', 1 ).
test( 't22', 317, [], ['r3','r2'], 'fam1', 1 ).
test( 't23', 662, [], [], 'fam1', 1 ).
test( 't24', 438, [], [], 'fam1', 1 ).
test( 't25', 110, ['m10','m9'], [], 'fam1', 1 ).
test( 't26', 665, [], [], 'fam1', 1 ).
test( 't27', 772, [], [], 'fam1', 1 ).
test( 't28', 731, ['m9','m10','m3'], [], 'fam1', 1 ).
test( 't29', 670, ['m3'], [], 'fam1', 1 ).
test( 't30', 524, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
