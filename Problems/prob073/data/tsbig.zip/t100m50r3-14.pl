%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 50
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 540, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't2', 468, [], [], 'fam1', 1 ).
test( 't3', 492, [], [], 'fam1', 1 ).
test( 't4', 59, [], [], 'fam1', 1 ).
test( 't5', 32, [], ['r3','r2'], 'fam1', 1 ).
test( 't6', 153, [], [], 'fam1', 1 ).
test( 't7', 156, ['m5','m28','m45','m22','m24','m38','m21','m10','m4','m7','m2','m6','m18','m31','m33','m8','m49','m44'], ['r2','r3'], 'fam1', 1 ).
test( 't8', 31, [], [], 'fam1', 1 ).
test( 't9', 424, [], ['r3','r1'], 'fam1', 1 ).
test( 't10', 561, ['m5','m9','m14','m27'], [], 'fam1', 1 ).
test( 't11', 588, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't12', 716, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't13', 216, [], [], 'fam1', 1 ).
test( 't14', 365, [], [], 'fam1', 1 ).
test( 't15', 652, [], [], 'fam1', 1 ).
test( 't16', 157, [], ['r3'], 'fam1', 1 ).
test( 't17', 361, [], [], 'fam1', 1 ).
test( 't18', 236, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't19', 324, [], [], 'fam1', 1 ).
test( 't20', 705, ['m38','m20','m10','m11','m5','m46','m6','m28','m29','m16','m45','m13','m50','m33','m43'], [], 'fam1', 1 ).
test( 't21', 359, [], [], 'fam1', 1 ).
test( 't22', 407, [], ['r3','r1'], 'fam1', 1 ).
test( 't23', 579, ['m47','m14','m43'], ['r2'], 'fam1', 1 ).
test( 't24', 111, [], ['r3','r1'], 'fam1', 1 ).
test( 't25', 664, [], ['r3','r2'], 'fam1', 1 ).
test( 't26', 326, ['m17','m10','m19','m46','m3','m12','m14','m36','m2'], [], 'fam1', 1 ).
test( 't27', 418, [], ['r1','r2'], 'fam1', 1 ).
test( 't28', 757, [], [], 'fam1', 1 ).
test( 't29', 676, [], [], 'fam1', 1 ).
test( 't30', 490, [], [], 'fam1', 1 ).
test( 't31', 324, [], ['r3','r2'], 'fam1', 1 ).
test( 't32', 545, [], [], 'fam1', 1 ).
test( 't33', 481, [], [], 'fam1', 1 ).
test( 't34', 641, ['m20','m30','m19','m34','m22','m38','m33','m44','m23','m46','m40','m39','m41','m47','m26'], [], 'fam1', 1 ).
test( 't35', 24, ['m43','m25','m39','m42','m44','m13','m28','m40','m5','m47','m6','m32','m11','m49','m4','m17','m10','m7','m27','m34'], [], 'fam1', 1 ).
test( 't36', 2, [], [], 'fam1', 1 ).
test( 't37', 382, [], ['r2'], 'fam1', 1 ).
test( 't38', 92, [], [], 'fam1', 1 ).
test( 't39', 665, [], [], 'fam1', 1 ).
test( 't40', 205, [], [], 'fam1', 1 ).
test( 't41', 222, ['m29','m38'], [], 'fam1', 1 ).
test( 't42', 345, ['m30','m21','m8','m1','m13','m25','m20','m43','m3','m24','m19','m42','m44','m39','m38','m26','m41','m11','m48','m33'], ['r1'], 'fam1', 1 ).
test( 't43', 475, [], [], 'fam1', 1 ).
test( 't44', 513, [], [], 'fam1', 1 ).
test( 't45', 275, [], [], 'fam1', 1 ).
test( 't46', 623, [], [], 'fam1', 1 ).
test( 't47', 676, [], ['r3','r1'], 'fam1', 1 ).
test( 't48', 630, [], [], 'fam1', 1 ).
test( 't49', 562, [], [], 'fam1', 1 ).
test( 't50', 6, [], [], 'fam1', 1 ).
test( 't51', 551, ['m43','m21','m6','m27','m17','m24','m50','m34','m32','m4','m2','m18','m49','m41','m12'], ['r3','r1','r2'], 'fam1', 1 ).
test( 't52', 141, [], [], 'fam1', 1 ).
test( 't53', 337, [], [], 'fam1', 1 ).
test( 't54', 711, [], [], 'fam1', 1 ).
test( 't55', 33, [], [], 'fam1', 1 ).
test( 't56', 374, [], [], 'fam1', 1 ).
test( 't57', 641, ['m9','m41','m28','m46','m12','m21','m4','m7','m49','m23','m40','m18','m10','m13','m47','m3'], [], 'fam1', 1 ).
test( 't58', 358, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't59', 128, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't60', 509, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't61', 552, [], [], 'fam1', 1 ).
test( 't62', 646, [], [], 'fam1', 1 ).
test( 't63', 377, [], ['r3','r1'], 'fam1', 1 ).
test( 't64', 43, [], ['r3','r1'], 'fam1', 1 ).
test( 't65', 726, ['m41'], ['r1','r3','r2'], 'fam1', 1 ).
test( 't66', 286, [], ['r1'], 'fam1', 1 ).
test( 't67', 69, [], [], 'fam1', 1 ).
test( 't68', 2, [], [], 'fam1', 1 ).
test( 't69', 72, ['m17','m50','m36','m38','m13','m5','m34','m46','m14','m29','m12','m7','m2'], [], 'fam1', 1 ).
test( 't70', 410, ['m25','m49','m30','m36','m6','m43','m15','m11','m28','m7','m44','m33','m9','m16','m47'], ['r1','r3','r2'], 'fam1', 1 ).
test( 't71', 645, ['m41','m12','m20','m40','m27','m18','m16','m19','m14','m10','m4','m45','m15','m35','m46','m6','m49','m26','m17'], ['r3','r2','r1'], 'fam1', 1 ).
test( 't72', 683, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't73', 174, [], [], 'fam1', 1 ).
test( 't74', 719, [], ['r1','r2'], 'fam1', 1 ).
test( 't75', 628, [], [], 'fam1', 1 ).
test( 't76', 260, [], [], 'fam1', 1 ).
test( 't77', 654, ['m43','m21','m37','m49','m29','m22'], ['r2','r3'], 'fam1', 1 ).
test( 't78', 723, [], [], 'fam1', 1 ).
test( 't79', 782, [], [], 'fam1', 1 ).
test( 't80', 162, ['m37','m17','m8','m21','m46','m44','m4','m26','m27','m35','m25','m24','m10','m32','m15','m45','m41','m40','m29','m14'], [], 'fam1', 1 ).
test( 't81', 696, [], [], 'fam1', 1 ).
test( 't82', 544, [], [], 'fam1', 1 ).
test( 't83', 272, [], [], 'fam1', 1 ).
test( 't84', 680, [], [], 'fam1', 1 ).
test( 't85', 692, ['m50','m8','m31','m36','m40','m43','m49','m17','m21','m3','m39','m6','m37','m23','m19','m33','m47'], ['r2'], 'fam1', 1 ).
test( 't86', 163, [], ['r2'], 'fam1', 1 ).
test( 't87', 468, [], [], 'fam1', 1 ).
test( 't88', 159, [], [], 'fam1', 1 ).
test( 't89', 396, [], [], 'fam1', 1 ).
test( 't90', 497, ['m44','m14','m9','m36','m38','m46','m6','m28','m25','m7','m42','m5','m41','m22','m3','m32','m34','m4'], ['r3','r2','r1'], 'fam1', 1 ).
test( 't91', 339, [], ['r1','r2'], 'fam1', 1 ).
test( 't92', 264, ['m19','m24','m41','m39','m9','m26','m29','m10','m17','m33','m2','m22','m8','m3','m45','m15','m12','m11'], [], 'fam1', 1 ).
test( 't93', 78, [], [], 'fam1', 1 ).
test( 't94', 365, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't95', 33, [], [], 'fam1', 1 ).
test( 't96', 537, [], [], 'fam1', 1 ).
test( 't97', 400, ['m13','m8'], [], 'fam1', 1 ).
test( 't98', 722, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't99', 660, [], [], 'fam1', 1 ).
test( 't100', 765, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').
embedded_board( 'm21').
embedded_board( 'm22').
embedded_board( 'm23').
embedded_board( 'm24').
embedded_board( 'm25').
embedded_board( 'm26').
embedded_board( 'm27').
embedded_board( 'm28').
embedded_board( 'm29').
embedded_board( 'm30').
embedded_board( 'm31').
embedded_board( 'm32').
embedded_board( 'm33').
embedded_board( 'm34').
embedded_board( 'm35').
embedded_board( 'm36').
embedded_board( 'm37').
embedded_board( 'm38').
embedded_board( 'm39').
embedded_board( 'm40').
embedded_board( 'm41').
embedded_board( 'm42').
embedded_board( 'm43').
embedded_board( 'm44').
embedded_board( 'm45').
embedded_board( 'm46').
embedded_board( 'm47').
embedded_board( 'm48').
embedded_board( 'm49').
embedded_board( 'm50').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
