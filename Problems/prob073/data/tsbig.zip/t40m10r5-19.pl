%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 467, ['m10'], [], 'fam1', 1 ).
test( 't2', 676, [], [], 'fam1', 1 ).
test( 't3', 305, ['m2','m9','m10'], [], 'fam1', 1 ).
test( 't4', 323, [], ['r1'], 'fam1', 1 ).
test( 't5', 249, [], ['r5','r3','r1','r4','r2'], 'fam1', 1 ).
test( 't6', 300, [], [], 'fam1', 1 ).
test( 't7', 554, [], ['r4','r2','r3'], 'fam1', 1 ).
test( 't8', 471, [], [], 'fam1', 1 ).
test( 't9', 480, [], [], 'fam1', 1 ).
test( 't10', 412, [], [], 'fam1', 1 ).
test( 't11', 794, [], ['r4','r3','r1','r5','r2'], 'fam1', 1 ).
test( 't12', 166, [], ['r3','r2','r4','r1','r5'], 'fam1', 1 ).
test( 't13', 174, [], [], 'fam1', 1 ).
test( 't14', 197, [], [], 'fam1', 1 ).
test( 't15', 451, ['m7'], ['r1'], 'fam1', 1 ).
test( 't16', 377, [], [], 'fam1', 1 ).
test( 't17', 799, [], [], 'fam1', 1 ).
test( 't18', 715, [], ['r2'], 'fam1', 1 ).
test( 't19', 176, [], ['r1','r5','r3','r2','r4'], 'fam1', 1 ).
test( 't20', 335, ['m5','m8','m9'], [], 'fam1', 1 ).
test( 't21', 151, [], [], 'fam1', 1 ).
test( 't22', 201, [], [], 'fam1', 1 ).
test( 't23', 286, ['m7','m10'], [], 'fam1', 1 ).
test( 't24', 761, [], ['r2','r4','r5','r1'], 'fam1', 1 ).
test( 't25', 396, [], [], 'fam1', 1 ).
test( 't26', 50, [], [], 'fam1', 1 ).
test( 't27', 37, [], [], 'fam1', 1 ).
test( 't28', 797, [], [], 'fam1', 1 ).
test( 't29', 563, ['m8','m6','m4','m2'], [], 'fam1', 1 ).
test( 't30', 545, [], [], 'fam1', 1 ).
test( 't31', 760, [], [], 'fam1', 1 ).
test( 't32', 190, [], [], 'fam1', 1 ).
test( 't33', 697, [], [], 'fam1', 1 ).
test( 't34', 27, [], [], 'fam1', 1 ).
test( 't35', 612, [], ['r2','r1','r3','r4'], 'fam1', 1 ).
test( 't36', 397, [], [], 'fam1', 1 ).
test( 't37', 124, ['m2','m5','m6'], ['r3','r4','r1','r5'], 'fam1', 1 ).
test( 't38', 372, [], [], 'fam1', 1 ).
test( 't39', 347, ['m5','m4'], [], 'fam1', 1 ).
test( 't40', 609, ['m9','m2','m10'], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
