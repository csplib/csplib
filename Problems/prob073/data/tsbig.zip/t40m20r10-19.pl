%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 20
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 304, [], [], 'fam1', 1 ).
test( 't2', 522, ['m16'], [], 'fam1', 1 ).
test( 't3', 274, [], ['r5','r2','r4','r3','r8','r10'], 'fam1', 1 ).
test( 't4', 326, [], [], 'fam1', 1 ).
test( 't5', 597, [], ['r9'], 'fam1', 1 ).
test( 't6', 365, [], ['r9','r4'], 'fam1', 1 ).
test( 't7', 665, ['m1','m12'], [], 'fam1', 1 ).
test( 't8', 279, [], ['r4'], 'fam1', 1 ).
test( 't9', 108, [], [], 'fam1', 1 ).
test( 't10', 314, [], [], 'fam1', 1 ).
test( 't11', 101, [], [], 'fam1', 1 ).
test( 't12', 770, [], [], 'fam1', 1 ).
test( 't13', 214, [], [], 'fam1', 1 ).
test( 't14', 746, [], [], 'fam1', 1 ).
test( 't15', 136, [], ['r4','r2','r9','r8','r7','r5','r3','r10','r6','r1'], 'fam1', 1 ).
test( 't16', 473, ['m9','m6','m19','m1','m17','m13','m10','m20'], [], 'fam1', 1 ).
test( 't17', 145, [], [], 'fam1', 1 ).
test( 't18', 759, [], [], 'fam1', 1 ).
test( 't19', 472, [], [], 'fam1', 1 ).
test( 't20', 210, ['m18','m11','m1','m19','m8'], [], 'fam1', 1 ).
test( 't21', 783, [], ['r5','r6'], 'fam1', 1 ).
test( 't22', 178, [], [], 'fam1', 1 ).
test( 't23', 184, [], ['r3','r10','r7'], 'fam1', 1 ).
test( 't24', 218, [], [], 'fam1', 1 ).
test( 't25', 616, [], ['r5','r7','r1','r3','r6','r8','r10','r2'], 'fam1', 1 ).
test( 't26', 745, [], ['r7','r6','r4'], 'fam1', 1 ).
test( 't27', 312, [], [], 'fam1', 1 ).
test( 't28', 536, [], [], 'fam1', 1 ).
test( 't29', 757, [], [], 'fam1', 1 ).
test( 't30', 749, [], [], 'fam1', 1 ).
test( 't31', 291, [], [], 'fam1', 1 ).
test( 't32', 97, [], [], 'fam1', 1 ).
test( 't33', 337, [], ['r8','r3','r5','r7','r4','r6'], 'fam1', 1 ).
test( 't34', 94, ['m12','m18','m3','m1'], [], 'fam1', 1 ).
test( 't35', 153, ['m15','m9','m8','m10','m5','m6','m13'], [], 'fam1', 1 ).
test( 't36', 523, [], [], 'fam1', 1 ).
test( 't37', 522, [], [], 'fam1', 1 ).
test( 't38', 493, ['m3','m10','m18','m19','m7','m8','m1','m17'], [], 'fam1', 1 ).
test( 't39', 765, [], [], 'fam1', 1 ).
test( 't40', 369, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
