%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 10
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 429, [], ['r4','r6','r3','r9'], 'fam1', 1 ).
test( 't2', 781, [], [], 'fam1', 1 ).
test( 't3', 590, [], [], 'fam1', 1 ).
test( 't4', 71, [], [], 'fam1', 1 ).
test( 't5', 156, [], [], 'fam1', 1 ).
test( 't6', 769, [], [], 'fam1', 1 ).
test( 't7', 239, ['m8'], [], 'fam1', 1 ).
test( 't8', 271, [], [], 'fam1', 1 ).
test( 't9', 98, [], ['r7','r10'], 'fam1', 1 ).
test( 't10', 309, [], [], 'fam1', 1 ).
test( 't11', 629, [], [], 'fam1', 1 ).
test( 't12', 428, [], ['r10','r2','r5','r9','r8','r4','r1','r6','r7'], 'fam1', 1 ).
test( 't13', 177, [], [], 'fam1', 1 ).
test( 't14', 451, [], ['r5','r4','r10','r6','r1','r8'], 'fam1', 1 ).
test( 't15', 535, [], ['r4','r5','r6','r7','r9','r8','r3','r1','r10','r2'], 'fam1', 1 ).
test( 't16', 496, [], [], 'fam1', 1 ).
test( 't17', 38, [], [], 'fam1', 1 ).
test( 't18', 424, [], ['r10'], 'fam1', 1 ).
test( 't19', 346, [], [], 'fam1', 1 ).
test( 't20', 62, [], [], 'fam1', 1 ).
test( 't21', 493, [], ['r3','r4','r8','r6','r9','r2','r1','r7','r10'], 'fam1', 1 ).
test( 't22', 262, ['m4','m7','m5'], [], 'fam1', 1 ).
test( 't23', 755, [], [], 'fam1', 1 ).
test( 't24', 67, [], [], 'fam1', 1 ).
test( 't25', 248, [], [], 'fam1', 1 ).
test( 't26', 449, [], [], 'fam1', 1 ).
test( 't27', 92, [], [], 'fam1', 1 ).
test( 't28', 569, [], ['r6','r9'], 'fam1', 1 ).
test( 't29', 525, [], [], 'fam1', 1 ).
test( 't30', 734, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
