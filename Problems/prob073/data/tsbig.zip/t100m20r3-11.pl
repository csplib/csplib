%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 20
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 560, [], [], 'fam1', 1 ).
test( 't2', 424, [], [], 'fam1', 1 ).
test( 't3', 587, [], [], 'fam1', 1 ).
test( 't4', 481, [], [], 'fam1', 1 ).
test( 't5', 402, [], [], 'fam1', 1 ).
test( 't6', 758, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't7', 242, ['m14','m4','m20','m15','m8','m11','m5','m16'], ['r3','r1','r2'], 'fam1', 1 ).
test( 't8', 185, ['m12','m7','m9','m19','m14','m8','m3','m4'], ['r2'], 'fam1', 1 ).
test( 't9', 7, ['m1','m14','m17','m3','m12','m18','m5','m13'], ['r2','r3'], 'fam1', 1 ).
test( 't10', 462, [], [], 'fam1', 1 ).
test( 't11', 200, [], [], 'fam1', 1 ).
test( 't12', 673, [], [], 'fam1', 1 ).
test( 't13', 104, [], [], 'fam1', 1 ).
test( 't14', 384, [], [], 'fam1', 1 ).
test( 't15', 657, [], [], 'fam1', 1 ).
test( 't16', 63, [], [], 'fam1', 1 ).
test( 't17', 340, [], ['r3','r1'], 'fam1', 1 ).
test( 't18', 230, [], [], 'fam1', 1 ).
test( 't19', 268, ['m13','m10','m11','m16'], ['r1'], 'fam1', 1 ).
test( 't20', 66, [], [], 'fam1', 1 ).
test( 't21', 320, ['m3','m13','m11','m16','m4','m5','m9','m12'], [], 'fam1', 1 ).
test( 't22', 130, [], [], 'fam1', 1 ).
test( 't23', 282, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't24', 178, [], ['r3'], 'fam1', 1 ).
test( 't25', 91, [], [], 'fam1', 1 ).
test( 't26', 605, [], ['r1','r3'], 'fam1', 1 ).
test( 't27', 353, [], ['r1'], 'fam1', 1 ).
test( 't28', 600, ['m15','m17','m5','m4','m7','m20','m9','m16'], ['r1','r2'], 'fam1', 1 ).
test( 't29', 776, [], [], 'fam1', 1 ).
test( 't30', 487, [], [], 'fam1', 1 ).
test( 't31', 721, [], [], 'fam1', 1 ).
test( 't32', 412, [], [], 'fam1', 1 ).
test( 't33', 535, [], [], 'fam1', 1 ).
test( 't34', 533, ['m4','m14','m5','m6','m16'], [], 'fam1', 1 ).
test( 't35', 153, [], [], 'fam1', 1 ).
test( 't36', 169, [], [], 'fam1', 1 ).
test( 't37', 76, [], [], 'fam1', 1 ).
test( 't38', 537, ['m13','m16','m2','m7'], [], 'fam1', 1 ).
test( 't39', 736, [], [], 'fam1', 1 ).
test( 't40', 127, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't41', 195, [], [], 'fam1', 1 ).
test( 't42', 214, [], [], 'fam1', 1 ).
test( 't43', 690, [], [], 'fam1', 1 ).
test( 't44', 752, [], [], 'fam1', 1 ).
test( 't45', 794, ['m11','m16','m20','m13','m17','m9'], [], 'fam1', 1 ).
test( 't46', 426, [], ['r3'], 'fam1', 1 ).
test( 't47', 412, ['m19','m12','m6','m10'], [], 'fam1', 1 ).
test( 't48', 5, ['m11','m20','m19','m2','m18','m17','m5','m16'], [], 'fam1', 1 ).
test( 't49', 672, ['m3','m20'], [], 'fam1', 1 ).
test( 't50', 361, [], ['r3','r1'], 'fam1', 1 ).
test( 't51', 401, [], ['r2'], 'fam1', 1 ).
test( 't52', 569, ['m18'], [], 'fam1', 1 ).
test( 't53', 506, [], ['r3','r2'], 'fam1', 1 ).
test( 't54', 358, [], ['r2','r1'], 'fam1', 1 ).
test( 't55', 325, [], [], 'fam1', 1 ).
test( 't56', 553, [], ['r2'], 'fam1', 1 ).
test( 't57', 757, [], [], 'fam1', 1 ).
test( 't58', 438, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't59', 625, [], [], 'fam1', 1 ).
test( 't60', 175, [], [], 'fam1', 1 ).
test( 't61', 355, ['m19'], ['r1'], 'fam1', 1 ).
test( 't62', 174, [], [], 'fam1', 1 ).
test( 't63', 671, ['m6','m20','m14','m18'], [], 'fam1', 1 ).
test( 't64', 34, [], ['r1'], 'fam1', 1 ).
test( 't65', 185, ['m3','m5','m8','m19','m14','m17'], [], 'fam1', 1 ).
test( 't66', 574, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't67', 11, [], [], 'fam1', 1 ).
test( 't68', 678, [], [], 'fam1', 1 ).
test( 't69', 54, [], ['r1'], 'fam1', 1 ).
test( 't70', 395, ['m18'], [], 'fam1', 1 ).
test( 't71', 414, [], [], 'fam1', 1 ).
test( 't72', 362, [], [], 'fam1', 1 ).
test( 't73', 760, [], ['r3','r1'], 'fam1', 1 ).
test( 't74', 607, [], [], 'fam1', 1 ).
test( 't75', 272, [], [], 'fam1', 1 ).
test( 't76', 506, ['m16','m14','m11'], [], 'fam1', 1 ).
test( 't77', 363, [], [], 'fam1', 1 ).
test( 't78', 86, [], [], 'fam1', 1 ).
test( 't79', 733, ['m7','m3','m18','m17','m15','m8','m9'], [], 'fam1', 1 ).
test( 't80', 452, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't81', 336, [], [], 'fam1', 1 ).
test( 't82', 747, ['m17','m13','m6','m9','m2'], ['r2','r1','r3'], 'fam1', 1 ).
test( 't83', 228, [], [], 'fam1', 1 ).
test( 't84', 376, [], ['r2','r1'], 'fam1', 1 ).
test( 't85', 6, [], ['r1'], 'fam1', 1 ).
test( 't86', 69, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't87', 48, [], [], 'fam1', 1 ).
test( 't88', 79, [], [], 'fam1', 1 ).
test( 't89', 192, [], [], 'fam1', 1 ).
test( 't90', 201, [], [], 'fam1', 1 ).
test( 't91', 143, [], ['r3','r1'], 'fam1', 1 ).
test( 't92', 485, [], [], 'fam1', 1 ).
test( 't93', 77, [], [], 'fam1', 1 ).
test( 't94', 782, [], ['r2','r1'], 'fam1', 1 ).
test( 't95', 515, [], [], 'fam1', 1 ).
test( 't96', 284, [], [], 'fam1', 1 ).
test( 't97', 618, [], [], 'fam1', 1 ).
test( 't98', 253, [], ['r2'], 'fam1', 1 ).
test( 't99', 446, ['m16'], [], 'fam1', 1 ).
test( 't100', 664, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
