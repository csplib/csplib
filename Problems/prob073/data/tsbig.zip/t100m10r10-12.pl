%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 10
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 556, [], ['r2','r8','r6','r4','r9','r5','r3','r10'], 'fam1', 1 ).
test( 't2', 773, [], [], 'fam1', 1 ).
test( 't3', 322, [], [], 'fam1', 1 ).
test( 't4', 546, [], [], 'fam1', 1 ).
test( 't5', 192, [], ['r2'], 'fam1', 1 ).
test( 't6', 129, [], [], 'fam1', 1 ).
test( 't7', 301, [], [], 'fam1', 1 ).
test( 't8', 50, [], [], 'fam1', 1 ).
test( 't9', 579, [], [], 'fam1', 1 ).
test( 't10', 786, [], ['r8'], 'fam1', 1 ).
test( 't11', 268, [], [], 'fam1', 1 ).
test( 't12', 330, [], [], 'fam1', 1 ).
test( 't13', 706, [], [], 'fam1', 1 ).
test( 't14', 537, [], [], 'fam1', 1 ).
test( 't15', 801, [], [], 'fam1', 1 ).
test( 't16', 599, [], ['r6','r8','r4','r2','r5'], 'fam1', 1 ).
test( 't17', 666, [], [], 'fam1', 1 ).
test( 't18', 583, [], [], 'fam1', 1 ).
test( 't19', 364, [], [], 'fam1', 1 ).
test( 't20', 73, ['m8','m1'], [], 'fam1', 1 ).
test( 't21', 312, [], [], 'fam1', 1 ).
test( 't22', 419, ['m10','m8','m4','m6'], ['r10','r8','r1','r4','r9','r5','r7'], 'fam1', 1 ).
test( 't23', 191, [], [], 'fam1', 1 ).
test( 't24', 553, [], [], 'fam1', 1 ).
test( 't25', 185, [], [], 'fam1', 1 ).
test( 't26', 208, [], ['r6','r1','r9','r2'], 'fam1', 1 ).
test( 't27', 253, [], [], 'fam1', 1 ).
test( 't28', 359, [], ['r3','r8','r1','r5','r9','r10','r4','r6'], 'fam1', 1 ).
test( 't29', 287, [], [], 'fam1', 1 ).
test( 't30', 205, [], ['r6','r4','r7','r1','r3'], 'fam1', 1 ).
test( 't31', 545, [], [], 'fam1', 1 ).
test( 't32', 63, [], [], 'fam1', 1 ).
test( 't33', 396, [], [], 'fam1', 1 ).
test( 't34', 648, [], ['r3','r2','r5','r7','r10','r8','r6'], 'fam1', 1 ).
test( 't35', 667, [], [], 'fam1', 1 ).
test( 't36', 397, [], ['r9','r5','r7'], 'fam1', 1 ).
test( 't37', 208, [], [], 'fam1', 1 ).
test( 't38', 360, [], ['r1','r9','r7','r4'], 'fam1', 1 ).
test( 't39', 377, [], [], 'fam1', 1 ).
test( 't40', 797, [], [], 'fam1', 1 ).
test( 't41', 421, ['m2'], [], 'fam1', 1 ).
test( 't42', 3, [], [], 'fam1', 1 ).
test( 't43', 647, [], ['r2','r8'], 'fam1', 1 ).
test( 't44', 81, [], ['r1','r5','r3','r2','r7','r9','r6','r4'], 'fam1', 1 ).
test( 't45', 222, [], ['r5','r2','r1','r4','r9','r7'], 'fam1', 1 ).
test( 't46', 166, [], [], 'fam1', 1 ).
test( 't47', 209, [], [], 'fam1', 1 ).
test( 't48', 195, [], [], 'fam1', 1 ).
test( 't49', 64, [], ['r4'], 'fam1', 1 ).
test( 't50', 367, [], [], 'fam1', 1 ).
test( 't51', 695, [], [], 'fam1', 1 ).
test( 't52', 757, [], [], 'fam1', 1 ).
test( 't53', 734, [], ['r4','r3','r10'], 'fam1', 1 ).
test( 't54', 601, [], [], 'fam1', 1 ).
test( 't55', 84, [], [], 'fam1', 1 ).
test( 't56', 633, [], [], 'fam1', 1 ).
test( 't57', 113, [], [], 'fam1', 1 ).
test( 't58', 769, [], [], 'fam1', 1 ).
test( 't59', 188, [], [], 'fam1', 1 ).
test( 't60', 296, [], ['r6','r4'], 'fam1', 1 ).
test( 't61', 525, [], ['r7','r9','r10','r6','r8','r4','r2','r5'], 'fam1', 1 ).
test( 't62', 334, ['m3','m2','m4'], [], 'fam1', 1 ).
test( 't63', 274, [], [], 'fam1', 1 ).
test( 't64', 589, [], ['r6'], 'fam1', 1 ).
test( 't65', 173, [], [], 'fam1', 1 ).
test( 't66', 105, [], ['r9'], 'fam1', 1 ).
test( 't67', 107, [], [], 'fam1', 1 ).
test( 't68', 767, [], [], 'fam1', 1 ).
test( 't69', 12, ['m10','m7','m5','m9'], ['r5','r1','r8','r6','r9'], 'fam1', 1 ).
test( 't70', 573, [], [], 'fam1', 1 ).
test( 't71', 482, [], [], 'fam1', 1 ).
test( 't72', 648, ['m8','m7','m10'], [], 'fam1', 1 ).
test( 't73', 73, [], [], 'fam1', 1 ).
test( 't74', 470, [], [], 'fam1', 1 ).
test( 't75', 700, [], [], 'fam1', 1 ).
test( 't76', 562, [], [], 'fam1', 1 ).
test( 't77', 374, [], [], 'fam1', 1 ).
test( 't78', 86, [], ['r2','r9','r3','r4','r10','r6'], 'fam1', 1 ).
test( 't79', 682, [], [], 'fam1', 1 ).
test( 't80', 589, [], [], 'fam1', 1 ).
test( 't81', 581, ['m8','m7'], [], 'fam1', 1 ).
test( 't82', 539, [], [], 'fam1', 1 ).
test( 't83', 725, ['m9','m5'], [], 'fam1', 1 ).
test( 't84', 24, ['m3','m10','m9'], [], 'fam1', 1 ).
test( 't85', 627, [], [], 'fam1', 1 ).
test( 't86', 262, ['m6','m7','m2'], [], 'fam1', 1 ).
test( 't87', 205, [], [], 'fam1', 1 ).
test( 't88', 79, [], [], 'fam1', 1 ).
test( 't89', 543, ['m10','m1'], [], 'fam1', 1 ).
test( 't90', 731, [], [], 'fam1', 1 ).
test( 't91', 308, [], [], 'fam1', 1 ).
test( 't92', 522, [], [], 'fam1', 1 ).
test( 't93', 789, ['m5'], [], 'fam1', 1 ).
test( 't94', 632, ['m10','m2'], ['r4','r5','r8','r2','r9','r6','r3'], 'fam1', 1 ).
test( 't95', 415, [], ['r3','r9','r5','r1','r6'], 'fam1', 1 ).
test( 't96', 402, [], ['r10','r8','r7','r1','r6','r4','r3','r5','r9'], 'fam1', 1 ).
test( 't97', 483, [], [], 'fam1', 1 ).
test( 't98', 387, [], [], 'fam1', 1 ).
test( 't99', 355, [], [], 'fam1', 1 ).
test( 't100', 328, ['m7'], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
