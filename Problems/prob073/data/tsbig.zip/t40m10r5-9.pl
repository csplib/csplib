%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 675, [], [], 'fam1', 1 ).
test( 't2', 582, [], [], 'fam1', 1 ).
test( 't3', 184, [], ['r3'], 'fam1', 1 ).
test( 't4', 665, [], [], 'fam1', 1 ).
test( 't5', 181, [], ['r2','r1','r4','r3'], 'fam1', 1 ).
test( 't6', 792, [], [], 'fam1', 1 ).
test( 't7', 149, [], [], 'fam1', 1 ).
test( 't8', 327, [], ['r5'], 'fam1', 1 ).
test( 't9', 554, [], [], 'fam1', 1 ).
test( 't10', 112, [], [], 'fam1', 1 ).
test( 't11', 281, [], [], 'fam1', 1 ).
test( 't12', 517, ['m2','m5','m7'], [], 'fam1', 1 ).
test( 't13', 38, ['m5'], ['r3','r2'], 'fam1', 1 ).
test( 't14', 641, [], [], 'fam1', 1 ).
test( 't15', 537, [], [], 'fam1', 1 ).
test( 't16', 386, [], ['r3'], 'fam1', 1 ).
test( 't17', 348, [], [], 'fam1', 1 ).
test( 't18', 680, [], [], 'fam1', 1 ).
test( 't19', 101, ['m1','m5','m10'], ['r5','r3','r1'], 'fam1', 1 ).
test( 't20', 411, [], [], 'fam1', 1 ).
test( 't21', 707, [], [], 'fam1', 1 ).
test( 't22', 689, [], [], 'fam1', 1 ).
test( 't23', 441, [], ['r5','r2','r3','r4'], 'fam1', 1 ).
test( 't24', 378, [], ['r1','r2'], 'fam1', 1 ).
test( 't25', 67, [], [], 'fam1', 1 ).
test( 't26', 702, [], [], 'fam1', 1 ).
test( 't27', 135, ['m1','m8','m2','m10'], ['r4','r2','r5','r1'], 'fam1', 1 ).
test( 't28', 643, [], [], 'fam1', 1 ).
test( 't29', 634, [], [], 'fam1', 1 ).
test( 't30', 627, ['m1','m8'], [], 'fam1', 1 ).
test( 't31', 399, [], [], 'fam1', 1 ).
test( 't32', 264, [], [], 'fam1', 1 ).
test( 't33', 222, [], [], 'fam1', 1 ).
test( 't34', 160, [], [], 'fam1', 1 ).
test( 't35', 300, [], [], 'fam1', 1 ).
test( 't36', 558, [], ['r2'], 'fam1', 1 ).
test( 't37', 222, [], ['r4','r2','r1','r3'], 'fam1', 1 ).
test( 't38', 769, [], [], 'fam1', 1 ).
test( 't39', 727, [], [], 'fam1', 1 ).
test( 't40', 165, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
