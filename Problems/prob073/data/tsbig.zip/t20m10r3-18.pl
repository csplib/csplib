%% ****  Testsuite  ****
% Number of tests                  : 20
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 229, [], [], 'fam1', 1 ).
test( 't2', 306, [], [], 'fam1', 1 ).
test( 't3', 695, [], [], 'fam1', 1 ).
test( 't4', 199, [], [], 'fam1', 1 ).
test( 't5', 659, [], ['r1'], 'fam1', 1 ).
test( 't6', 121, [], [], 'fam1', 1 ).
test( 't7', 61, ['m1','m2','m8','m7'], [], 'fam1', 1 ).
test( 't8', 142, [], ['r3'], 'fam1', 1 ).
test( 't9', 592, [], [], 'fam1', 1 ).
test( 't10', 746, [], [], 'fam1', 1 ).
test( 't11', 613, [], [], 'fam1', 1 ).
test( 't12', 337, [], ['r3'], 'fam1', 1 ).
test( 't13', 87, [], ['r3'], 'fam1', 1 ).
test( 't14', 308, [], [], 'fam1', 1 ).
test( 't15', 259, ['m7'], [], 'fam1', 1 ).
test( 't16', 650, [], [], 'fam1', 1 ).
test( 't17', 506, [], [], 'fam1', 1 ).
test( 't18', 170, ['m8','m5'], [], 'fam1', 1 ).
test( 't19', 405, [], ['r2'], 'fam1', 1 ).
test( 't20', 724, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
