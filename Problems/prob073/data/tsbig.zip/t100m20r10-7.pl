%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 20
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 720, [], ['r3','r7','r1','r10','r8','r4','r9','r5'], 'fam1', 1 ).
test( 't2', 34, [], [], 'fam1', 1 ).
test( 't3', 407, ['m9','m1','m2','m6','m3','m5','m17'], [], 'fam1', 1 ).
test( 't4', 588, [], ['r7','r4','r8','r3','r6','r5','r2','r9','r10'], 'fam1', 1 ).
test( 't5', 548, ['m15','m16','m7','m18','m9','m3','m19','m2'], ['r2','r1','r6','r5','r3','r4','r9'], 'fam1', 1 ).
test( 't6', 150, [], [], 'fam1', 1 ).
test( 't7', 306, [], [], 'fam1', 1 ).
test( 't8', 315, ['m16','m11','m9','m12','m20','m10','m15','m7'], [], 'fam1', 1 ).
test( 't9', 206, [], [], 'fam1', 1 ).
test( 't10', 385, ['m1','m10','m12','m17'], [], 'fam1', 1 ).
test( 't11', 451, [], [], 'fam1', 1 ).
test( 't12', 588, [], ['r3','r2'], 'fam1', 1 ).
test( 't13', 232, [], [], 'fam1', 1 ).
test( 't14', 498, [], [], 'fam1', 1 ).
test( 't15', 389, [], [], 'fam1', 1 ).
test( 't16', 293, [], [], 'fam1', 1 ).
test( 't17', 703, [], [], 'fam1', 1 ).
test( 't18', 270, [], ['r4','r5','r1','r2','r6','r7','r10','r3','r8','r9'], 'fam1', 1 ).
test( 't19', 164, [], ['r6','r5','r3','r4','r9','r10','r1','r2','r8'], 'fam1', 1 ).
test( 't20', 477, ['m3','m5','m14'], [], 'fam1', 1 ).
test( 't21', 690, ['m8','m10','m17','m6'], ['r6','r9','r3'], 'fam1', 1 ).
test( 't22', 16, [], [], 'fam1', 1 ).
test( 't23', 365, [], [], 'fam1', 1 ).
test( 't24', 30, [], [], 'fam1', 1 ).
test( 't25', 565, [], ['r10','r6','r8','r4','r2','r1','r3'], 'fam1', 1 ).
test( 't26', 153, ['m11','m6','m1'], [], 'fam1', 1 ).
test( 't27', 190, [], ['r5','r2','r6','r7','r10','r8','r3','r4'], 'fam1', 1 ).
test( 't28', 698, [], ['r10','r8','r9','r1'], 'fam1', 1 ).
test( 't29', 246, [], [], 'fam1', 1 ).
test( 't30', 204, [], ['r5','r3'], 'fam1', 1 ).
test( 't31', 720, [], [], 'fam1', 1 ).
test( 't32', 2, ['m6','m4','m1'], ['r10','r2','r4','r3','r8','r6'], 'fam1', 1 ).
test( 't33', 113, [], [], 'fam1', 1 ).
test( 't34', 425, [], [], 'fam1', 1 ).
test( 't35', 59, ['m18','m9','m19','m20'], [], 'fam1', 1 ).
test( 't36', 737, [], [], 'fam1', 1 ).
test( 't37', 259, [], [], 'fam1', 1 ).
test( 't38', 708, [], ['r4','r7'], 'fam1', 1 ).
test( 't39', 687, [], ['r1','r4','r2','r7','r10','r3','r8','r9','r5'], 'fam1', 1 ).
test( 't40', 531, [], [], 'fam1', 1 ).
test( 't41', 344, [], [], 'fam1', 1 ).
test( 't42', 476, [], [], 'fam1', 1 ).
test( 't43', 744, ['m12','m7','m2'], [], 'fam1', 1 ).
test( 't44', 187, ['m19','m7','m18'], ['r7','r8','r1','r4'], 'fam1', 1 ).
test( 't45', 588, [], ['r6','r4'], 'fam1', 1 ).
test( 't46', 762, [], [], 'fam1', 1 ).
test( 't47', 499, [], [], 'fam1', 1 ).
test( 't48', 90, [], [], 'fam1', 1 ).
test( 't49', 219, [], ['r10','r6','r7','r4','r2','r5','r9','r3','r8'], 'fam1', 1 ).
test( 't50', 546, ['m9','m8','m11'], ['r6'], 'fam1', 1 ).
test( 't51', 568, ['m18','m7','m14','m19'], [], 'fam1', 1 ).
test( 't52', 615, ['m4','m10','m17'], [], 'fam1', 1 ).
test( 't53', 420, [], [], 'fam1', 1 ).
test( 't54', 409, [], ['r4','r3','r8','r2','r5','r7','r1','r9','r6'], 'fam1', 1 ).
test( 't55', 283, [], [], 'fam1', 1 ).
test( 't56', 447, [], [], 'fam1', 1 ).
test( 't57', 198, ['m11','m5','m16','m10','m13'], ['r8'], 'fam1', 1 ).
test( 't58', 411, [], ['r3','r7','r6','r4','r10'], 'fam1', 1 ).
test( 't59', 456, [], [], 'fam1', 1 ).
test( 't60', 529, [], [], 'fam1', 1 ).
test( 't61', 41, [], [], 'fam1', 1 ).
test( 't62', 321, [], [], 'fam1', 1 ).
test( 't63', 112, [], [], 'fam1', 1 ).
test( 't64', 295, [], [], 'fam1', 1 ).
test( 't65', 795, ['m19','m9','m10','m4','m13','m15'], ['r6','r5','r8','r1','r10','r4','r2'], 'fam1', 1 ).
test( 't66', 439, ['m14','m11','m7','m4','m13'], ['r2','r4','r6','r9','r7','r5','r1','r10'], 'fam1', 1 ).
test( 't67', 710, ['m2','m5','m3','m16','m4'], ['r6','r7','r8','r3','r9'], 'fam1', 1 ).
test( 't68', 145, [], [], 'fam1', 1 ).
test( 't69', 61, [], [], 'fam1', 1 ).
test( 't70', 613, [], ['r8','r3','r4','r2','r10'], 'fam1', 1 ).
test( 't71', 5, ['m11','m15','m7','m20','m17'], ['r6','r5','r8','r3'], 'fam1', 1 ).
test( 't72', 682, [], [], 'fam1', 1 ).
test( 't73', 557, [], ['r3','r7','r6','r9','r8','r10'], 'fam1', 1 ).
test( 't74', 92, ['m19','m1','m2','m6'], [], 'fam1', 1 ).
test( 't75', 386, [], [], 'fam1', 1 ).
test( 't76', 241, [], [], 'fam1', 1 ).
test( 't77', 227, [], [], 'fam1', 1 ).
test( 't78', 526, [], [], 'fam1', 1 ).
test( 't79', 220, [], [], 'fam1', 1 ).
test( 't80', 486, [], [], 'fam1', 1 ).
test( 't81', 609, [], ['r4','r1','r2','r5','r10','r7','r3','r6'], 'fam1', 1 ).
test( 't82', 266, [], [], 'fam1', 1 ).
test( 't83', 124, ['m9','m10','m6','m20','m19','m13','m12','m16'], [], 'fam1', 1 ).
test( 't84', 31, [], ['r3','r7','r10','r8','r6','r9'], 'fam1', 1 ).
test( 't85', 709, [], [], 'fam1', 1 ).
test( 't86', 385, [], ['r1'], 'fam1', 1 ).
test( 't87', 227, [], [], 'fam1', 1 ).
test( 't88', 338, [], [], 'fam1', 1 ).
test( 't89', 641, [], [], 'fam1', 1 ).
test( 't90', 298, [], ['r4','r8','r7','r9','r1','r2'], 'fam1', 1 ).
test( 't91', 327, [], ['r6','r10','r7','r3'], 'fam1', 1 ).
test( 't92', 35, ['m12','m5'], [], 'fam1', 1 ).
test( 't93', 773, [], [], 'fam1', 1 ).
test( 't94', 18, [], ['r2','r8','r9','r5','r6','r4'], 'fam1', 1 ).
test( 't95', 429, [], [], 'fam1', 1 ).
test( 't96', 124, [], [], 'fam1', 1 ).
test( 't97', 194, [], [], 'fam1', 1 ).
test( 't98', 660, ['m7','m19','m13','m8'], ['r6','r3','r4','r5','r1','r8'], 'fam1', 1 ).
test( 't99', 287, [], [], 'fam1', 1 ).
test( 't100', 462, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
