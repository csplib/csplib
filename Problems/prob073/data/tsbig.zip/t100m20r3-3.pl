%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 20
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 140, [], [], 'fam1', 1 ).
test( 't2', 182, [], [], 'fam1', 1 ).
test( 't3', 720, ['m4','m8','m18','m2'], ['r1','r3','r2'], 'fam1', 1 ).
test( 't4', 607, [], [], 'fam1', 1 ).
test( 't5', 309, [], ['r1','r3'], 'fam1', 1 ).
test( 't6', 672, [], [], 'fam1', 1 ).
test( 't7', 367, [], ['r1','r2'], 'fam1', 1 ).
test( 't8', 662, [], [], 'fam1', 1 ).
test( 't9', 506, [], [], 'fam1', 1 ).
test( 't10', 3, [], [], 'fam1', 1 ).
test( 't11', 112, [], ['r3','r1'], 'fam1', 1 ).
test( 't12', 112, ['m10','m5'], [], 'fam1', 1 ).
test( 't13', 442, [], [], 'fam1', 1 ).
test( 't14', 368, ['m15','m16','m3'], [], 'fam1', 1 ).
test( 't15', 763, [], [], 'fam1', 1 ).
test( 't16', 548, [], [], 'fam1', 1 ).
test( 't17', 792, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't18', 448, [], [], 'fam1', 1 ).
test( 't19', 385, [], [], 'fam1', 1 ).
test( 't20', 626, [], [], 'fam1', 1 ).
test( 't21', 16, [], [], 'fam1', 1 ).
test( 't22', 593, [], [], 'fam1', 1 ).
test( 't23', 629, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't24', 772, [], [], 'fam1', 1 ).
test( 't25', 629, [], [], 'fam1', 1 ).
test( 't26', 691, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't27', 352, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't28', 437, [], [], 'fam1', 1 ).
test( 't29', 245, [], [], 'fam1', 1 ).
test( 't30', 453, [], [], 'fam1', 1 ).
test( 't31', 524, ['m20','m19','m5','m11','m13'], [], 'fam1', 1 ).
test( 't32', 791, ['m19','m5','m20'], [], 'fam1', 1 ).
test( 't33', 460, [], ['r1','r2'], 'fam1', 1 ).
test( 't34', 175, [], [], 'fam1', 1 ).
test( 't35', 18, [], [], 'fam1', 1 ).
test( 't36', 283, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't37', 569, [], ['r3'], 'fam1', 1 ).
test( 't38', 369, [], [], 'fam1', 1 ).
test( 't39', 577, ['m15','m20','m5'], ['r2','r3','r1'], 'fam1', 1 ).
test( 't40', 415, ['m9','m16','m12','m8','m10','m3'], ['r3','r2','r1'], 'fam1', 1 ).
test( 't41', 799, ['m2','m4'], [], 'fam1', 1 ).
test( 't42', 580, [], [], 'fam1', 1 ).
test( 't43', 596, ['m17','m5','m4','m19'], ['r1'], 'fam1', 1 ).
test( 't44', 533, ['m17','m8','m18','m1','m12'], [], 'fam1', 1 ).
test( 't45', 661, [], ['r2','r3'], 'fam1', 1 ).
test( 't46', 38, [], ['r2'], 'fam1', 1 ).
test( 't47', 574, [], ['r2','r3'], 'fam1', 1 ).
test( 't48', 317, [], [], 'fam1', 1 ).
test( 't49', 582, [], [], 'fam1', 1 ).
test( 't50', 623, ['m12','m2'], ['r1'], 'fam1', 1 ).
test( 't51', 142, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't52', 258, [], [], 'fam1', 1 ).
test( 't53', 196, [], ['r1','r3'], 'fam1', 1 ).
test( 't54', 311, [], ['r1'], 'fam1', 1 ).
test( 't55', 210, [], [], 'fam1', 1 ).
test( 't56', 494, [], [], 'fam1', 1 ).
test( 't57', 564, [], ['r3'], 'fam1', 1 ).
test( 't58', 772, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't59', 748, [], [], 'fam1', 1 ).
test( 't60', 27, ['m16','m15','m6','m17'], [], 'fam1', 1 ).
test( 't61', 252, [], [], 'fam1', 1 ).
test( 't62', 793, [], [], 'fam1', 1 ).
test( 't63', 696, ['m5','m3','m1','m14'], [], 'fam1', 1 ).
test( 't64', 715, [], [], 'fam1', 1 ).
test( 't65', 653, [], ['r2','r1'], 'fam1', 1 ).
test( 't66', 593, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't67', 477, [], [], 'fam1', 1 ).
test( 't68', 685, [], ['r2','r3'], 'fam1', 1 ).
test( 't69', 638, [], [], 'fam1', 1 ).
test( 't70', 447, [], ['r2','r3'], 'fam1', 1 ).
test( 't71', 86, [], [], 'fam1', 1 ).
test( 't72', 451, ['m8','m7','m9','m5','m18','m16','m4'], [], 'fam1', 1 ).
test( 't73', 750, [], ['r2','r1'], 'fam1', 1 ).
test( 't74', 51, [], [], 'fam1', 1 ).
test( 't75', 338, [], [], 'fam1', 1 ).
test( 't76', 390, [], [], 'fam1', 1 ).
test( 't77', 448, [], [], 'fam1', 1 ).
test( 't78', 619, ['m5'], [], 'fam1', 1 ).
test( 't79', 786, [], [], 'fam1', 1 ).
test( 't80', 712, [], [], 'fam1', 1 ).
test( 't81', 390, [], [], 'fam1', 1 ).
test( 't82', 394, ['m8','m12','m6','m15','m16','m19','m20','m18'], [], 'fam1', 1 ).
test( 't83', 262, [], [], 'fam1', 1 ).
test( 't84', 672, [], [], 'fam1', 1 ).
test( 't85', 594, [], ['r3'], 'fam1', 1 ).
test( 't86', 747, ['m16'], [], 'fam1', 1 ).
test( 't87', 504, [], [], 'fam1', 1 ).
test( 't88', 639, [], [], 'fam1', 1 ).
test( 't89', 516, [], [], 'fam1', 1 ).
test( 't90', 615, [], [], 'fam1', 1 ).
test( 't91', 654, [], ['r1'], 'fam1', 1 ).
test( 't92', 197, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't93', 122, [], [], 'fam1', 1 ).
test( 't94', 770, [], [], 'fam1', 1 ).
test( 't95', 646, [], [], 'fam1', 1 ).
test( 't96', 397, ['m7','m14','m16','m13','m19','m12'], [], 'fam1', 1 ).
test( 't97', 88, ['m15','m7','m8','m20','m6','m17','m14','m1'], [], 'fam1', 1 ).
test( 't98', 552, ['m20','m16','m3','m19','m8'], [], 'fam1', 1 ).
test( 't99', 606, [], [], 'fam1', 1 ).
test( 't100', 793, ['m1','m5','m12','m8','m14','m4','m15','m16'], ['r1','r2','r3'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
