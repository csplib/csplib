%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 50
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 71, [], [], 'fam1', 1 ).
test( 't2', 624, ['m11','m28','m44'], [], 'fam1', 1 ).
test( 't3', 375, [], [], 'fam1', 1 ).
test( 't4', 556, [], [], 'fam1', 1 ).
test( 't5', 96, [], [], 'fam1', 1 ).
test( 't6', 362, [], [], 'fam1', 1 ).
test( 't7', 766, [], [], 'fam1', 1 ).
test( 't8', 238, [], [], 'fam1', 1 ).
test( 't9', 426, [], ['r1'], 'fam1', 1 ).
test( 't10', 614, ['m28','m10','m5','m36','m4','m8','m44','m3','m22','m35'], [], 'fam1', 1 ).
test( 't11', 340, ['m30','m25','m24','m12'], ['r1','r2'], 'fam1', 1 ).
test( 't12', 560, [], [], 'fam1', 1 ).
test( 't13', 282, [], ['r3','r2'], 'fam1', 1 ).
test( 't14', 283, [], [], 'fam1', 1 ).
test( 't15', 32, [], ['r1','r2'], 'fam1', 1 ).
test( 't16', 429, [], [], 'fam1', 1 ).
test( 't17', 650, [], [], 'fam1', 1 ).
test( 't18', 644, [], [], 'fam1', 1 ).
test( 't19', 211, ['m46','m42','m30','m26','m38','m8','m1','m35','m36','m15','m39','m12','m3','m11','m17','m37','m41','m9','m27','m28'], ['r3','r2'], 'fam1', 1 ).
test( 't20', 46, [], [], 'fam1', 1 ).
test( 't21', 604, ['m9','m44','m49','m42','m35','m23','m27','m38','m46','m5'], [], 'fam1', 1 ).
test( 't22', 252, [], [], 'fam1', 1 ).
test( 't23', 289, [], [], 'fam1', 1 ).
test( 't24', 167, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't25', 30, [], [], 'fam1', 1 ).
test( 't26', 466, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't27', 98, [], ['r1'], 'fam1', 1 ).
test( 't28', 656, [], [], 'fam1', 1 ).
test( 't29', 463, ['m38','m19','m48','m35','m26'], ['r3','r1'], 'fam1', 1 ).
test( 't30', 368, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't31', 781, ['m8','m28','m50','m9'], [], 'fam1', 1 ).
test( 't32', 208, [], [], 'fam1', 1 ).
test( 't33', 558, ['m1','m28','m29','m46','m38','m23','m6','m45','m48','m35','m4','m43','m10','m11','m15','m22'], [], 'fam1', 1 ).
test( 't34', 43, [], ['r3','r1'], 'fam1', 1 ).
test( 't35', 12, [], ['r2','r1'], 'fam1', 1 ).
test( 't36', 413, [], [], 'fam1', 1 ).
test( 't37', 447, [], [], 'fam1', 1 ).
test( 't38', 455, [], [], 'fam1', 1 ).
test( 't39', 421, [], [], 'fam1', 1 ).
test( 't40', 786, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't41', 370, ['m39','m33','m32','m34','m16','m24'], [], 'fam1', 1 ).
test( 't42', 120, ['m37','m19','m33','m41','m5','m36','m34','m26','m32','m12','m27'], ['r2','r3'], 'fam1', 1 ).
test( 't43', 720, [], [], 'fam1', 1 ).
test( 't44', 109, [], [], 'fam1', 1 ).
test( 't45', 62, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't46', 103, ['m32','m2','m22','m25','m4','m39','m28','m36','m7','m21','m23','m24','m48','m8','m12','m18','m37','m26','m42'], [], 'fam1', 1 ).
test( 't47', 391, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't48', 209, [], [], 'fam1', 1 ).
test( 't49', 772, [], ['r1','r3'], 'fam1', 1 ).
test( 't50', 178, [], [], 'fam1', 1 ).
test( 't51', 122, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't52', 366, [], [], 'fam1', 1 ).
test( 't53', 33, ['m42','m40','m23','m15','m28'], [], 'fam1', 1 ).
test( 't54', 48, [], ['r2','r1'], 'fam1', 1 ).
test( 't55', 609, [], [], 'fam1', 1 ).
test( 't56', 283, [], [], 'fam1', 1 ).
test( 't57', 650, [], [], 'fam1', 1 ).
test( 't58', 41, [], [], 'fam1', 1 ).
test( 't59', 227, [], [], 'fam1', 1 ).
test( 't60', 766, [], [], 'fam1', 1 ).
test( 't61', 511, [], [], 'fam1', 1 ).
test( 't62', 278, [], [], 'fam1', 1 ).
test( 't63', 706, [], ['r3','r1'], 'fam1', 1 ).
test( 't64', 215, [], ['r2'], 'fam1', 1 ).
test( 't65', 400, ['m34'], ['r3','r2'], 'fam1', 1 ).
test( 't66', 249, [], [], 'fam1', 1 ).
test( 't67', 272, [], [], 'fam1', 1 ).
test( 't68', 511, [], ['r2'], 'fam1', 1 ).
test( 't69', 304, [], [], 'fam1', 1 ).
test( 't70', 511, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't71', 483, [], [], 'fam1', 1 ).
test( 't72', 507, [], ['r2'], 'fam1', 1 ).
test( 't73', 787, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't74', 482, [], ['r3'], 'fam1', 1 ).
test( 't75', 653, [], [], 'fam1', 1 ).
test( 't76', 458, [], ['r1','r2'], 'fam1', 1 ).
test( 't77', 396, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't78', 319, [], [], 'fam1', 1 ).
test( 't79', 439, [], [], 'fam1', 1 ).
test( 't80', 679, ['m18','m21','m48','m30','m33','m42','m2','m15','m4','m25','m39'], [], 'fam1', 1 ).
test( 't81', 274, [], [], 'fam1', 1 ).
test( 't82', 47, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't83', 247, [], [], 'fam1', 1 ).
test( 't84', 140, ['m5','m25','m18','m35','m17','m21'], [], 'fam1', 1 ).
test( 't85', 682, [], ['r2'], 'fam1', 1 ).
test( 't86', 697, [], [], 'fam1', 1 ).
test( 't87', 182, ['m29','m31','m38','m34','m18','m13','m12','m14','m15','m22','m47','m6','m24','m30'], [], 'fam1', 1 ).
test( 't88', 395, [], [], 'fam1', 1 ).
test( 't89', 544, [], [], 'fam1', 1 ).
test( 't90', 89, [], ['r1','r2'], 'fam1', 1 ).
test( 't91', 33, [], [], 'fam1', 1 ).
test( 't92', 633, [], ['r2','r3'], 'fam1', 1 ).
test( 't93', 73, [], [], 'fam1', 1 ).
test( 't94', 208, [], [], 'fam1', 1 ).
test( 't95', 471, ['m45','m31','m5','m44','m23','m2','m48','m22','m26','m25','m3','m35','m32','m28','m4','m8','m10','m6'], ['r1'], 'fam1', 1 ).
test( 't96', 234, [], ['r1','r2'], 'fam1', 1 ).
test( 't97', 402, [], [], 'fam1', 1 ).
test( 't98', 140, ['m46','m8','m1','m36','m5','m2','m19','m32','m27','m39','m38','m40','m43'], [], 'fam1', 1 ).
test( 't99', 495, [], [], 'fam1', 1 ).
test( 't100', 782, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').
embedded_board( 'm21').
embedded_board( 'm22').
embedded_board( 'm23').
embedded_board( 'm24').
embedded_board( 'm25').
embedded_board( 'm26').
embedded_board( 'm27').
embedded_board( 'm28').
embedded_board( 'm29').
embedded_board( 'm30').
embedded_board( 'm31').
embedded_board( 'm32').
embedded_board( 'm33').
embedded_board( 'm34').
embedded_board( 'm35').
embedded_board( 'm36').
embedded_board( 'm37').
embedded_board( 'm38').
embedded_board( 'm39').
embedded_board( 'm40').
embedded_board( 'm41').
embedded_board( 'm42').
embedded_board( 'm43').
embedded_board( 'm44').
embedded_board( 'm45').
embedded_board( 'm46').
embedded_board( 'm47').
embedded_board( 'm48').
embedded_board( 'm49').
embedded_board( 'm50').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
