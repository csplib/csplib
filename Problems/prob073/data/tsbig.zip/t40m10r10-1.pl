%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 10
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 97, [], [], 'fam1', 1 ).
test( 't2', 205, [], [], 'fam1', 1 ).
test( 't3', 478, ['m8','m3','m10','m2'], [], 'fam1', 1 ).
test( 't4', 473, ['m10','m5'], [], 'fam1', 1 ).
test( 't5', 579, [], ['r3','r7','r9'], 'fam1', 1 ).
test( 't6', 506, [], [], 'fam1', 1 ).
test( 't7', 2, [], [], 'fam1', 1 ).
test( 't8', 513, [], [], 'fam1', 1 ).
test( 't9', 89, ['m4','m1','m2','m10'], [], 'fam1', 1 ).
test( 't10', 119, [], [], 'fam1', 1 ).
test( 't11', 535, ['m4','m5'], ['r10','r2','r6','r9','r4','r1','r8','r7','r5'], 'fam1', 1 ).
test( 't12', 526, [], [], 'fam1', 1 ).
test( 't13', 499, [], [], 'fam1', 1 ).
test( 't14', 377, ['m9'], [], 'fam1', 1 ).
test( 't15', 247, [], [], 'fam1', 1 ).
test( 't16', 656, [], [], 'fam1', 1 ).
test( 't17', 145, [], [], 'fam1', 1 ).
test( 't18', 160, ['m1','m6'], [], 'fam1', 1 ).
test( 't19', 632, [], [], 'fam1', 1 ).
test( 't20', 547, [], ['r9','r1','r4','r6','r10','r7','r3'], 'fam1', 1 ).
test( 't21', 648, [], [], 'fam1', 1 ).
test( 't22', 479, [], [], 'fam1', 1 ).
test( 't23', 644, [], [], 'fam1', 1 ).
test( 't24', 589, [], ['r8'], 'fam1', 1 ).
test( 't25', 410, [], [], 'fam1', 1 ).
test( 't26', 672, ['m6','m10'], [], 'fam1', 1 ).
test( 't27', 438, [], [], 'fam1', 1 ).
test( 't28', 361, [], [], 'fam1', 1 ).
test( 't29', 418, [], [], 'fam1', 1 ).
test( 't30', 241, [], [], 'fam1', 1 ).
test( 't31', 257, [], [], 'fam1', 1 ).
test( 't32', 279, [], [], 'fam1', 1 ).
test( 't33', 637, [], ['r8','r3','r4','r9','r2','r5'], 'fam1', 1 ).
test( 't34', 473, [], [], 'fam1', 1 ).
test( 't35', 192, [], [], 'fam1', 1 ).
test( 't36', 747, [], [], 'fam1', 1 ).
test( 't37', 113, [], [], 'fam1', 1 ).
test( 't38', 766, [], [], 'fam1', 1 ).
test( 't39', 216, [], ['r2','r1','r10','r5','r9','r7','r6','r8','r4','r3'], 'fam1', 1 ).
test( 't40', 596, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
