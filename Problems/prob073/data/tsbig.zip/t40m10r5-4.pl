%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 374, ['m9','m8'], [], 'fam1', 1 ).
test( 't2', 192, [], [], 'fam1', 1 ).
test( 't3', 487, [], ['r1','r5','r2','r4','r3'], 'fam1', 1 ).
test( 't4', 123, [], [], 'fam1', 1 ).
test( 't5', 670, ['m7','m6','m1'], ['r1','r2','r4','r5','r3'], 'fam1', 1 ).
test( 't6', 779, [], [], 'fam1', 1 ).
test( 't7', 78, ['m7'], [], 'fam1', 1 ).
test( 't8', 533, [], ['r4','r1','r5'], 'fam1', 1 ).
test( 't9', 33, ['m6','m3','m2'], [], 'fam1', 1 ).
test( 't10', 672, [], [], 'fam1', 1 ).
test( 't11', 44, [], [], 'fam1', 1 ).
test( 't12', 498, [], [], 'fam1', 1 ).
test( 't13', 90, ['m7','m10'], [], 'fam1', 1 ).
test( 't14', 195, [], [], 'fam1', 1 ).
test( 't15', 573, [], ['r4','r1','r5','r3','r2'], 'fam1', 1 ).
test( 't16', 394, ['m9','m1','m5','m6'], [], 'fam1', 1 ).
test( 't17', 604, [], [], 'fam1', 1 ).
test( 't18', 213, ['m10','m6','m3','m9'], [], 'fam1', 1 ).
test( 't19', 131, [], [], 'fam1', 1 ).
test( 't20', 502, ['m6'], [], 'fam1', 1 ).
test( 't21', 531, [], [], 'fam1', 1 ).
test( 't22', 453, ['m8','m7','m5'], [], 'fam1', 1 ).
test( 't23', 780, ['m7','m3','m6'], [], 'fam1', 1 ).
test( 't24', 376, ['m8'], ['r4','r1','r2','r5'], 'fam1', 1 ).
test( 't25', 115, [], [], 'fam1', 1 ).
test( 't26', 413, [], ['r2'], 'fam1', 1 ).
test( 't27', 548, ['m8','m2'], [], 'fam1', 1 ).
test( 't28', 608, [], [], 'fam1', 1 ).
test( 't29', 94, ['m8','m2','m5'], [], 'fam1', 1 ).
test( 't30', 699, [], ['r1','r2','r4','r3','r5'], 'fam1', 1 ).
test( 't31', 798, [], [], 'fam1', 1 ).
test( 't32', 292, [], ['r2','r5','r4','r3'], 'fam1', 1 ).
test( 't33', 544, [], ['r1'], 'fam1', 1 ).
test( 't34', 762, ['m6'], ['r5','r2','r1'], 'fam1', 1 ).
test( 't35', 591, [], [], 'fam1', 1 ).
test( 't36', 517, ['m4','m3','m6','m7'], [], 'fam1', 1 ).
test( 't37', 558, [], ['r1','r2','r3','r4','r5'], 'fam1', 1 ).
test( 't38', 218, [], ['r1','r5','r3','r4','r2'], 'fam1', 1 ).
test( 't39', 669, [], ['r3','r4','r5','r2'], 'fam1', 1 ).
test( 't40', 789, [], ['r3','r2','r1','r4','r5'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
