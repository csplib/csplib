%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 20
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 15, [], [], 'fam1', 1 ).
test( 't2', 593, [], [], 'fam1', 1 ).
test( 't3', 150, [], [], 'fam1', 1 ).
test( 't4', 389, ['m8','m20'], [], 'fam1', 1 ).
test( 't5', 699, [], ['r3','r1'], 'fam1', 1 ).
test( 't6', 348, [], [], 'fam1', 1 ).
test( 't7', 522, [], [], 'fam1', 1 ).
test( 't8', 155, [], ['r3','r1'], 'fam1', 1 ).
test( 't9', 277, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't10', 245, [], [], 'fam1', 1 ).
test( 't11', 549, [], ['r3','r1'], 'fam1', 1 ).
test( 't12', 499, [], ['r2'], 'fam1', 1 ).
test( 't13', 195, ['m1','m3','m17','m4','m13','m7'], [], 'fam1', 1 ).
test( 't14', 571, [], [], 'fam1', 1 ).
test( 't15', 374, [], [], 'fam1', 1 ).
test( 't16', 348, [], [], 'fam1', 1 ).
test( 't17', 384, ['m4','m15','m13','m5'], ['r1','r2'], 'fam1', 1 ).
test( 't18', 773, [], ['r3','r2'], 'fam1', 1 ).
test( 't19', 296, [], [], 'fam1', 1 ).
test( 't20', 279, [], [], 'fam1', 1 ).
test( 't21', 230, [], [], 'fam1', 1 ).
test( 't22', 277, [], [], 'fam1', 1 ).
test( 't23', 240, ['m19','m7','m14','m6','m1','m12','m13'], [], 'fam1', 1 ).
test( 't24', 619, [], [], 'fam1', 1 ).
test( 't25', 479, [], ['r1','r3'], 'fam1', 1 ).
test( 't26', 343, [], [], 'fam1', 1 ).
test( 't27', 710, [], [], 'fam1', 1 ).
test( 't28', 89, [], ['r1'], 'fam1', 1 ).
test( 't29', 312, ['m11','m8','m12','m20','m14','m2','m18'], [], 'fam1', 1 ).
test( 't30', 765, ['m15'], [], 'fam1', 1 ).
test( 't31', 716, [], ['r1'], 'fam1', 1 ).
test( 't32', 387, [], [], 'fam1', 1 ).
test( 't33', 781, [], [], 'fam1', 1 ).
test( 't34', 641, [], [], 'fam1', 1 ).
test( 't35', 59, ['m4','m9','m14','m5'], ['r3','r1'], 'fam1', 1 ).
test( 't36', 27, [], [], 'fam1', 1 ).
test( 't37', 584, [], ['r2','r1'], 'fam1', 1 ).
test( 't38', 668, [], [], 'fam1', 1 ).
test( 't39', 685, [], [], 'fam1', 1 ).
test( 't40', 644, ['m8','m19','m4','m14','m10','m9','m15'], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
