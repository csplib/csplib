%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 20
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 162, ['m19','m1','m14','m12'], [], 'fam1', 1 ).
test( 't2', 761, [], [], 'fam1', 1 ).
test( 't3', 581, ['m12','m17','m11','m4','m18','m7','m16','m5'], [], 'fam1', 1 ).
test( 't4', 276, ['m9','m16'], [], 'fam1', 1 ).
test( 't5', 643, [], ['r2','r5','r4','r1'], 'fam1', 1 ).
test( 't6', 290, [], ['r2','r3'], 'fam1', 1 ).
test( 't7', 118, [], [], 'fam1', 1 ).
test( 't8', 688, [], [], 'fam1', 1 ).
test( 't9', 65, ['m13','m11','m5','m19','m9','m4','m18'], [], 'fam1', 1 ).
test( 't10', 643, ['m10','m12','m15','m18'], [], 'fam1', 1 ).
test( 't11', 62, [], [], 'fam1', 1 ).
test( 't12', 467, ['m2','m11','m16','m15','m5','m4','m18','m13'], [], 'fam1', 1 ).
test( 't13', 308, [], ['r5','r2'], 'fam1', 1 ).
test( 't14', 411, ['m4','m15','m20','m7','m2','m8','m10','m5'], [], 'fam1', 1 ).
test( 't15', 679, [], ['r2','r4','r3'], 'fam1', 1 ).
test( 't16', 487, [], [], 'fam1', 1 ).
test( 't17', 604, [], [], 'fam1', 1 ).
test( 't18', 461, [], [], 'fam1', 1 ).
test( 't19', 341, [], [], 'fam1', 1 ).
test( 't20', 742, ['m7','m10','m16','m6'], ['r4','r3','r5','r1','r2'], 'fam1', 1 ).
test( 't21', 83, ['m7','m14','m16'], [], 'fam1', 1 ).
test( 't22', 28, [], [], 'fam1', 1 ).
test( 't23', 498, ['m8','m11','m9','m1','m17'], [], 'fam1', 1 ).
test( 't24', 800, [], [], 'fam1', 1 ).
test( 't25', 341, ['m8','m15','m1','m14','m19','m3','m17','m7'], [], 'fam1', 1 ).
test( 't26', 294, [], [], 'fam1', 1 ).
test( 't27', 460, [], [], 'fam1', 1 ).
test( 't28', 151, [], [], 'fam1', 1 ).
test( 't29', 575, [], ['r3','r4'], 'fam1', 1 ).
test( 't30', 188, [], ['r2','r4','r5','r1'], 'fam1', 1 ).
test( 't31', 163, [], [], 'fam1', 1 ).
test( 't32', 177, [], ['r1','r2','r5','r3','r4'], 'fam1', 1 ).
test( 't33', 758, [], [], 'fam1', 1 ).
test( 't34', 123, [], [], 'fam1', 1 ).
test( 't35', 732, [], [], 'fam1', 1 ).
test( 't36', 732, ['m4'], [], 'fam1', 1 ).
test( 't37', 800, [], [], 'fam1', 1 ).
test( 't38', 394, ['m12','m14','m7','m3','m9','m10','m8'], [], 'fam1', 1 ).
test( 't39', 451, [], [], 'fam1', 1 ).
test( 't40', 274, ['m2','m13','m19','m17'], [], 'fam1', 1 ).
test( 't41', 578, ['m14','m2'], [], 'fam1', 1 ).
test( 't42', 66, [], ['r5','r3','r1'], 'fam1', 1 ).
test( 't43', 762, [], [], 'fam1', 1 ).
test( 't44', 111, [], ['r5'], 'fam1', 1 ).
test( 't45', 437, [], [], 'fam1', 1 ).
test( 't46', 583, [], [], 'fam1', 1 ).
test( 't47', 739, [], ['r3','r2','r1','r5','r4'], 'fam1', 1 ).
test( 't48', 775, [], ['r1'], 'fam1', 1 ).
test( 't49', 485, ['m16','m15','m1','m5','m4'], ['r2','r3'], 'fam1', 1 ).
test( 't50', 187, ['m9','m8','m18','m16'], [], 'fam1', 1 ).
test( 't51', 612, [], [], 'fam1', 1 ).
test( 't52', 576, [], [], 'fam1', 1 ).
test( 't53', 43, [], [], 'fam1', 1 ).
test( 't54', 269, [], [], 'fam1', 1 ).
test( 't55', 333, [], [], 'fam1', 1 ).
test( 't56', 491, [], ['r2'], 'fam1', 1 ).
test( 't57', 263, ['m2','m14','m15','m18','m20'], [], 'fam1', 1 ).
test( 't58', 563, [], [], 'fam1', 1 ).
test( 't59', 757, [], [], 'fam1', 1 ).
test( 't60', 135, [], ['r2','r5'], 'fam1', 1 ).
test( 't61', 498, [], [], 'fam1', 1 ).
test( 't62', 585, [], [], 'fam1', 1 ).
test( 't63', 433, ['m16'], ['r2'], 'fam1', 1 ).
test( 't64', 781, [], [], 'fam1', 1 ).
test( 't65', 130, [], ['r1','r2','r5','r4','r3'], 'fam1', 1 ).
test( 't66', 651, [], [], 'fam1', 1 ).
test( 't67', 155, [], ['r3','r5','r2','r1','r4'], 'fam1', 1 ).
test( 't68', 747, [], [], 'fam1', 1 ).
test( 't69', 234, [], [], 'fam1', 1 ).
test( 't70', 340, [], [], 'fam1', 1 ).
test( 't71', 378, [], [], 'fam1', 1 ).
test( 't72', 212, [], [], 'fam1', 1 ).
test( 't73', 32, [], [], 'fam1', 1 ).
test( 't74', 763, ['m7','m16','m9','m3','m10','m15'], [], 'fam1', 1 ).
test( 't75', 488, [], ['r5','r3','r4','r1','r2'], 'fam1', 1 ).
test( 't76', 617, [], [], 'fam1', 1 ).
test( 't77', 536, [], [], 'fam1', 1 ).
test( 't78', 222, [], ['r4'], 'fam1', 1 ).
test( 't79', 331, ['m4','m11','m19','m5'], [], 'fam1', 1 ).
test( 't80', 754, [], [], 'fam1', 1 ).
test( 't81', 533, ['m12','m9','m3','m17'], [], 'fam1', 1 ).
test( 't82', 521, [], ['r1'], 'fam1', 1 ).
test( 't83', 187, [], [], 'fam1', 1 ).
test( 't84', 374, [], ['r2','r4'], 'fam1', 1 ).
test( 't85', 568, ['m10'], ['r3','r2','r4','r1'], 'fam1', 1 ).
test( 't86', 80, [], ['r4','r1','r5'], 'fam1', 1 ).
test( 't87', 613, [], ['r5','r2','r4','r1','r3'], 'fam1', 1 ).
test( 't88', 32, [], [], 'fam1', 1 ).
test( 't89', 518, [], [], 'fam1', 1 ).
test( 't90', 647, [], [], 'fam1', 1 ).
test( 't91', 799, [], ['r5','r3','r4','r2'], 'fam1', 1 ).
test( 't92', 475, [], [], 'fam1', 1 ).
test( 't93', 187, [], [], 'fam1', 1 ).
test( 't94', 539, ['m12','m17','m20'], ['r5','r4','r2','r1'], 'fam1', 1 ).
test( 't95', 668, ['m3','m20','m17','m1','m10'], ['r5','r1','r4'], 'fam1', 1 ).
test( 't96', 122, ['m10','m18','m2'], ['r1','r4','r3','r5','r2'], 'fam1', 1 ).
test( 't97', 402, [], [], 'fam1', 1 ).
test( 't98', 14, [], [], 'fam1', 1 ).
test( 't99', 589, [], [], 'fam1', 1 ).
test( 't100', 554, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
