%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 20
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 68, [], [], 'fam1', 1 ).
test( 't2', 33, [], [], 'fam1', 1 ).
test( 't3', 487, ['m11','m7','m13','m14','m16','m3','m1','m9'], ['r4','r2','r1'], 'fam1', 1 ).
test( 't4', 633, [], [], 'fam1', 1 ).
test( 't5', 776, ['m14'], [], 'fam1', 1 ).
test( 't6', 727, [], ['r5','r3','r2'], 'fam1', 1 ).
test( 't7', 548, [], [], 'fam1', 1 ).
test( 't8', 771, [], [], 'fam1', 1 ).
test( 't9', 163, [], [], 'fam1', 1 ).
test( 't10', 309, [], [], 'fam1', 1 ).
test( 't11', 71, [], ['r2','r1','r5'], 'fam1', 1 ).
test( 't12', 86, [], [], 'fam1', 1 ).
test( 't13', 139, ['m8'], [], 'fam1', 1 ).
test( 't14', 494, ['m15'], [], 'fam1', 1 ).
test( 't15', 411, ['m12','m6','m19','m11'], ['r4','r5'], 'fam1', 1 ).
test( 't16', 404, [], ['r1','r3','r2','r5'], 'fam1', 1 ).
test( 't17', 618, [], [], 'fam1', 1 ).
test( 't18', 737, [], [], 'fam1', 1 ).
test( 't19', 101, [], [], 'fam1', 1 ).
test( 't20', 40, ['m18'], [], 'fam1', 1 ).
test( 't21', 101, ['m9','m2','m6'], [], 'fam1', 1 ).
test( 't22', 598, [], [], 'fam1', 1 ).
test( 't23', 187, [], [], 'fam1', 1 ).
test( 't24', 549, [], [], 'fam1', 1 ).
test( 't25', 232, ['m2','m4','m18','m20','m19','m14','m12','m5'], [], 'fam1', 1 ).
test( 't26', 604, [], [], 'fam1', 1 ).
test( 't27', 223, [], [], 'fam1', 1 ).
test( 't28', 258, [], [], 'fam1', 1 ).
test( 't29', 25, [], [], 'fam1', 1 ).
test( 't30', 328, [], [], 'fam1', 1 ).
test( 't31', 359, [], [], 'fam1', 1 ).
test( 't32', 84, [], [], 'fam1', 1 ).
test( 't33', 250, [], [], 'fam1', 1 ).
test( 't34', 560, [], [], 'fam1', 1 ).
test( 't35', 719, [], [], 'fam1', 1 ).
test( 't36', 501, [], ['r4','r2','r1','r3'], 'fam1', 1 ).
test( 't37', 376, [], [], 'fam1', 1 ).
test( 't38', 800, ['m13','m14','m1'], [], 'fam1', 1 ).
test( 't39', 415, [], [], 'fam1', 1 ).
test( 't40', 437, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
