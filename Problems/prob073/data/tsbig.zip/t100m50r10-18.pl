%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 50
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 356, ['m11','m32','m9','m34','m12','m2','m1','m5','m44','m50','m48','m7','m28','m19','m30','m6','m25','m17','m16','m46'], ['r8','r3','r5','r7','r1','r4','r9'], 'fam1', 1 ).
test( 't2', 340, ['m3','m44','m14','m19','m13','m2','m42','m23','m4','m32','m35','m10','m33','m17','m8'], [], 'fam1', 1 ).
test( 't3', 787, [], [], 'fam1', 1 ).
test( 't4', 274, [], [], 'fam1', 1 ).
test( 't5', 689, ['m29'], [], 'fam1', 1 ).
test( 't6', 344, [], ['r3','r2','r7','r4','r5','r1','r9','r10','r6','r8'], 'fam1', 1 ).
test( 't7', 536, [], [], 'fam1', 1 ).
test( 't8', 395, [], [], 'fam1', 1 ).
test( 't9', 57, [], ['r9','r2'], 'fam1', 1 ).
test( 't10', 345, [], [], 'fam1', 1 ).
test( 't11', 672, ['m41','m46','m39','m14','m2','m13','m19','m32','m6','m12','m30','m11','m18','m48','m16','m5','m22'], ['r3'], 'fam1', 1 ).
test( 't12', 709, [], [], 'fam1', 1 ).
test( 't13', 241, [], [], 'fam1', 1 ).
test( 't14', 239, [], [], 'fam1', 1 ).
test( 't15', 300, [], [], 'fam1', 1 ).
test( 't16', 59, [], ['r8','r6','r5','r2','r9','r7'], 'fam1', 1 ).
test( 't17', 392, ['m2','m16','m9','m7','m32','m37','m28','m41','m45','m10','m14','m6','m20','m33','m5'], [], 'fam1', 1 ).
test( 't18', 181, [], [], 'fam1', 1 ).
test( 't19', 260, [], ['r4','r6','r8','r9','r3','r7','r2','r5'], 'fam1', 1 ).
test( 't20', 323, [], [], 'fam1', 1 ).
test( 't21', 260, ['m37','m42','m21','m47','m16','m50'], [], 'fam1', 1 ).
test( 't22', 479, [], [], 'fam1', 1 ).
test( 't23', 44, [], ['r4','r9','r7','r10','r5','r3','r2','r1','r8','r6'], 'fam1', 1 ).
test( 't24', 164, [], [], 'fam1', 1 ).
test( 't25', 556, ['m46','m21','m12','m30','m26','m32','m38','m33','m2','m5','m14','m36','m50','m19','m1'], [], 'fam1', 1 ).
test( 't26', 455, ['m33','m35','m4','m40','m22','m6','m38','m19','m43','m50','m26','m46','m45','m31','m39'], [], 'fam1', 1 ).
test( 't27', 434, ['m18','m38','m1','m13','m20','m8','m48','m6'], [], 'fam1', 1 ).
test( 't28', 356, [], ['r5','r7'], 'fam1', 1 ).
test( 't29', 504, [], [], 'fam1', 1 ).
test( 't30', 781, ['m12','m39','m17','m2','m50','m47','m37','m36','m42','m10'], ['r8','r6'], 'fam1', 1 ).
test( 't31', 392, ['m50','m16','m3','m11','m12','m29','m34','m49','m8','m21','m26','m10','m42','m22','m43','m28','m41'], [], 'fam1', 1 ).
test( 't32', 300, [], ['r1'], 'fam1', 1 ).
test( 't33', 587, [], [], 'fam1', 1 ).
test( 't34', 194, [], [], 'fam1', 1 ).
test( 't35', 349, [], [], 'fam1', 1 ).
test( 't36', 648, [], [], 'fam1', 1 ).
test( 't37', 247, [], [], 'fam1', 1 ).
test( 't38', 593, [], [], 'fam1', 1 ).
test( 't39', 321, [], [], 'fam1', 1 ).
test( 't40', 496, [], [], 'fam1', 1 ).
test( 't41', 339, [], [], 'fam1', 1 ).
test( 't42', 350, [], ['r3','r7','r9','r1','r2','r10','r5','r8','r4','r6'], 'fam1', 1 ).
test( 't43', 625, ['m23','m8','m32','m12','m14','m38','m7','m35'], ['r7','r8','r1','r2','r9'], 'fam1', 1 ).
test( 't44', 16, ['m11','m2','m18','m13'], [], 'fam1', 1 ).
test( 't45', 572, [], ['r1','r6','r3','r4','r10','r8','r9','r2','r7'], 'fam1', 1 ).
test( 't46', 75, [], [], 'fam1', 1 ).
test( 't47', 78, [], [], 'fam1', 1 ).
test( 't48', 421, [], [], 'fam1', 1 ).
test( 't49', 550, [], ['r6','r3','r9','r5','r2','r7'], 'fam1', 1 ).
test( 't50', 527, [], [], 'fam1', 1 ).
test( 't51', 739, [], ['r1','r7','r4','r2'], 'fam1', 1 ).
test( 't52', 577, [], [], 'fam1', 1 ).
test( 't53', 215, [], [], 'fam1', 1 ).
test( 't54', 83, [], [], 'fam1', 1 ).
test( 't55', 62, [], [], 'fam1', 1 ).
test( 't56', 99, [], [], 'fam1', 1 ).
test( 't57', 189, [], [], 'fam1', 1 ).
test( 't58', 544, [], [], 'fam1', 1 ).
test( 't59', 746, ['m22','m18','m16','m25','m40','m21','m17','m48','m12','m13'], [], 'fam1', 1 ).
test( 't60', 651, [], [], 'fam1', 1 ).
test( 't61', 234, ['m41'], [], 'fam1', 1 ).
test( 't62', 413, [], [], 'fam1', 1 ).
test( 't63', 521, [], [], 'fam1', 1 ).
test( 't64', 773, [], [], 'fam1', 1 ).
test( 't65', 118, [], [], 'fam1', 1 ).
test( 't66', 685, [], ['r7','r8','r4','r9','r3'], 'fam1', 1 ).
test( 't67', 453, [], [], 'fam1', 1 ).
test( 't68', 437, [], [], 'fam1', 1 ).
test( 't69', 413, [], [], 'fam1', 1 ).
test( 't70', 192, [], [], 'fam1', 1 ).
test( 't71', 295, [], [], 'fam1', 1 ).
test( 't72', 782, [], ['r9'], 'fam1', 1 ).
test( 't73', 781, [], [], 'fam1', 1 ).
test( 't74', 82, [], [], 'fam1', 1 ).
test( 't75', 431, [], [], 'fam1', 1 ).
test( 't76', 433, ['m34','m13','m38','m35','m15','m6','m10','m16','m21','m12','m27','m25','m41','m14','m18'], ['r8','r6'], 'fam1', 1 ).
test( 't77', 398, [], ['r3'], 'fam1', 1 ).
test( 't78', 137, [], [], 'fam1', 1 ).
test( 't79', 149, ['m1','m47','m6','m25','m24','m30','m49','m45','m37'], [], 'fam1', 1 ).
test( 't80', 218, ['m44','m41','m20','m28','m10'], [], 'fam1', 1 ).
test( 't81', 743, [], [], 'fam1', 1 ).
test( 't82', 382, ['m28','m9','m15','m11'], ['r1','r9','r2','r4','r5'], 'fam1', 1 ).
test( 't83', 533, [], [], 'fam1', 1 ).
test( 't84', 586, [], ['r3','r7','r9','r2','r5','r1'], 'fam1', 1 ).
test( 't85', 412, [], [], 'fam1', 1 ).
test( 't86', 366, ['m31','m3','m20','m11','m23','m30','m25','m44','m19','m27','m47'], ['r8','r2','r4'], 'fam1', 1 ).
test( 't87', 245, [], [], 'fam1', 1 ).
test( 't88', 526, ['m2','m9','m39','m22','m38','m42','m14','m44','m30','m46','m49','m12','m7','m10','m26','m8','m4','m45','m32','m20'], [], 'fam1', 1 ).
test( 't89', 201, [], [], 'fam1', 1 ).
test( 't90', 412, [], [], 'fam1', 1 ).
test( 't91', 398, [], ['r2','r8','r5','r1','r7','r9'], 'fam1', 1 ).
test( 't92', 772, [], [], 'fam1', 1 ).
test( 't93', 698, [], ['r8','r10','r7'], 'fam1', 1 ).
test( 't94', 752, [], [], 'fam1', 1 ).
test( 't95', 498, [], ['r4','r10','r5','r1','r7','r8','r6'], 'fam1', 1 ).
test( 't96', 84, [], ['r8','r5','r10','r1'], 'fam1', 1 ).
test( 't97', 630, [], [], 'fam1', 1 ).
test( 't98', 53, ['m41','m34','m17','m38','m44','m4','m25','m50','m22','m31','m16'], [], 'fam1', 1 ).
test( 't99', 364, ['m43','m5','m1','m42','m9','m12','m24','m22','m11','m8','m34','m14','m31'], ['r4','r6','r3'], 'fam1', 1 ).
test( 't100', 543, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').
embedded_board( 'm21').
embedded_board( 'm22').
embedded_board( 'm23').
embedded_board( 'm24').
embedded_board( 'm25').
embedded_board( 'm26').
embedded_board( 'm27').
embedded_board( 'm28').
embedded_board( 'm29').
embedded_board( 'm30').
embedded_board( 'm31').
embedded_board( 'm32').
embedded_board( 'm33').
embedded_board( 'm34').
embedded_board( 'm35').
embedded_board( 'm36').
embedded_board( 'm37').
embedded_board( 'm38').
embedded_board( 'm39').
embedded_board( 'm40').
embedded_board( 'm41').
embedded_board( 'm42').
embedded_board( 'm43').
embedded_board( 'm44').
embedded_board( 'm45').
embedded_board( 'm46').
embedded_board( 'm47').
embedded_board( 'm48').
embedded_board( 'm49').
embedded_board( 'm50').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
