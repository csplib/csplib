%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 20
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 109, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't2', 465, [], [], 'fam1', 1 ).
test( 't3', 281, [], [], 'fam1', 1 ).
test( 't4', 589, [], ['r3'], 'fam1', 1 ).
test( 't5', 367, ['m10','m6'], [], 'fam1', 1 ).
test( 't6', 726, [], [], 'fam1', 1 ).
test( 't7', 520, ['m14','m6','m7','m16','m12'], [], 'fam1', 1 ).
test( 't8', 154, [], [], 'fam1', 1 ).
test( 't9', 382, [], [], 'fam1', 1 ).
test( 't10', 349, [], [], 'fam1', 1 ).
test( 't11', 385, ['m6','m11','m4','m19','m10','m15'], ['r2'], 'fam1', 1 ).
test( 't12', 122, [], [], 'fam1', 1 ).
test( 't13', 613, [], [], 'fam1', 1 ).
test( 't14', 512, [], [], 'fam1', 1 ).
test( 't15', 616, [], ['r1'], 'fam1', 1 ).
test( 't16', 554, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't17', 646, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't18', 380, [], [], 'fam1', 1 ).
test( 't19', 97, ['m18','m16','m20','m8','m10'], [], 'fam1', 1 ).
test( 't20', 617, [], [], 'fam1', 1 ).
test( 't21', 146, [], [], 'fam1', 1 ).
test( 't22', 413, [], [], 'fam1', 1 ).
test( 't23', 235, [], [], 'fam1', 1 ).
test( 't24', 278, [], [], 'fam1', 1 ).
test( 't25', 194, [], [], 'fam1', 1 ).
test( 't26', 645, ['m1','m10','m16','m8'], [], 'fam1', 1 ).
test( 't27', 780, [], [], 'fam1', 1 ).
test( 't28', 290, [], [], 'fam1', 1 ).
test( 't29', 344, [], [], 'fam1', 1 ).
test( 't30', 26, [], ['r3'], 'fam1', 1 ).
test( 't31', 651, ['m5','m14','m3'], [], 'fam1', 1 ).
test( 't32', 93, [], ['r2'], 'fam1', 1 ).
test( 't33', 327, [], ['r1','r2'], 'fam1', 1 ).
test( 't34', 74, [], ['r2','r3'], 'fam1', 1 ).
test( 't35', 188, [], [], 'fam1', 1 ).
test( 't36', 405, [], [], 'fam1', 1 ).
test( 't37', 792, [], [], 'fam1', 1 ).
test( 't38', 105, [], [], 'fam1', 1 ).
test( 't39', 246, [], [], 'fam1', 1 ).
test( 't40', 565, ['m19','m5','m11','m1','m15'], [], 'fam1', 1 ).
test( 't41', 107, [], [], 'fam1', 1 ).
test( 't42', 375, ['m5','m10','m18','m4','m17','m1','m7','m6'], ['r2','r1','r3'], 'fam1', 1 ).
test( 't43', 91, [], [], 'fam1', 1 ).
test( 't44', 147, [], [], 'fam1', 1 ).
test( 't45', 741, ['m15','m9','m20','m19','m4','m10'], [], 'fam1', 1 ).
test( 't46', 268, [], [], 'fam1', 1 ).
test( 't47', 309, [], [], 'fam1', 1 ).
test( 't48', 605, [], [], 'fam1', 1 ).
test( 't49', 564, [], [], 'fam1', 1 ).
test( 't50', 31, [], ['r2'], 'fam1', 1 ).
test( 't51', 686, [], [], 'fam1', 1 ).
test( 't52', 265, [], ['r3'], 'fam1', 1 ).
test( 't53', 440, ['m4','m9','m7','m15','m2','m17','m5'], [], 'fam1', 1 ).
test( 't54', 506, ['m4'], [], 'fam1', 1 ).
test( 't55', 767, [], [], 'fam1', 1 ).
test( 't56', 732, [], ['r1','r2'], 'fam1', 1 ).
test( 't57', 5, [], ['r3'], 'fam1', 1 ).
test( 't58', 469, [], ['r1','r3'], 'fam1', 1 ).
test( 't59', 661, ['m12','m20','m15','m4','m3'], ['r1','r2','r3'], 'fam1', 1 ).
test( 't60', 68, [], [], 'fam1', 1 ).
test( 't61', 510, [], ['r1'], 'fam1', 1 ).
test( 't62', 72, [], [], 'fam1', 1 ).
test( 't63', 435, [], [], 'fam1', 1 ).
test( 't64', 608, ['m14','m3','m1','m5','m2','m13'], [], 'fam1', 1 ).
test( 't65', 439, [], [], 'fam1', 1 ).
test( 't66', 82, [], [], 'fam1', 1 ).
test( 't67', 655, [], [], 'fam1', 1 ).
test( 't68', 262, [], [], 'fam1', 1 ).
test( 't69', 624, [], [], 'fam1', 1 ).
test( 't70', 101, [], [], 'fam1', 1 ).
test( 't71', 221, [], [], 'fam1', 1 ).
test( 't72', 739, [], [], 'fam1', 1 ).
test( 't73', 499, [], [], 'fam1', 1 ).
test( 't74', 660, [], [], 'fam1', 1 ).
test( 't75', 723, [], [], 'fam1', 1 ).
test( 't76', 599, ['m5','m11','m13','m7','m4'], [], 'fam1', 1 ).
test( 't77', 439, [], ['r2'], 'fam1', 1 ).
test( 't78', 183, [], [], 'fam1', 1 ).
test( 't79', 42, ['m8','m3','m19','m6','m16'], ['r2','r3'], 'fam1', 1 ).
test( 't80', 635, [], [], 'fam1', 1 ).
test( 't81', 620, [], [], 'fam1', 1 ).
test( 't82', 411, ['m18','m2','m17'], [], 'fam1', 1 ).
test( 't83', 503, [], ['r2'], 'fam1', 1 ).
test( 't84', 518, [], ['r2'], 'fam1', 1 ).
test( 't85', 565, [], [], 'fam1', 1 ).
test( 't86', 357, [], [], 'fam1', 1 ).
test( 't87', 625, [], ['r1'], 'fam1', 1 ).
test( 't88', 630, [], [], 'fam1', 1 ).
test( 't89', 677, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't90', 44, [], [], 'fam1', 1 ).
test( 't91', 756, ['m18'], ['r1','r3'], 'fam1', 1 ).
test( 't92', 692, [], [], 'fam1', 1 ).
test( 't93', 400, [], [], 'fam1', 1 ).
test( 't94', 369, [], [], 'fam1', 1 ).
test( 't95', 85, [], [], 'fam1', 1 ).
test( 't96', 480, [], [], 'fam1', 1 ).
test( 't97', 568, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't98', 630, ['m10','m11','m4'], ['r1','r2'], 'fam1', 1 ).
test( 't99', 279, [], [], 'fam1', 1 ).
test( 't100', 481, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
