%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 20
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 250, [], [], 'fam1', 1 ).
test( 't2', 679, [], [], 'fam1', 1 ).
test( 't3', 701, [], [], 'fam1', 1 ).
test( 't4', 688, ['m15','m2','m5'], ['r7','r4','r3','r6','r1','r9','r2','r5','r8'], 'fam1', 1 ).
test( 't5', 438, [], [], 'fam1', 1 ).
test( 't6', 628, [], ['r4','r8','r7','r9','r5','r10','r2','r3'], 'fam1', 1 ).
test( 't7', 231, [], ['r3'], 'fam1', 1 ).
test( 't8', 615, [], [], 'fam1', 1 ).
test( 't9', 500, [], ['r1','r3','r9','r2'], 'fam1', 1 ).
test( 't10', 500, [], [], 'fam1', 1 ).
test( 't11', 439, [], [], 'fam1', 1 ).
test( 't12', 325, [], [], 'fam1', 1 ).
test( 't13', 21, [], ['r1','r5','r6','r8','r3'], 'fam1', 1 ).
test( 't14', 175, [], [], 'fam1', 1 ).
test( 't15', 701, [], [], 'fam1', 1 ).
test( 't16', 644, [], [], 'fam1', 1 ).
test( 't17', 693, ['m14'], ['r3','r4','r10'], 'fam1', 1 ).
test( 't18', 242, [], [], 'fam1', 1 ).
test( 't19', 637, [], ['r10','r7','r6','r4','r2','r5','r1'], 'fam1', 1 ).
test( 't20', 244, [], [], 'fam1', 1 ).
test( 't21', 773, [], [], 'fam1', 1 ).
test( 't22', 520, [], ['r10','r7','r4','r1','r5'], 'fam1', 1 ).
test( 't23', 439, [], [], 'fam1', 1 ).
test( 't24', 150, [], ['r7','r1','r3','r8','r6','r10','r4'], 'fam1', 1 ).
test( 't25', 306, [], ['r4','r3','r1','r10','r8','r7','r5'], 'fam1', 1 ).
test( 't26', 150, [], [], 'fam1', 1 ).
test( 't27', 357, [], [], 'fam1', 1 ).
test( 't28', 191, [], [], 'fam1', 1 ).
test( 't29', 533, [], [], 'fam1', 1 ).
test( 't30', 140, [], [], 'fam1', 1 ).
test( 't31', 14, [], ['r7','r10','r2'], 'fam1', 1 ).
test( 't32', 638, [], [], 'fam1', 1 ).
test( 't33', 236, [], ['r8','r2','r3','r1','r6','r10','r7','r4'], 'fam1', 1 ).
test( 't34', 133, [], ['r1','r4','r7','r6'], 'fam1', 1 ).
test( 't35', 501, [], [], 'fam1', 1 ).
test( 't36', 36, [], ['r9'], 'fam1', 1 ).
test( 't37', 60, ['m8','m6','m11','m2','m16','m1','m18'], [], 'fam1', 1 ).
test( 't38', 403, [], [], 'fam1', 1 ).
test( 't39', 212, ['m13'], [], 'fam1', 1 ).
test( 't40', 497, [], [], 'fam1', 1 ).
test( 't41', 332, ['m5','m18','m9','m13','m17','m15','m10'], [], 'fam1', 1 ).
test( 't42', 705, [], ['r5','r6','r1','r4','r9','r10','r8','r2','r7'], 'fam1', 1 ).
test( 't43', 417, ['m20','m8'], ['r1','r5','r7','r2','r8'], 'fam1', 1 ).
test( 't44', 701, [], [], 'fam1', 1 ).
test( 't45', 164, ['m1','m4'], [], 'fam1', 1 ).
test( 't46', 728, [], ['r4','r5','r8','r7','r1','r10','r9','r2'], 'fam1', 1 ).
test( 't47', 255, [], [], 'fam1', 1 ).
test( 't48', 96, [], ['r10','r5','r6','r4','r9','r2','r1','r3','r7'], 'fam1', 1 ).
test( 't49', 108, ['m11','m17'], [], 'fam1', 1 ).
test( 't50', 522, [], [], 'fam1', 1 ).
test( 't51', 718, [], [], 'fam1', 1 ).
test( 't52', 778, [], [], 'fam1', 1 ).
test( 't53', 408, [], [], 'fam1', 1 ).
test( 't54', 513, [], [], 'fam1', 1 ).
test( 't55', 75, [], [], 'fam1', 1 ).
test( 't56', 645, [], [], 'fam1', 1 ).
test( 't57', 291, [], [], 'fam1', 1 ).
test( 't58', 214, [], ['r4','r5','r9'], 'fam1', 1 ).
test( 't59', 714, [], [], 'fam1', 1 ).
test( 't60', 249, [], ['r10','r1','r3','r7','r2','r6','r5'], 'fam1', 1 ).
test( 't61', 207, [], [], 'fam1', 1 ).
test( 't62', 792, [], [], 'fam1', 1 ).
test( 't63', 737, [], [], 'fam1', 1 ).
test( 't64', 44, [], ['r3','r8','r6','r5'], 'fam1', 1 ).
test( 't65', 255, [], [], 'fam1', 1 ).
test( 't66', 301, [], ['r6','r8','r3','r10','r5','r2'], 'fam1', 1 ).
test( 't67', 436, [], [], 'fam1', 1 ).
test( 't68', 69, [], ['r6','r1','r8','r5','r4','r9','r7'], 'fam1', 1 ).
test( 't69', 247, [], [], 'fam1', 1 ).
test( 't70', 250, ['m3','m14','m2','m11','m17','m10','m8','m5'], ['r5','r7','r10','r3','r9','r8','r4','r1','r2','r6'], 'fam1', 1 ).
test( 't71', 505, [], ['r3','r9','r8','r5','r2','r4','r6','r10','r1'], 'fam1', 1 ).
test( 't72', 153, ['m3','m6','m11','m9','m18','m12'], [], 'fam1', 1 ).
test( 't73', 118, [], [], 'fam1', 1 ).
test( 't74', 768, [], [], 'fam1', 1 ).
test( 't75', 24, [], [], 'fam1', 1 ).
test( 't76', 694, [], [], 'fam1', 1 ).
test( 't77', 18, [], [], 'fam1', 1 ).
test( 't78', 224, ['m14','m8','m12','m15','m13','m4','m11'], [], 'fam1', 1 ).
test( 't79', 720, ['m13','m7','m16','m1','m19','m14'], ['r4','r9','r1','r2','r7','r5','r3'], 'fam1', 1 ).
test( 't80', 79, [], [], 'fam1', 1 ).
test( 't81', 306, [], [], 'fam1', 1 ).
test( 't82', 743, [], [], 'fam1', 1 ).
test( 't83', 757, [], ['r10','r8'], 'fam1', 1 ).
test( 't84', 343, [], [], 'fam1', 1 ).
test( 't85', 413, [], [], 'fam1', 1 ).
test( 't86', 434, [], [], 'fam1', 1 ).
test( 't87', 751, [], [], 'fam1', 1 ).
test( 't88', 213, [], [], 'fam1', 1 ).
test( 't89', 761, [], [], 'fam1', 1 ).
test( 't90', 671, [], [], 'fam1', 1 ).
test( 't91', 438, [], [], 'fam1', 1 ).
test( 't92', 191, [], ['r3','r1','r6','r5','r10','r2'], 'fam1', 1 ).
test( 't93', 573, ['m15','m11','m16','m10','m13','m18','m2','m19'], [], 'fam1', 1 ).
test( 't94', 115, [], [], 'fam1', 1 ).
test( 't95', 578, ['m8','m18','m20','m5','m13','m6','m14'], [], 'fam1', 1 ).
test( 't96', 477, [], [], 'fam1', 1 ).
test( 't97', 317, [], ['r8','r7','r3','r6'], 'fam1', 1 ).
test( 't98', 369, [], [], 'fam1', 1 ).
test( 't99', 518, [], [], 'fam1', 1 ).
test( 't100', 366, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
