%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 10
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 688, [], [], 'fam1', 1 ).
test( 't2', 205, [], [], 'fam1', 1 ).
test( 't3', 592, [], [], 'fam1', 1 ).
test( 't4', 56, ['m8','m4','m1','m10'], ['r9','r8','r10','r7','r2','r5'], 'fam1', 1 ).
test( 't5', 207, [], ['r2','r7','r6','r3','r8','r4','r10','r9','r5','r1'], 'fam1', 1 ).
test( 't6', 109, ['m10','m3'], [], 'fam1', 1 ).
test( 't7', 177, [], ['r2','r8','r4','r7'], 'fam1', 1 ).
test( 't8', 187, [], [], 'fam1', 1 ).
test( 't9', 623, [], [], 'fam1', 1 ).
test( 't10', 585, [], [], 'fam1', 1 ).
test( 't11', 22, [], [], 'fam1', 1 ).
test( 't12', 246, [], ['r2','r1','r6'], 'fam1', 1 ).
test( 't13', 121, [], [], 'fam1', 1 ).
test( 't14', 173, [], [], 'fam1', 1 ).
test( 't15', 59, ['m4','m1'], [], 'fam1', 1 ).
test( 't16', 175, [], [], 'fam1', 1 ).
test( 't17', 381, [], [], 'fam1', 1 ).
test( 't18', 89, [], ['r4','r2'], 'fam1', 1 ).
test( 't19', 406, [], [], 'fam1', 1 ).
test( 't20', 100, [], [], 'fam1', 1 ).
test( 't21', 635, [], [], 'fam1', 1 ).
test( 't22', 517, [], [], 'fam1', 1 ).
test( 't23', 430, [], ['r5'], 'fam1', 1 ).
test( 't24', 636, [], [], 'fam1', 1 ).
test( 't25', 217, [], [], 'fam1', 1 ).
test( 't26', 605, [], [], 'fam1', 1 ).
test( 't27', 279, [], [], 'fam1', 1 ).
test( 't28', 654, ['m8'], [], 'fam1', 1 ).
test( 't29', 422, ['m5','m3','m6'], [], 'fam1', 1 ).
test( 't30', 474, ['m5'], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
