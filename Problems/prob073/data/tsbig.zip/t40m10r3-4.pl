%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 141, ['m1','m2','m4'], ['r2','r3'], 'fam1', 1 ).
test( 't2', 706, [], [], 'fam1', 1 ).
test( 't3', 540, ['m4','m2','m5','m8'], [], 'fam1', 1 ).
test( 't4', 628, [], [], 'fam1', 1 ).
test( 't5', 765, [], [], 'fam1', 1 ).
test( 't6', 291, ['m5','m3','m1','m6'], [], 'fam1', 1 ).
test( 't7', 468, [], ['r3','r2'], 'fam1', 1 ).
test( 't8', 113, [], [], 'fam1', 1 ).
test( 't9', 514, [], [], 'fam1', 1 ).
test( 't10', 260, [], [], 'fam1', 1 ).
test( 't11', 435, [], ['r1'], 'fam1', 1 ).
test( 't12', 702, [], [], 'fam1', 1 ).
test( 't13', 176, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't14', 627, [], [], 'fam1', 1 ).
test( 't15', 119, [], [], 'fam1', 1 ).
test( 't16', 523, [], ['r2'], 'fam1', 1 ).
test( 't17', 523, [], [], 'fam1', 1 ).
test( 't18', 49, [], [], 'fam1', 1 ).
test( 't19', 714, ['m4'], [], 'fam1', 1 ).
test( 't20', 33, [], ['r2'], 'fam1', 1 ).
test( 't21', 107, [], [], 'fam1', 1 ).
test( 't22', 615, [], [], 'fam1', 1 ).
test( 't23', 636, [], [], 'fam1', 1 ).
test( 't24', 243, [], [], 'fam1', 1 ).
test( 't25', 718, [], [], 'fam1', 1 ).
test( 't26', 6, ['m7'], [], 'fam1', 1 ).
test( 't27', 283, [], [], 'fam1', 1 ).
test( 't28', 606, ['m1','m8'], [], 'fam1', 1 ).
test( 't29', 153, ['m4'], [], 'fam1', 1 ).
test( 't30', 527, [], [], 'fam1', 1 ).
test( 't31', 630, [], [], 'fam1', 1 ).
test( 't32', 575, [], [], 'fam1', 1 ).
test( 't33', 326, [], [], 'fam1', 1 ).
test( 't34', 52, ['m8','m5'], [], 'fam1', 1 ).
test( 't35', 680, [], [], 'fam1', 1 ).
test( 't36', 332, ['m6','m7'], [], 'fam1', 1 ).
test( 't37', 200, ['m4','m1'], [], 'fam1', 1 ).
test( 't38', 707, [], [], 'fam1', 1 ).
test( 't39', 539, [], ['r3','r1'], 'fam1', 1 ).
test( 't40', 45, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
