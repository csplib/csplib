%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 256, ['m2','m4','m5'], [], 'fam1', 1 ).
test( 't2', 172, [], [], 'fam1', 1 ).
test( 't3', 451, ['m1','m3'], [], 'fam1', 1 ).
test( 't4', 756, [], ['r3','r2'], 'fam1', 1 ).
test( 't5', 737, ['m9','m6','m2'], [], 'fam1', 1 ).
test( 't6', 549, [], [], 'fam1', 1 ).
test( 't7', 715, [], [], 'fam1', 1 ).
test( 't8', 631, ['m5','m1'], ['r1','r3'], 'fam1', 1 ).
test( 't9', 229, [], [], 'fam1', 1 ).
test( 't10', 468, [], [], 'fam1', 1 ).
test( 't11', 23, [], [], 'fam1', 1 ).
test( 't12', 443, [], [], 'fam1', 1 ).
test( 't13', 210, [], [], 'fam1', 1 ).
test( 't14', 541, [], [], 'fam1', 1 ).
test( 't15', 539, [], [], 'fam1', 1 ).
test( 't16', 60, [], [], 'fam1', 1 ).
test( 't17', 301, [], [], 'fam1', 1 ).
test( 't18', 194, [], [], 'fam1', 1 ).
test( 't19', 160, [], [], 'fam1', 1 ).
test( 't20', 315, ['m7','m2','m1','m5'], [], 'fam1', 1 ).
test( 't21', 468, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't22', 517, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't23', 545, ['m3','m6','m9','m4'], [], 'fam1', 1 ).
test( 't24', 125, [], ['r3','r1'], 'fam1', 1 ).
test( 't25', 275, [], ['r3'], 'fam1', 1 ).
test( 't26', 346, [], [], 'fam1', 1 ).
test( 't27', 6, [], [], 'fam1', 1 ).
test( 't28', 303, [], [], 'fam1', 1 ).
test( 't29', 46, [], ['r1','r3'], 'fam1', 1 ).
test( 't30', 676, [], [], 'fam1', 1 ).
test( 't31', 597, [], [], 'fam1', 1 ).
test( 't32', 312, ['m5','m1','m8'], ['r3'], 'fam1', 1 ).
test( 't33', 126, [], ['r2'], 'fam1', 1 ).
test( 't34', 19, [], [], 'fam1', 1 ).
test( 't35', 666, [], [], 'fam1', 1 ).
test( 't36', 722, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't37', 748, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't38', 445, [], [], 'fam1', 1 ).
test( 't39', 273, ['m9'], ['r1','r2','r3'], 'fam1', 1 ).
test( 't40', 437, [], [], 'fam1', 1 ).
test( 't41', 293, ['m4','m5','m1'], [], 'fam1', 1 ).
test( 't42', 634, ['m1'], ['r1','r3'], 'fam1', 1 ).
test( 't43', 244, [], [], 'fam1', 1 ).
test( 't44', 758, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't45', 765, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't46', 68, [], [], 'fam1', 1 ).
test( 't47', 738, [], ['r2','r1'], 'fam1', 1 ).
test( 't48', 728, [], ['r2','r1'], 'fam1', 1 ).
test( 't49', 432, [], ['r1','r3'], 'fam1', 1 ).
test( 't50', 748, [], [], 'fam1', 1 ).
test( 't51', 623, [], [], 'fam1', 1 ).
test( 't52', 550, [], [], 'fam1', 1 ).
test( 't53', 413, [], [], 'fam1', 1 ).
test( 't54', 648, [], [], 'fam1', 1 ).
test( 't55', 60, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't56', 717, ['m4','m9'], [], 'fam1', 1 ).
test( 't57', 66, ['m8','m3','m7'], ['r3'], 'fam1', 1 ).
test( 't58', 452, [], [], 'fam1', 1 ).
test( 't59', 456, [], [], 'fam1', 1 ).
test( 't60', 100, [], [], 'fam1', 1 ).
test( 't61', 640, [], ['r2'], 'fam1', 1 ).
test( 't62', 205, [], [], 'fam1', 1 ).
test( 't63', 790, [], [], 'fam1', 1 ).
test( 't64', 310, [], [], 'fam1', 1 ).
test( 't65', 547, [], [], 'fam1', 1 ).
test( 't66', 626, [], [], 'fam1', 1 ).
test( 't67', 673, [], [], 'fam1', 1 ).
test( 't68', 24, [], [], 'fam1', 1 ).
test( 't69', 443, [], ['r3','r1'], 'fam1', 1 ).
test( 't70', 29, [], [], 'fam1', 1 ).
test( 't71', 646, [], ['r1','r3'], 'fam1', 1 ).
test( 't72', 97, [], [], 'fam1', 1 ).
test( 't73', 797, [], [], 'fam1', 1 ).
test( 't74', 445, [], [], 'fam1', 1 ).
test( 't75', 531, [], [], 'fam1', 1 ).
test( 't76', 688, [], [], 'fam1', 1 ).
test( 't77', 377, ['m4','m1'], [], 'fam1', 1 ).
test( 't78', 12, [], [], 'fam1', 1 ).
test( 't79', 758, [], ['r1'], 'fam1', 1 ).
test( 't80', 428, [], [], 'fam1', 1 ).
test( 't81', 252, [], [], 'fam1', 1 ).
test( 't82', 98, ['m9','m7','m3','m2'], [], 'fam1', 1 ).
test( 't83', 720, [], [], 'fam1', 1 ).
test( 't84', 534, [], ['r3'], 'fam1', 1 ).
test( 't85', 294, [], [], 'fam1', 1 ).
test( 't86', 295, [], [], 'fam1', 1 ).
test( 't87', 84, [], [], 'fam1', 1 ).
test( 't88', 697, [], [], 'fam1', 1 ).
test( 't89', 128, [], [], 'fam1', 1 ).
test( 't90', 318, [], [], 'fam1', 1 ).
test( 't91', 758, [], [], 'fam1', 1 ).
test( 't92', 586, [], ['r1','r3'], 'fam1', 1 ).
test( 't93', 259, [], ['r2'], 'fam1', 1 ).
test( 't94', 636, [], [], 'fam1', 1 ).
test( 't95', 20, [], [], 'fam1', 1 ).
test( 't96', 86, [], [], 'fam1', 1 ).
test( 't97', 146, [], [], 'fam1', 1 ).
test( 't98', 41, [], [], 'fam1', 1 ).
test( 't99', 211, [], ['r3'], 'fam1', 1 ).
test( 't100', 178, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
