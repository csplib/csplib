%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 10
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 612, [], [], 'fam1', 1 ).
test( 't2', 368, [], ['r3','r5','r6','r7','r10','r8','r4','r1','r9','r2'], 'fam1', 1 ).
test( 't3', 190, [], ['r5','r6','r9','r2','r4','r1','r10','r3'], 'fam1', 1 ).
test( 't4', 484, [], ['r2','r1','r5','r4','r6','r8','r10','r3','r7'], 'fam1', 1 ).
test( 't5', 118, [], ['r1','r10','r2','r8','r9','r5','r6','r4'], 'fam1', 1 ).
test( 't6', 10, [], ['r7','r5','r8'], 'fam1', 1 ).
test( 't7', 738, [], ['r3','r9','r4'], 'fam1', 1 ).
test( 't8', 199, [], ['r9','r8','r6','r3','r1','r4'], 'fam1', 1 ).
test( 't9', 28, ['m9'], [], 'fam1', 1 ).
test( 't10', 400, [], [], 'fam1', 1 ).
test( 't11', 101, ['m1','m3','m5'], [], 'fam1', 1 ).
test( 't12', 350, [], [], 'fam1', 1 ).
test( 't13', 69, [], [], 'fam1', 1 ).
test( 't14', 419, [], [], 'fam1', 1 ).
test( 't15', 359, ['m3'], [], 'fam1', 1 ).
test( 't16', 619, [], [], 'fam1', 1 ).
test( 't17', 86, [], ['r3','r8','r7','r1','r6','r10','r9','r5'], 'fam1', 1 ).
test( 't18', 115, [], [], 'fam1', 1 ).
test( 't19', 162, ['m9','m4','m3','m6'], [], 'fam1', 1 ).
test( 't20', 105, [], [], 'fam1', 1 ).
test( 't21', 102, [], ['r4','r3','r2','r1','r10','r8','r6','r7'], 'fam1', 1 ).
test( 't22', 164, [], [], 'fam1', 1 ).
test( 't23', 416, ['m6','m8'], ['r1','r4','r10','r6','r7','r2','r5','r8','r3'], 'fam1', 1 ).
test( 't24', 397, ['m5'], ['r10','r8','r3','r1','r7','r4','r5','r6','r2','r9'], 'fam1', 1 ).
test( 't25', 657, [], ['r6','r7','r4','r10','r5','r2','r8'], 'fam1', 1 ).
test( 't26', 285, ['m7','m2','m6'], [], 'fam1', 1 ).
test( 't27', 755, ['m9','m3'], [], 'fam1', 1 ).
test( 't28', 413, [], [], 'fam1', 1 ).
test( 't29', 465, [], [], 'fam1', 1 ).
test( 't30', 24, ['m2','m7','m4','m8'], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
