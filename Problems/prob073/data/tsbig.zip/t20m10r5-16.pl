%% ****  Testsuite  ****
% Number of tests                  : 20
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 477, [], [], 'fam1', 1 ).
test( 't2', 682, ['m10','m3','m2'], [], 'fam1', 1 ).
test( 't3', 629, [], ['r3','r4','r5','r1'], 'fam1', 1 ).
test( 't4', 349, [], [], 'fam1', 1 ).
test( 't5', 259, [], [], 'fam1', 1 ).
test( 't6', 790, ['m1','m7'], ['r3','r1','r2','r5','r4'], 'fam1', 1 ).
test( 't7', 551, [], [], 'fam1', 1 ).
test( 't8', 628, [], [], 'fam1', 1 ).
test( 't9', 691, [], [], 'fam1', 1 ).
test( 't10', 586, [], [], 'fam1', 1 ).
test( 't11', 409, [], [], 'fam1', 1 ).
test( 't12', 503, ['m6'], ['r3','r2','r1','r5','r4'], 'fam1', 1 ).
test( 't13', 276, ['m7','m3','m1'], [], 'fam1', 1 ).
test( 't14', 338, [], ['r3','r2','r1','r4','r5'], 'fam1', 1 ).
test( 't15', 75, [], [], 'fam1', 1 ).
test( 't16', 551, [], [], 'fam1', 1 ).
test( 't17', 504, [], [], 'fam1', 1 ).
test( 't18', 393, [], [], 'fam1', 1 ).
test( 't19', 650, [], ['r4'], 'fam1', 1 ).
test( 't20', 711, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
