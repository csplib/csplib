%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 10
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 396, [], [], 'fam1', 1 ).
test( 't2', 614, ['m10'], [], 'fam1', 1 ).
test( 't3', 470, [], [], 'fam1', 1 ).
test( 't4', 540, ['m7'], [], 'fam1', 1 ).
test( 't5', 457, ['m10','m1','m2'], ['r1','r6','r3','r5','r8','r9','r7'], 'fam1', 1 ).
test( 't6', 367, [], [], 'fam1', 1 ).
test( 't7', 775, [], [], 'fam1', 1 ).
test( 't8', 478, [], [], 'fam1', 1 ).
test( 't9', 603, [], [], 'fam1', 1 ).
test( 't10', 487, ['m8','m1'], [], 'fam1', 1 ).
test( 't11', 559, [], [], 'fam1', 1 ).
test( 't12', 461, [], [], 'fam1', 1 ).
test( 't13', 197, [], [], 'fam1', 1 ).
test( 't14', 271, [], [], 'fam1', 1 ).
test( 't15', 131, [], ['r4','r3'], 'fam1', 1 ).
test( 't16', 427, [], [], 'fam1', 1 ).
test( 't17', 73, [], ['r10','r8','r7','r9'], 'fam1', 1 ).
test( 't18', 163, [], [], 'fam1', 1 ).
test( 't19', 394, [], [], 'fam1', 1 ).
test( 't20', 427, ['m1','m10'], [], 'fam1', 1 ).
test( 't21', 680, ['m5','m10'], [], 'fam1', 1 ).
test( 't22', 411, [], [], 'fam1', 1 ).
test( 't23', 374, [], ['r6','r1','r3','r5','r2','r4'], 'fam1', 1 ).
test( 't24', 146, [], ['r5'], 'fam1', 1 ).
test( 't25', 381, [], [], 'fam1', 1 ).
test( 't26', 630, ['m8','m10','m6','m7'], [], 'fam1', 1 ).
test( 't27', 139, ['m3','m9','m2'], [], 'fam1', 1 ).
test( 't28', 512, [], [], 'fam1', 1 ).
test( 't29', 741, [], [], 'fam1', 1 ).
test( 't30', 365, [], [], 'fam1', 1 ).
test( 't31', 245, [], ['r7','r2','r9','r10','r1'], 'fam1', 1 ).
test( 't32', 247, [], [], 'fam1', 1 ).
test( 't33', 678, [], ['r9','r10','r1','r8','r7','r4','r6','r2'], 'fam1', 1 ).
test( 't34', 331, [], [], 'fam1', 1 ).
test( 't35', 223, [], ['r1','r10','r2','r7','r9','r3','r5','r6','r8','r4'], 'fam1', 1 ).
test( 't36', 241, [], [], 'fam1', 1 ).
test( 't37', 620, ['m8','m10','m3'], ['r5','r3'], 'fam1', 1 ).
test( 't38', 340, [], [], 'fam1', 1 ).
test( 't39', 373, [], ['r6','r3','r4','r1','r7','r2','r10','r9'], 'fam1', 1 ).
test( 't40', 473, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
