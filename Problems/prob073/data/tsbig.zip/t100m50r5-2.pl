%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 50
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 568, [], [], 'fam1', 1 ).
test( 't2', 191, [], [], 'fam1', 1 ).
test( 't3', 127, ['m4','m30','m34','m43','m14','m31','m11','m48','m32','m36','m3','m6','m26','m7','m16'], [], 'fam1', 1 ).
test( 't4', 365, ['m47','m23','m20','m39','m4','m7','m34','m33','m27','m13'], ['r4','r2','r5','r1'], 'fam1', 1 ).
test( 't5', 672, [], [], 'fam1', 1 ).
test( 't6', 8, [], ['r4','r2'], 'fam1', 1 ).
test( 't7', 554, [], ['r4','r2','r3'], 'fam1', 1 ).
test( 't8', 369, [], [], 'fam1', 1 ).
test( 't9', 440, ['m11','m27','m14','m47','m40','m25','m16','m28','m46','m39','m32','m38','m20','m21','m8','m36'], [], 'fam1', 1 ).
test( 't10', 614, [], [], 'fam1', 1 ).
test( 't11', 635, [], [], 'fam1', 1 ).
test( 't12', 164, [], [], 'fam1', 1 ).
test( 't13', 702, ['m20','m7','m19','m44','m10','m31','m48','m22','m46','m21','m37','m1','m30','m47'], [], 'fam1', 1 ).
test( 't14', 218, [], ['r5'], 'fam1', 1 ).
test( 't15', 419, [], [], 'fam1', 1 ).
test( 't16', 422, [], ['r4'], 'fam1', 1 ).
test( 't17', 734, [], [], 'fam1', 1 ).
test( 't18', 27, [], ['r3','r5','r2','r1','r4'], 'fam1', 1 ).
test( 't19', 740, [], [], 'fam1', 1 ).
test( 't20', 371, [], ['r4','r1','r3','r5'], 'fam1', 1 ).
test( 't21', 689, [], [], 'fam1', 1 ).
test( 't22', 33, [], [], 'fam1', 1 ).
test( 't23', 709, [], ['r4'], 'fam1', 1 ).
test( 't24', 704, ['m24'], ['r5'], 'fam1', 1 ).
test( 't25', 223, [], [], 'fam1', 1 ).
test( 't26', 180, [], [], 'fam1', 1 ).
test( 't27', 690, [], [], 'fam1', 1 ).
test( 't28', 612, ['m12'], [], 'fam1', 1 ).
test( 't29', 732, [], [], 'fam1', 1 ).
test( 't30', 533, [], [], 'fam1', 1 ).
test( 't31', 643, [], [], 'fam1', 1 ).
test( 't32', 56, [], [], 'fam1', 1 ).
test( 't33', 441, [], [], 'fam1', 1 ).
test( 't34', 600, [], ['r1'], 'fam1', 1 ).
test( 't35', 119, [], [], 'fam1', 1 ).
test( 't36', 30, ['m42','m19','m18','m15','m13','m6','m37','m27','m11','m25','m24','m38','m20','m35'], ['r2','r3'], 'fam1', 1 ).
test( 't37', 143, [], [], 'fam1', 1 ).
test( 't38', 393, ['m33','m49','m7','m16','m36','m4','m47','m2','m3','m30','m23','m43'], [], 'fam1', 1 ).
test( 't39', 799, [], [], 'fam1', 1 ).
test( 't40', 685, [], [], 'fam1', 1 ).
test( 't41', 710, [], [], 'fam1', 1 ).
test( 't42', 730, ['m25','m2','m7','m17','m21','m38','m1','m45','m8','m14','m27','m12','m4','m19','m44','m23'], [], 'fam1', 1 ).
test( 't43', 288, ['m8','m12','m17','m2','m28','m35','m24','m11','m31','m43','m27','m1','m36','m20','m37'], [], 'fam1', 1 ).
test( 't44', 734, [], [], 'fam1', 1 ).
test( 't45', 76, [], [], 'fam1', 1 ).
test( 't46', 527, [], [], 'fam1', 1 ).
test( 't47', 61, ['m6','m11','m3','m12','m35'], [], 'fam1', 1 ).
test( 't48', 548, [], [], 'fam1', 1 ).
test( 't49', 762, [], [], 'fam1', 1 ).
test( 't50', 404, [], [], 'fam1', 1 ).
test( 't51', 90, [], [], 'fam1', 1 ).
test( 't52', 272, [], [], 'fam1', 1 ).
test( 't53', 717, ['m22','m42','m16','m27','m20','m26','m50','m24','m30','m8','m36','m45','m6','m5','m11','m28'], [], 'fam1', 1 ).
test( 't54', 768, [], ['r4','r5'], 'fam1', 1 ).
test( 't55', 737, [], [], 'fam1', 1 ).
test( 't56', 417, [], [], 'fam1', 1 ).
test( 't57', 253, [], [], 'fam1', 1 ).
test( 't58', 381, [], [], 'fam1', 1 ).
test( 't59', 102, ['m23','m40','m25','m8','m38','m16','m13'], [], 'fam1', 1 ).
test( 't60', 597, ['m7','m8','m27','m1','m34','m15','m39','m40','m9','m38','m47','m31','m32','m16','m43','m19','m21','m18','m2'], ['r5','r4','r2'], 'fam1', 1 ).
test( 't61', 799, [], [], 'fam1', 1 ).
test( 't62', 333, ['m41','m19','m29','m1','m50','m38','m26','m46','m42','m11','m10','m16'], [], 'fam1', 1 ).
test( 't63', 372, [], [], 'fam1', 1 ).
test( 't64', 302, [], [], 'fam1', 1 ).
test( 't65', 194, [], [], 'fam1', 1 ).
test( 't66', 620, [], ['r1','r2','r3','r4'], 'fam1', 1 ).
test( 't67', 754, [], [], 'fam1', 1 ).
test( 't68', 415, [], [], 'fam1', 1 ).
test( 't69', 666, [], ['r5','r2'], 'fam1', 1 ).
test( 't70', 194, [], [], 'fam1', 1 ).
test( 't71', 337, [], [], 'fam1', 1 ).
test( 't72', 150, [], [], 'fam1', 1 ).
test( 't73', 739, [], [], 'fam1', 1 ).
test( 't74', 732, [], [], 'fam1', 1 ).
test( 't75', 622, [], [], 'fam1', 1 ).
test( 't76', 690, [], ['r4','r1','r2','r3'], 'fam1', 1 ).
test( 't77', 384, [], [], 'fam1', 1 ).
test( 't78', 146, [], [], 'fam1', 1 ).
test( 't79', 695, [], [], 'fam1', 1 ).
test( 't80', 214, ['m27'], [], 'fam1', 1 ).
test( 't81', 237, [], ['r5','r2'], 'fam1', 1 ).
test( 't82', 700, [], [], 'fam1', 1 ).
test( 't83', 209, [], ['r4','r2','r1'], 'fam1', 1 ).
test( 't84', 726, ['m32','m45','m41','m3'], [], 'fam1', 1 ).
test( 't85', 164, [], [], 'fam1', 1 ).
test( 't86', 467, [], [], 'fam1', 1 ).
test( 't87', 705, ['m21','m33','m31','m34','m23','m38','m25','m35','m3','m28','m9','m13','m16','m6'], ['r5','r1','r3','r4','r2'], 'fam1', 1 ).
test( 't88', 62, [], ['r5','r3','r2'], 'fam1', 1 ).
test( 't89', 340, ['m46','m41','m25','m9','m6','m23','m29','m32','m8','m5','m33','m19','m20','m37','m30','m12','m42'], [], 'fam1', 1 ).
test( 't90', 405, [], ['r3','r2','r5','r4','r1'], 'fam1', 1 ).
test( 't91', 722, ['m47','m15','m45','m33','m1','m44','m35','m14'], [], 'fam1', 1 ).
test( 't92', 513, [], [], 'fam1', 1 ).
test( 't93', 397, [], [], 'fam1', 1 ).
test( 't94', 496, [], [], 'fam1', 1 ).
test( 't95', 94, [], [], 'fam1', 1 ).
test( 't96', 381, [], [], 'fam1', 1 ).
test( 't97', 298, [], [], 'fam1', 1 ).
test( 't98', 389, [], [], 'fam1', 1 ).
test( 't99', 201, [], ['r1','r3','r5','r2','r4'], 'fam1', 1 ).
test( 't100', 310, [], ['r2'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').
embedded_board( 'm21').
embedded_board( 'm22').
embedded_board( 'm23').
embedded_board( 'm24').
embedded_board( 'm25').
embedded_board( 'm26').
embedded_board( 'm27').
embedded_board( 'm28').
embedded_board( 'm29').
embedded_board( 'm30').
embedded_board( 'm31').
embedded_board( 'm32').
embedded_board( 'm33').
embedded_board( 'm34').
embedded_board( 'm35').
embedded_board( 'm36').
embedded_board( 'm37').
embedded_board( 'm38').
embedded_board( 'm39').
embedded_board( 'm40').
embedded_board( 'm41').
embedded_board( 'm42').
embedded_board( 'm43').
embedded_board( 'm44').
embedded_board( 'm45').
embedded_board( 'm46').
embedded_board( 'm47').
embedded_board( 'm48').
embedded_board( 'm49').
embedded_board( 'm50').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
