%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 20
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 179, [], ['r2'], 'fam1', 1 ).
test( 't2', 642, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't3', 108, [], [], 'fam1', 1 ).
test( 't4', 624, [], [], 'fam1', 1 ).
test( 't5', 351, ['m8','m5','m12','m2','m10'], [], 'fam1', 1 ).
test( 't6', 591, [], ['r2','r1'], 'fam1', 1 ).
test( 't7', 338, ['m11','m6','m20','m2','m14','m4','m7','m5'], ['r2','r1'], 'fam1', 1 ).
test( 't8', 220, [], [], 'fam1', 1 ).
test( 't9', 572, [], [], 'fam1', 1 ).
test( 't10', 513, [], ['r3'], 'fam1', 1 ).
test( 't11', 453, [], [], 'fam1', 1 ).
test( 't12', 514, [], [], 'fam1', 1 ).
test( 't13', 643, ['m1','m13','m5'], ['r1','r2'], 'fam1', 1 ).
test( 't14', 335, [], [], 'fam1', 1 ).
test( 't15', 101, [], [], 'fam1', 1 ).
test( 't16', 166, [], [], 'fam1', 1 ).
test( 't17', 482, [], [], 'fam1', 1 ).
test( 't18', 252, [], [], 'fam1', 1 ).
test( 't19', 121, [], [], 'fam1', 1 ).
test( 't20', 373, ['m7','m4'], [], 'fam1', 1 ).
test( 't21', 396, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't22', 450, [], [], 'fam1', 1 ).
test( 't23', 388, [], [], 'fam1', 1 ).
test( 't24', 251, [], [], 'fam1', 1 ).
test( 't25', 111, [], [], 'fam1', 1 ).
test( 't26', 710, [], ['r3','r1'], 'fam1', 1 ).
test( 't27', 757, [], [], 'fam1', 1 ).
test( 't28', 791, [], [], 'fam1', 1 ).
test( 't29', 124, [], [], 'fam1', 1 ).
test( 't30', 310, [], [], 'fam1', 1 ).
test( 't31', 547, [], [], 'fam1', 1 ).
test( 't32', 475, [], [], 'fam1', 1 ).
test( 't33', 446, [], ['r3'], 'fam1', 1 ).
test( 't34', 629, [], ['r3'], 'fam1', 1 ).
test( 't35', 674, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't36', 695, [], [], 'fam1', 1 ).
test( 't37', 674, [], [], 'fam1', 1 ).
test( 't38', 627, ['m15','m1','m9','m14','m16','m18'], [], 'fam1', 1 ).
test( 't39', 255, [], [], 'fam1', 1 ).
test( 't40', 730, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
