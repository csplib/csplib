%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 797, ['m4'], [], 'fam1', 1 ).
test( 't2', 192, ['m8','m7'], [], 'fam1', 1 ).
test( 't3', 379, ['m8'], ['r4','r1'], 'fam1', 1 ).
test( 't4', 247, ['m9','m1','m6'], [], 'fam1', 1 ).
test( 't5', 4, [], [], 'fam1', 1 ).
test( 't6', 658, [], [], 'fam1', 1 ).
test( 't7', 793, [], [], 'fam1', 1 ).
test( 't8', 747, ['m1','m2','m4','m5'], [], 'fam1', 1 ).
test( 't9', 65, [], [], 'fam1', 1 ).
test( 't10', 120, [], [], 'fam1', 1 ).
test( 't11', 436, [], [], 'fam1', 1 ).
test( 't12', 413, [], ['r4','r2'], 'fam1', 1 ).
test( 't13', 340, [], [], 'fam1', 1 ).
test( 't14', 574, ['m2','m1','m4','m9'], ['r4','r3','r2','r1'], 'fam1', 1 ).
test( 't15', 346, [], [], 'fam1', 1 ).
test( 't16', 380, [], [], 'fam1', 1 ).
test( 't17', 558, [], [], 'fam1', 1 ).
test( 't18', 104, ['m10','m2','m7','m1'], [], 'fam1', 1 ).
test( 't19', 246, [], [], 'fam1', 1 ).
test( 't20', 500, [], [], 'fam1', 1 ).
test( 't21', 710, [], ['r5'], 'fam1', 1 ).
test( 't22', 617, [], [], 'fam1', 1 ).
test( 't23', 567, [], [], 'fam1', 1 ).
test( 't24', 589, ['m7','m5','m10','m1'], [], 'fam1', 1 ).
test( 't25', 725, [], [], 'fam1', 1 ).
test( 't26', 658, [], ['r2','r4'], 'fam1', 1 ).
test( 't27', 734, ['m8','m2','m6'], [], 'fam1', 1 ).
test( 't28', 470, [], ['r5','r4','r2'], 'fam1', 1 ).
test( 't29', 438, ['m7','m9','m8'], [], 'fam1', 1 ).
test( 't30', 662, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
