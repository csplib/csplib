%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 20
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 795, ['m15','m6','m18','m8','m7','m9','m11','m17'], [], 'fam1', 1 ).
test( 't2', 711, [], [], 'fam1', 1 ).
test( 't3', 225, ['m2','m14','m4','m15','m13','m16','m12','m5'], ['r5','r1','r3','r2'], 'fam1', 1 ).
test( 't4', 378, [], ['r4','r5','r2','r1','r3'], 'fam1', 1 ).
test( 't5', 736, ['m9','m6','m4','m1','m11','m15'], [], 'fam1', 1 ).
test( 't6', 552, ['m14','m8','m17'], ['r2'], 'fam1', 1 ).
test( 't7', 130, ['m20','m4'], [], 'fam1', 1 ).
test( 't8', 677, [], [], 'fam1', 1 ).
test( 't9', 541, [], ['r1','r2','r4','r5'], 'fam1', 1 ).
test( 't10', 310, [], [], 'fam1', 1 ).
test( 't11', 432, [], [], 'fam1', 1 ).
test( 't12', 716, [], ['r1','r5','r2','r4'], 'fam1', 1 ).
test( 't13', 705, [], [], 'fam1', 1 ).
test( 't14', 539, [], [], 'fam1', 1 ).
test( 't15', 113, [], [], 'fam1', 1 ).
test( 't16', 72, [], [], 'fam1', 1 ).
test( 't17', 300, [], [], 'fam1', 1 ).
test( 't18', 306, [], [], 'fam1', 1 ).
test( 't19', 675, ['m10','m9','m3','m18','m14','m19','m4','m1'], [], 'fam1', 1 ).
test( 't20', 597, ['m5','m15','m12','m6'], [], 'fam1', 1 ).
test( 't21', 234, [], [], 'fam1', 1 ).
test( 't22', 327, ['m10'], ['r2','r4','r3','r1'], 'fam1', 1 ).
test( 't23', 137, [], [], 'fam1', 1 ).
test( 't24', 317, [], [], 'fam1', 1 ).
test( 't25', 568, [], ['r5','r3','r4','r1'], 'fam1', 1 ).
test( 't26', 234, [], ['r5'], 'fam1', 1 ).
test( 't27', 45, [], ['r3','r5','r2'], 'fam1', 1 ).
test( 't28', 666, [], [], 'fam1', 1 ).
test( 't29', 34, [], ['r2','r3','r4','r5','r1'], 'fam1', 1 ).
test( 't30', 408, ['m11','m8','m4','m13','m9','m6','m19','m3'], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
