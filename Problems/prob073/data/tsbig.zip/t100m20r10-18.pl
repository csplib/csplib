%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 20
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 305, [], ['r7','r2'], 'fam1', 1 ).
test( 't2', 9, [], [], 'fam1', 1 ).
test( 't3', 670, [], [], 'fam1', 1 ).
test( 't4', 276, [], [], 'fam1', 1 ).
test( 't5', 313, [], ['r5','r10'], 'fam1', 1 ).
test( 't6', 617, [], [], 'fam1', 1 ).
test( 't7', 15, [], ['r5','r2','r10','r8','r9','r6','r7','r4','r3','r1'], 'fam1', 1 ).
test( 't8', 709, ['m2'], [], 'fam1', 1 ).
test( 't9', 536, [], [], 'fam1', 1 ).
test( 't10', 159, [], [], 'fam1', 1 ).
test( 't11', 2, [], [], 'fam1', 1 ).
test( 't12', 561, [], [], 'fam1', 1 ).
test( 't13', 502, [], [], 'fam1', 1 ).
test( 't14', 142, ['m14','m3','m17','m4'], [], 'fam1', 1 ).
test( 't15', 451, [], [], 'fam1', 1 ).
test( 't16', 793, [], ['r8','r2','r3','r7','r9','r6','r4','r10','r1'], 'fam1', 1 ).
test( 't17', 547, [], ['r1'], 'fam1', 1 ).
test( 't18', 753, [], ['r7','r1','r3'], 'fam1', 1 ).
test( 't19', 273, [], ['r6','r9'], 'fam1', 1 ).
test( 't20', 192, [], [], 'fam1', 1 ).
test( 't21', 428, ['m2','m20'], ['r1','r6','r8'], 'fam1', 1 ).
test( 't22', 514, [], ['r4','r7','r1','r6','r8','r10'], 'fam1', 1 ).
test( 't23', 73, ['m20'], [], 'fam1', 1 ).
test( 't24', 98, ['m13','m18','m9','m6','m4','m16','m10'], [], 'fam1', 1 ).
test( 't25', 460, [], [], 'fam1', 1 ).
test( 't26', 495, [], [], 'fam1', 1 ).
test( 't27', 98, [], ['r8'], 'fam1', 1 ).
test( 't28', 177, ['m12','m13','m3','m19','m7','m18','m10','m2'], [], 'fam1', 1 ).
test( 't29', 413, [], [], 'fam1', 1 ).
test( 't30', 104, [], [], 'fam1', 1 ).
test( 't31', 508, [], [], 'fam1', 1 ).
test( 't32', 621, [], [], 'fam1', 1 ).
test( 't33', 344, ['m17','m2','m5'], ['r4','r6','r5','r3','r1','r10','r8','r2','r7','r9'], 'fam1', 1 ).
test( 't34', 276, ['m3','m18'], [], 'fam1', 1 ).
test( 't35', 627, [], [], 'fam1', 1 ).
test( 't36', 210, [], [], 'fam1', 1 ).
test( 't37', 551, [], ['r9','r7','r6'], 'fam1', 1 ).
test( 't38', 86, [], ['r7','r5','r9','r2','r4','r6'], 'fam1', 1 ).
test( 't39', 760, [], [], 'fam1', 1 ).
test( 't40', 519, [], [], 'fam1', 1 ).
test( 't41', 740, [], ['r3','r10'], 'fam1', 1 ).
test( 't42', 102, [], ['r10','r5','r8','r9'], 'fam1', 1 ).
test( 't43', 546, [], [], 'fam1', 1 ).
test( 't44', 351, [], [], 'fam1', 1 ).
test( 't45', 671, ['m5','m3','m20'], [], 'fam1', 1 ).
test( 't46', 113, [], ['r9','r5'], 'fam1', 1 ).
test( 't47', 654, [], [], 'fam1', 1 ).
test( 't48', 288, [], [], 'fam1', 1 ).
test( 't49', 289, [], [], 'fam1', 1 ).
test( 't50', 756, [], [], 'fam1', 1 ).
test( 't51', 609, [], [], 'fam1', 1 ).
test( 't52', 586, [], [], 'fam1', 1 ).
test( 't53', 520, [], [], 'fam1', 1 ).
test( 't54', 371, ['m14','m12','m10','m6'], ['r10'], 'fam1', 1 ).
test( 't55', 524, [], [], 'fam1', 1 ).
test( 't56', 108, [], ['r3','r10','r1','r5','r8','r6','r7'], 'fam1', 1 ).
test( 't57', 472, [], [], 'fam1', 1 ).
test( 't58', 256, [], [], 'fam1', 1 ).
test( 't59', 641, [], [], 'fam1', 1 ).
test( 't60', 334, [], ['r2','r10','r9'], 'fam1', 1 ).
test( 't61', 722, [], [], 'fam1', 1 ).
test( 't62', 781, [], [], 'fam1', 1 ).
test( 't63', 58, ['m17','m11','m13','m15','m4','m16','m9','m14'], [], 'fam1', 1 ).
test( 't64', 163, [], [], 'fam1', 1 ).
test( 't65', 756, [], [], 'fam1', 1 ).
test( 't66', 137, [], [], 'fam1', 1 ).
test( 't67', 74, ['m20','m13','m3','m10','m12','m5'], ['r9','r5'], 'fam1', 1 ).
test( 't68', 111, [], [], 'fam1', 1 ).
test( 't69', 25, [], [], 'fam1', 1 ).
test( 't70', 582, [], [], 'fam1', 1 ).
test( 't71', 273, [], [], 'fam1', 1 ).
test( 't72', 495, [], ['r4','r7','r8','r5','r3','r6'], 'fam1', 1 ).
test( 't73', 371, [], [], 'fam1', 1 ).
test( 't74', 482, [], ['r5','r1','r2','r8','r3','r7','r6','r4','r9'], 'fam1', 1 ).
test( 't75', 92, [], ['r7','r10','r1','r4','r9','r8'], 'fam1', 1 ).
test( 't76', 449, [], [], 'fam1', 1 ).
test( 't77', 44, ['m17','m18','m20'], ['r4','r1','r3','r9','r6','r5','r8','r10','r7','r2'], 'fam1', 1 ).
test( 't78', 457, [], ['r1'], 'fam1', 1 ).
test( 't79', 398, ['m14','m10','m5','m16','m4'], [], 'fam1', 1 ).
test( 't80', 47, [], [], 'fam1', 1 ).
test( 't81', 261, [], ['r7','r3','r4','r10'], 'fam1', 1 ).
test( 't82', 564, [], [], 'fam1', 1 ).
test( 't83', 670, [], [], 'fam1', 1 ).
test( 't84', 547, [], [], 'fam1', 1 ).
test( 't85', 469, [], [], 'fam1', 1 ).
test( 't86', 742, [], [], 'fam1', 1 ).
test( 't87', 21, ['m14'], [], 'fam1', 1 ).
test( 't88', 590, [], [], 'fam1', 1 ).
test( 't89', 598, [], [], 'fam1', 1 ).
test( 't90', 696, [], ['r10'], 'fam1', 1 ).
test( 't91', 205, [], [], 'fam1', 1 ).
test( 't92', 735, [], [], 'fam1', 1 ).
test( 't93', 766, [], [], 'fam1', 1 ).
test( 't94', 360, ['m11','m3','m8','m16','m18','m2'], [], 'fam1', 1 ).
test( 't95', 638, [], [], 'fam1', 1 ).
test( 't96', 371, [], [], 'fam1', 1 ).
test( 't97', 233, [], [], 'fam1', 1 ).
test( 't98', 490, ['m20','m10'], [], 'fam1', 1 ).
test( 't99', 345, [], [], 'fam1', 1 ).
test( 't100', 532, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
