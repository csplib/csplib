%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 20
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 404, ['m17','m13','m15','m14','m20','m10','m3'], ['r2','r3','r1'], 'fam1', 1 ).
test( 't2', 279, [], [], 'fam1', 1 ).
test( 't3', 173, ['m19','m11','m16','m9','m10','m1','m15','m14'], [], 'fam1', 1 ).
test( 't4', 670, [], ['r2','r3'], 'fam1', 1 ).
test( 't5', 186, [], [], 'fam1', 1 ).
test( 't6', 123, [], ['r1','r3'], 'fam1', 1 ).
test( 't7', 32, [], [], 'fam1', 1 ).
test( 't8', 312, ['m8','m18','m13','m1','m14'], ['r3','r1','r2'], 'fam1', 1 ).
test( 't9', 562, [], [], 'fam1', 1 ).
test( 't10', 330, [], [], 'fam1', 1 ).
test( 't11', 625, [], [], 'fam1', 1 ).
test( 't12', 557, [], [], 'fam1', 1 ).
test( 't13', 780, [], ['r3'], 'fam1', 1 ).
test( 't14', 728, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't15', 473, [], ['r1','r3'], 'fam1', 1 ).
test( 't16', 414, [], ['r2'], 'fam1', 1 ).
test( 't17', 26, [], [], 'fam1', 1 ).
test( 't18', 3, ['m4','m6','m9','m7','m20','m17'], [], 'fam1', 1 ).
test( 't19', 788, [], [], 'fam1', 1 ).
test( 't20', 54, [], [], 'fam1', 1 ).
test( 't21', 428, ['m9','m11','m13','m18','m15','m7','m8','m19'], [], 'fam1', 1 ).
test( 't22', 419, ['m6','m19','m13','m4','m5','m11','m14','m7'], [], 'fam1', 1 ).
test( 't23', 60, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't24', 691, [], [], 'fam1', 1 ).
test( 't25', 749, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't26', 609, [], [], 'fam1', 1 ).
test( 't27', 218, ['m18','m5','m14','m16','m20'], [], 'fam1', 1 ).
test( 't28', 698, [], ['r2','r3'], 'fam1', 1 ).
test( 't29', 179, [], ['r1'], 'fam1', 1 ).
test( 't30', 72, ['m2','m18','m12'], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
