%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 585, ['m5'], ['r5','r1','r3','r2','r4'], 'fam1', 1 ).
test( 't2', 305, [], [], 'fam1', 1 ).
test( 't3', 628, [], [], 'fam1', 1 ).
test( 't4', 444, [], ['r5','r1'], 'fam1', 1 ).
test( 't5', 677, ['m6','m5','m1','m8'], [], 'fam1', 1 ).
test( 't6', 620, [], [], 'fam1', 1 ).
test( 't7', 167, [], ['r2','r4'], 'fam1', 1 ).
test( 't8', 686, [], [], 'fam1', 1 ).
test( 't9', 177, [], ['r3'], 'fam1', 1 ).
test( 't10', 231, [], [], 'fam1', 1 ).
test( 't11', 152, [], [], 'fam1', 1 ).
test( 't12', 48, [], ['r2','r1','r4','r5'], 'fam1', 1 ).
test( 't13', 227, [], [], 'fam1', 1 ).
test( 't14', 412, [], [], 'fam1', 1 ).
test( 't15', 530, [], [], 'fam1', 1 ).
test( 't16', 493, [], ['r5','r3','r1','r4'], 'fam1', 1 ).
test( 't17', 313, [], ['r1'], 'fam1', 1 ).
test( 't18', 533, [], ['r4','r5','r3','r2','r1'], 'fam1', 1 ).
test( 't19', 38, ['m8'], [], 'fam1', 1 ).
test( 't20', 87, [], [], 'fam1', 1 ).
test( 't21', 775, ['m4','m6','m3'], [], 'fam1', 1 ).
test( 't22', 232, ['m1','m6'], [], 'fam1', 1 ).
test( 't23', 482, [], [], 'fam1', 1 ).
test( 't24', 673, [], ['r1','r5','r2','r3'], 'fam1', 1 ).
test( 't25', 239, [], ['r5'], 'fam1', 1 ).
test( 't26', 691, [], [], 'fam1', 1 ).
test( 't27', 345, [], [], 'fam1', 1 ).
test( 't28', 671, [], [], 'fam1', 1 ).
test( 't29', 314, [], [], 'fam1', 1 ).
test( 't30', 37, ['m3','m6','m9','m5'], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
