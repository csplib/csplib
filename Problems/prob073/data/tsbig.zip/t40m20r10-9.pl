%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 20
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 575, [], [], 'fam1', 1 ).
test( 't2', 419, ['m6','m16','m17','m2','m13'], [], 'fam1', 1 ).
test( 't3', 694, [], [], 'fam1', 1 ).
test( 't4', 385, [], [], 'fam1', 1 ).
test( 't5', 76, [], ['r6','r9','r1','r4','r2','r10','r7','r8','r5'], 'fam1', 1 ).
test( 't6', 227, [], ['r2','r5','r6','r7','r10'], 'fam1', 1 ).
test( 't7', 725, [], [], 'fam1', 1 ).
test( 't8', 291, [], [], 'fam1', 1 ).
test( 't9', 768, [], ['r8','r5','r7','r6'], 'fam1', 1 ).
test( 't10', 360, [], [], 'fam1', 1 ).
test( 't11', 192, [], ['r1','r10','r2','r9','r4','r7','r3','r8','r6','r5'], 'fam1', 1 ).
test( 't12', 746, [], [], 'fam1', 1 ).
test( 't13', 794, ['m3','m9','m18'], [], 'fam1', 1 ).
test( 't14', 662, [], [], 'fam1', 1 ).
test( 't15', 116, [], ['r10'], 'fam1', 1 ).
test( 't16', 591, [], [], 'fam1', 1 ).
test( 't17', 34, ['m7','m18','m16','m9','m20'], ['r7','r9','r2','r4','r1'], 'fam1', 1 ).
test( 't18', 519, ['m12'], [], 'fam1', 1 ).
test( 't19', 106, [], [], 'fam1', 1 ).
test( 't20', 717, [], [], 'fam1', 1 ).
test( 't21', 743, [], ['r5','r2'], 'fam1', 1 ).
test( 't22', 603, [], [], 'fam1', 1 ).
test( 't23', 538, [], [], 'fam1', 1 ).
test( 't24', 128, [], [], 'fam1', 1 ).
test( 't25', 150, [], [], 'fam1', 1 ).
test( 't26', 450, [], [], 'fam1', 1 ).
test( 't27', 640, [], [], 'fam1', 1 ).
test( 't28', 736, [], ['r8','r9','r1'], 'fam1', 1 ).
test( 't29', 561, [], [], 'fam1', 1 ).
test( 't30', 182, [], [], 'fam1', 1 ).
test( 't31', 485, [], [], 'fam1', 1 ).
test( 't32', 551, [], [], 'fam1', 1 ).
test( 't33', 774, ['m19','m3'], [], 'fam1', 1 ).
test( 't34', 176, [], ['r2'], 'fam1', 1 ).
test( 't35', 697, [], [], 'fam1', 1 ).
test( 't36', 4, [], [], 'fam1', 1 ).
test( 't37', 3, [], ['r6','r3','r5','r4','r2','r10','r8','r7'], 'fam1', 1 ).
test( 't38', 630, [], [], 'fam1', 1 ).
test( 't39', 609, ['m15','m9','m11','m2','m17','m6','m7','m14'], [], 'fam1', 1 ).
test( 't40', 559, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
