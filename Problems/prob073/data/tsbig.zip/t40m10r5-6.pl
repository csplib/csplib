%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 266, [], [], 'fam1', 1 ).
test( 't2', 64, ['m1'], [], 'fam1', 1 ).
test( 't3', 270, [], [], 'fam1', 1 ).
test( 't4', 141, ['m2','m10','m6'], ['r2','r3','r5','r1'], 'fam1', 1 ).
test( 't5', 713, [], [], 'fam1', 1 ).
test( 't6', 451, [], [], 'fam1', 1 ).
test( 't7', 286, [], [], 'fam1', 1 ).
test( 't8', 301, [], [], 'fam1', 1 ).
test( 't9', 178, ['m10','m7','m1'], [], 'fam1', 1 ).
test( 't10', 449, [], [], 'fam1', 1 ).
test( 't11', 466, ['m8','m9'], [], 'fam1', 1 ).
test( 't12', 765, ['m6','m4','m7'], ['r2','r5','r1','r3','r4'], 'fam1', 1 ).
test( 't13', 396, ['m6'], [], 'fam1', 1 ).
test( 't14', 174, [], [], 'fam1', 1 ).
test( 't15', 761, [], [], 'fam1', 1 ).
test( 't16', 800, [], ['r5','r4'], 'fam1', 1 ).
test( 't17', 213, [], [], 'fam1', 1 ).
test( 't18', 406, [], [], 'fam1', 1 ).
test( 't19', 401, [], ['r3'], 'fam1', 1 ).
test( 't20', 263, [], [], 'fam1', 1 ).
test( 't21', 436, [], [], 'fam1', 1 ).
test( 't22', 165, ['m4','m9','m8'], [], 'fam1', 1 ).
test( 't23', 497, [], ['r1'], 'fam1', 1 ).
test( 't24', 377, [], [], 'fam1', 1 ).
test( 't25', 70, ['m2','m7','m5'], [], 'fam1', 1 ).
test( 't26', 108, [], [], 'fam1', 1 ).
test( 't27', 381, [], ['r2'], 'fam1', 1 ).
test( 't28', 249, [], [], 'fam1', 1 ).
test( 't29', 5, [], [], 'fam1', 1 ).
test( 't30', 592, [], ['r1','r3','r5','r4','r2'], 'fam1', 1 ).
test( 't31', 6, [], [], 'fam1', 1 ).
test( 't32', 230, ['m3'], ['r5','r4'], 'fam1', 1 ).
test( 't33', 681, [], ['r2','r3','r5','r4'], 'fam1', 1 ).
test( 't34', 697, ['m9','m5','m8'], [], 'fam1', 1 ).
test( 't35', 720, [], [], 'fam1', 1 ).
test( 't36', 710, [], ['r4','r3','r2','r5'], 'fam1', 1 ).
test( 't37', 294, [], ['r5'], 'fam1', 1 ).
test( 't38', 362, ['m5','m9','m7'], [], 'fam1', 1 ).
test( 't39', 122, [], [], 'fam1', 1 ).
test( 't40', 77, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
