%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 50
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 483, [], [], 'fam1', 1 ).
test( 't2', 229, [], ['r5','r2'], 'fam1', 1 ).
test( 't3', 386, ['m26','m23','m42','m6','m50','m45'], [], 'fam1', 1 ).
test( 't4', 29, [], [], 'fam1', 1 ).
test( 't5', 38, [], [], 'fam1', 1 ).
test( 't6', 742, ['m4','m43','m19','m1'], ['r2','r4','r5','r1','r3'], 'fam1', 1 ).
test( 't7', 66, [], ['r5','r2','r3'], 'fam1', 1 ).
test( 't8', 600, [], [], 'fam1', 1 ).
test( 't9', 767, ['m20','m7','m30','m44','m18','m14','m36','m26'], [], 'fam1', 1 ).
test( 't10', 505, [], [], 'fam1', 1 ).
test( 't11', 197, ['m36','m38','m8','m30','m28','m29','m9','m2','m26','m18','m17','m43','m16','m3','m24','m12','m25','m14'], [], 'fam1', 1 ).
test( 't12', 721, ['m44','m17','m50'], [], 'fam1', 1 ).
test( 't13', 91, [], [], 'fam1', 1 ).
test( 't14', 299, [], [], 'fam1', 1 ).
test( 't15', 728, [], [], 'fam1', 1 ).
test( 't16', 355, [], ['r2','r1','r4','r3','r5'], 'fam1', 1 ).
test( 't17', 262, ['m39','m45','m31'], [], 'fam1', 1 ).
test( 't18', 382, [], [], 'fam1', 1 ).
test( 't19', 9, [], [], 'fam1', 1 ).
test( 't20', 219, [], [], 'fam1', 1 ).
test( 't21', 782, ['m42','m4','m7','m41','m28','m38','m37','m9','m44','m13','m6','m17','m30','m19','m24','m33','m5','m45'], ['r4','r2','r1','r3'], 'fam1', 1 ).
test( 't22', 314, ['m3','m30','m32','m24','m49','m17','m4','m21','m44','m14'], [], 'fam1', 1 ).
test( 't23', 118, [], [], 'fam1', 1 ).
test( 't24', 291, [], [], 'fam1', 1 ).
test( 't25', 796, ['m40','m8','m7','m18','m4','m42'], [], 'fam1', 1 ).
test( 't26', 427, ['m16','m47','m7','m3','m17','m39','m12','m46','m20','m15','m42','m33','m40'], ['r1','r3','r4'], 'fam1', 1 ).
test( 't27', 329, [], [], 'fam1', 1 ).
test( 't28', 649, [], [], 'fam1', 1 ).
test( 't29', 677, [], [], 'fam1', 1 ).
test( 't30', 460, [], ['r2','r5','r1'], 'fam1', 1 ).
test( 't31', 616, [], [], 'fam1', 1 ).
test( 't32', 49, [], [], 'fam1', 1 ).
test( 't33', 521, [], [], 'fam1', 1 ).
test( 't34', 777, [], [], 'fam1', 1 ).
test( 't35', 536, ['m28','m21','m46','m8','m41','m36','m34','m40','m3','m49','m43','m26','m1','m19','m42','m27'], [], 'fam1', 1 ).
test( 't36', 652, ['m42','m43','m46','m1','m31','m36','m44','m33','m5'], [], 'fam1', 1 ).
test( 't37', 255, [], [], 'fam1', 1 ).
test( 't38', 486, ['m24','m22','m7','m32','m25','m30','m46','m9','m10','m38','m5'], ['r4','r5','r1','r3'], 'fam1', 1 ).
test( 't39', 295, [], [], 'fam1', 1 ).
test( 't40', 143, [], [], 'fam1', 1 ).
test( 't41', 529, [], [], 'fam1', 1 ).
test( 't42', 482, [], [], 'fam1', 1 ).
test( 't43', 692, [], ['r3'], 'fam1', 1 ).
test( 't44', 18, ['m4','m10','m31','m16','m40','m45','m7','m33','m44','m34','m17'], [], 'fam1', 1 ).
test( 't45', 98, [], [], 'fam1', 1 ).
test( 't46', 205, [], [], 'fam1', 1 ).
test( 't47', 586, [], ['r5','r2','r1','r3','r4'], 'fam1', 1 ).
test( 't48', 698, [], [], 'fam1', 1 ).
test( 't49', 737, [], [], 'fam1', 1 ).
test( 't50', 139, [], [], 'fam1', 1 ).
test( 't51', 648, [], [], 'fam1', 1 ).
test( 't52', 178, [], [], 'fam1', 1 ).
test( 't53', 548, [], ['r2','r1'], 'fam1', 1 ).
test( 't54', 579, [], [], 'fam1', 1 ).
test( 't55', 613, [], [], 'fam1', 1 ).
test( 't56', 329, ['m37','m39','m30','m41','m34','m47','m50'], [], 'fam1', 1 ).
test( 't57', 786, [], ['r2','r5','r4','r3','r1'], 'fam1', 1 ).
test( 't58', 715, ['m43','m31','m17','m5','m11','m10','m45','m3','m35','m6','m25','m42','m28','m14','m22','m16','m24','m29','m33'], [], 'fam1', 1 ).
test( 't59', 592, ['m7'], ['r5','r1','r2','r3'], 'fam1', 1 ).
test( 't60', 305, [], ['r4'], 'fam1', 1 ).
test( 't61', 443, [], [], 'fam1', 1 ).
test( 't62', 125, [], [], 'fam1', 1 ).
test( 't63', 183, [], [], 'fam1', 1 ).
test( 't64', 235, [], ['r2','r1','r4','r3','r5'], 'fam1', 1 ).
test( 't65', 170, [], [], 'fam1', 1 ).
test( 't66', 220, [], ['r2','r4','r3'], 'fam1', 1 ).
test( 't67', 206, [], ['r2','r3','r4'], 'fam1', 1 ).
test( 't68', 680, [], [], 'fam1', 1 ).
test( 't69', 406, ['m13','m38','m41','m12','m19','m49','m1','m4','m21','m43','m40','m34','m17','m27','m7','m48','m44','m29','m39','m22'], ['r2','r4','r1','r3','r5'], 'fam1', 1 ).
test( 't70', 672, [], ['r1','r3','r2','r5'], 'fam1', 1 ).
test( 't71', 410, [], [], 'fam1', 1 ).
test( 't72', 311, [], ['r1','r3','r4'], 'fam1', 1 ).
test( 't73', 11, [], [], 'fam1', 1 ).
test( 't74', 88, ['m35','m40','m14','m39','m22','m29','m23','m32','m50','m45','m41','m28','m36','m38','m8','m21','m17'], [], 'fam1', 1 ).
test( 't75', 482, [], ['r3','r4'], 'fam1', 1 ).
test( 't76', 473, [], ['r4'], 'fam1', 1 ).
test( 't77', 685, [], [], 'fam1', 1 ).
test( 't78', 791, [], [], 'fam1', 1 ).
test( 't79', 259, [], [], 'fam1', 1 ).
test( 't80', 767, [], [], 'fam1', 1 ).
test( 't81', 48, [], ['r1','r4','r2'], 'fam1', 1 ).
test( 't82', 294, ['m49'], ['r1','r4','r2'], 'fam1', 1 ).
test( 't83', 136, [], [], 'fam1', 1 ).
test( 't84', 131, ['m29','m3','m27','m30'], [], 'fam1', 1 ).
test( 't85', 341, ['m9'], [], 'fam1', 1 ).
test( 't86', 42, [], [], 'fam1', 1 ).
test( 't87', 312, ['m33','m41','m43','m8','m6','m31'], ['r2','r3','r5','r1','r4'], 'fam1', 1 ).
test( 't88', 719, [], [], 'fam1', 1 ).
test( 't89', 458, [], ['r5','r1'], 'fam1', 1 ).
test( 't90', 6, ['m18','m26','m22','m36','m14','m13','m3','m30','m31','m46','m16','m15','m1','m33','m27'], [], 'fam1', 1 ).
test( 't91', 737, [], ['r1','r3','r4','r2','r5'], 'fam1', 1 ).
test( 't92', 397, [], [], 'fam1', 1 ).
test( 't93', 616, [], ['r1','r4'], 'fam1', 1 ).
test( 't94', 288, [], ['r2','r4','r3','r5'], 'fam1', 1 ).
test( 't95', 624, [], [], 'fam1', 1 ).
test( 't96', 123, [], [], 'fam1', 1 ).
test( 't97', 343, ['m33','m46','m7','m14','m16','m38','m29','m15','m25','m30','m2','m20','m40','m3','m18','m24','m6','m19'], [], 'fam1', 1 ).
test( 't98', 580, [], [], 'fam1', 1 ).
test( 't99', 553, [], [], 'fam1', 1 ).
test( 't100', 392, ['m1','m32','m50','m15'], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').
embedded_board( 'm21').
embedded_board( 'm22').
embedded_board( 'm23').
embedded_board( 'm24').
embedded_board( 'm25').
embedded_board( 'm26').
embedded_board( 'm27').
embedded_board( 'm28').
embedded_board( 'm29').
embedded_board( 'm30').
embedded_board( 'm31').
embedded_board( 'm32').
embedded_board( 'm33').
embedded_board( 'm34').
embedded_board( 'm35').
embedded_board( 'm36').
embedded_board( 'm37').
embedded_board( 'm38').
embedded_board( 'm39').
embedded_board( 'm40').
embedded_board( 'm41').
embedded_board( 'm42').
embedded_board( 'm43').
embedded_board( 'm44').
embedded_board( 'm45').
embedded_board( 'm46').
embedded_board( 'm47').
embedded_board( 'm48').
embedded_board( 'm49').
embedded_board( 'm50').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
