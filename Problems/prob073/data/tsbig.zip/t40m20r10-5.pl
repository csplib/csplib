%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 20
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 658, [], ['r4','r8','r3','r7','r6','r5','r9','r2','r10'], 'fam1', 1 ).
test( 't2', 569, [], ['r9','r2','r5'], 'fam1', 1 ).
test( 't3', 209, [], ['r9','r3','r8','r5','r6','r10','r4'], 'fam1', 1 ).
test( 't4', 92, ['m13','m4','m12','m20','m3','m14','m2','m15'], [], 'fam1', 1 ).
test( 't5', 31, [], [], 'fam1', 1 ).
test( 't6', 380, [], ['r7','r1','r4','r10','r2','r8'], 'fam1', 1 ).
test( 't7', 565, [], [], 'fam1', 1 ).
test( 't8', 242, [], [], 'fam1', 1 ).
test( 't9', 6, [], [], 'fam1', 1 ).
test( 't10', 175, [], ['r2','r10','r6','r5','r4','r3','r7'], 'fam1', 1 ).
test( 't11', 506, [], [], 'fam1', 1 ).
test( 't12', 190, [], ['r9','r8','r2','r10','r3','r4','r5','r6','r7','r1'], 'fam1', 1 ).
test( 't13', 247, [], [], 'fam1', 1 ).
test( 't14', 654, ['m18','m14','m15'], [], 'fam1', 1 ).
test( 't15', 5, [], [], 'fam1', 1 ).
test( 't16', 78, [], ['r4','r10','r9','r3','r2','r8','r7','r1','r5','r6'], 'fam1', 1 ).
test( 't17', 756, [], ['r4','r3','r7','r6','r9','r2','r10'], 'fam1', 1 ).
test( 't18', 19, [], [], 'fam1', 1 ).
test( 't19', 697, [], [], 'fam1', 1 ).
test( 't20', 207, ['m12','m5'], [], 'fam1', 1 ).
test( 't21', 642, [], [], 'fam1', 1 ).
test( 't22', 277, [], [], 'fam1', 1 ).
test( 't23', 348, [], ['r10','r3','r5'], 'fam1', 1 ).
test( 't24', 196, ['m20','m13','m3','m10','m2','m17','m14'], [], 'fam1', 1 ).
test( 't25', 429, [], [], 'fam1', 1 ).
test( 't26', 423, [], ['r6','r4','r5','r8','r7','r9','r3','r1'], 'fam1', 1 ).
test( 't27', 698, [], ['r9'], 'fam1', 1 ).
test( 't28', 596, ['m13','m7'], [], 'fam1', 1 ).
test( 't29', 443, [], [], 'fam1', 1 ).
test( 't30', 526, ['m3','m1','m9','m2','m6','m20'], [], 'fam1', 1 ).
test( 't31', 714, [], [], 'fam1', 1 ).
test( 't32', 600, ['m20'], ['r10','r3','r5','r2','r9','r8','r1','r6','r7','r4'], 'fam1', 1 ).
test( 't33', 435, [], [], 'fam1', 1 ).
test( 't34', 132, [], [], 'fam1', 1 ).
test( 't35', 727, ['m8','m16','m7','m5','m15','m4'], ['r7','r5','r6'], 'fam1', 1 ).
test( 't36', 646, [], [], 'fam1', 1 ).
test( 't37', 25, ['m15','m14','m17','m19'], [], 'fam1', 1 ).
test( 't38', 679, [], [], 'fam1', 1 ).
test( 't39', 462, [], ['r6'], 'fam1', 1 ).
test( 't40', 7, ['m9','m5','m10','m3','m16','m8','m18','m11'], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
