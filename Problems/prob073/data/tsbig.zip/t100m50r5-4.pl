%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 50
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 789, [], ['r4','r1','r2'], 'fam1', 1 ).
test( 't2', 387, [], ['r5','r2'], 'fam1', 1 ).
test( 't3', 444, [], ['r5','r4','r2'], 'fam1', 1 ).
test( 't4', 744, [], [], 'fam1', 1 ).
test( 't5', 65, [], ['r3'], 'fam1', 1 ).
test( 't6', 6, [], [], 'fam1', 1 ).
test( 't7', 154, [], [], 'fam1', 1 ).
test( 't8', 500, [], [], 'fam1', 1 ).
test( 't9', 6, [], [], 'fam1', 1 ).
test( 't10', 238, [], ['r4','r2'], 'fam1', 1 ).
test( 't11', 140, [], [], 'fam1', 1 ).
test( 't12', 141, ['m37','m48','m50','m25','m35','m27','m9','m28','m36','m10','m23','m21','m32'], [], 'fam1', 1 ).
test( 't13', 411, ['m44','m7','m1'], [], 'fam1', 1 ).
test( 't14', 186, [], [], 'fam1', 1 ).
test( 't15', 75, [], ['r5'], 'fam1', 1 ).
test( 't16', 522, [], [], 'fam1', 1 ).
test( 't17', 609, [], [], 'fam1', 1 ).
test( 't18', 600, [], [], 'fam1', 1 ).
test( 't19', 681, [], ['r4','r2','r3','r5'], 'fam1', 1 ).
test( 't20', 270, [], [], 'fam1', 1 ).
test( 't21', 514, [], [], 'fam1', 1 ).
test( 't22', 274, ['m16','m14','m47','m13','m15','m29','m41','m46','m6','m30','m39','m1'], [], 'fam1', 1 ).
test( 't23', 563, [], [], 'fam1', 1 ).
test( 't24', 124, [], [], 'fam1', 1 ).
test( 't25', 191, ['m46','m50','m49','m23','m31','m19','m12','m17','m14','m44','m43','m20','m1','m7','m41'], [], 'fam1', 1 ).
test( 't26', 647, [], [], 'fam1', 1 ).
test( 't27', 658, [], [], 'fam1', 1 ).
test( 't28', 314, ['m17','m13','m10','m47'], [], 'fam1', 1 ).
test( 't29', 74, [], ['r2','r1','r4','r3','r5'], 'fam1', 1 ).
test( 't30', 555, [], [], 'fam1', 1 ).
test( 't31', 11, [], [], 'fam1', 1 ).
test( 't32', 169, [], [], 'fam1', 1 ).
test( 't33', 16, [], [], 'fam1', 1 ).
test( 't34', 488, [], [], 'fam1', 1 ).
test( 't35', 445, [], [], 'fam1', 1 ).
test( 't36', 249, [], [], 'fam1', 1 ).
test( 't37', 549, [], [], 'fam1', 1 ).
test( 't38', 670, [], [], 'fam1', 1 ).
test( 't39', 414, [], [], 'fam1', 1 ).
test( 't40', 155, [], [], 'fam1', 1 ).
test( 't41', 668, ['m3','m32','m47'], [], 'fam1', 1 ).
test( 't42', 776, [], [], 'fam1', 1 ).
test( 't43', 786, [], ['r3'], 'fam1', 1 ).
test( 't44', 310, [], ['r5','r3'], 'fam1', 1 ).
test( 't45', 410, [], ['r5'], 'fam1', 1 ).
test( 't46', 245, ['m9','m20','m11','m40','m35','m27','m7','m43','m23','m47','m5','m46','m38','m41','m37','m36','m19','m45'], ['r1','r3','r5','r4'], 'fam1', 1 ).
test( 't47', 146, [], [], 'fam1', 1 ).
test( 't48', 254, ['m11','m16','m46','m8','m23','m20','m9','m6','m50','m25','m41','m24','m1','m15','m17','m13'], ['r4','r1','r2','r5','r3'], 'fam1', 1 ).
test( 't49', 528, [], [], 'fam1', 1 ).
test( 't50', 309, ['m11','m9','m42','m10','m28','m21','m39','m17','m44','m45','m35'], [], 'fam1', 1 ).
test( 't51', 304, ['m43','m25','m4','m17','m41'], [], 'fam1', 1 ).
test( 't52', 441, [], [], 'fam1', 1 ).
test( 't53', 801, [], ['r2','r5','r3','r4','r1'], 'fam1', 1 ).
test( 't54', 667, [], [], 'fam1', 1 ).
test( 't55', 228, [], ['r4','r3','r5','r2','r1'], 'fam1', 1 ).
test( 't56', 499, [], [], 'fam1', 1 ).
test( 't57', 252, [], [], 'fam1', 1 ).
test( 't58', 795, [], [], 'fam1', 1 ).
test( 't59', 687, ['m47','m6','m21','m43','m36','m37','m22','m5','m14','m19','m31','m32','m26'], [], 'fam1', 1 ).
test( 't60', 251, [], ['r3','r1','r5','r2','r4'], 'fam1', 1 ).
test( 't61', 49, ['m26','m42','m44','m37','m50','m49','m39','m18','m15','m7','m19','m32','m6','m3','m8','m34','m48','m36','m43'], ['r5'], 'fam1', 1 ).
test( 't62', 566, [], ['r1','r5'], 'fam1', 1 ).
test( 't63', 131, ['m8','m11','m49','m23','m40','m4','m45','m29'], [], 'fam1', 1 ).
test( 't64', 133, [], ['r3','r1','r2','r5'], 'fam1', 1 ).
test( 't65', 115, [], [], 'fam1', 1 ).
test( 't66', 770, ['m12','m33','m19','m16','m8','m46','m44','m38','m22','m41','m30','m49','m50','m17','m42'], ['r4','r5'], 'fam1', 1 ).
test( 't67', 250, ['m34','m7','m36','m1','m19','m25','m30','m17','m12','m14','m46','m40','m29','m22','m18','m28','m35','m9','m32','m27'], [], 'fam1', 1 ).
test( 't68', 77, [], [], 'fam1', 1 ).
test( 't69', 454, [], [], 'fam1', 1 ).
test( 't70', 740, [], [], 'fam1', 1 ).
test( 't71', 284, ['m2'], [], 'fam1', 1 ).
test( 't72', 596, [], [], 'fam1', 1 ).
test( 't73', 727, [], [], 'fam1', 1 ).
test( 't74', 722, [], ['r4','r2','r3','r1','r5'], 'fam1', 1 ).
test( 't75', 128, [], ['r4','r3','r5','r2'], 'fam1', 1 ).
test( 't76', 263, [], [], 'fam1', 1 ).
test( 't77', 751, [], ['r2'], 'fam1', 1 ).
test( 't78', 229, [], [], 'fam1', 1 ).
test( 't79', 797, [], [], 'fam1', 1 ).
test( 't80', 447, [], ['r5','r1','r3'], 'fam1', 1 ).
test( 't81', 784, [], [], 'fam1', 1 ).
test( 't82', 391, [], [], 'fam1', 1 ).
test( 't83', 261, ['m16','m25','m33','m35','m6','m8','m17','m32','m41','m31','m39','m4','m28','m45','m2','m15','m11','m12'], [], 'fam1', 1 ).
test( 't84', 24, [], [], 'fam1', 1 ).
test( 't85', 655, [], [], 'fam1', 1 ).
test( 't86', 452, [], [], 'fam1', 1 ).
test( 't87', 102, [], ['r5'], 'fam1', 1 ).
test( 't88', 315, [], [], 'fam1', 1 ).
test( 't89', 91, [], ['r3','r2','r4'], 'fam1', 1 ).
test( 't90', 352, ['m24','m45'], ['r2','r5','r3'], 'fam1', 1 ).
test( 't91', 759, [], [], 'fam1', 1 ).
test( 't92', 799, ['m28','m41','m23','m38','m44','m5','m35','m24','m29','m7','m10','m34','m6','m46','m1','m47','m37','m50'], [], 'fam1', 1 ).
test( 't93', 326, [], [], 'fam1', 1 ).
test( 't94', 200, ['m33','m35','m38','m48','m37','m50','m49','m12','m5','m16','m7','m18','m19','m44','m28'], ['r2','r3','r5'], 'fam1', 1 ).
test( 't95', 315, [], [], 'fam1', 1 ).
test( 't96', 771, [], [], 'fam1', 1 ).
test( 't97', 789, [], [], 'fam1', 1 ).
test( 't98', 667, [], ['r3','r2','r4','r5','r1'], 'fam1', 1 ).
test( 't99', 733, ['m19','m15','m11','m24','m21','m31','m12','m46','m2'], [], 'fam1', 1 ).
test( 't100', 415, ['m28','m45','m20','m10','m19','m27','m50','m15','m29','m39','m34','m25','m9'], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').
embedded_board( 'm21').
embedded_board( 'm22').
embedded_board( 'm23').
embedded_board( 'm24').
embedded_board( 'm25').
embedded_board( 'm26').
embedded_board( 'm27').
embedded_board( 'm28').
embedded_board( 'm29').
embedded_board( 'm30').
embedded_board( 'm31').
embedded_board( 'm32').
embedded_board( 'm33').
embedded_board( 'm34').
embedded_board( 'm35').
embedded_board( 'm36').
embedded_board( 'm37').
embedded_board( 'm38').
embedded_board( 'm39').
embedded_board( 'm40').
embedded_board( 'm41').
embedded_board( 'm42').
embedded_board( 'm43').
embedded_board( 'm44').
embedded_board( 'm45').
embedded_board( 'm46').
embedded_board( 'm47').
embedded_board( 'm48').
embedded_board( 'm49').
embedded_board( 'm50').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
