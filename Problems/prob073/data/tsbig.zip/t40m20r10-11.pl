%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 20
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 257, ['m9','m12','m11','m4','m5','m14'], [], 'fam1', 1 ).
test( 't2', 128, [], [], 'fam1', 1 ).
test( 't3', 550, ['m2','m13'], [], 'fam1', 1 ).
test( 't4', 295, [], [], 'fam1', 1 ).
test( 't5', 140, [], [], 'fam1', 1 ).
test( 't6', 527, [], [], 'fam1', 1 ).
test( 't7', 34, [], [], 'fam1', 1 ).
test( 't8', 137, ['m13','m7','m11','m19','m14','m15','m4'], [], 'fam1', 1 ).
test( 't9', 760, [], ['r4'], 'fam1', 1 ).
test( 't10', 649, ['m7','m6','m12','m20','m18','m13','m17','m9'], [], 'fam1', 1 ).
test( 't11', 396, [], [], 'fam1', 1 ).
test( 't12', 152, ['m8','m10','m11','m7','m18','m20'], ['r9','r5','r2','r10','r4','r3','r6','r1','r7','r8'], 'fam1', 1 ).
test( 't13', 476, [], [], 'fam1', 1 ).
test( 't14', 283, [], [], 'fam1', 1 ).
test( 't15', 108, [], [], 'fam1', 1 ).
test( 't16', 534, [], [], 'fam1', 1 ).
test( 't17', 504, [], ['r10','r8','r4','r1','r7','r5','r6','r2','r9'], 'fam1', 1 ).
test( 't18', 631, [], [], 'fam1', 1 ).
test( 't19', 122, ['m14','m17','m19'], [], 'fam1', 1 ).
test( 't20', 491, [], ['r7','r4','r2','r5'], 'fam1', 1 ).
test( 't21', 134, ['m12','m6','m16'], [], 'fam1', 1 ).
test( 't22', 304, [], ['r9','r7','r3'], 'fam1', 1 ).
test( 't23', 45, [], ['r3','r4'], 'fam1', 1 ).
test( 't24', 752, [], [], 'fam1', 1 ).
test( 't25', 326, [], [], 'fam1', 1 ).
test( 't26', 205, [], [], 'fam1', 1 ).
test( 't27', 409, [], [], 'fam1', 1 ).
test( 't28', 379, [], [], 'fam1', 1 ).
test( 't29', 789, [], [], 'fam1', 1 ).
test( 't30', 199, [], [], 'fam1', 1 ).
test( 't31', 335, [], [], 'fam1', 1 ).
test( 't32', 225, [], [], 'fam1', 1 ).
test( 't33', 169, [], [], 'fam1', 1 ).
test( 't34', 138, [], [], 'fam1', 1 ).
test( 't35', 543, [], [], 'fam1', 1 ).
test( 't36', 452, [], [], 'fam1', 1 ).
test( 't37', 636, [], [], 'fam1', 1 ).
test( 't38', 467, [], [], 'fam1', 1 ).
test( 't39', 619, [], [], 'fam1', 1 ).
test( 't40', 257, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
