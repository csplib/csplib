%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 20
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 548, [], [], 'fam1', 1 ).
test( 't2', 105, [], [], 'fam1', 1 ).
test( 't3', 709, [], [], 'fam1', 1 ).
test( 't4', 125, ['m12','m9','m7','m4','m18','m11'], ['r2'], 'fam1', 1 ).
test( 't5', 126, [], [], 'fam1', 1 ).
test( 't6', 531, ['m10','m16'], [], 'fam1', 1 ).
test( 't7', 417, [], ['r1','r5'], 'fam1', 1 ).
test( 't8', 71, ['m2','m10'], [], 'fam1', 1 ).
test( 't9', 565, [], [], 'fam1', 1 ).
test( 't10', 264, [], ['r1'], 'fam1', 1 ).
test( 't11', 479, [], [], 'fam1', 1 ).
test( 't12', 95, ['m19','m14'], [], 'fam1', 1 ).
test( 't13', 498, [], [], 'fam1', 1 ).
test( 't14', 258, ['m6','m8','m1','m17'], [], 'fam1', 1 ).
test( 't15', 60, [], [], 'fam1', 1 ).
test( 't16', 512, [], [], 'fam1', 1 ).
test( 't17', 709, [], ['r1'], 'fam1', 1 ).
test( 't18', 140, [], ['r5','r1'], 'fam1', 1 ).
test( 't19', 479, [], [], 'fam1', 1 ).
test( 't20', 286, [], ['r3'], 'fam1', 1 ).
test( 't21', 594, [], ['r4','r3'], 'fam1', 1 ).
test( 't22', 173, ['m19','m3','m2','m16','m4'], [], 'fam1', 1 ).
test( 't23', 170, [], ['r4','r2','r1'], 'fam1', 1 ).
test( 't24', 721, [], [], 'fam1', 1 ).
test( 't25', 377, ['m4','m3','m14','m15','m10','m17'], ['r3'], 'fam1', 1 ).
test( 't26', 743, [], [], 'fam1', 1 ).
test( 't27', 482, [], ['r5','r2','r4'], 'fam1', 1 ).
test( 't28', 68, [], [], 'fam1', 1 ).
test( 't29', 589, [], [], 'fam1', 1 ).
test( 't30', 406, [], ['r1','r2','r4','r3'], 'fam1', 1 ).
test( 't31', 69, ['m11','m5','m9'], [], 'fam1', 1 ).
test( 't32', 390, [], [], 'fam1', 1 ).
test( 't33', 467, ['m19','m12','m10','m8','m14','m13','m16','m11'], [], 'fam1', 1 ).
test( 't34', 440, [], [], 'fam1', 1 ).
test( 't35', 609, [], [], 'fam1', 1 ).
test( 't36', 667, [], ['r3','r1'], 'fam1', 1 ).
test( 't37', 240, [], [], 'fam1', 1 ).
test( 't38', 496, [], [], 'fam1', 1 ).
test( 't39', 564, [], [], 'fam1', 1 ).
test( 't40', 724, [], [], 'fam1', 1 ).
test( 't41', 212, [], [], 'fam1', 1 ).
test( 't42', 576, [], [], 'fam1', 1 ).
test( 't43', 630, [], [], 'fam1', 1 ).
test( 't44', 425, [], ['r5','r4','r1','r2','r3'], 'fam1', 1 ).
test( 't45', 192, [], ['r2','r1','r5','r4'], 'fam1', 1 ).
test( 't46', 536, ['m10','m5','m16'], [], 'fam1', 1 ).
test( 't47', 9, ['m6','m11','m13','m12','m2'], [], 'fam1', 1 ).
test( 't48', 658, ['m14','m3','m1','m5'], [], 'fam1', 1 ).
test( 't49', 790, ['m1','m7','m8','m12','m4'], [], 'fam1', 1 ).
test( 't50', 373, [], [], 'fam1', 1 ).
test( 't51', 488, ['m17','m14','m5','m6','m15'], [], 'fam1', 1 ).
test( 't52', 305, ['m7'], [], 'fam1', 1 ).
test( 't53', 408, [], ['r2','r5','r1','r4'], 'fam1', 1 ).
test( 't54', 553, [], [], 'fam1', 1 ).
test( 't55', 150, [], [], 'fam1', 1 ).
test( 't56', 335, ['m5'], ['r3','r4','r5'], 'fam1', 1 ).
test( 't57', 642, [], [], 'fam1', 1 ).
test( 't58', 338, [], [], 'fam1', 1 ).
test( 't59', 545, [], [], 'fam1', 1 ).
test( 't60', 20, [], ['r2','r5'], 'fam1', 1 ).
test( 't61', 279, [], [], 'fam1', 1 ).
test( 't62', 672, [], [], 'fam1', 1 ).
test( 't63', 259, [], [], 'fam1', 1 ).
test( 't64', 493, [], ['r1','r2','r4','r5','r3'], 'fam1', 1 ).
test( 't65', 367, ['m3','m10','m17'], [], 'fam1', 1 ).
test( 't66', 403, [], ['r3','r2','r4','r1'], 'fam1', 1 ).
test( 't67', 705, [], [], 'fam1', 1 ).
test( 't68', 366, [], [], 'fam1', 1 ).
test( 't69', 495, ['m20','m2','m5','m19','m7','m17','m10','m9'], [], 'fam1', 1 ).
test( 't70', 721, [], ['r1','r3','r4','r2'], 'fam1', 1 ).
test( 't71', 434, [], [], 'fam1', 1 ).
test( 't72', 239, [], ['r4'], 'fam1', 1 ).
test( 't73', 560, [], [], 'fam1', 1 ).
test( 't74', 231, [], [], 'fam1', 1 ).
test( 't75', 646, [], [], 'fam1', 1 ).
test( 't76', 324, [], [], 'fam1', 1 ).
test( 't77', 646, [], [], 'fam1', 1 ).
test( 't78', 296, [], ['r2','r3','r5'], 'fam1', 1 ).
test( 't79', 9, ['m8','m5','m1','m16','m19','m11','m7'], [], 'fam1', 1 ).
test( 't80', 535, ['m5','m16','m20'], [], 'fam1', 1 ).
test( 't81', 720, ['m4','m11','m14','m8','m7'], [], 'fam1', 1 ).
test( 't82', 205, ['m8','m4','m16'], ['r1','r3'], 'fam1', 1 ).
test( 't83', 640, [], [], 'fam1', 1 ).
test( 't84', 594, [], ['r5','r2','r4','r3','r1'], 'fam1', 1 ).
test( 't85', 159, [], [], 'fam1', 1 ).
test( 't86', 127, [], [], 'fam1', 1 ).
test( 't87', 790, ['m15','m18','m1','m10','m11','m13','m6','m4'], [], 'fam1', 1 ).
test( 't88', 72, [], [], 'fam1', 1 ).
test( 't89', 209, [], [], 'fam1', 1 ).
test( 't90', 213, [], ['r3','r5','r2','r4','r1'], 'fam1', 1 ).
test( 't91', 527, [], [], 'fam1', 1 ).
test( 't92', 383, [], [], 'fam1', 1 ).
test( 't93', 150, ['m9','m11','m1','m5'], [], 'fam1', 1 ).
test( 't94', 534, [], [], 'fam1', 1 ).
test( 't95', 701, [], [], 'fam1', 1 ).
test( 't96', 401, [], [], 'fam1', 1 ).
test( 't97', 595, [], [], 'fam1', 1 ).
test( 't98', 139, [], [], 'fam1', 1 ).
test( 't99', 190, [], ['r4','r2','r1','r3'], 'fam1', 1 ).
test( 't100', 280, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
