%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 50
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 508, [], [], 'fam1', 1 ).
test( 't2', 305, ['m32','m26','m16','m4','m22','m37','m24','m43','m49','m47'], [], 'fam1', 1 ).
test( 't3', 332, [], [], 'fam1', 1 ).
test( 't4', 587, [], ['r2','r4','r3'], 'fam1', 1 ).
test( 't5', 116, [], [], 'fam1', 1 ).
test( 't6', 143, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't7', 736, [], [], 'fam1', 1 ).
test( 't8', 412, [], [], 'fam1', 1 ).
test( 't9', 551, [], [], 'fam1', 1 ).
test( 't10', 191, [], [], 'fam1', 1 ).
test( 't11', 732, [], [], 'fam1', 1 ).
test( 't12', 142, [], [], 'fam1', 1 ).
test( 't13', 189, [], ['r4','r3'], 'fam1', 1 ).
test( 't14', 403, [], [], 'fam1', 1 ).
test( 't15', 371, [], [], 'fam1', 1 ).
test( 't16', 616, [], [], 'fam1', 1 ).
test( 't17', 497, [], [], 'fam1', 1 ).
test( 't18', 256, [], ['r4','r2','r3'], 'fam1', 1 ).
test( 't19', 527, [], [], 'fam1', 1 ).
test( 't20', 253, [], [], 'fam1', 1 ).
test( 't21', 113, [], [], 'fam1', 1 ).
test( 't22', 90, [], ['r2','r3','r5','r1','r4'], 'fam1', 1 ).
test( 't23', 642, [], [], 'fam1', 1 ).
test( 't24', 183, ['m8','m31','m11','m37','m34','m13','m19','m16'], [], 'fam1', 1 ).
test( 't25', 153, [], [], 'fam1', 1 ).
test( 't26', 11, ['m17','m25'], [], 'fam1', 1 ).
test( 't27', 415, [], [], 'fam1', 1 ).
test( 't28', 147, ['m10','m6','m37','m25','m41','m22','m40','m7','m36','m29','m49'], [], 'fam1', 1 ).
test( 't29', 60, [], [], 'fam1', 1 ).
test( 't30', 64, [], ['r2','r4'], 'fam1', 1 ).
test( 't31', 55, [], [], 'fam1', 1 ).
test( 't32', 13, [], [], 'fam1', 1 ).
test( 't33', 376, [], [], 'fam1', 1 ).
test( 't34', 635, [], [], 'fam1', 1 ).
test( 't35', 786, [], [], 'fam1', 1 ).
test( 't36', 640, ['m34','m28','m48','m14','m38','m22','m3','m30','m39','m23','m49','m27'], [], 'fam1', 1 ).
test( 't37', 162, [], ['r5','r4','r3','r1','r2'], 'fam1', 1 ).
test( 't38', 546, ['m8','m29','m47','m5','m6','m20','m24','m30','m48','m10','m3','m22','m31','m2'], ['r4','r5','r2','r1'], 'fam1', 1 ).
test( 't39', 652, [], ['r1','r5','r2','r4','r3'], 'fam1', 1 ).
test( 't40', 275, ['m2','m38','m40','m28','m46','m26','m35','m8'], [], 'fam1', 1 ).
test( 't41', 62, [], [], 'fam1', 1 ).
test( 't42', 134, [], [], 'fam1', 1 ).
test( 't43', 486, [], [], 'fam1', 1 ).
test( 't44', 783, ['m22','m20','m44','m4','m26','m7','m49'], [], 'fam1', 1 ).
test( 't45', 233, [], [], 'fam1', 1 ).
test( 't46', 347, [], [], 'fam1', 1 ).
test( 't47', 223, [], [], 'fam1', 1 ).
test( 't48', 745, [], [], 'fam1', 1 ).
test( 't49', 344, [], [], 'fam1', 1 ).
test( 't50', 48, [], [], 'fam1', 1 ).
test( 't51', 358, [], [], 'fam1', 1 ).
test( 't52', 743, [], ['r2'], 'fam1', 1 ).
test( 't53', 14, [], [], 'fam1', 1 ).
test( 't54', 491, ['m30','m48','m29','m25','m45','m6','m38','m10','m14','m33'], [], 'fam1', 1 ).
test( 't55', 394, [], [], 'fam1', 1 ).
test( 't56', 687, [], [], 'fam1', 1 ).
test( 't57', 782, [], [], 'fam1', 1 ).
test( 't58', 51, [], [], 'fam1', 1 ).
test( 't59', 210, ['m49','m15','m14','m27','m2','m33','m50','m10','m12'], [], 'fam1', 1 ).
test( 't60', 48, [], [], 'fam1', 1 ).
test( 't61', 556, [], [], 'fam1', 1 ).
test( 't62', 16, ['m34','m32','m39','m11','m43','m21','m27','m28','m49','m12','m17','m46','m29','m37'], ['r5','r1','r3','r2'], 'fam1', 1 ).
test( 't63', 759, ['m27','m34','m40','m33','m11','m6','m4','m38','m31','m37','m28','m7','m49','m9','m19','m35','m43','m24','m21','m50'], [], 'fam1', 1 ).
test( 't64', 660, ['m27','m32','m36','m6','m18','m49','m19','m37','m50','m7','m15','m9','m5','m10','m31','m1','m30','m2'], [], 'fam1', 1 ).
test( 't65', 174, [], ['r1'], 'fam1', 1 ).
test( 't66', 800, [], [], 'fam1', 1 ).
test( 't67', 478, [], [], 'fam1', 1 ).
test( 't68', 277, ['m4','m38','m41','m25','m42','m20','m36','m22','m24','m5','m26','m35','m49'], [], 'fam1', 1 ).
test( 't69', 645, [], ['r3','r4','r5','r1','r2'], 'fam1', 1 ).
test( 't70', 77, [], [], 'fam1', 1 ).
test( 't71', 560, [], [], 'fam1', 1 ).
test( 't72', 750, [], ['r5','r2'], 'fam1', 1 ).
test( 't73', 443, [], ['r3'], 'fam1', 1 ).
test( 't74', 495, [], ['r4','r1','r2'], 'fam1', 1 ).
test( 't75', 217, [], [], 'fam1', 1 ).
test( 't76', 247, ['m19','m23','m17','m31','m9'], [], 'fam1', 1 ).
test( 't77', 254, [], ['r5','r2','r4'], 'fam1', 1 ).
test( 't78', 121, [], ['r4'], 'fam1', 1 ).
test( 't79', 288, ['m16','m41','m4','m11','m36','m2','m38','m27','m42','m30','m12'], [], 'fam1', 1 ).
test( 't80', 102, [], [], 'fam1', 1 ).
test( 't81', 242, [], ['r1','r4','r5','r3','r2'], 'fam1', 1 ).
test( 't82', 446, [], [], 'fam1', 1 ).
test( 't83', 248, [], ['r2','r3'], 'fam1', 1 ).
test( 't84', 17, [], ['r2','r1','r5','r3','r4'], 'fam1', 1 ).
test( 't85', 653, [], [], 'fam1', 1 ).
test( 't86', 636, [], [], 'fam1', 1 ).
test( 't87', 51, [], [], 'fam1', 1 ).
test( 't88', 270, [], [], 'fam1', 1 ).
test( 't89', 571, [], ['r2','r3'], 'fam1', 1 ).
test( 't90', 354, [], [], 'fam1', 1 ).
test( 't91', 766, [], [], 'fam1', 1 ).
test( 't92', 675, [], ['r1'], 'fam1', 1 ).
test( 't93', 269, [], [], 'fam1', 1 ).
test( 't94', 554, [], [], 'fam1', 1 ).
test( 't95', 697, ['m24','m34','m14','m17','m40','m29','m42','m28','m33','m38','m48','m46'], [], 'fam1', 1 ).
test( 't96', 671, [], [], 'fam1', 1 ).
test( 't97', 652, [], [], 'fam1', 1 ).
test( 't98', 651, [], [], 'fam1', 1 ).
test( 't99', 697, [], [], 'fam1', 1 ).
test( 't100', 512, [], ['r4','r3','r1'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').
embedded_board( 'm21').
embedded_board( 'm22').
embedded_board( 'm23').
embedded_board( 'm24').
embedded_board( 'm25').
embedded_board( 'm26').
embedded_board( 'm27').
embedded_board( 'm28').
embedded_board( 'm29').
embedded_board( 'm30').
embedded_board( 'm31').
embedded_board( 'm32').
embedded_board( 'm33').
embedded_board( 'm34').
embedded_board( 'm35').
embedded_board( 'm36').
embedded_board( 'm37').
embedded_board( 'm38').
embedded_board( 'm39').
embedded_board( 'm40').
embedded_board( 'm41').
embedded_board( 'm42').
embedded_board( 'm43').
embedded_board( 'm44').
embedded_board( 'm45').
embedded_board( 'm46').
embedded_board( 'm47').
embedded_board( 'm48').
embedded_board( 'm49').
embedded_board( 'm50').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
