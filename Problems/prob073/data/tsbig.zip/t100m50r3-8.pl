%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 50
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 524, [], [], 'fam1', 1 ).
test( 't2', 255, [], [], 'fam1', 1 ).
test( 't3', 645, ['m39','m43','m15','m22','m24','m13','m19','m4','m50','m8','m42','m9','m11'], [], 'fam1', 1 ).
test( 't4', 448, [], [], 'fam1', 1 ).
test( 't5', 42, [], [], 'fam1', 1 ).
test( 't6', 251, [], [], 'fam1', 1 ).
test( 't7', 525, [], [], 'fam1', 1 ).
test( 't8', 614, ['m27','m9','m43','m5'], [], 'fam1', 1 ).
test( 't9', 509, [], [], 'fam1', 1 ).
test( 't10', 8, [], [], 'fam1', 1 ).
test( 't11', 247, [], [], 'fam1', 1 ).
test( 't12', 147, [], [], 'fam1', 1 ).
test( 't13', 253, [], [], 'fam1', 1 ).
test( 't14', 487, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't15', 56, [], [], 'fam1', 1 ).
test( 't16', 38, [], [], 'fam1', 1 ).
test( 't17', 220, ['m21','m29','m16','m14','m38','m20','m33','m40'], [], 'fam1', 1 ).
test( 't18', 648, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't19', 449, ['m11','m13','m49','m46','m26','m10','m32','m38','m29','m5','m21','m35','m40','m15','m28'], [], 'fam1', 1 ).
test( 't20', 520, [], [], 'fam1', 1 ).
test( 't21', 144, ['m28','m43','m36','m49'], ['r1','r2'], 'fam1', 1 ).
test( 't22', 465, [], [], 'fam1', 1 ).
test( 't23', 303, ['m7','m16','m34','m6','m11','m44','m39','m25','m2','m5','m15'], ['r1','r2','r3'], 'fam1', 1 ).
test( 't24', 356, [], [], 'fam1', 1 ).
test( 't25', 717, [], [], 'fam1', 1 ).
test( 't26', 686, [], [], 'fam1', 1 ).
test( 't27', 654, [], [], 'fam1', 1 ).
test( 't28', 153, [], [], 'fam1', 1 ).
test( 't29', 211, [], ['r3'], 'fam1', 1 ).
test( 't30', 517, [], [], 'fam1', 1 ).
test( 't31', 114, ['m12','m7'], [], 'fam1', 1 ).
test( 't32', 209, ['m37','m21','m20','m8','m47','m35','m27','m36','m48','m38','m6','m14','m33'], [], 'fam1', 1 ).
test( 't33', 240, [], [], 'fam1', 1 ).
test( 't34', 577, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't35', 92, [], [], 'fam1', 1 ).
test( 't36', 226, ['m46','m2','m16','m21','m33','m22','m15','m42','m50','m25','m9','m23','m12','m32','m14'], ['r3','r1','r2'], 'fam1', 1 ).
test( 't37', 523, ['m40','m36','m9','m39','m16','m25'], [], 'fam1', 1 ).
test( 't38', 692, [], [], 'fam1', 1 ).
test( 't39', 404, [], [], 'fam1', 1 ).
test( 't40', 590, [], [], 'fam1', 1 ).
test( 't41', 44, [], [], 'fam1', 1 ).
test( 't42', 359, [], [], 'fam1', 1 ).
test( 't43', 289, [], [], 'fam1', 1 ).
test( 't44', 506, [], [], 'fam1', 1 ).
test( 't45', 571, [], [], 'fam1', 1 ).
test( 't46', 800, [], ['r2'], 'fam1', 1 ).
test( 't47', 439, [], [], 'fam1', 1 ).
test( 't48', 196, [], [], 'fam1', 1 ).
test( 't49', 188, [], [], 'fam1', 1 ).
test( 't50', 76, [], [], 'fam1', 1 ).
test( 't51', 612, [], [], 'fam1', 1 ).
test( 't52', 498, [], [], 'fam1', 1 ).
test( 't53', 474, ['m48','m1','m27'], ['r3'], 'fam1', 1 ).
test( 't54', 164, [], [], 'fam1', 1 ).
test( 't55', 56, ['m42','m14','m19','m16','m7','m26','m20','m32','m36','m48','m28','m29','m38','m31','m39','m11','m12','m40'], [], 'fam1', 1 ).
test( 't56', 94, [], [], 'fam1', 1 ).
test( 't57', 684, [], [], 'fam1', 1 ).
test( 't58', 518, [], ['r2'], 'fam1', 1 ).
test( 't59', 703, ['m29','m18','m17','m38','m16','m43','m23','m5','m2','m42'], ['r1','r3','r2'], 'fam1', 1 ).
test( 't60', 537, ['m4','m35','m3','m40','m19','m31','m8','m47','m15','m37','m18','m43'], [], 'fam1', 1 ).
test( 't61', 389, [], ['r2'], 'fam1', 1 ).
test( 't62', 409, ['m6','m15','m44','m8','m19','m23','m10','m22','m5'], [], 'fam1', 1 ).
test( 't63', 469, [], [], 'fam1', 1 ).
test( 't64', 562, [], [], 'fam1', 1 ).
test( 't65', 33, [], ['r2'], 'fam1', 1 ).
test( 't66', 768, [], [], 'fam1', 1 ).
test( 't67', 296, [], [], 'fam1', 1 ).
test( 't68', 345, [], ['r1'], 'fam1', 1 ).
test( 't69', 715, [], [], 'fam1', 1 ).
test( 't70', 239, [], ['r1','r3'], 'fam1', 1 ).
test( 't71', 180, [], ['r2'], 'fam1', 1 ).
test( 't72', 152, ['m8','m12','m37','m36','m45','m39','m41','m5','m49','m23','m34','m26','m20','m14','m28','m30','m21'], ['r2','r1'], 'fam1', 1 ).
test( 't73', 247, [], ['r2'], 'fam1', 1 ).
test( 't74', 526, [], ['r1'], 'fam1', 1 ).
test( 't75', 4, [], [], 'fam1', 1 ).
test( 't76', 267, ['m11','m10','m3','m12','m29','m22'], ['r2','r1','r3'], 'fam1', 1 ).
test( 't77', 349, [], [], 'fam1', 1 ).
test( 't78', 227, [], [], 'fam1', 1 ).
test( 't79', 578, [], [], 'fam1', 1 ).
test( 't80', 207, [], [], 'fam1', 1 ).
test( 't81', 419, ['m38','m22','m46','m24','m31','m1','m8','m13','m14','m45'], [], 'fam1', 1 ).
test( 't82', 102, [], ['r2'], 'fam1', 1 ).
test( 't83', 434, ['m35','m8','m27','m30','m25','m46','m15','m21','m47'], [], 'fam1', 1 ).
test( 't84', 157, [], ['r2'], 'fam1', 1 ).
test( 't85', 791, [], [], 'fam1', 1 ).
test( 't86', 797, [], ['r3'], 'fam1', 1 ).
test( 't87', 658, [], [], 'fam1', 1 ).
test( 't88', 628, ['m3','m6','m14','m30','m47','m2','m10','m33','m39','m41','m8','m26','m34','m46','m24','m49','m5','m35','m29'], ['r1','r2'], 'fam1', 1 ).
test( 't89', 407, [], [], 'fam1', 1 ).
test( 't90', 254, [], ['r2'], 'fam1', 1 ).
test( 't91', 509, [], [], 'fam1', 1 ).
test( 't92', 133, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't93', 512, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't94', 630, [], [], 'fam1', 1 ).
test( 't95', 17, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't96', 388, [], [], 'fam1', 1 ).
test( 't97', 388, [], ['r2'], 'fam1', 1 ).
test( 't98', 51, [], [], 'fam1', 1 ).
test( 't99', 485, [], ['r1'], 'fam1', 1 ).
test( 't100', 751, [], ['r3','r1'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').
embedded_board( 'm21').
embedded_board( 'm22').
embedded_board( 'm23').
embedded_board( 'm24').
embedded_board( 'm25').
embedded_board( 'm26').
embedded_board( 'm27').
embedded_board( 'm28').
embedded_board( 'm29').
embedded_board( 'm30').
embedded_board( 'm31').
embedded_board( 'm32').
embedded_board( 'm33').
embedded_board( 'm34').
embedded_board( 'm35').
embedded_board( 'm36').
embedded_board( 'm37').
embedded_board( 'm38').
embedded_board( 'm39').
embedded_board( 'm40').
embedded_board( 'm41').
embedded_board( 'm42').
embedded_board( 'm43').
embedded_board( 'm44').
embedded_board( 'm45').
embedded_board( 'm46').
embedded_board( 'm47').
embedded_board( 'm48').
embedded_board( 'm49').
embedded_board( 'm50').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
