%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 164, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't2', 14, ['m6','m4','m1','m5'], [], 'fam1', 1 ).
test( 't3', 368, [], [], 'fam1', 1 ).
test( 't4', 417, [], [], 'fam1', 1 ).
test( 't5', 506, [], [], 'fam1', 1 ).
test( 't6', 649, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't7', 463, [], ['r3'], 'fam1', 1 ).
test( 't8', 34, [], [], 'fam1', 1 ).
test( 't9', 473, [], [], 'fam1', 1 ).
test( 't10', 241, ['m5','m6','m7'], ['r2'], 'fam1', 1 ).
test( 't11', 606, [], [], 'fam1', 1 ).
test( 't12', 253, [], [], 'fam1', 1 ).
test( 't13', 53, [], ['r1'], 'fam1', 1 ).
test( 't14', 61, [], [], 'fam1', 1 ).
test( 't15', 21, [], ['r3'], 'fam1', 1 ).
test( 't16', 238, ['m6','m10','m3','m4'], [], 'fam1', 1 ).
test( 't17', 511, ['m7'], [], 'fam1', 1 ).
test( 't18', 300, [], [], 'fam1', 1 ).
test( 't19', 796, ['m10','m8'], [], 'fam1', 1 ).
test( 't20', 774, [], [], 'fam1', 1 ).
test( 't21', 226, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't22', 203, [], [], 'fam1', 1 ).
test( 't23', 691, [], [], 'fam1', 1 ).
test( 't24', 7, [], [], 'fam1', 1 ).
test( 't25', 519, [], [], 'fam1', 1 ).
test( 't26', 627, [], [], 'fam1', 1 ).
test( 't27', 165, [], [], 'fam1', 1 ).
test( 't28', 661, [], [], 'fam1', 1 ).
test( 't29', 73, [], [], 'fam1', 1 ).
test( 't30', 158, [], [], 'fam1', 1 ).
test( 't31', 379, [], [], 'fam1', 1 ).
test( 't32', 573, ['m7'], [], 'fam1', 1 ).
test( 't33', 280, [], ['r2'], 'fam1', 1 ).
test( 't34', 39, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't35', 368, [], [], 'fam1', 1 ).
test( 't36', 735, [], [], 'fam1', 1 ).
test( 't37', 466, [], [], 'fam1', 1 ).
test( 't38', 327, [], [], 'fam1', 1 ).
test( 't39', 110, [], [], 'fam1', 1 ).
test( 't40', 660, [], ['r1','r3','r2'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
