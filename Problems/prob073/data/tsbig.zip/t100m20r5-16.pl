%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 20
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 425, [], ['r2','r1','r5','r3'], 'fam1', 1 ).
test( 't2', 181, [], ['r5'], 'fam1', 1 ).
test( 't3', 155, [], [], 'fam1', 1 ).
test( 't4', 416, ['m20'], [], 'fam1', 1 ).
test( 't5', 241, ['m14'], [], 'fam1', 1 ).
test( 't6', 144, [], ['r5'], 'fam1', 1 ).
test( 't7', 157, [], [], 'fam1', 1 ).
test( 't8', 241, [], ['r3','r2'], 'fam1', 1 ).
test( 't9', 620, [], [], 'fam1', 1 ).
test( 't10', 516, ['m7','m13','m15','m4','m8','m16','m19'], ['r5','r2','r1','r4'], 'fam1', 1 ).
test( 't11', 39, [], ['r4','r5','r3','r2','r1'], 'fam1', 1 ).
test( 't12', 440, ['m1','m5','m13'], ['r4','r2'], 'fam1', 1 ).
test( 't13', 671, ['m15','m5','m8','m1','m10','m13','m18','m2'], [], 'fam1', 1 ).
test( 't14', 281, [], [], 'fam1', 1 ).
test( 't15', 152, [], [], 'fam1', 1 ).
test( 't16', 166, ['m9','m2','m19','m3','m20','m11','m17'], ['r2','r5'], 'fam1', 1 ).
test( 't17', 340, [], [], 'fam1', 1 ).
test( 't18', 137, ['m11','m20','m9','m5','m18','m13','m14','m2'], [], 'fam1', 1 ).
test( 't19', 449, [], [], 'fam1', 1 ).
test( 't20', 641, [], [], 'fam1', 1 ).
test( 't21', 434, [], [], 'fam1', 1 ).
test( 't22', 96, [], [], 'fam1', 1 ).
test( 't23', 761, [], [], 'fam1', 1 ).
test( 't24', 613, [], ['r4'], 'fam1', 1 ).
test( 't25', 385, [], [], 'fam1', 1 ).
test( 't26', 710, [], [], 'fam1', 1 ).
test( 't27', 338, [], [], 'fam1', 1 ).
test( 't28', 58, ['m8','m10','m18','m17','m14','m11'], [], 'fam1', 1 ).
test( 't29', 771, [], [], 'fam1', 1 ).
test( 't30', 751, [], [], 'fam1', 1 ).
test( 't31', 416, [], [], 'fam1', 1 ).
test( 't32', 451, [], ['r4','r2','r3'], 'fam1', 1 ).
test( 't33', 352, [], ['r4','r3','r1','r5','r2'], 'fam1', 1 ).
test( 't34', 418, [], ['r5','r2','r4'], 'fam1', 1 ).
test( 't35', 122, [], [], 'fam1', 1 ).
test( 't36', 298, ['m16'], ['r5','r4','r1','r3'], 'fam1', 1 ).
test( 't37', 263, [], [], 'fam1', 1 ).
test( 't38', 551, [], [], 'fam1', 1 ).
test( 't39', 204, [], [], 'fam1', 1 ).
test( 't40', 224, [], ['r5','r3','r1','r2'], 'fam1', 1 ).
test( 't41', 200, [], [], 'fam1', 1 ).
test( 't42', 250, [], ['r3'], 'fam1', 1 ).
test( 't43', 751, [], [], 'fam1', 1 ).
test( 't44', 533, [], ['r2','r3','r1','r4','r5'], 'fam1', 1 ).
test( 't45', 232, [], [], 'fam1', 1 ).
test( 't46', 444, [], ['r4','r3','r5','r1','r2'], 'fam1', 1 ).
test( 't47', 657, [], [], 'fam1', 1 ).
test( 't48', 501, [], [], 'fam1', 1 ).
test( 't49', 155, [], [], 'fam1', 1 ).
test( 't50', 747, [], ['r2'], 'fam1', 1 ).
test( 't51', 669, [], ['r5','r4','r1'], 'fam1', 1 ).
test( 't52', 708, ['m4','m12','m9','m5','m11','m3','m2'], [], 'fam1', 1 ).
test( 't53', 295, ['m15','m4'], ['r1'], 'fam1', 1 ).
test( 't54', 185, [], ['r1'], 'fam1', 1 ).
test( 't55', 476, [], [], 'fam1', 1 ).
test( 't56', 134, [], ['r4','r1','r5','r3','r2'], 'fam1', 1 ).
test( 't57', 754, ['m2'], ['r3','r5','r2','r1'], 'fam1', 1 ).
test( 't58', 340, [], [], 'fam1', 1 ).
test( 't59', 273, [], [], 'fam1', 1 ).
test( 't60', 123, [], ['r3','r2','r5'], 'fam1', 1 ).
test( 't61', 71, [], [], 'fam1', 1 ).
test( 't62', 441, [], [], 'fam1', 1 ).
test( 't63', 79, [], [], 'fam1', 1 ).
test( 't64', 381, [], ['r2','r3'], 'fam1', 1 ).
test( 't65', 253, [], [], 'fam1', 1 ).
test( 't66', 385, ['m11'], [], 'fam1', 1 ).
test( 't67', 371, [], [], 'fam1', 1 ).
test( 't68', 488, [], [], 'fam1', 1 ).
test( 't69', 588, [], [], 'fam1', 1 ).
test( 't70', 777, [], [], 'fam1', 1 ).
test( 't71', 313, [], [], 'fam1', 1 ).
test( 't72', 374, ['m14','m18','m4','m5','m20','m1','m19'], [], 'fam1', 1 ).
test( 't73', 10, [], ['r2','r1','r5','r4'], 'fam1', 1 ).
test( 't74', 761, [], [], 'fam1', 1 ).
test( 't75', 766, [], [], 'fam1', 1 ).
test( 't76', 446, ['m1','m3','m14','m11'], ['r1','r5','r2','r3','r4'], 'fam1', 1 ).
test( 't77', 252, [], [], 'fam1', 1 ).
test( 't78', 6, [], [], 'fam1', 1 ).
test( 't79', 124, ['m19','m7','m10','m6','m2','m18','m20','m16'], [], 'fam1', 1 ).
test( 't80', 238, ['m17','m8','m18'], [], 'fam1', 1 ).
test( 't81', 558, [], ['r4','r3'], 'fam1', 1 ).
test( 't82', 524, ['m16','m12','m14'], [], 'fam1', 1 ).
test( 't83', 276, [], [], 'fam1', 1 ).
test( 't84', 785, [], ['r5'], 'fam1', 1 ).
test( 't85', 556, [], [], 'fam1', 1 ).
test( 't86', 222, [], ['r3'], 'fam1', 1 ).
test( 't87', 668, [], [], 'fam1', 1 ).
test( 't88', 722, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't89', 179, [], [], 'fam1', 1 ).
test( 't90', 196, ['m10','m19','m7','m18'], [], 'fam1', 1 ).
test( 't91', 256, ['m18','m3','m9','m20','m8','m1','m6'], [], 'fam1', 1 ).
test( 't92', 280, [], ['r1','r5','r3','r4'], 'fam1', 1 ).
test( 't93', 459, [], [], 'fam1', 1 ).
test( 't94', 680, [], [], 'fam1', 1 ).
test( 't95', 28, ['m12','m3'], ['r5','r1','r2','r3'], 'fam1', 1 ).
test( 't96', 671, [], ['r3'], 'fam1', 1 ).
test( 't97', 283, [], [], 'fam1', 1 ).
test( 't98', 168, ['m18','m2','m7','m6','m16','m4'], [], 'fam1', 1 ).
test( 't99', 627, [], [], 'fam1', 1 ).
test( 't100', 61, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
