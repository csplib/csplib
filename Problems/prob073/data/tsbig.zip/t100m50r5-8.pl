%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 50
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 397, [], [], 'fam1', 1 ).
test( 't2', 293, [], [], 'fam1', 1 ).
test( 't3', 384, [], [], 'fam1', 1 ).
test( 't4', 745, [], ['r4','r1'], 'fam1', 1 ).
test( 't5', 2, [], [], 'fam1', 1 ).
test( 't6', 26, ['m29','m7','m36','m49','m1','m27','m42','m9','m10'], [], 'fam1', 1 ).
test( 't7', 584, ['m5','m49','m18','m38','m7','m19','m31','m28','m6','m46','m48'], [], 'fam1', 1 ).
test( 't8', 79, [], ['r3','r1'], 'fam1', 1 ).
test( 't9', 566, [], [], 'fam1', 1 ).
test( 't10', 778, [], ['r3','r5','r1','r4'], 'fam1', 1 ).
test( 't11', 262, ['m22','m23','m10','m34','m47'], [], 'fam1', 1 ).
test( 't12', 363, [], [], 'fam1', 1 ).
test( 't13', 276, [], [], 'fam1', 1 ).
test( 't14', 242, [], ['r4','r2','r1'], 'fam1', 1 ).
test( 't15', 739, [], [], 'fam1', 1 ).
test( 't16', 11, [], [], 'fam1', 1 ).
test( 't17', 709, [], ['r4','r1'], 'fam1', 1 ).
test( 't18', 541, [], [], 'fam1', 1 ).
test( 't19', 102, [], [], 'fam1', 1 ).
test( 't20', 800, ['m18','m8','m28','m41','m16','m20'], [], 'fam1', 1 ).
test( 't21', 548, [], [], 'fam1', 1 ).
test( 't22', 11, [], ['r4','r3','r2','r1','r5'], 'fam1', 1 ).
test( 't23', 106, [], [], 'fam1', 1 ).
test( 't24', 572, ['m30','m15','m50','m40','m18','m37','m10','m47','m14','m42','m46','m20','m24','m49','m7','m36','m38'], [], 'fam1', 1 ).
test( 't25', 371, [], [], 'fam1', 1 ).
test( 't26', 751, ['m18','m8','m49','m7','m9','m1','m28','m48','m35'], [], 'fam1', 1 ).
test( 't27', 507, [], [], 'fam1', 1 ).
test( 't28', 626, [], [], 'fam1', 1 ).
test( 't29', 590, ['m14','m2','m24','m30'], [], 'fam1', 1 ).
test( 't30', 150, [], [], 'fam1', 1 ).
test( 't31', 461, [], [], 'fam1', 1 ).
test( 't32', 647, [], ['r4','r5','r1','r3'], 'fam1', 1 ).
test( 't33', 220, [], [], 'fam1', 1 ).
test( 't34', 624, [], [], 'fam1', 1 ).
test( 't35', 632, ['m19','m36','m24','m39'], [], 'fam1', 1 ).
test( 't36', 217, [], [], 'fam1', 1 ).
test( 't37', 279, [], [], 'fam1', 1 ).
test( 't38', 27, ['m25','m1','m43','m16','m20','m8','m32','m18'], ['r3','r5'], 'fam1', 1 ).
test( 't39', 63, [], [], 'fam1', 1 ).
test( 't40', 644, [], [], 'fam1', 1 ).
test( 't41', 665, [], ['r1'], 'fam1', 1 ).
test( 't42', 454, ['m23','m49','m12','m33','m25','m46','m6','m30','m4','m40','m35','m17','m37','m31','m28','m24','m5'], [], 'fam1', 1 ).
test( 't43', 300, [], [], 'fam1', 1 ).
test( 't44', 16, ['m28','m48','m31','m37'], [], 'fam1', 1 ).
test( 't45', 106, ['m47','m5','m15','m44','m23','m27','m17','m34'], ['r1','r2','r3','r5','r4'], 'fam1', 1 ).
test( 't46', 308, [], [], 'fam1', 1 ).
test( 't47', 150, [], ['r1','r2','r5','r4'], 'fam1', 1 ).
test( 't48', 620, [], [], 'fam1', 1 ).
test( 't49', 147, [], [], 'fam1', 1 ).
test( 't50', 240, [], ['r3','r2'], 'fam1', 1 ).
test( 't51', 97, [], ['r5'], 'fam1', 1 ).
test( 't52', 75, ['m16','m46','m2','m50','m47','m27','m45','m12','m19','m25','m10','m23','m6','m3','m31','m36','m44','m24','m43','m15'], [], 'fam1', 1 ).
test( 't53', 23, [], [], 'fam1', 1 ).
test( 't54', 443, [], [], 'fam1', 1 ).
test( 't55', 800, ['m33','m16','m49','m41','m7','m50','m8','m6','m39','m31','m14','m36','m35','m17','m3','m15','m21','m13','m4','m2'], ['r5','r1'], 'fam1', 1 ).
test( 't56', 649, [], [], 'fam1', 1 ).
test( 't57', 740, ['m49'], ['r2'], 'fam1', 1 ).
test( 't58', 427, ['m27','m43'], [], 'fam1', 1 ).
test( 't59', 584, [], ['r3','r5','r1'], 'fam1', 1 ).
test( 't60', 522, [], [], 'fam1', 1 ).
test( 't61', 312, [], ['r4','r5'], 'fam1', 1 ).
test( 't62', 720, [], [], 'fam1', 1 ).
test( 't63', 453, [], ['r5'], 'fam1', 1 ).
test( 't64', 371, [], [], 'fam1', 1 ).
test( 't65', 562, [], [], 'fam1', 1 ).
test( 't66', 192, ['m27','m41','m28','m21','m35','m1','m11','m38','m18','m46','m25','m2','m43','m24','m20','m37','m44'], [], 'fam1', 1 ).
test( 't67', 483, [], [], 'fam1', 1 ).
test( 't68', 45, ['m48','m3','m28','m22','m36','m7','m23','m40','m31','m17','m16','m25','m26'], [], 'fam1', 1 ).
test( 't69', 382, [], [], 'fam1', 1 ).
test( 't70', 751, [], [], 'fam1', 1 ).
test( 't71', 637, [], ['r5'], 'fam1', 1 ).
test( 't72', 584, [], [], 'fam1', 1 ).
test( 't73', 672, [], [], 'fam1', 1 ).
test( 't74', 710, [], [], 'fam1', 1 ).
test( 't75', 795, [], [], 'fam1', 1 ).
test( 't76', 308, ['m9','m41','m28','m15','m22','m24','m16','m5','m19','m6','m34','m2','m11','m31','m36'], [], 'fam1', 1 ).
test( 't77', 612, [], [], 'fam1', 1 ).
test( 't78', 246, [], [], 'fam1', 1 ).
test( 't79', 740, ['m20','m22','m18','m31','m32','m17','m46','m45','m30'], ['r4','r3','r2','r5','r1'], 'fam1', 1 ).
test( 't80', 590, ['m17','m42','m4','m38','m20','m47','m5','m50','m10','m36','m35','m27','m44'], [], 'fam1', 1 ).
test( 't81', 592, [], ['r4','r3','r5'], 'fam1', 1 ).
test( 't82', 95, [], [], 'fam1', 1 ).
test( 't83', 561, [], ['r3','r2','r5','r1','r4'], 'fam1', 1 ).
test( 't84', 202, [], [], 'fam1', 1 ).
test( 't85', 468, [], [], 'fam1', 1 ).
test( 't86', 466, [], [], 'fam1', 1 ).
test( 't87', 544, ['m28','m32','m21','m17','m27','m30','m20'], [], 'fam1', 1 ).
test( 't88', 715, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't89', 256, [], [], 'fam1', 1 ).
test( 't90', 79, [], [], 'fam1', 1 ).
test( 't91', 556, [], ['r1','r5','r4'], 'fam1', 1 ).
test( 't92', 453, [], [], 'fam1', 1 ).
test( 't93', 564, [], [], 'fam1', 1 ).
test( 't94', 579, [], [], 'fam1', 1 ).
test( 't95', 509, [], [], 'fam1', 1 ).
test( 't96', 157, ['m44','m9','m45'], [], 'fam1', 1 ).
test( 't97', 205, [], ['r1','r4','r5'], 'fam1', 1 ).
test( 't98', 345, [], [], 'fam1', 1 ).
test( 't99', 535, [], [], 'fam1', 1 ).
test( 't100', 570, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').
embedded_board( 'm21').
embedded_board( 'm22').
embedded_board( 'm23').
embedded_board( 'm24').
embedded_board( 'm25').
embedded_board( 'm26').
embedded_board( 'm27').
embedded_board( 'm28').
embedded_board( 'm29').
embedded_board( 'm30').
embedded_board( 'm31').
embedded_board( 'm32').
embedded_board( 'm33').
embedded_board( 'm34').
embedded_board( 'm35').
embedded_board( 'm36').
embedded_board( 'm37').
embedded_board( 'm38').
embedded_board( 'm39').
embedded_board( 'm40').
embedded_board( 'm41').
embedded_board( 'm42').
embedded_board( 'm43').
embedded_board( 'm44').
embedded_board( 'm45').
embedded_board( 'm46').
embedded_board( 'm47').
embedded_board( 'm48').
embedded_board( 'm49').
embedded_board( 'm50').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
