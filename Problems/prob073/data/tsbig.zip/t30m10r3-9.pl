%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 610, [], [], 'fam1', 1 ).
test( 't2', 272, [], ['r3'], 'fam1', 1 ).
test( 't3', 568, ['m6'], [], 'fam1', 1 ).
test( 't4', 613, ['m6','m7'], ['r3'], 'fam1', 1 ).
test( 't5', 768, ['m9','m4','m2','m10'], [], 'fam1', 1 ).
test( 't6', 522, [], [], 'fam1', 1 ).
test( 't7', 226, ['m6','m10','m9','m1'], ['r1'], 'fam1', 1 ).
test( 't8', 137, [], [], 'fam1', 1 ).
test( 't9', 72, [], [], 'fam1', 1 ).
test( 't10', 780, [], [], 'fam1', 1 ).
test( 't11', 666, [], ['r2','r3'], 'fam1', 1 ).
test( 't12', 237, ['m8','m2','m6'], [], 'fam1', 1 ).
test( 't13', 573, [], ['r3','r1'], 'fam1', 1 ).
test( 't14', 380, ['m8','m2','m3'], [], 'fam1', 1 ).
test( 't15', 323, [], [], 'fam1', 1 ).
test( 't16', 207, ['m6','m3','m8'], [], 'fam1', 1 ).
test( 't17', 51, [], [], 'fam1', 1 ).
test( 't18', 743, ['m4','m1','m10','m8'], [], 'fam1', 1 ).
test( 't19', 181, ['m7','m6','m10'], [], 'fam1', 1 ).
test( 't20', 129, ['m8','m2','m10','m9'], [], 'fam1', 1 ).
test( 't21', 12, [], ['r1','r3'], 'fam1', 1 ).
test( 't22', 622, [], [], 'fam1', 1 ).
test( 't23', 315, [], [], 'fam1', 1 ).
test( 't24', 607, [], [], 'fam1', 1 ).
test( 't25', 618, ['m10','m1','m4'], ['r3','r1','r2'], 'fam1', 1 ).
test( 't26', 119, ['m4','m9','m6','m7'], [], 'fam1', 1 ).
test( 't27', 761, [], [], 'fam1', 1 ).
test( 't28', 13, [], [], 'fam1', 1 ).
test( 't29', 619, [], ['r1','r2'], 'fam1', 1 ).
test( 't30', 140, [], ['r2','r1'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
