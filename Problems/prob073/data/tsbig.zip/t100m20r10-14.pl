%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 20
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 549, [], ['r10','r4','r1','r6','r5','r2'], 'fam1', 1 ).
test( 't2', 513, [], ['r2','r10','r4','r3','r9'], 'fam1', 1 ).
test( 't3', 445, [], [], 'fam1', 1 ).
test( 't4', 266, [], [], 'fam1', 1 ).
test( 't5', 458, [], [], 'fam1', 1 ).
test( 't6', 331, [], [], 'fam1', 1 ).
test( 't7', 148, [], [], 'fam1', 1 ).
test( 't8', 764, [], ['r1','r4','r6','r8','r9','r3','r5','r2','r10','r7'], 'fam1', 1 ).
test( 't9', 266, ['m14','m18','m8','m10','m4','m17','m13','m2'], [], 'fam1', 1 ).
test( 't10', 784, [], [], 'fam1', 1 ).
test( 't11', 793, [], ['r9','r7','r8','r4','r3'], 'fam1', 1 ).
test( 't12', 272, [], [], 'fam1', 1 ).
test( 't13', 340, [], [], 'fam1', 1 ).
test( 't14', 87, [], [], 'fam1', 1 ).
test( 't15', 665, [], ['r1','r8','r3','r4'], 'fam1', 1 ).
test( 't16', 10, [], [], 'fam1', 1 ).
test( 't17', 40, [], [], 'fam1', 1 ).
test( 't18', 124, [], [], 'fam1', 1 ).
test( 't19', 291, [], ['r6','r9'], 'fam1', 1 ).
test( 't20', 36, [], ['r2','r7','r5','r9','r8','r4','r1'], 'fam1', 1 ).
test( 't21', 717, ['m1','m12','m3','m19','m13'], [], 'fam1', 1 ).
test( 't22', 580, [], [], 'fam1', 1 ).
test( 't23', 342, [], [], 'fam1', 1 ).
test( 't24', 50, [], ['r1','r3','r5','r10','r9','r2','r6','r8'], 'fam1', 1 ).
test( 't25', 665, [], [], 'fam1', 1 ).
test( 't26', 405, [], [], 'fam1', 1 ).
test( 't27', 762, [], ['r10','r7','r4','r8','r6'], 'fam1', 1 ).
test( 't28', 498, [], [], 'fam1', 1 ).
test( 't29', 99, ['m4','m1','m9'], ['r7'], 'fam1', 1 ).
test( 't30', 456, [], [], 'fam1', 1 ).
test( 't31', 792, [], ['r9','r5','r3','r7','r4','r8'], 'fam1', 1 ).
test( 't32', 486, [], [], 'fam1', 1 ).
test( 't33', 739, ['m19','m8','m16','m11','m9','m18','m17'], [], 'fam1', 1 ).
test( 't34', 669, [], [], 'fam1', 1 ).
test( 't35', 259, ['m1','m15','m17','m8','m13','m19'], [], 'fam1', 1 ).
test( 't36', 112, [], [], 'fam1', 1 ).
test( 't37', 649, [], [], 'fam1', 1 ).
test( 't38', 475, [], ['r9','r1','r3','r7','r8'], 'fam1', 1 ).
test( 't39', 40, [], [], 'fam1', 1 ).
test( 't40', 66, ['m1','m19','m9','m6','m12','m15','m14'], [], 'fam1', 1 ).
test( 't41', 633, [], [], 'fam1', 1 ).
test( 't42', 233, [], ['r3','r10','r6'], 'fam1', 1 ).
test( 't43', 666, [], [], 'fam1', 1 ).
test( 't44', 228, [], [], 'fam1', 1 ).
test( 't45', 279, ['m18','m7','m11','m5','m14','m19','m12','m15'], [], 'fam1', 1 ).
test( 't46', 81, ['m18','m16','m9','m3','m2'], [], 'fam1', 1 ).
test( 't47', 348, ['m15','m5'], [], 'fam1', 1 ).
test( 't48', 501, [], [], 'fam1', 1 ).
test( 't49', 281, [], [], 'fam1', 1 ).
test( 't50', 334, [], [], 'fam1', 1 ).
test( 't51', 282, [], ['r9','r6','r7','r5','r2'], 'fam1', 1 ).
test( 't52', 392, [], [], 'fam1', 1 ).
test( 't53', 775, ['m11','m10','m17'], [], 'fam1', 1 ).
test( 't54', 564, [], [], 'fam1', 1 ).
test( 't55', 398, [], [], 'fam1', 1 ).
test( 't56', 96, [], ['r10','r8','r7','r1','r2','r3','r4','r6','r9'], 'fam1', 1 ).
test( 't57', 763, [], [], 'fam1', 1 ).
test( 't58', 617, [], ['r8'], 'fam1', 1 ).
test( 't59', 134, [], ['r5','r1','r4','r7','r2'], 'fam1', 1 ).
test( 't60', 776, [], ['r9','r6','r3','r1','r8'], 'fam1', 1 ).
test( 't61', 426, ['m4','m3'], [], 'fam1', 1 ).
test( 't62', 561, [], ['r6','r9','r3','r10','r2'], 'fam1', 1 ).
test( 't63', 499, [], [], 'fam1', 1 ).
test( 't64', 45, ['m19','m11','m1'], [], 'fam1', 1 ).
test( 't65', 184, [], [], 'fam1', 1 ).
test( 't66', 253, ['m12','m14','m8','m20','m7','m9'], [], 'fam1', 1 ).
test( 't67', 249, [], [], 'fam1', 1 ).
test( 't68', 29, [], [], 'fam1', 1 ).
test( 't69', 616, ['m5','m10','m6','m1','m8','m18','m2','m17'], [], 'fam1', 1 ).
test( 't70', 473, ['m9','m12'], [], 'fam1', 1 ).
test( 't71', 137, [], [], 'fam1', 1 ).
test( 't72', 534, [], [], 'fam1', 1 ).
test( 't73', 411, [], [], 'fam1', 1 ).
test( 't74', 348, ['m3','m13','m11','m4','m19','m7','m1','m12'], [], 'fam1', 1 ).
test( 't75', 172, [], ['r3','r8','r1','r9','r10','r4','r5','r2','r7','r6'], 'fam1', 1 ).
test( 't76', 333, ['m7','m2','m13','m16','m17'], ['r6','r3','r7'], 'fam1', 1 ).
test( 't77', 429, [], ['r8'], 'fam1', 1 ).
test( 't78', 763, [], [], 'fam1', 1 ).
test( 't79', 76, [], [], 'fam1', 1 ).
test( 't80', 416, [], [], 'fam1', 1 ).
test( 't81', 172, [], [], 'fam1', 1 ).
test( 't82', 302, ['m7','m10','m6','m5'], [], 'fam1', 1 ).
test( 't83', 293, [], [], 'fam1', 1 ).
test( 't84', 193, ['m3','m8','m1','m11'], ['r8','r10','r6','r1','r2','r3','r4','r5'], 'fam1', 1 ).
test( 't85', 473, [], [], 'fam1', 1 ).
test( 't86', 789, [], [], 'fam1', 1 ).
test( 't87', 46, [], [], 'fam1', 1 ).
test( 't88', 625, ['m12','m14'], ['r7','r6','r1','r5','r9','r10','r8'], 'fam1', 1 ).
test( 't89', 242, [], ['r8','r3','r6','r9','r7','r10','r2','r5','r1'], 'fam1', 1 ).
test( 't90', 801, [], [], 'fam1', 1 ).
test( 't91', 432, [], [], 'fam1', 1 ).
test( 't92', 721, [], [], 'fam1', 1 ).
test( 't93', 635, [], ['r6','r2','r8','r5'], 'fam1', 1 ).
test( 't94', 268, [], ['r1','r7','r4','r2','r10','r6','r3','r9'], 'fam1', 1 ).
test( 't95', 743, ['m8','m13'], [], 'fam1', 1 ).
test( 't96', 533, [], [], 'fam1', 1 ).
test( 't97', 145, [], [], 'fam1', 1 ).
test( 't98', 264, [], [], 'fam1', 1 ).
test( 't99', 246, [], ['r10'], 'fam1', 1 ).
test( 't100', 530, [], ['r7','r8','r5','r3','r1'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
