%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 50
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 346, ['m20','m33','m21','m3','m41','m44','m2','m16','m5','m35','m49','m47','m18','m48','m28','m6'], ['r4','r3','r5','r1'], 'fam1', 1 ).
test( 't2', 500, [], [], 'fam1', 1 ).
test( 't3', 356, [], [], 'fam1', 1 ).
test( 't4', 625, [], [], 'fam1', 1 ).
test( 't5', 769, [], [], 'fam1', 1 ).
test( 't6', 331, [], [], 'fam1', 1 ).
test( 't7', 317, ['m35','m28','m25','m44','m5','m49','m23','m4','m32','m34','m6','m2','m50','m42','m15','m7','m18','m31','m16','m37'], ['r5','r2','r3','r4','r1'], 'fam1', 1 ).
test( 't8', 780, ['m5','m14','m16','m6','m2','m1','m8','m24','m46','m26'], [], 'fam1', 1 ).
test( 't9', 177, ['m9','m26','m44','m10','m43'], [], 'fam1', 1 ).
test( 't10', 519, [], ['r1'], 'fam1', 1 ).
test( 't11', 86, [], [], 'fam1', 1 ).
test( 't12', 36, [], [], 'fam1', 1 ).
test( 't13', 203, ['m28','m49','m13','m36','m12','m39','m16','m20','m47','m4','m23','m7'], ['r2','r4','r3','r1','r5'], 'fam1', 1 ).
test( 't14', 717, ['m25','m26','m2','m48','m14','m22','m1'], ['r3','r1','r4'], 'fam1', 1 ).
test( 't15', 550, [], [], 'fam1', 1 ).
test( 't16', 731, [], ['r1','r3','r5','r2'], 'fam1', 1 ).
test( 't17', 232, [], [], 'fam1', 1 ).
test( 't18', 736, ['m7','m8','m35','m4','m38'], [], 'fam1', 1 ).
test( 't19', 607, [], [], 'fam1', 1 ).
test( 't20', 281, ['m38','m20','m41','m21','m49','m28','m46','m33','m5','m30','m50','m22','m13','m2','m29','m39','m26','m44','m45','m1'], [], 'fam1', 1 ).
test( 't21', 768, [], [], 'fam1', 1 ).
test( 't22', 242, ['m40','m32','m44','m43','m42','m33'], [], 'fam1', 1 ).
test( 't23', 395, ['m21','m7','m46','m4','m44','m49','m41','m23','m9','m32','m33','m28','m45','m29'], [], 'fam1', 1 ).
test( 't24', 776, [], ['r1','r2','r5','r3'], 'fam1', 1 ).
test( 't25', 491, [], [], 'fam1', 1 ).
test( 't26', 294, [], ['r5','r3','r4'], 'fam1', 1 ).
test( 't27', 675, [], ['r3'], 'fam1', 1 ).
test( 't28', 450, [], [], 'fam1', 1 ).
test( 't29', 20, [], ['r1','r4'], 'fam1', 1 ).
test( 't30', 152, ['m13','m17','m16','m9','m8','m1'], [], 'fam1', 1 ).
test( 't31', 611, [], [], 'fam1', 1 ).
test( 't32', 55, [], [], 'fam1', 1 ).
test( 't33', 597, [], [], 'fam1', 1 ).
test( 't34', 539, [], [], 'fam1', 1 ).
test( 't35', 755, [], [], 'fam1', 1 ).
test( 't36', 293, [], [], 'fam1', 1 ).
test( 't37', 282, [], [], 'fam1', 1 ).
test( 't38', 214, [], [], 'fam1', 1 ).
test( 't39', 755, [], [], 'fam1', 1 ).
test( 't40', 568, ['m32','m33','m35','m25','m42','m22','m21','m15','m10','m27','m46'], [], 'fam1', 1 ).
test( 't41', 603, ['m34','m33','m47','m19','m18','m15','m36','m27','m2','m8','m23','m30','m26','m29','m28','m22'], [], 'fam1', 1 ).
test( 't42', 444, [], [], 'fam1', 1 ).
test( 't43', 479, [], [], 'fam1', 1 ).
test( 't44', 383, [], ['r1','r4'], 'fam1', 1 ).
test( 't45', 89, [], [], 'fam1', 1 ).
test( 't46', 713, [], [], 'fam1', 1 ).
test( 't47', 660, [], [], 'fam1', 1 ).
test( 't48', 725, ['m37','m3','m5','m49','m20','m48','m14'], ['r4'], 'fam1', 1 ).
test( 't49', 159, [], [], 'fam1', 1 ).
test( 't50', 765, [], ['r5'], 'fam1', 1 ).
test( 't51', 177, ['m17','m42'], [], 'fam1', 1 ).
test( 't52', 408, [], [], 'fam1', 1 ).
test( 't53', 702, ['m3','m26','m31','m41','m37','m33','m7'], [], 'fam1', 1 ).
test( 't54', 655, ['m19','m22','m14','m20','m45','m40','m23','m7','m49','m16'], ['r4','r1','r5'], 'fam1', 1 ).
test( 't55', 31, [], ['r1','r2','r3','r5'], 'fam1', 1 ).
test( 't56', 431, ['m50','m39'], [], 'fam1', 1 ).
test( 't57', 56, [], [], 'fam1', 1 ).
test( 't58', 424, [], [], 'fam1', 1 ).
test( 't59', 680, [], [], 'fam1', 1 ).
test( 't60', 124, [], [], 'fam1', 1 ).
test( 't61', 437, ['m11'], [], 'fam1', 1 ).
test( 't62', 608, [], [], 'fam1', 1 ).
test( 't63', 112, [], [], 'fam1', 1 ).
test( 't64', 181, [], ['r3','r2','r5'], 'fam1', 1 ).
test( 't65', 497, [], ['r4','r3'], 'fam1', 1 ).
test( 't66', 798, [], [], 'fam1', 1 ).
test( 't67', 247, [], ['r4'], 'fam1', 1 ).
test( 't68', 689, [], ['r5'], 'fam1', 1 ).
test( 't69', 636, ['m46','m18','m39','m45','m44','m25','m41'], [], 'fam1', 1 ).
test( 't70', 283, [], [], 'fam1', 1 ).
test( 't71', 77, [], [], 'fam1', 1 ).
test( 't72', 182, ['m11'], [], 'fam1', 1 ).
test( 't73', 423, [], [], 'fam1', 1 ).
test( 't74', 241, [], [], 'fam1', 1 ).
test( 't75', 637, [], [], 'fam1', 1 ).
test( 't76', 319, [], [], 'fam1', 1 ).
test( 't77', 164, [], ['r1','r4','r2'], 'fam1', 1 ).
test( 't78', 647, [], [], 'fam1', 1 ).
test( 't79', 646, ['m8','m13','m3','m11','m46','m49','m23','m16','m22','m7','m17','m47','m1','m24','m32','m28','m19','m38'], [], 'fam1', 1 ).
test( 't80', 625, [], [], 'fam1', 1 ).
test( 't81', 238, ['m40','m11','m4','m2','m16','m23','m43','m33','m26','m6','m31','m39','m17','m37','m22'], [], 'fam1', 1 ).
test( 't82', 347, ['m40','m2'], [], 'fam1', 1 ).
test( 't83', 266, [], ['r2'], 'fam1', 1 ).
test( 't84', 260, [], ['r2','r4'], 'fam1', 1 ).
test( 't85', 325, [], [], 'fam1', 1 ).
test( 't86', 375, [], [], 'fam1', 1 ).
test( 't87', 784, [], [], 'fam1', 1 ).
test( 't88', 584, ['m41','m9','m29','m35'], [], 'fam1', 1 ).
test( 't89', 270, [], ['r5','r3','r1','r4'], 'fam1', 1 ).
test( 't90', 780, [], [], 'fam1', 1 ).
test( 't91', 346, ['m34','m47','m23','m20','m1','m40','m16','m25','m8','m39'], [], 'fam1', 1 ).
test( 't92', 783, [], [], 'fam1', 1 ).
test( 't93', 153, [], [], 'fam1', 1 ).
test( 't94', 516, [], [], 'fam1', 1 ).
test( 't95', 477, [], ['r4','r3','r1','r5','r2'], 'fam1', 1 ).
test( 't96', 491, [], [], 'fam1', 1 ).
test( 't97', 566, [], [], 'fam1', 1 ).
test( 't98', 284, [], [], 'fam1', 1 ).
test( 't99', 414, [], [], 'fam1', 1 ).
test( 't100', 621, [], ['r1','r2','r4','r5'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').
embedded_board( 'm21').
embedded_board( 'm22').
embedded_board( 'm23').
embedded_board( 'm24').
embedded_board( 'm25').
embedded_board( 'm26').
embedded_board( 'm27').
embedded_board( 'm28').
embedded_board( 'm29').
embedded_board( 'm30').
embedded_board( 'm31').
embedded_board( 'm32').
embedded_board( 'm33').
embedded_board( 'm34').
embedded_board( 'm35').
embedded_board( 'm36').
embedded_board( 'm37').
embedded_board( 'm38').
embedded_board( 'm39').
embedded_board( 'm40').
embedded_board( 'm41').
embedded_board( 'm42').
embedded_board( 'm43').
embedded_board( 'm44').
embedded_board( 'm45').
embedded_board( 'm46').
embedded_board( 'm47').
embedded_board( 'm48').
embedded_board( 'm49').
embedded_board( 'm50').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
