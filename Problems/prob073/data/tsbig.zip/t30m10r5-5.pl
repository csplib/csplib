%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 42, [], [], 'fam1', 1 ).
test( 't2', 274, [], [], 'fam1', 1 ).
test( 't3', 573, [], [], 'fam1', 1 ).
test( 't4', 507, ['m9','m4'], [], 'fam1', 1 ).
test( 't5', 504, [], ['r1','r2','r5','r3','r4'], 'fam1', 1 ).
test( 't6', 81, [], [], 'fam1', 1 ).
test( 't7', 572, [], [], 'fam1', 1 ).
test( 't8', 703, ['m1','m9','m5','m10'], [], 'fam1', 1 ).
test( 't9', 345, ['m4','m2'], [], 'fam1', 1 ).
test( 't10', 314, [], ['r4','r1','r5','r2','r3'], 'fam1', 1 ).
test( 't11', 173, [], ['r5'], 'fam1', 1 ).
test( 't12', 113, ['m9','m1'], [], 'fam1', 1 ).
test( 't13', 681, [], ['r2','r3','r4','r1','r5'], 'fam1', 1 ).
test( 't14', 12, [], [], 'fam1', 1 ).
test( 't15', 677, [], ['r5','r1','r3','r2'], 'fam1', 1 ).
test( 't16', 716, [], ['r4','r1','r5'], 'fam1', 1 ).
test( 't17', 499, [], ['r3','r2','r1','r5','r4'], 'fam1', 1 ).
test( 't18', 364, [], [], 'fam1', 1 ).
test( 't19', 188, [], [], 'fam1', 1 ).
test( 't20', 591, [], [], 'fam1', 1 ).
test( 't21', 202, [], [], 'fam1', 1 ).
test( 't22', 689, ['m5','m6','m7','m3'], [], 'fam1', 1 ).
test( 't23', 65, [], [], 'fam1', 1 ).
test( 't24', 693, [], ['r4','r3'], 'fam1', 1 ).
test( 't25', 781, ['m2','m6','m10'], ['r4','r2','r1'], 'fam1', 1 ).
test( 't26', 297, [], ['r5','r4'], 'fam1', 1 ).
test( 't27', 269, [], [], 'fam1', 1 ).
test( 't28', 204, [], [], 'fam1', 1 ).
test( 't29', 417, ['m9','m7'], [], 'fam1', 1 ).
test( 't30', 378, [], ['r3','r1'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
