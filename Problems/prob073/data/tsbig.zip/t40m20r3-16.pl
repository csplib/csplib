%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 20
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 116, [], [], 'fam1', 1 ).
test( 't2', 136, ['m19'], [], 'fam1', 1 ).
test( 't3', 759, [], [], 'fam1', 1 ).
test( 't4', 362, [], [], 'fam1', 1 ).
test( 't5', 497, [], [], 'fam1', 1 ).
test( 't6', 593, [], [], 'fam1', 1 ).
test( 't7', 193, [], [], 'fam1', 1 ).
test( 't8', 104, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't9', 457, [], ['r1','r3'], 'fam1', 1 ).
test( 't10', 460, [], ['r2'], 'fam1', 1 ).
test( 't11', 752, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't12', 191, [], [], 'fam1', 1 ).
test( 't13', 664, [], [], 'fam1', 1 ).
test( 't14', 323, [], ['r1'], 'fam1', 1 ).
test( 't15', 545, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't16', 450, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't17', 391, [], [], 'fam1', 1 ).
test( 't18', 205, [], [], 'fam1', 1 ).
test( 't19', 48, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't20', 34, [], [], 'fam1', 1 ).
test( 't21', 374, [], ['r2','r3'], 'fam1', 1 ).
test( 't22', 733, [], [], 'fam1', 1 ).
test( 't23', 644, [], [], 'fam1', 1 ).
test( 't24', 589, [], [], 'fam1', 1 ).
test( 't25', 700, [], [], 'fam1', 1 ).
test( 't26', 430, [], [], 'fam1', 1 ).
test( 't27', 346, [], [], 'fam1', 1 ).
test( 't28', 622, [], [], 'fam1', 1 ).
test( 't29', 124, [], [], 'fam1', 1 ).
test( 't30', 105, ['m11','m9'], ['r3','r2'], 'fam1', 1 ).
test( 't31', 760, [], [], 'fam1', 1 ).
test( 't32', 311, [], [], 'fam1', 1 ).
test( 't33', 551, ['m15'], [], 'fam1', 1 ).
test( 't34', 713, [], [], 'fam1', 1 ).
test( 't35', 784, [], ['r3'], 'fam1', 1 ).
test( 't36', 800, [], ['r2'], 'fam1', 1 ).
test( 't37', 13, ['m8','m2','m18','m6','m4','m1'], [], 'fam1', 1 ).
test( 't38', 688, [], [], 'fam1', 1 ).
test( 't39', 191, [], [], 'fam1', 1 ).
test( 't40', 685, [], ['r3','r1'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
