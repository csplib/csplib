%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 95, [], ['r3'], 'fam1', 1 ).
test( 't2', 605, ['m9'], [], 'fam1', 1 ).
test( 't3', 541, [], [], 'fam1', 1 ).
test( 't4', 624, ['m6','m10','m8'], ['r5'], 'fam1', 1 ).
test( 't5', 173, ['m4','m9'], [], 'fam1', 1 ).
test( 't6', 78, [], [], 'fam1', 1 ).
test( 't7', 775, [], [], 'fam1', 1 ).
test( 't8', 756, ['m5','m9'], [], 'fam1', 1 ).
test( 't9', 424, [], [], 'fam1', 1 ).
test( 't10', 548, [], ['r5','r2','r1','r3','r4'], 'fam1', 1 ).
test( 't11', 158, ['m8','m10','m6'], ['r3','r2','r1'], 'fam1', 1 ).
test( 't12', 265, ['m7','m5','m3'], [], 'fam1', 1 ).
test( 't13', 597, [], [], 'fam1', 1 ).
test( 't14', 194, [], [], 'fam1', 1 ).
test( 't15', 691, [], [], 'fam1', 1 ).
test( 't16', 403, ['m6'], [], 'fam1', 1 ).
test( 't17', 567, ['m6','m2','m8','m4'], ['r5','r4','r1','r2'], 'fam1', 1 ).
test( 't18', 631, [], [], 'fam1', 1 ).
test( 't19', 151, [], [], 'fam1', 1 ).
test( 't20', 519, [], [], 'fam1', 1 ).
test( 't21', 556, [], ['r5'], 'fam1', 1 ).
test( 't22', 617, ['m6'], [], 'fam1', 1 ).
test( 't23', 168, [], [], 'fam1', 1 ).
test( 't24', 432, [], [], 'fam1', 1 ).
test( 't25', 104, [], ['r1','r4','r5','r2'], 'fam1', 1 ).
test( 't26', 246, [], [], 'fam1', 1 ).
test( 't27', 780, ['m10','m3','m9','m6'], [], 'fam1', 1 ).
test( 't28', 545, [], [], 'fam1', 1 ).
test( 't29', 379, ['m5','m6'], [], 'fam1', 1 ).
test( 't30', 61, ['m1','m4'], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
