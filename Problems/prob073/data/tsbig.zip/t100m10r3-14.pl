%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 592, [], [], 'fam1', 1 ).
test( 't2', 336, [], [], 'fam1', 1 ).
test( 't3', 745, [], [], 'fam1', 1 ).
test( 't4', 482, [], ['r2','r1'], 'fam1', 1 ).
test( 't5', 537, ['m7','m6','m5','m2'], ['r3','r1','r2'], 'fam1', 1 ).
test( 't6', 149, ['m6','m7'], [], 'fam1', 1 ).
test( 't7', 302, [], [], 'fam1', 1 ).
test( 't8', 185, [], [], 'fam1', 1 ).
test( 't9', 252, ['m3','m1','m2'], [], 'fam1', 1 ).
test( 't10', 213, [], [], 'fam1', 1 ).
test( 't11', 739, [], ['r3'], 'fam1', 1 ).
test( 't12', 466, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't13', 246, [], [], 'fam1', 1 ).
test( 't14', 516, [], [], 'fam1', 1 ).
test( 't15', 250, [], [], 'fam1', 1 ).
test( 't16', 8, ['m10','m1','m2','m8'], [], 'fam1', 1 ).
test( 't17', 661, [], [], 'fam1', 1 ).
test( 't18', 335, ['m10','m8','m7'], [], 'fam1', 1 ).
test( 't19', 262, [], [], 'fam1', 1 ).
test( 't20', 797, [], [], 'fam1', 1 ).
test( 't21', 354, [], ['r3'], 'fam1', 1 ).
test( 't22', 765, [], [], 'fam1', 1 ).
test( 't23', 380, [], ['r3'], 'fam1', 1 ).
test( 't24', 339, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't25', 602, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't26', 751, [], ['r2','r1'], 'fam1', 1 ).
test( 't27', 767, [], ['r1'], 'fam1', 1 ).
test( 't28', 45, [], [], 'fam1', 1 ).
test( 't29', 357, [], [], 'fam1', 1 ).
test( 't30', 86, [], [], 'fam1', 1 ).
test( 't31', 153, ['m9','m2','m10'], ['r2','r3'], 'fam1', 1 ).
test( 't32', 353, [], [], 'fam1', 1 ).
test( 't33', 23, [], [], 'fam1', 1 ).
test( 't34', 23, [], [], 'fam1', 1 ).
test( 't35', 261, [], [], 'fam1', 1 ).
test( 't36', 698, ['m1'], ['r1','r2'], 'fam1', 1 ).
test( 't37', 656, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't38', 75, ['m1'], [], 'fam1', 1 ).
test( 't39', 514, [], ['r1'], 'fam1', 1 ).
test( 't40', 745, [], [], 'fam1', 1 ).
test( 't41', 326, [], [], 'fam1', 1 ).
test( 't42', 370, [], [], 'fam1', 1 ).
test( 't43', 236, [], [], 'fam1', 1 ).
test( 't44', 558, [], [], 'fam1', 1 ).
test( 't45', 753, [], [], 'fam1', 1 ).
test( 't46', 642, [], [], 'fam1', 1 ).
test( 't47', 508, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't48', 701, [], [], 'fam1', 1 ).
test( 't49', 524, [], [], 'fam1', 1 ).
test( 't50', 500, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't51', 61, ['m4'], [], 'fam1', 1 ).
test( 't52', 245, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't53', 690, [], [], 'fam1', 1 ).
test( 't54', 771, [], [], 'fam1', 1 ).
test( 't55', 655, [], [], 'fam1', 1 ).
test( 't56', 68, [], ['r2','r1'], 'fam1', 1 ).
test( 't57', 492, [], ['r1'], 'fam1', 1 ).
test( 't58', 181, [], [], 'fam1', 1 ).
test( 't59', 526, [], ['r1','r3'], 'fam1', 1 ).
test( 't60', 150, [], [], 'fam1', 1 ).
test( 't61', 474, [], [], 'fam1', 1 ).
test( 't62', 241, [], [], 'fam1', 1 ).
test( 't63', 170, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't64', 254, [], [], 'fam1', 1 ).
test( 't65', 255, [], [], 'fam1', 1 ).
test( 't66', 441, [], [], 'fam1', 1 ).
test( 't67', 577, [], [], 'fam1', 1 ).
test( 't68', 572, ['m6'], [], 'fam1', 1 ).
test( 't69', 80, ['m7','m10','m3','m4'], [], 'fam1', 1 ).
test( 't70', 314, [], [], 'fam1', 1 ).
test( 't71', 315, [], ['r3','r1'], 'fam1', 1 ).
test( 't72', 758, [], [], 'fam1', 1 ).
test( 't73', 800, [], [], 'fam1', 1 ).
test( 't74', 303, ['m5'], [], 'fam1', 1 ).
test( 't75', 109, [], ['r2'], 'fam1', 1 ).
test( 't76', 606, [], [], 'fam1', 1 ).
test( 't77', 386, [], ['r3'], 'fam1', 1 ).
test( 't78', 753, [], [], 'fam1', 1 ).
test( 't79', 422, [], [], 'fam1', 1 ).
test( 't80', 44, [], [], 'fam1', 1 ).
test( 't81', 194, [], [], 'fam1', 1 ).
test( 't82', 34, [], [], 'fam1', 1 ).
test( 't83', 108, [], ['r2'], 'fam1', 1 ).
test( 't84', 595, [], ['r2'], 'fam1', 1 ).
test( 't85', 364, [], [], 'fam1', 1 ).
test( 't86', 485, [], [], 'fam1', 1 ).
test( 't87', 176, [], [], 'fam1', 1 ).
test( 't88', 285, [], [], 'fam1', 1 ).
test( 't89', 503, [], ['r3'], 'fam1', 1 ).
test( 't90', 657, [], [], 'fam1', 1 ).
test( 't91', 757, [], [], 'fam1', 1 ).
test( 't92', 448, [], [], 'fam1', 1 ).
test( 't93', 723, [], [], 'fam1', 1 ).
test( 't94', 273, [], [], 'fam1', 1 ).
test( 't95', 45, ['m5','m8','m4'], ['r1','r2'], 'fam1', 1 ).
test( 't96', 431, [], [], 'fam1', 1 ).
test( 't97', 20, [], [], 'fam1', 1 ).
test( 't98', 609, [], [], 'fam1', 1 ).
test( 't99', 319, [], [], 'fam1', 1 ).
test( 't100', 319, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
