%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 487, [], [], 'fam1', 1 ).
test( 't2', 624, [], ['r2','r3'], 'fam1', 1 ).
test( 't3', 678, [], [], 'fam1', 1 ).
test( 't4', 71, [], [], 'fam1', 1 ).
test( 't5', 545, ['m6'], [], 'fam1', 1 ).
test( 't6', 222, [], [], 'fam1', 1 ).
test( 't7', 12, [], [], 'fam1', 1 ).
test( 't8', 684, [], [], 'fam1', 1 ).
test( 't9', 721, [], [], 'fam1', 1 ).
test( 't10', 293, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't11', 508, [], [], 'fam1', 1 ).
test( 't12', 544, [], ['r2','r3'], 'fam1', 1 ).
test( 't13', 679, [], [], 'fam1', 1 ).
test( 't14', 569, [], [], 'fam1', 1 ).
test( 't15', 494, [], [], 'fam1', 1 ).
test( 't16', 526, [], [], 'fam1', 1 ).
test( 't17', 465, ['m9','m10','m7','m8'], ['r3','r2'], 'fam1', 1 ).
test( 't18', 331, [], [], 'fam1', 1 ).
test( 't19', 502, [], [], 'fam1', 1 ).
test( 't20', 104, [], [], 'fam1', 1 ).
test( 't21', 327, [], [], 'fam1', 1 ).
test( 't22', 476, ['m3'], ['r3','r1','r2'], 'fam1', 1 ).
test( 't23', 562, [], ['r1','r2'], 'fam1', 1 ).
test( 't24', 409, [], [], 'fam1', 1 ).
test( 't25', 499, [], [], 'fam1', 1 ).
test( 't26', 667, [], [], 'fam1', 1 ).
test( 't27', 697, [], ['r2'], 'fam1', 1 ).
test( 't28', 208, [], ['r1','r3'], 'fam1', 1 ).
test( 't29', 402, [], ['r2','r1'], 'fam1', 1 ).
test( 't30', 677, [], ['r2','r3'], 'fam1', 1 ).
test( 't31', 682, [], [], 'fam1', 1 ).
test( 't32', 399, [], [], 'fam1', 1 ).
test( 't33', 570, ['m9','m10'], ['r1','r2'], 'fam1', 1 ).
test( 't34', 423, [], [], 'fam1', 1 ).
test( 't35', 13, [], [], 'fam1', 1 ).
test( 't36', 453, [], [], 'fam1', 1 ).
test( 't37', 537, ['m5','m10','m3','m2'], [], 'fam1', 1 ).
test( 't38', 786, [], [], 'fam1', 1 ).
test( 't39', 252, [], [], 'fam1', 1 ).
test( 't40', 136, [], [], 'fam1', 1 ).
test( 't41', 559, ['m8'], ['r1','r2'], 'fam1', 1 ).
test( 't42', 191, [], [], 'fam1', 1 ).
test( 't43', 682, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't44', 776, [], [], 'fam1', 1 ).
test( 't45', 34, ['m1','m4','m7'], [], 'fam1', 1 ).
test( 't46', 430, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't47', 564, [], [], 'fam1', 1 ).
test( 't48', 471, [], [], 'fam1', 1 ).
test( 't49', 655, [], [], 'fam1', 1 ).
test( 't50', 715, [], [], 'fam1', 1 ).
test( 't51', 437, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't52', 24, [], [], 'fam1', 1 ).
test( 't53', 247, [], ['r2','r1'], 'fam1', 1 ).
test( 't54', 669, [], [], 'fam1', 1 ).
test( 't55', 695, [], ['r2'], 'fam1', 1 ).
test( 't56', 647, [], [], 'fam1', 1 ).
test( 't57', 596, ['m10','m6'], [], 'fam1', 1 ).
test( 't58', 179, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't59', 147, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't60', 456, [], ['r1'], 'fam1', 1 ).
test( 't61', 97, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't62', 563, [], [], 'fam1', 1 ).
test( 't63', 621, [], ['r1','r2'], 'fam1', 1 ).
test( 't64', 324, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't65', 520, ['m10','m3','m1'], [], 'fam1', 1 ).
test( 't66', 350, [], [], 'fam1', 1 ).
test( 't67', 197, [], [], 'fam1', 1 ).
test( 't68', 422, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't69', 708, [], [], 'fam1', 1 ).
test( 't70', 622, [], [], 'fam1', 1 ).
test( 't71', 197, ['m5','m7'], [], 'fam1', 1 ).
test( 't72', 564, ['m10','m7'], [], 'fam1', 1 ).
test( 't73', 423, [], [], 'fam1', 1 ).
test( 't74', 172, ['m10'], ['r1'], 'fam1', 1 ).
test( 't75', 515, [], [], 'fam1', 1 ).
test( 't76', 445, ['m1','m3','m5','m4'], [], 'fam1', 1 ).
test( 't77', 698, [], [], 'fam1', 1 ).
test( 't78', 514, [], [], 'fam1', 1 ).
test( 't79', 507, [], [], 'fam1', 1 ).
test( 't80', 385, ['m3'], [], 'fam1', 1 ).
test( 't81', 20, [], [], 'fam1', 1 ).
test( 't82', 61, ['m6'], [], 'fam1', 1 ).
test( 't83', 319, [], [], 'fam1', 1 ).
test( 't84', 506, ['m4'], [], 'fam1', 1 ).
test( 't85', 398, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't86', 664, [], [], 'fam1', 1 ).
test( 't87', 174, [], [], 'fam1', 1 ).
test( 't88', 207, [], ['r2'], 'fam1', 1 ).
test( 't89', 600, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't90', 467, [], ['r2'], 'fam1', 1 ).
test( 't91', 634, [], [], 'fam1', 1 ).
test( 't92', 701, [], [], 'fam1', 1 ).
test( 't93', 381, ['m8','m3','m10'], [], 'fam1', 1 ).
test( 't94', 358, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't95', 314, [], [], 'fam1', 1 ).
test( 't96', 551, [], ['r1','r2'], 'fam1', 1 ).
test( 't97', 260, ['m4'], [], 'fam1', 1 ).
test( 't98', 302, [], [], 'fam1', 1 ).
test( 't99', 391, [], ['r2'], 'fam1', 1 ).
test( 't100', 450, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
