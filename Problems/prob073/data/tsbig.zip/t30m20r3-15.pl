%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 20
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 218, [], ['r1','r2'], 'fam1', 1 ).
test( 't2', 667, [], [], 'fam1', 1 ).
test( 't3', 409, [], [], 'fam1', 1 ).
test( 't4', 347, ['m5','m18'], [], 'fam1', 1 ).
test( 't5', 402, [], [], 'fam1', 1 ).
test( 't6', 358, [], [], 'fam1', 1 ).
test( 't7', 657, [], ['r2','r3'], 'fam1', 1 ).
test( 't8', 781, ['m6','m15','m7','m17','m19','m16','m1','m3'], [], 'fam1', 1 ).
test( 't9', 544, [], [], 'fam1', 1 ).
test( 't10', 131, [], [], 'fam1', 1 ).
test( 't11', 537, [], [], 'fam1', 1 ).
test( 't12', 604, ['m20','m13','m18','m6','m2','m9','m7','m5'], ['r1'], 'fam1', 1 ).
test( 't13', 157, [], [], 'fam1', 1 ).
test( 't14', 386, ['m11','m16','m19','m15','m14'], [], 'fam1', 1 ).
test( 't15', 209, [], ['r3'], 'fam1', 1 ).
test( 't16', 246, [], [], 'fam1', 1 ).
test( 't17', 753, [], [], 'fam1', 1 ).
test( 't18', 643, [], ['r3','r2'], 'fam1', 1 ).
test( 't19', 120, [], [], 'fam1', 1 ).
test( 't20', 116, ['m7','m4','m3','m19'], [], 'fam1', 1 ).
test( 't21', 277, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't22', 331, [], [], 'fam1', 1 ).
test( 't23', 14, [], [], 'fam1', 1 ).
test( 't24', 413, [], [], 'fam1', 1 ).
test( 't25', 690, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't26', 301, ['m3','m12','m2','m18','m15','m11','m13','m16'], [], 'fam1', 1 ).
test( 't27', 202, [], [], 'fam1', 1 ).
test( 't28', 447, [], ['r2','r3'], 'fam1', 1 ).
test( 't29', 543, [], [], 'fam1', 1 ).
test( 't30', 531, [], ['r1','r2'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
