%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 20
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 309, [], ['r1'], 'fam1', 1 ).
test( 't2', 737, [], [], 'fam1', 1 ).
test( 't3', 759, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't4', 181, [], [], 'fam1', 1 ).
test( 't5', 462, [], [], 'fam1', 1 ).
test( 't6', 8, [], [], 'fam1', 1 ).
test( 't7', 780, [], [], 'fam1', 1 ).
test( 't8', 718, [], [], 'fam1', 1 ).
test( 't9', 245, [], [], 'fam1', 1 ).
test( 't10', 742, ['m11','m16','m2','m17','m7','m5','m14'], [], 'fam1', 1 ).
test( 't11', 641, [], [], 'fam1', 1 ).
test( 't12', 756, [], [], 'fam1', 1 ).
test( 't13', 536, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't14', 649, [], [], 'fam1', 1 ).
test( 't15', 578, [], [], 'fam1', 1 ).
test( 't16', 492, [], [], 'fam1', 1 ).
test( 't17', 624, ['m11'], ['r3','r1'], 'fam1', 1 ).
test( 't18', 72, [], [], 'fam1', 1 ).
test( 't19', 37, ['m12','m13','m17'], [], 'fam1', 1 ).
test( 't20', 127, [], [], 'fam1', 1 ).
test( 't21', 745, [], [], 'fam1', 1 ).
test( 't22', 241, [], ['r2','r1'], 'fam1', 1 ).
test( 't23', 144, ['m18','m9','m15','m13','m14'], [], 'fam1', 1 ).
test( 't24', 63, [], [], 'fam1', 1 ).
test( 't25', 398, [], [], 'fam1', 1 ).
test( 't26', 390, [], ['r1'], 'fam1', 1 ).
test( 't27', 578, ['m5','m19'], ['r2'], 'fam1', 1 ).
test( 't28', 639, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't29', 159, [], ['r1','r3'], 'fam1', 1 ).
test( 't30', 702, [], ['r2','r1'], 'fam1', 1 ).
test( 't31', 17, [], [], 'fam1', 1 ).
test( 't32', 676, [], [], 'fam1', 1 ).
test( 't33', 609, [], ['r1','r3'], 'fam1', 1 ).
test( 't34', 485, [], [], 'fam1', 1 ).
test( 't35', 88, [], ['r2','r1'], 'fam1', 1 ).
test( 't36', 551, [], [], 'fam1', 1 ).
test( 't37', 582, [], [], 'fam1', 1 ).
test( 't38', 682, [], ['r2'], 'fam1', 1 ).
test( 't39', 347, [], [], 'fam1', 1 ).
test( 't40', 740, [], [], 'fam1', 1 ).
test( 't41', 236, [], [], 'fam1', 1 ).
test( 't42', 554, [], [], 'fam1', 1 ).
test( 't43', 61, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't44', 445, [], [], 'fam1', 1 ).
test( 't45', 159, [], [], 'fam1', 1 ).
test( 't46', 590, [], [], 'fam1', 1 ).
test( 't47', 136, [], [], 'fam1', 1 ).
test( 't48', 402, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't49', 85, [], ['r2','r1'], 'fam1', 1 ).
test( 't50', 60, [], ['r3'], 'fam1', 1 ).
test( 't51', 146, [], [], 'fam1', 1 ).
test( 't52', 421, [], [], 'fam1', 1 ).
test( 't53', 680, ['m13','m7','m6','m18','m5','m4','m8','m19'], [], 'fam1', 1 ).
test( 't54', 423, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't55', 25, ['m11','m2'], [], 'fam1', 1 ).
test( 't56', 352, [], [], 'fam1', 1 ).
test( 't57', 565, [], ['r2'], 'fam1', 1 ).
test( 't58', 348, ['m2','m12','m11'], [], 'fam1', 1 ).
test( 't59', 654, [], ['r3'], 'fam1', 1 ).
test( 't60', 298, ['m3','m13','m1','m6','m19','m16'], [], 'fam1', 1 ).
test( 't61', 39, ['m7','m20','m15','m4'], [], 'fam1', 1 ).
test( 't62', 199, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't63', 751, [], [], 'fam1', 1 ).
test( 't64', 303, ['m1','m17'], ['r1','r2'], 'fam1', 1 ).
test( 't65', 431, [], [], 'fam1', 1 ).
test( 't66', 260, [], [], 'fam1', 1 ).
test( 't67', 26, [], [], 'fam1', 1 ).
test( 't68', 789, [], [], 'fam1', 1 ).
test( 't69', 495, ['m9','m2','m1','m7'], [], 'fam1', 1 ).
test( 't70', 56, [], [], 'fam1', 1 ).
test( 't71', 293, ['m5','m1','m4','m9','m8','m15'], [], 'fam1', 1 ).
test( 't72', 83, [], [], 'fam1', 1 ).
test( 't73', 636, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't74', 618, [], [], 'fam1', 1 ).
test( 't75', 488, ['m16','m6','m5'], [], 'fam1', 1 ).
test( 't76', 430, [], [], 'fam1', 1 ).
test( 't77', 86, [], [], 'fam1', 1 ).
test( 't78', 29, [], [], 'fam1', 1 ).
test( 't79', 246, [], [], 'fam1', 1 ).
test( 't80', 761, [], [], 'fam1', 1 ).
test( 't81', 420, ['m17'], [], 'fam1', 1 ).
test( 't82', 468, [], ['r1'], 'fam1', 1 ).
test( 't83', 414, [], [], 'fam1', 1 ).
test( 't84', 24, [], [], 'fam1', 1 ).
test( 't85', 784, [], [], 'fam1', 1 ).
test( 't86', 100, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't87', 201, ['m17','m9','m3','m8','m5','m20','m10'], [], 'fam1', 1 ).
test( 't88', 363, [], [], 'fam1', 1 ).
test( 't89', 591, [], [], 'fam1', 1 ).
test( 't90', 168, ['m6','m2'], [], 'fam1', 1 ).
test( 't91', 199, ['m14','m10','m16','m4'], [], 'fam1', 1 ).
test( 't92', 537, [], [], 'fam1', 1 ).
test( 't93', 673, [], [], 'fam1', 1 ).
test( 't94', 363, [], [], 'fam1', 1 ).
test( 't95', 603, ['m4','m20','m9','m15','m13','m17','m11','m5'], [], 'fam1', 1 ).
test( 't96', 153, [], [], 'fam1', 1 ).
test( 't97', 87, [], ['r2'], 'fam1', 1 ).
test( 't98', 411, ['m7','m4','m2','m20'], ['r1'], 'fam1', 1 ).
test( 't99', 361, [], [], 'fam1', 1 ).
test( 't100', 608, [], ['r2','r3','r1'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
