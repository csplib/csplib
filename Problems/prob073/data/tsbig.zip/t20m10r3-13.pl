%% ****  Testsuite  ****
% Number of tests                  : 20
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 702, [], [], 'fam1', 1 ).
test( 't2', 752, [], [], 'fam1', 1 ).
test( 't3', 445, [], [], 'fam1', 1 ).
test( 't4', 480, ['m4'], ['r3','r1','r2'], 'fam1', 1 ).
test( 't5', 497, [], ['r1'], 'fam1', 1 ).
test( 't6', 665, [], [], 'fam1', 1 ).
test( 't7', 275, [], [], 'fam1', 1 ).
test( 't8', 580, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't9', 508, ['m7','m8','m10'], [], 'fam1', 1 ).
test( 't10', 700, [], [], 'fam1', 1 ).
test( 't11', 383, [], [], 'fam1', 1 ).
test( 't12', 703, [], [], 'fam1', 1 ).
test( 't13', 261, [], [], 'fam1', 1 ).
test( 't14', 318, [], [], 'fam1', 1 ).
test( 't15', 664, [], ['r3','r1'], 'fam1', 1 ).
test( 't16', 93, [], ['r3','r1'], 'fam1', 1 ).
test( 't17', 785, ['m3','m1','m4'], ['r3','r2','r1'], 'fam1', 1 ).
test( 't18', 724, [], [], 'fam1', 1 ).
test( 't19', 345, ['m1','m4'], [], 'fam1', 1 ).
test( 't20', 680, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
