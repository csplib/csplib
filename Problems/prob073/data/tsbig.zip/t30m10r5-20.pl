%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 308, [], [], 'fam1', 1 ).
test( 't2', 723, [], [], 'fam1', 1 ).
test( 't3', 226, [], [], 'fam1', 1 ).
test( 't4', 133, [], ['r5','r4','r2','r1','r3'], 'fam1', 1 ).
test( 't5', 473, [], ['r1','r5'], 'fam1', 1 ).
test( 't6', 59, ['m6','m2','m4'], [], 'fam1', 1 ).
test( 't7', 288, ['m1','m5','m8'], [], 'fam1', 1 ).
test( 't8', 98, [], [], 'fam1', 1 ).
test( 't9', 55, ['m7'], [], 'fam1', 1 ).
test( 't10', 62, ['m9','m6'], [], 'fam1', 1 ).
test( 't11', 296, ['m2','m10','m9','m7'], ['r3','r2','r1'], 'fam1', 1 ).
test( 't12', 654, ['m1','m4','m3','m10'], [], 'fam1', 1 ).
test( 't13', 248, [], [], 'fam1', 1 ).
test( 't14', 400, [], [], 'fam1', 1 ).
test( 't15', 103, [], [], 'fam1', 1 ).
test( 't16', 107, [], [], 'fam1', 1 ).
test( 't17', 584, [], ['r3','r1','r5'], 'fam1', 1 ).
test( 't18', 259, [], [], 'fam1', 1 ).
test( 't19', 613, [], [], 'fam1', 1 ).
test( 't20', 284, [], [], 'fam1', 1 ).
test( 't21', 62, [], ['r4','r3'], 'fam1', 1 ).
test( 't22', 519, ['m1','m10','m3','m5'], [], 'fam1', 1 ).
test( 't23', 575, [], ['r2','r4'], 'fam1', 1 ).
test( 't24', 339, [], [], 'fam1', 1 ).
test( 't25', 74, [], ['r5','r4'], 'fam1', 1 ).
test( 't26', 57, [], [], 'fam1', 1 ).
test( 't27', 325, [], [], 'fam1', 1 ).
test( 't28', 673, [], [], 'fam1', 1 ).
test( 't29', 321, [], [], 'fam1', 1 ).
test( 't30', 95, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
