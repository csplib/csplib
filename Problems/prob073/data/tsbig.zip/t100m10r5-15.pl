%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 394, ['m4'], ['r2'], 'fam1', 1 ).
test( 't2', 799, [], [], 'fam1', 1 ).
test( 't3', 328, [], ['r1','r5','r2'], 'fam1', 1 ).
test( 't4', 104, [], ['r2'], 'fam1', 1 ).
test( 't5', 61, ['m9','m5'], ['r2'], 'fam1', 1 ).
test( 't6', 99, [], [], 'fam1', 1 ).
test( 't7', 481, ['m3'], ['r4'], 'fam1', 1 ).
test( 't8', 29, [], [], 'fam1', 1 ).
test( 't9', 369, [], [], 'fam1', 1 ).
test( 't10', 306, [], [], 'fam1', 1 ).
test( 't11', 383, ['m9','m3'], [], 'fam1', 1 ).
test( 't12', 152, [], [], 'fam1', 1 ).
test( 't13', 669, [], [], 'fam1', 1 ).
test( 't14', 449, [], [], 'fam1', 1 ).
test( 't15', 738, ['m6'], [], 'fam1', 1 ).
test( 't16', 690, ['m4','m6','m9','m3'], ['r1','r2','r4'], 'fam1', 1 ).
test( 't17', 736, [], [], 'fam1', 1 ).
test( 't18', 258, [], [], 'fam1', 1 ).
test( 't19', 734, [], [], 'fam1', 1 ).
test( 't20', 97, ['m2'], [], 'fam1', 1 ).
test( 't21', 163, [], [], 'fam1', 1 ).
test( 't22', 683, ['m4','m8'], [], 'fam1', 1 ).
test( 't23', 210, ['m8','m9','m6','m5'], [], 'fam1', 1 ).
test( 't24', 669, [], ['r3','r2','r5'], 'fam1', 1 ).
test( 't25', 304, [], [], 'fam1', 1 ).
test( 't26', 388, [], [], 'fam1', 1 ).
test( 't27', 152, [], ['r5','r1','r4'], 'fam1', 1 ).
test( 't28', 441, [], [], 'fam1', 1 ).
test( 't29', 66, [], [], 'fam1', 1 ).
test( 't30', 323, [], [], 'fam1', 1 ).
test( 't31', 14, [], [], 'fam1', 1 ).
test( 't32', 453, [], [], 'fam1', 1 ).
test( 't33', 151, [], [], 'fam1', 1 ).
test( 't34', 458, ['m1','m7','m4'], [], 'fam1', 1 ).
test( 't35', 527, [], [], 'fam1', 1 ).
test( 't36', 125, [], [], 'fam1', 1 ).
test( 't37', 365, [], [], 'fam1', 1 ).
test( 't38', 582, [], [], 'fam1', 1 ).
test( 't39', 495, [], [], 'fam1', 1 ).
test( 't40', 195, ['m3'], [], 'fam1', 1 ).
test( 't41', 518, [], [], 'fam1', 1 ).
test( 't42', 175, ['m6','m4','m2','m1'], [], 'fam1', 1 ).
test( 't43', 675, [], ['r1','r5','r2','r4'], 'fam1', 1 ).
test( 't44', 268, ['m6','m7','m5'], [], 'fam1', 1 ).
test( 't45', 157, [], ['r1','r5','r4','r2'], 'fam1', 1 ).
test( 't46', 144, [], [], 'fam1', 1 ).
test( 't47', 273, ['m8','m1','m3'], ['r2','r5','r4','r3'], 'fam1', 1 ).
test( 't48', 676, ['m8'], [], 'fam1', 1 ).
test( 't49', 722, [], [], 'fam1', 1 ).
test( 't50', 592, [], [], 'fam1', 1 ).
test( 't51', 539, [], [], 'fam1', 1 ).
test( 't52', 695, ['m5','m1'], ['r3'], 'fam1', 1 ).
test( 't53', 131, [], ['r4','r2'], 'fam1', 1 ).
test( 't54', 575, ['m2','m6','m5'], [], 'fam1', 1 ).
test( 't55', 448, [], [], 'fam1', 1 ).
test( 't56', 480, [], [], 'fam1', 1 ).
test( 't57', 696, [], [], 'fam1', 1 ).
test( 't58', 184, [], ['r1'], 'fam1', 1 ).
test( 't59', 617, ['m3'], [], 'fam1', 1 ).
test( 't60', 125, [], [], 'fam1', 1 ).
test( 't61', 171, [], [], 'fam1', 1 ).
test( 't62', 183, ['m4'], [], 'fam1', 1 ).
test( 't63', 378, ['m7','m9'], [], 'fam1', 1 ).
test( 't64', 664, [], [], 'fam1', 1 ).
test( 't65', 704, [], [], 'fam1', 1 ).
test( 't66', 692, [], [], 'fam1', 1 ).
test( 't67', 576, [], ['r4','r5'], 'fam1', 1 ).
test( 't68', 608, [], [], 'fam1', 1 ).
test( 't69', 640, [], [], 'fam1', 1 ).
test( 't70', 700, [], [], 'fam1', 1 ).
test( 't71', 7, [], [], 'fam1', 1 ).
test( 't72', 527, [], [], 'fam1', 1 ).
test( 't73', 500, [], [], 'fam1', 1 ).
test( 't74', 313, [], [], 'fam1', 1 ).
test( 't75', 466, [], [], 'fam1', 1 ).
test( 't76', 178, [], [], 'fam1', 1 ).
test( 't77', 229, [], [], 'fam1', 1 ).
test( 't78', 85, [], [], 'fam1', 1 ).
test( 't79', 14, [], [], 'fam1', 1 ).
test( 't80', 605, [], [], 'fam1', 1 ).
test( 't81', 501, [], [], 'fam1', 1 ).
test( 't82', 402, [], ['r1','r5','r4','r3','r2'], 'fam1', 1 ).
test( 't83', 228, [], [], 'fam1', 1 ).
test( 't84', 6, [], [], 'fam1', 1 ).
test( 't85', 93, [], [], 'fam1', 1 ).
test( 't86', 221, [], [], 'fam1', 1 ).
test( 't87', 605, [], ['r2','r4','r5','r1','r3'], 'fam1', 1 ).
test( 't88', 376, [], ['r3','r4','r1','r2','r5'], 'fam1', 1 ).
test( 't89', 67, [], [], 'fam1', 1 ).
test( 't90', 708, [], [], 'fam1', 1 ).
test( 't91', 622, [], [], 'fam1', 1 ).
test( 't92', 76, ['m2'], ['r4','r1','r3','r2'], 'fam1', 1 ).
test( 't93', 750, ['m1','m7','m9'], [], 'fam1', 1 ).
test( 't94', 570, [], [], 'fam1', 1 ).
test( 't95', 401, ['m4','m8','m10','m6'], ['r4','r1'], 'fam1', 1 ).
test( 't96', 96, [], [], 'fam1', 1 ).
test( 't97', 359, [], [], 'fam1', 1 ).
test( 't98', 260, ['m6','m3','m8'], ['r3'], 'fam1', 1 ).
test( 't99', 64, [], [], 'fam1', 1 ).
test( 't100', 652, [], ['r5','r3','r1','r2','r4'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
