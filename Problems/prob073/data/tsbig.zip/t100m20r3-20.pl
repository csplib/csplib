%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 20
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 96, [], [], 'fam1', 1 ).
test( 't2', 318, ['m11','m13','m20','m17','m18','m6','m12','m10'], [], 'fam1', 1 ).
test( 't3', 579, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't4', 282, ['m10','m4','m13','m8','m3','m17'], ['r2','r1','r3'], 'fam1', 1 ).
test( 't5', 564, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't6', 325, ['m7','m8','m20'], [], 'fam1', 1 ).
test( 't7', 645, [], [], 'fam1', 1 ).
test( 't8', 708, ['m17','m6'], [], 'fam1', 1 ).
test( 't9', 757, [], [], 'fam1', 1 ).
test( 't10', 385, [], [], 'fam1', 1 ).
test( 't11', 55, ['m15','m7'], [], 'fam1', 1 ).
test( 't12', 712, ['m1'], [], 'fam1', 1 ).
test( 't13', 400, [], ['r1','r2'], 'fam1', 1 ).
test( 't14', 644, ['m20','m11','m2'], [], 'fam1', 1 ).
test( 't15', 249, ['m6','m7','m11','m9','m14','m15','m18','m1'], ['r3'], 'fam1', 1 ).
test( 't16', 625, [], [], 'fam1', 1 ).
test( 't17', 272, [], ['r2'], 'fam1', 1 ).
test( 't18', 633, [], [], 'fam1', 1 ).
test( 't19', 354, [], [], 'fam1', 1 ).
test( 't20', 199, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't21', 648, ['m19','m4','m11','m12','m2'], [], 'fam1', 1 ).
test( 't22', 688, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't23', 480, ['m13','m14','m4','m3'], [], 'fam1', 1 ).
test( 't24', 654, ['m9','m10','m11','m19','m1','m16','m3','m20'], [], 'fam1', 1 ).
test( 't25', 129, [], [], 'fam1', 1 ).
test( 't26', 130, [], [], 'fam1', 1 ).
test( 't27', 383, ['m11','m14','m13','m17'], [], 'fam1', 1 ).
test( 't28', 500, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't29', 495, [], [], 'fam1', 1 ).
test( 't30', 128, [], [], 'fam1', 1 ).
test( 't31', 105, ['m2','m8','m3','m12','m7','m1','m5'], [], 'fam1', 1 ).
test( 't32', 689, [], [], 'fam1', 1 ).
test( 't33', 173, [], [], 'fam1', 1 ).
test( 't34', 630, ['m9','m19','m14','m17','m5','m1'], [], 'fam1', 1 ).
test( 't35', 634, [], [], 'fam1', 1 ).
test( 't36', 82, [], [], 'fam1', 1 ).
test( 't37', 196, [], ['r1','r3'], 'fam1', 1 ).
test( 't38', 620, [], [], 'fam1', 1 ).
test( 't39', 334, [], [], 'fam1', 1 ).
test( 't40', 714, [], [], 'fam1', 1 ).
test( 't41', 5, [], [], 'fam1', 1 ).
test( 't42', 763, ['m4','m5','m9','m15','m20','m12','m14'], ['r1','r3','r2'], 'fam1', 1 ).
test( 't43', 339, [], [], 'fam1', 1 ).
test( 't44', 397, [], [], 'fam1', 1 ).
test( 't45', 610, [], [], 'fam1', 1 ).
test( 't46', 90, [], ['r1'], 'fam1', 1 ).
test( 't47', 83, [], [], 'fam1', 1 ).
test( 't48', 441, [], [], 'fam1', 1 ).
test( 't49', 470, ['m20'], [], 'fam1', 1 ).
test( 't50', 180, [], [], 'fam1', 1 ).
test( 't51', 630, [], ['r3','r1'], 'fam1', 1 ).
test( 't52', 699, ['m3','m16','m7','m17'], ['r2','r3','r1'], 'fam1', 1 ).
test( 't53', 175, ['m1','m10','m9'], [], 'fam1', 1 ).
test( 't54', 232, [], [], 'fam1', 1 ).
test( 't55', 542, ['m16','m7'], ['r3','r1'], 'fam1', 1 ).
test( 't56', 487, ['m6','m2','m15','m4','m18'], [], 'fam1', 1 ).
test( 't57', 291, [], [], 'fam1', 1 ).
test( 't58', 72, [], [], 'fam1', 1 ).
test( 't59', 222, [], [], 'fam1', 1 ).
test( 't60', 130, [], [], 'fam1', 1 ).
test( 't61', 535, [], [], 'fam1', 1 ).
test( 't62', 687, [], [], 'fam1', 1 ).
test( 't63', 538, [], [], 'fam1', 1 ).
test( 't64', 520, [], [], 'fam1', 1 ).
test( 't65', 226, ['m6','m8','m12','m16','m19','m7'], [], 'fam1', 1 ).
test( 't66', 115, [], [], 'fam1', 1 ).
test( 't67', 504, [], [], 'fam1', 1 ).
test( 't68', 201, [], [], 'fam1', 1 ).
test( 't69', 672, [], ['r2'], 'fam1', 1 ).
test( 't70', 67, [], ['r1','r2'], 'fam1', 1 ).
test( 't71', 546, ['m9','m15','m18','m1','m13','m6'], [], 'fam1', 1 ).
test( 't72', 620, [], [], 'fam1', 1 ).
test( 't73', 367, [], [], 'fam1', 1 ).
test( 't74', 474, [], [], 'fam1', 1 ).
test( 't75', 559, ['m15','m2','m14','m8','m6','m1'], [], 'fam1', 1 ).
test( 't76', 314, [], [], 'fam1', 1 ).
test( 't77', 222, [], [], 'fam1', 1 ).
test( 't78', 661, [], [], 'fam1', 1 ).
test( 't79', 766, [], [], 'fam1', 1 ).
test( 't80', 250, [], [], 'fam1', 1 ).
test( 't81', 600, ['m16'], [], 'fam1', 1 ).
test( 't82', 660, [], [], 'fam1', 1 ).
test( 't83', 340, [], [], 'fam1', 1 ).
test( 't84', 790, [], [], 'fam1', 1 ).
test( 't85', 187, [], [], 'fam1', 1 ).
test( 't86', 379, [], [], 'fam1', 1 ).
test( 't87', 725, ['m9','m14','m11','m2','m1','m4'], ['r2'], 'fam1', 1 ).
test( 't88', 144, [], [], 'fam1', 1 ).
test( 't89', 121, [], [], 'fam1', 1 ).
test( 't90', 729, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't91', 304, [], ['r3'], 'fam1', 1 ).
test( 't92', 741, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't93', 198, ['m20','m1','m6','m8','m17','m19'], [], 'fam1', 1 ).
test( 't94', 633, [], [], 'fam1', 1 ).
test( 't95', 412, [], [], 'fam1', 1 ).
test( 't96', 239, [], [], 'fam1', 1 ).
test( 't97', 353, [], [], 'fam1', 1 ).
test( 't98', 602, ['m20','m17','m19','m4','m10'], [], 'fam1', 1 ).
test( 't99', 147, [], ['r1','r3'], 'fam1', 1 ).
test( 't100', 291, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
