%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 20
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 599, ['m20','m6','m17','m9','m8','m16'], [], 'fam1', 1 ).
test( 't2', 696, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't3', 315, [], [], 'fam1', 1 ).
test( 't4', 499, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't5', 56, [], [], 'fam1', 1 ).
test( 't6', 580, [], [], 'fam1', 1 ).
test( 't7', 673, [], [], 'fam1', 1 ).
test( 't8', 601, [], [], 'fam1', 1 ).
test( 't9', 29, [], [], 'fam1', 1 ).
test( 't10', 498, [], ['r1','r2'], 'fam1', 1 ).
test( 't11', 723, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't12', 548, ['m4','m6','m16'], [], 'fam1', 1 ).
test( 't13', 300, ['m18','m10','m13','m14','m6','m16'], [], 'fam1', 1 ).
test( 't14', 750, ['m11','m12','m18','m16','m7'], [], 'fam1', 1 ).
test( 't15', 775, ['m10','m3','m9','m13','m1','m16','m6'], [], 'fam1', 1 ).
test( 't16', 641, [], ['r2','r1'], 'fam1', 1 ).
test( 't17', 801, [], ['r3','r1'], 'fam1', 1 ).
test( 't18', 95, [], [], 'fam1', 1 ).
test( 't19', 91, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't20', 410, ['m14','m11','m2','m7','m4','m20','m15','m9'], [], 'fam1', 1 ).
test( 't21', 173, ['m14','m3','m9'], ['r2'], 'fam1', 1 ).
test( 't22', 25, ['m13'], ['r2'], 'fam1', 1 ).
test( 't23', 190, [], [], 'fam1', 1 ).
test( 't24', 60, ['m9','m6','m14','m8','m15','m1'], [], 'fam1', 1 ).
test( 't25', 364, [], [], 'fam1', 1 ).
test( 't26', 786, [], [], 'fam1', 1 ).
test( 't27', 467, [], [], 'fam1', 1 ).
test( 't28', 715, [], ['r1'], 'fam1', 1 ).
test( 't29', 144, [], ['r2'], 'fam1', 1 ).
test( 't30', 592, [], [], 'fam1', 1 ).
test( 't31', 704, [], [], 'fam1', 1 ).
test( 't32', 259, [], [], 'fam1', 1 ).
test( 't33', 235, ['m10','m12'], [], 'fam1', 1 ).
test( 't34', 203, [], [], 'fam1', 1 ).
test( 't35', 87, [], ['r1','r3'], 'fam1', 1 ).
test( 't36', 668, [], [], 'fam1', 1 ).
test( 't37', 793, [], ['r3'], 'fam1', 1 ).
test( 't38', 77, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't39', 435, [], [], 'fam1', 1 ).
test( 't40', 610, [], ['r2','r3'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
