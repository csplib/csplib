%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 88, [], [], 'fam1', 1 ).
test( 't2', 740, [], [], 'fam1', 1 ).
test( 't3', 752, ['m4','m1','m3','m10'], [], 'fam1', 1 ).
test( 't4', 503, [], [], 'fam1', 1 ).
test( 't5', 536, [], [], 'fam1', 1 ).
test( 't6', 537, [], [], 'fam1', 1 ).
test( 't7', 300, [], [], 'fam1', 1 ).
test( 't8', 668, [], [], 'fam1', 1 ).
test( 't9', 332, ['m9','m7','m3'], [], 'fam1', 1 ).
test( 't10', 693, [], [], 'fam1', 1 ).
test( 't11', 30, [], [], 'fam1', 1 ).
test( 't12', 249, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't13', 673, [], [], 'fam1', 1 ).
test( 't14', 391, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't15', 51, [], [], 'fam1', 1 ).
test( 't16', 386, ['m8','m9'], [], 'fam1', 1 ).
test( 't17', 328, [], [], 'fam1', 1 ).
test( 't18', 313, [], ['r3'], 'fam1', 1 ).
test( 't19', 103, [], [], 'fam1', 1 ).
test( 't20', 190, [], ['r3'], 'fam1', 1 ).
test( 't21', 741, ['m4','m1'], [], 'fam1', 1 ).
test( 't22', 800, [], [], 'fam1', 1 ).
test( 't23', 425, ['m10'], [], 'fam1', 1 ).
test( 't24', 552, [], [], 'fam1', 1 ).
test( 't25', 749, [], [], 'fam1', 1 ).
test( 't26', 31, ['m8','m3','m4','m1'], [], 'fam1', 1 ).
test( 't27', 632, [], [], 'fam1', 1 ).
test( 't28', 690, [], [], 'fam1', 1 ).
test( 't29', 530, ['m2','m6','m8','m7'], [], 'fam1', 1 ).
test( 't30', 706, [], [], 'fam1', 1 ).
test( 't31', 131, [], [], 'fam1', 1 ).
test( 't32', 377, ['m2','m8','m3'], [], 'fam1', 1 ).
test( 't33', 505, [], ['r3'], 'fam1', 1 ).
test( 't34', 656, ['m5','m10','m8'], [], 'fam1', 1 ).
test( 't35', 654, [], [], 'fam1', 1 ).
test( 't36', 720, [], [], 'fam1', 1 ).
test( 't37', 757, [], [], 'fam1', 1 ).
test( 't38', 90, ['m10','m2','m9'], [], 'fam1', 1 ).
test( 't39', 331, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't40', 450, [], [], 'fam1', 1 ).
test( 't41', 103, [], [], 'fam1', 1 ).
test( 't42', 276, [], [], 'fam1', 1 ).
test( 't43', 571, [], [], 'fam1', 1 ).
test( 't44', 782, [], ['r3','r1'], 'fam1', 1 ).
test( 't45', 568, ['m10'], ['r1'], 'fam1', 1 ).
test( 't46', 772, [], [], 'fam1', 1 ).
test( 't47', 106, [], ['r2'], 'fam1', 1 ).
test( 't48', 198, ['m1','m3','m5','m10'], [], 'fam1', 1 ).
test( 't49', 183, [], [], 'fam1', 1 ).
test( 't50', 800, ['m6','m7'], [], 'fam1', 1 ).
test( 't51', 705, ['m8'], ['r3','r2'], 'fam1', 1 ).
test( 't52', 140, [], [], 'fam1', 1 ).
test( 't53', 107, [], [], 'fam1', 1 ).
test( 't54', 542, [], [], 'fam1', 1 ).
test( 't55', 597, [], [], 'fam1', 1 ).
test( 't56', 97, [], [], 'fam1', 1 ).
test( 't57', 580, [], [], 'fam1', 1 ).
test( 't58', 59, ['m1'], [], 'fam1', 1 ).
test( 't59', 325, [], ['r2'], 'fam1', 1 ).
test( 't60', 336, [], [], 'fam1', 1 ).
test( 't61', 76, [], [], 'fam1', 1 ).
test( 't62', 482, [], [], 'fam1', 1 ).
test( 't63', 776, [], [], 'fam1', 1 ).
test( 't64', 428, ['m10','m3'], ['r2','r1','r3'], 'fam1', 1 ).
test( 't65', 237, [], ['r3'], 'fam1', 1 ).
test( 't66', 433, ['m9','m8','m6','m5'], ['r2'], 'fam1', 1 ).
test( 't67', 701, [], [], 'fam1', 1 ).
test( 't68', 220, [], [], 'fam1', 1 ).
test( 't69', 478, ['m2','m7','m1','m8'], [], 'fam1', 1 ).
test( 't70', 102, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't71', 32, [], ['r2','r3'], 'fam1', 1 ).
test( 't72', 617, ['m10','m3'], ['r3','r1','r2'], 'fam1', 1 ).
test( 't73', 454, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't74', 360, [], ['r3','r1'], 'fam1', 1 ).
test( 't75', 541, ['m8'], [], 'fam1', 1 ).
test( 't76', 107, [], [], 'fam1', 1 ).
test( 't77', 609, ['m1','m4','m10'], ['r2','r3'], 'fam1', 1 ).
test( 't78', 730, [], [], 'fam1', 1 ).
test( 't79', 107, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't80', 274, [], [], 'fam1', 1 ).
test( 't81', 589, [], [], 'fam1', 1 ).
test( 't82', 305, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't83', 249, [], [], 'fam1', 1 ).
test( 't84', 96, [], [], 'fam1', 1 ).
test( 't85', 365, [], ['r2','r3'], 'fam1', 1 ).
test( 't86', 651, [], [], 'fam1', 1 ).
test( 't87', 163, [], ['r2','r1'], 'fam1', 1 ).
test( 't88', 202, [], [], 'fam1', 1 ).
test( 't89', 560, ['m9','m10','m4','m5'], [], 'fam1', 1 ).
test( 't90', 571, [], [], 'fam1', 1 ).
test( 't91', 104, [], [], 'fam1', 1 ).
test( 't92', 740, [], [], 'fam1', 1 ).
test( 't93', 720, [], [], 'fam1', 1 ).
test( 't94', 437, [], [], 'fam1', 1 ).
test( 't95', 230, ['m3','m5','m2','m1'], [], 'fam1', 1 ).
test( 't96', 157, ['m6','m1'], [], 'fam1', 1 ).
test( 't97', 145, [], [], 'fam1', 1 ).
test( 't98', 318, ['m3'], [], 'fam1', 1 ).
test( 't99', 531, [], [], 'fam1', 1 ).
test( 't100', 481, ['m2'], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
