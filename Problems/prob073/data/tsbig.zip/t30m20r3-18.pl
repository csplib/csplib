%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 20
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 800, [], [], 'fam1', 1 ).
test( 't2', 182, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't3', 258, [], [], 'fam1', 1 ).
test( 't4', 429, [], [], 'fam1', 1 ).
test( 't5', 80, [], ['r2','r1'], 'fam1', 1 ).
test( 't6', 724, [], [], 'fam1', 1 ).
test( 't7', 741, [], ['r3','r2'], 'fam1', 1 ).
test( 't8', 165, [], [], 'fam1', 1 ).
test( 't9', 171, [], ['r2','r1'], 'fam1', 1 ).
test( 't10', 665, [], [], 'fam1', 1 ).
test( 't11', 71, [], [], 'fam1', 1 ).
test( 't12', 363, ['m12','m18','m11'], [], 'fam1', 1 ).
test( 't13', 791, [], [], 'fam1', 1 ).
test( 't14', 747, [], ['r1','r2'], 'fam1', 1 ).
test( 't15', 259, [], ['r3'], 'fam1', 1 ).
test( 't16', 6, ['m9','m14','m19','m12','m18'], ['r3'], 'fam1', 1 ).
test( 't17', 58, [], [], 'fam1', 1 ).
test( 't18', 228, [], [], 'fam1', 1 ).
test( 't19', 744, [], [], 'fam1', 1 ).
test( 't20', 254, [], [], 'fam1', 1 ).
test( 't21', 578, [], [], 'fam1', 1 ).
test( 't22', 373, [], [], 'fam1', 1 ).
test( 't23', 389, ['m17','m5','m18','m10'], ['r1','r2'], 'fam1', 1 ).
test( 't24', 114, [], [], 'fam1', 1 ).
test( 't25', 475, [], [], 'fam1', 1 ).
test( 't26', 790, ['m12','m15','m13','m7','m18','m2','m4'], [], 'fam1', 1 ).
test( 't27', 290, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't28', 119, [], [], 'fam1', 1 ).
test( 't29', 53, [], ['r2','r1'], 'fam1', 1 ).
test( 't30', 548, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
