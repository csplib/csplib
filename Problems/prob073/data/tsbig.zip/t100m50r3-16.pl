%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 50
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 720, ['m44','m19','m1','m18','m20','m3','m16','m12','m23','m30','m36','m22','m10','m38','m42'], [], 'fam1', 1 ).
test( 't2', 186, [], [], 'fam1', 1 ).
test( 't3', 39, ['m47','m29','m46','m49','m35','m44','m5','m41','m43','m2','m22','m38','m45','m4','m40'], [], 'fam1', 1 ).
test( 't4', 251, [], [], 'fam1', 1 ).
test( 't5', 571, [], ['r2','r3'], 'fam1', 1 ).
test( 't6', 106, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't7', 568, [], [], 'fam1', 1 ).
test( 't8', 361, [], ['r2'], 'fam1', 1 ).
test( 't9', 40, [], [], 'fam1', 1 ).
test( 't10', 796, [], [], 'fam1', 1 ).
test( 't11', 332, [], [], 'fam1', 1 ).
test( 't12', 616, ['m12','m24','m37','m10','m43','m8','m21','m11','m14','m27','m41'], ['r1','r3'], 'fam1', 1 ).
test( 't13', 418, [], [], 'fam1', 1 ).
test( 't14', 231, [], [], 'fam1', 1 ).
test( 't15', 492, [], [], 'fam1', 1 ).
test( 't16', 29, [], [], 'fam1', 1 ).
test( 't17', 32, [], [], 'fam1', 1 ).
test( 't18', 749, ['m32','m6','m14','m21','m7','m20','m28','m33','m19','m5','m4','m39','m18','m37'], [], 'fam1', 1 ).
test( 't19', 513, ['m9','m29','m43','m15','m28','m11','m46','m34','m35','m8','m21','m27','m36','m20','m14','m24','m10'], ['r3','r2'], 'fam1', 1 ).
test( 't20', 85, [], [], 'fam1', 1 ).
test( 't21', 105, [], ['r2'], 'fam1', 1 ).
test( 't22', 16, [], [], 'fam1', 1 ).
test( 't23', 352, [], [], 'fam1', 1 ).
test( 't24', 408, [], [], 'fam1', 1 ).
test( 't25', 779, ['m12','m39','m41','m5','m22','m18','m1','m38','m30','m35','m27','m2'], [], 'fam1', 1 ).
test( 't26', 541, [], [], 'fam1', 1 ).
test( 't27', 208, [], [], 'fam1', 1 ).
test( 't28', 563, [], [], 'fam1', 1 ).
test( 't29', 204, [], [], 'fam1', 1 ).
test( 't30', 39, [], [], 'fam1', 1 ).
test( 't31', 334, ['m9','m28','m39','m7','m3','m6','m44','m21','m16','m10','m41','m1','m37','m29','m45','m40'], [], 'fam1', 1 ).
test( 't32', 168, [], [], 'fam1', 1 ).
test( 't33', 491, [], [], 'fam1', 1 ).
test( 't34', 120, [], [], 'fam1', 1 ).
test( 't35', 797, [], [], 'fam1', 1 ).
test( 't36', 673, [], [], 'fam1', 1 ).
test( 't37', 735, [], [], 'fam1', 1 ).
test( 't38', 208, [], [], 'fam1', 1 ).
test( 't39', 694, [], [], 'fam1', 1 ).
test( 't40', 93, ['m17','m16','m47','m5','m36','m23','m32','m25','m6','m8','m28'], [], 'fam1', 1 ).
test( 't41', 733, [], [], 'fam1', 1 ).
test( 't42', 249, ['m29','m35','m20','m28','m4','m30','m46','m10','m2','m25','m45'], ['r2','r3','r1'], 'fam1', 1 ).
test( 't43', 485, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't44', 588, [], [], 'fam1', 1 ).
test( 't45', 665, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't46', 253, [], [], 'fam1', 1 ).
test( 't47', 92, [], ['r2'], 'fam1', 1 ).
test( 't48', 650, ['m44','m37','m4','m14','m45','m11','m41','m8','m6','m46','m49','m7','m28','m35','m34','m17','m15','m9'], [], 'fam1', 1 ).
test( 't49', 473, ['m48','m23','m27','m22','m15','m50','m39','m33','m31','m30','m9','m16','m41','m10','m12','m36','m18','m19','m5','m47'], ['r3','r2','r1'], 'fam1', 1 ).
test( 't50', 180, [], [], 'fam1', 1 ).
test( 't51', 233, ['m16'], [], 'fam1', 1 ).
test( 't52', 176, ['m2','m35','m38','m7','m11','m49'], ['r3','r2'], 'fam1', 1 ).
test( 't53', 39, ['m6','m25','m28','m47','m15','m12','m50','m4','m31','m44','m36','m38','m19','m35','m34','m11','m37','m10','m24'], [], 'fam1', 1 ).
test( 't54', 152, ['m38'], [], 'fam1', 1 ).
test( 't55', 690, [], [], 'fam1', 1 ).
test( 't56', 17, ['m31','m37','m14','m22','m38','m11','m3','m26','m36','m24','m20'], [], 'fam1', 1 ).
test( 't57', 504, [], [], 'fam1', 1 ).
test( 't58', 119, [], ['r3'], 'fam1', 1 ).
test( 't59', 54, [], [], 'fam1', 1 ).
test( 't60', 632, [], [], 'fam1', 1 ).
test( 't61', 146, ['m44','m22','m15','m12','m7','m5','m38','m8'], ['r1'], 'fam1', 1 ).
test( 't62', 668, [], [], 'fam1', 1 ).
test( 't63', 745, [], ['r3'], 'fam1', 1 ).
test( 't64', 708, [], ['r2'], 'fam1', 1 ).
test( 't65', 208, ['m30','m47','m10','m44'], [], 'fam1', 1 ).
test( 't66', 447, [], ['r2','r3'], 'fam1', 1 ).
test( 't67', 380, ['m5','m12','m33','m44','m49','m19','m40','m28','m39','m37','m4'], ['r3','r2','r1'], 'fam1', 1 ).
test( 't68', 315, [], ['r1','r3'], 'fam1', 1 ).
test( 't69', 217, [], [], 'fam1', 1 ).
test( 't70', 125, [], [], 'fam1', 1 ).
test( 't71', 272, [], [], 'fam1', 1 ).
test( 't72', 13, [], [], 'fam1', 1 ).
test( 't73', 207, [], [], 'fam1', 1 ).
test( 't74', 110, ['m25','m37','m9','m12','m45','m40','m21','m33','m22','m13','m48'], ['r2','r1'], 'fam1', 1 ).
test( 't75', 667, [], [], 'fam1', 1 ).
test( 't76', 8, [], [], 'fam1', 1 ).
test( 't77', 255, [], [], 'fam1', 1 ).
test( 't78', 655, [], [], 'fam1', 1 ).
test( 't79', 600, ['m15','m48','m50','m32','m46','m37','m45','m12','m42','m11','m13','m26','m19','m39','m6','m16','m4'], ['r1','r2','r3'], 'fam1', 1 ).
test( 't80', 612, [], [], 'fam1', 1 ).
test( 't81', 48, [], ['r1','r3'], 'fam1', 1 ).
test( 't82', 83, [], [], 'fam1', 1 ).
test( 't83', 69, [], [], 'fam1', 1 ).
test( 't84', 734, [], [], 'fam1', 1 ).
test( 't85', 676, [], ['r2','r3'], 'fam1', 1 ).
test( 't86', 144, [], ['r2','r1'], 'fam1', 1 ).
test( 't87', 589, [], [], 'fam1', 1 ).
test( 't88', 208, [], [], 'fam1', 1 ).
test( 't89', 525, [], [], 'fam1', 1 ).
test( 't90', 484, [], [], 'fam1', 1 ).
test( 't91', 431, [], ['r3'], 'fam1', 1 ).
test( 't92', 601, [], [], 'fam1', 1 ).
test( 't93', 582, [], [], 'fam1', 1 ).
test( 't94', 94, [], [], 'fam1', 1 ).
test( 't95', 343, [], [], 'fam1', 1 ).
test( 't96', 58, ['m29','m35','m40','m22','m39','m38','m41','m36','m32','m1','m15','m28','m43','m37','m13','m45','m7','m30','m23'], ['r2','r1','r3'], 'fam1', 1 ).
test( 't97', 279, [], ['r3'], 'fam1', 1 ).
test( 't98', 206, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't99', 32, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't100', 490, [], ['r3','r2'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').
embedded_board( 'm21').
embedded_board( 'm22').
embedded_board( 'm23').
embedded_board( 'm24').
embedded_board( 'm25').
embedded_board( 'm26').
embedded_board( 'm27').
embedded_board( 'm28').
embedded_board( 'm29').
embedded_board( 'm30').
embedded_board( 'm31').
embedded_board( 'm32').
embedded_board( 'm33').
embedded_board( 'm34').
embedded_board( 'm35').
embedded_board( 'm36').
embedded_board( 'm37').
embedded_board( 'm38').
embedded_board( 'm39').
embedded_board( 'm40').
embedded_board( 'm41').
embedded_board( 'm42').
embedded_board( 'm43').
embedded_board( 'm44').
embedded_board( 'm45').
embedded_board( 'm46').
embedded_board( 'm47').
embedded_board( 'm48').
embedded_board( 'm49').
embedded_board( 'm50').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
