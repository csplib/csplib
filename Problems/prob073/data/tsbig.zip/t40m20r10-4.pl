%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 20
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 161, [], [], 'fam1', 1 ).
test( 't2', 558, [], ['r6','r4','r5','r7','r8','r3'], 'fam1', 1 ).
test( 't3', 199, [], [], 'fam1', 1 ).
test( 't4', 417, [], ['r9','r2','r3','r1'], 'fam1', 1 ).
test( 't5', 79, [], ['r3','r7','r5','r10'], 'fam1', 1 ).
test( 't6', 776, ['m18','m2','m1','m15'], [], 'fam1', 1 ).
test( 't7', 663, ['m18','m19','m9','m6','m5','m12','m11','m17'], [], 'fam1', 1 ).
test( 't8', 792, ['m5','m7','m15','m19','m9','m1','m8'], [], 'fam1', 1 ).
test( 't9', 626, [], [], 'fam1', 1 ).
test( 't10', 597, ['m18','m11','m14','m7'], [], 'fam1', 1 ).
test( 't11', 702, [], [], 'fam1', 1 ).
test( 't12', 230, ['m9','m16','m10','m7','m13','m8','m3'], [], 'fam1', 1 ).
test( 't13', 568, ['m20','m3','m8','m15'], [], 'fam1', 1 ).
test( 't14', 717, [], [], 'fam1', 1 ).
test( 't15', 630, [], ['r5','r8'], 'fam1', 1 ).
test( 't16', 529, [], [], 'fam1', 1 ).
test( 't17', 244, [], [], 'fam1', 1 ).
test( 't18', 755, [], ['r3','r9','r6','r4'], 'fam1', 1 ).
test( 't19', 453, ['m20','m1','m2','m17','m16','m3','m5','m6'], [], 'fam1', 1 ).
test( 't20', 106, [], [], 'fam1', 1 ).
test( 't21', 688, ['m4','m14','m2','m5','m9'], [], 'fam1', 1 ).
test( 't22', 438, [], [], 'fam1', 1 ).
test( 't23', 484, [], [], 'fam1', 1 ).
test( 't24', 508, [], [], 'fam1', 1 ).
test( 't25', 438, [], [], 'fam1', 1 ).
test( 't26', 646, ['m6','m4'], [], 'fam1', 1 ).
test( 't27', 436, [], [], 'fam1', 1 ).
test( 't28', 689, ['m10','m13','m18','m15','m20','m2'], [], 'fam1', 1 ).
test( 't29', 98, [], [], 'fam1', 1 ).
test( 't30', 141, [], [], 'fam1', 1 ).
test( 't31', 148, [], [], 'fam1', 1 ).
test( 't32', 501, ['m15','m10','m11','m7','m2','m1','m3'], ['r2','r5','r1','r10','r7','r4','r3'], 'fam1', 1 ).
test( 't33', 509, [], [], 'fam1', 1 ).
test( 't34', 323, ['m14'], [], 'fam1', 1 ).
test( 't35', 626, [], [], 'fam1', 1 ).
test( 't36', 288, [], [], 'fam1', 1 ).
test( 't37', 680, [], ['r3','r10','r4','r8','r5','r6','r1'], 'fam1', 1 ).
test( 't38', 18, [], [], 'fam1', 1 ).
test( 't39', 642, [], [], 'fam1', 1 ).
test( 't40', 419, [], ['r10','r1','r5','r9','r8','r2','r3','r4','r7'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
