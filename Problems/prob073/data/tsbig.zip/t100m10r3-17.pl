%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 702, ['m2','m5','m6','m9'], [], 'fam1', 1 ).
test( 't2', 82, ['m1'], [], 'fam1', 1 ).
test( 't3', 171, [], [], 'fam1', 1 ).
test( 't4', 721, [], [], 'fam1', 1 ).
test( 't5', 396, [], [], 'fam1', 1 ).
test( 't6', 642, [], [], 'fam1', 1 ).
test( 't7', 228, [], [], 'fam1', 1 ).
test( 't8', 107, [], [], 'fam1', 1 ).
test( 't9', 547, [], ['r1'], 'fam1', 1 ).
test( 't10', 568, [], [], 'fam1', 1 ).
test( 't11', 143, ['m5','m3'], [], 'fam1', 1 ).
test( 't12', 80, [], [], 'fam1', 1 ).
test( 't13', 6, [], ['r1'], 'fam1', 1 ).
test( 't14', 679, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't15', 405, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't16', 98, [], [], 'fam1', 1 ).
test( 't17', 313, ['m2'], [], 'fam1', 1 ).
test( 't18', 571, [], [], 'fam1', 1 ).
test( 't19', 701, ['m1','m3','m2','m7'], [], 'fam1', 1 ).
test( 't20', 274, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't21', 384, [], [], 'fam1', 1 ).
test( 't22', 712, [], ['r3'], 'fam1', 1 ).
test( 't23', 413, [], ['r3','r1'], 'fam1', 1 ).
test( 't24', 219, [], [], 'fam1', 1 ).
test( 't25', 545, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't26', 229, [], [], 'fam1', 1 ).
test( 't27', 607, [], [], 'fam1', 1 ).
test( 't28', 401, ['m1','m10','m4','m3'], ['r2','r3'], 'fam1', 1 ).
test( 't29', 240, [], [], 'fam1', 1 ).
test( 't30', 765, ['m4','m9','m1'], [], 'fam1', 1 ).
test( 't31', 647, [], [], 'fam1', 1 ).
test( 't32', 617, [], [], 'fam1', 1 ).
test( 't33', 520, ['m2','m4'], [], 'fam1', 1 ).
test( 't34', 596, [], [], 'fam1', 1 ).
test( 't35', 507, [], [], 'fam1', 1 ).
test( 't36', 247, [], ['r3','r1'], 'fam1', 1 ).
test( 't37', 442, [], [], 'fam1', 1 ).
test( 't38', 505, [], [], 'fam1', 1 ).
test( 't39', 529, [], [], 'fam1', 1 ).
test( 't40', 379, ['m4'], [], 'fam1', 1 ).
test( 't41', 343, [], [], 'fam1', 1 ).
test( 't42', 800, [], ['r3','r2'], 'fam1', 1 ).
test( 't43', 53, [], [], 'fam1', 1 ).
test( 't44', 560, [], [], 'fam1', 1 ).
test( 't45', 188, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't46', 311, ['m7','m2'], ['r2','r1'], 'fam1', 1 ).
test( 't47', 548, ['m5'], [], 'fam1', 1 ).
test( 't48', 483, ['m4','m5','m6','m10'], [], 'fam1', 1 ).
test( 't49', 756, [], [], 'fam1', 1 ).
test( 't50', 691, [], ['r3','r2'], 'fam1', 1 ).
test( 't51', 380, [], [], 'fam1', 1 ).
test( 't52', 539, [], [], 'fam1', 1 ).
test( 't53', 34, [], [], 'fam1', 1 ).
test( 't54', 668, [], ['r2'], 'fam1', 1 ).
test( 't55', 677, [], [], 'fam1', 1 ).
test( 't56', 257, [], [], 'fam1', 1 ).
test( 't57', 430, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't58', 644, [], [], 'fam1', 1 ).
test( 't59', 709, [], [], 'fam1', 1 ).
test( 't60', 456, ['m1','m5'], [], 'fam1', 1 ).
test( 't61', 285, [], [], 'fam1', 1 ).
test( 't62', 645, [], [], 'fam1', 1 ).
test( 't63', 138, ['m10','m5','m1','m2'], [], 'fam1', 1 ).
test( 't64', 242, ['m9','m5'], [], 'fam1', 1 ).
test( 't65', 671, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't66', 160, ['m9','m7'], [], 'fam1', 1 ).
test( 't67', 543, [], ['r1'], 'fam1', 1 ).
test( 't68', 794, [], [], 'fam1', 1 ).
test( 't69', 431, [], [], 'fam1', 1 ).
test( 't70', 533, ['m2','m6','m1','m4'], [], 'fam1', 1 ).
test( 't71', 18, [], [], 'fam1', 1 ).
test( 't72', 187, ['m5'], [], 'fam1', 1 ).
test( 't73', 596, [], ['r2','r3'], 'fam1', 1 ).
test( 't74', 363, [], [], 'fam1', 1 ).
test( 't75', 177, [], [], 'fam1', 1 ).
test( 't76', 178, ['m9','m1'], ['r3','r1','r2'], 'fam1', 1 ).
test( 't77', 13, ['m4','m10','m2','m6'], [], 'fam1', 1 ).
test( 't78', 476, [], [], 'fam1', 1 ).
test( 't79', 737, [], [], 'fam1', 1 ).
test( 't80', 251, [], ['r2'], 'fam1', 1 ).
test( 't81', 56, ['m10','m6'], ['r3','r1'], 'fam1', 1 ).
test( 't82', 385, [], [], 'fam1', 1 ).
test( 't83', 248, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't84', 556, [], [], 'fam1', 1 ).
test( 't85', 204, [], [], 'fam1', 1 ).
test( 't86', 406, [], [], 'fam1', 1 ).
test( 't87', 140, [], [], 'fam1', 1 ).
test( 't88', 66, ['m3','m6'], ['r2','r1'], 'fam1', 1 ).
test( 't89', 771, ['m4','m8'], [], 'fam1', 1 ).
test( 't90', 211, [], [], 'fam1', 1 ).
test( 't91', 619, [], [], 'fam1', 1 ).
test( 't92', 4, [], [], 'fam1', 1 ).
test( 't93', 295, [], [], 'fam1', 1 ).
test( 't94', 518, [], [], 'fam1', 1 ).
test( 't95', 277, [], [], 'fam1', 1 ).
test( 't96', 159, ['m9','m3'], [], 'fam1', 1 ).
test( 't97', 759, [], [], 'fam1', 1 ).
test( 't98', 696, ['m5','m8'], [], 'fam1', 1 ).
test( 't99', 64, [], [], 'fam1', 1 ).
test( 't100', 424, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
