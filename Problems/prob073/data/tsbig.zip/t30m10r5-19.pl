%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 434, [], [], 'fam1', 1 ).
test( 't2', 66, [], [], 'fam1', 1 ).
test( 't3', 788, ['m10','m1'], [], 'fam1', 1 ).
test( 't4', 483, ['m8','m2'], [], 'fam1', 1 ).
test( 't5', 273, [], [], 'fam1', 1 ).
test( 't6', 598, [], [], 'fam1', 1 ).
test( 't7', 319, [], [], 'fam1', 1 ).
test( 't8', 523, [], [], 'fam1', 1 ).
test( 't9', 592, ['m5','m4'], ['r2','r1','r3','r5'], 'fam1', 1 ).
test( 't10', 451, [], [], 'fam1', 1 ).
test( 't11', 691, [], [], 'fam1', 1 ).
test( 't12', 677, [], [], 'fam1', 1 ).
test( 't13', 760, [], [], 'fam1', 1 ).
test( 't14', 592, [], [], 'fam1', 1 ).
test( 't15', 186, ['m10','m6'], [], 'fam1', 1 ).
test( 't16', 177, [], ['r1','r3','r5'], 'fam1', 1 ).
test( 't17', 436, [], [], 'fam1', 1 ).
test( 't18', 277, [], [], 'fam1', 1 ).
test( 't19', 438, [], [], 'fam1', 1 ).
test( 't20', 646, [], [], 'fam1', 1 ).
test( 't21', 529, [], [], 'fam1', 1 ).
test( 't22', 98, [], ['r1','r2','r4'], 'fam1', 1 ).
test( 't23', 188, [], [], 'fam1', 1 ).
test( 't24', 414, [], [], 'fam1', 1 ).
test( 't25', 436, ['m5','m3','m9','m6'], [], 'fam1', 1 ).
test( 't26', 412, ['m7','m1'], ['r2','r5','r3'], 'fam1', 1 ).
test( 't27', 586, [], [], 'fam1', 1 ).
test( 't28', 709, [], [], 'fam1', 1 ).
test( 't29', 202, [], [], 'fam1', 1 ).
test( 't30', 326, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
