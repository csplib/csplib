%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 20
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 468, [], [], 'fam1', 1 ).
test( 't2', 380, [], ['r3','r8','r5','r1','r4','r6','r7','r2'], 'fam1', 1 ).
test( 't3', 89, [], [], 'fam1', 1 ).
test( 't4', 263, [], [], 'fam1', 1 ).
test( 't5', 562, [], [], 'fam1', 1 ).
test( 't6', 174, [], [], 'fam1', 1 ).
test( 't7', 719, ['m17','m9','m16','m19','m20'], [], 'fam1', 1 ).
test( 't8', 669, [], [], 'fam1', 1 ).
test( 't9', 499, ['m5','m15','m12','m10','m7'], [], 'fam1', 1 ).
test( 't10', 229, [], [], 'fam1', 1 ).
test( 't11', 568, [], ['r4','r3','r6','r9','r2','r7','r10','r5','r1','r8'], 'fam1', 1 ).
test( 't12', 313, ['m9','m2','m15','m20','m17','m6','m14'], [], 'fam1', 1 ).
test( 't13', 154, ['m13','m16','m11'], [], 'fam1', 1 ).
test( 't14', 639, ['m15','m10','m1','m17','m14','m7'], ['r1','r4','r5','r8','r3','r2'], 'fam1', 1 ).
test( 't15', 91, [], [], 'fam1', 1 ).
test( 't16', 767, [], [], 'fam1', 1 ).
test( 't17', 786, [], [], 'fam1', 1 ).
test( 't18', 592, [], ['r6','r9','r10','r7','r2'], 'fam1', 1 ).
test( 't19', 163, [], [], 'fam1', 1 ).
test( 't20', 571, [], ['r8','r4','r5','r9','r10'], 'fam1', 1 ).
test( 't21', 779, [], [], 'fam1', 1 ).
test( 't22', 406, [], ['r9','r3','r4','r7','r5','r2','r8','r6'], 'fam1', 1 ).
test( 't23', 264, ['m17','m12','m14','m6','m11','m4','m16'], [], 'fam1', 1 ).
test( 't24', 516, [], [], 'fam1', 1 ).
test( 't25', 284, [], [], 'fam1', 1 ).
test( 't26', 23, [], [], 'fam1', 1 ).
test( 't27', 482, [], [], 'fam1', 1 ).
test( 't28', 324, [], ['r9','r8','r5','r7','r2','r6','r4','r10','r1','r3'], 'fam1', 1 ).
test( 't29', 197, [], [], 'fam1', 1 ).
test( 't30', 405, [], [], 'fam1', 1 ).
test( 't31', 571, [], ['r6','r7','r2','r5','r3','r8','r10','r4','r9','r1'], 'fam1', 1 ).
test( 't32', 350, [], [], 'fam1', 1 ).
test( 't33', 623, ['m11','m19'], [], 'fam1', 1 ).
test( 't34', 464, [], ['r10','r2','r1'], 'fam1', 1 ).
test( 't35', 495, [], ['r5'], 'fam1', 1 ).
test( 't36', 694, [], ['r7','r5','r9','r1','r10','r4','r2'], 'fam1', 1 ).
test( 't37', 297, [], ['r2','r7','r1','r5'], 'fam1', 1 ).
test( 't38', 704, [], [], 'fam1', 1 ).
test( 't39', 389, [], [], 'fam1', 1 ).
test( 't40', 362, ['m10','m3','m6','m16','m8','m14'], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
