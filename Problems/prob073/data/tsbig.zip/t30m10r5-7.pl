%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 88, [], ['r3','r4','r1','r2','r5'], 'fam1', 1 ).
test( 't2', 23, [], [], 'fam1', 1 ).
test( 't3', 656, [], [], 'fam1', 1 ).
test( 't4', 748, [], [], 'fam1', 1 ).
test( 't5', 790, [], ['r1'], 'fam1', 1 ).
test( 't6', 12, ['m1','m9','m5','m3'], [], 'fam1', 1 ).
test( 't7', 223, [], ['r3','r4','r1','r2'], 'fam1', 1 ).
test( 't8', 498, [], [], 'fam1', 1 ).
test( 't9', 679, [], [], 'fam1', 1 ).
test( 't10', 709, [], [], 'fam1', 1 ).
test( 't11', 258, ['m1'], ['r3','r2','r1','r5','r4'], 'fam1', 1 ).
test( 't12', 659, [], ['r1'], 'fam1', 1 ).
test( 't13', 799, [], [], 'fam1', 1 ).
test( 't14', 101, [], ['r4'], 'fam1', 1 ).
test( 't15', 797, [], [], 'fam1', 1 ).
test( 't16', 424, [], ['r2','r3'], 'fam1', 1 ).
test( 't17', 380, ['m9'], [], 'fam1', 1 ).
test( 't18', 436, [], [], 'fam1', 1 ).
test( 't19', 497, [], ['r5','r4'], 'fam1', 1 ).
test( 't20', 644, [], [], 'fam1', 1 ).
test( 't21', 717, [], [], 'fam1', 1 ).
test( 't22', 555, [], [], 'fam1', 1 ).
test( 't23', 777, [], [], 'fam1', 1 ).
test( 't24', 28, [], [], 'fam1', 1 ).
test( 't25', 567, [], [], 'fam1', 1 ).
test( 't26', 695, ['m9','m1','m2','m3'], [], 'fam1', 1 ).
test( 't27', 33, [], [], 'fam1', 1 ).
test( 't28', 44, [], ['r3','r5','r4'], 'fam1', 1 ).
test( 't29', 489, [], ['r5'], 'fam1', 1 ).
test( 't30', 206, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
