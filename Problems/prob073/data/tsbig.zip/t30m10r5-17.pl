%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 726, [], ['r4'], 'fam1', 1 ).
test( 't2', 670, ['m3','m7'], [], 'fam1', 1 ).
test( 't3', 58, [], [], 'fam1', 1 ).
test( 't4', 183, [], [], 'fam1', 1 ).
test( 't5', 413, [], [], 'fam1', 1 ).
test( 't6', 132, ['m6','m1'], [], 'fam1', 1 ).
test( 't7', 1, [], ['r5','r2'], 'fam1', 1 ).
test( 't8', 498, ['m6','m8'], ['r5','r3','r1','r4','r2'], 'fam1', 1 ).
test( 't9', 176, [], [], 'fam1', 1 ).
test( 't10', 620, ['m6','m4','m7'], [], 'fam1', 1 ).
test( 't11', 128, [], [], 'fam1', 1 ).
test( 't12', 627, [], [], 'fam1', 1 ).
test( 't13', 579, [], [], 'fam1', 1 ).
test( 't14', 771, [], [], 'fam1', 1 ).
test( 't15', 24, [], ['r4','r2','r3','r5'], 'fam1', 1 ).
test( 't16', 615, [], [], 'fam1', 1 ).
test( 't17', 179, [], [], 'fam1', 1 ).
test( 't18', 716, [], [], 'fam1', 1 ).
test( 't19', 502, [], ['r1','r5','r2'], 'fam1', 1 ).
test( 't20', 317, [], [], 'fam1', 1 ).
test( 't21', 355, [], [], 'fam1', 1 ).
test( 't22', 783, [], [], 'fam1', 1 ).
test( 't23', 120, [], [], 'fam1', 1 ).
test( 't24', 371, [], [], 'fam1', 1 ).
test( 't25', 66, [], ['r4','r3','r2','r1'], 'fam1', 1 ).
test( 't26', 424, [], [], 'fam1', 1 ).
test( 't27', 17, [], [], 'fam1', 1 ).
test( 't28', 437, ['m1','m5','m6'], [], 'fam1', 1 ).
test( 't29', 218, [], [], 'fam1', 1 ).
test( 't30', 553, ['m7','m3'], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
