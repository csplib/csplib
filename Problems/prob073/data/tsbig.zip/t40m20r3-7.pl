%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 20
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 641, [], ['r3'], 'fam1', 1 ).
test( 't2', 281, [], [], 'fam1', 1 ).
test( 't3', 590, ['m2','m3','m13','m9','m20','m17'], [], 'fam1', 1 ).
test( 't4', 92, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't5', 421, [], [], 'fam1', 1 ).
test( 't6', 454, [], [], 'fam1', 1 ).
test( 't7', 532, [], ['r3'], 'fam1', 1 ).
test( 't8', 25, ['m14','m2','m16'], ['r2','r1','r3'], 'fam1', 1 ).
test( 't9', 393, [], [], 'fam1', 1 ).
test( 't10', 515, [], ['r1','r2'], 'fam1', 1 ).
test( 't11', 57, ['m1','m17','m16','m10','m6','m15'], ['r1','r3'], 'fam1', 1 ).
test( 't12', 445, [], [], 'fam1', 1 ).
test( 't13', 581, [], [], 'fam1', 1 ).
test( 't14', 553, ['m4','m13','m7','m15','m6','m12','m14'], [], 'fam1', 1 ).
test( 't15', 419, [], [], 'fam1', 1 ).
test( 't16', 590, ['m12','m7'], [], 'fam1', 1 ).
test( 't17', 488, [], [], 'fam1', 1 ).
test( 't18', 144, [], [], 'fam1', 1 ).
test( 't19', 573, ['m1','m10'], ['r3','r1'], 'fam1', 1 ).
test( 't20', 553, [], [], 'fam1', 1 ).
test( 't21', 65, [], [], 'fam1', 1 ).
test( 't22', 795, ['m3'], [], 'fam1', 1 ).
test( 't23', 428, ['m18','m17','m2','m5'], [], 'fam1', 1 ).
test( 't24', 586, ['m13','m8','m1','m14','m2'], [], 'fam1', 1 ).
test( 't25', 14, [], [], 'fam1', 1 ).
test( 't26', 741, [], ['r3','r2'], 'fam1', 1 ).
test( 't27', 790, [], [], 'fam1', 1 ).
test( 't28', 657, [], [], 'fam1', 1 ).
test( 't29', 729, [], [], 'fam1', 1 ).
test( 't30', 65, [], [], 'fam1', 1 ).
test( 't31', 273, [], [], 'fam1', 1 ).
test( 't32', 300, [], ['r2','r1'], 'fam1', 1 ).
test( 't33', 34, [], ['r1','r3'], 'fam1', 1 ).
test( 't34', 775, [], ['r3','r2'], 'fam1', 1 ).
test( 't35', 761, ['m17','m20','m10','m12','m5'], [], 'fam1', 1 ).
test( 't36', 709, [], [], 'fam1', 1 ).
test( 't37', 423, [], [], 'fam1', 1 ).
test( 't38', 698, [], [], 'fam1', 1 ).
test( 't39', 219, [], [], 'fam1', 1 ).
test( 't40', 523, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
