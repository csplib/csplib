%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 20
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 396, [], ['r9','r10','r2','r6'], 'fam1', 1 ).
test( 't2', 718, [], [], 'fam1', 1 ).
test( 't3', 59, [], [], 'fam1', 1 ).
test( 't4', 672, [], ['r4'], 'fam1', 1 ).
test( 't5', 691, [], [], 'fam1', 1 ).
test( 't6', 737, [], [], 'fam1', 1 ).
test( 't7', 354, [], [], 'fam1', 1 ).
test( 't8', 240, [], ['r1','r8','r2','r9'], 'fam1', 1 ).
test( 't9', 5, [], [], 'fam1', 1 ).
test( 't10', 414, [], [], 'fam1', 1 ).
test( 't11', 65, [], [], 'fam1', 1 ).
test( 't12', 344, [], ['r3','r5','r8','r4','r6','r10','r7','r2','r9'], 'fam1', 1 ).
test( 't13', 116, ['m16','m20','m10','m3','m6'], [], 'fam1', 1 ).
test( 't14', 48, [], [], 'fam1', 1 ).
test( 't15', 193, [], ['r10','r4','r5','r1','r2'], 'fam1', 1 ).
test( 't16', 649, [], [], 'fam1', 1 ).
test( 't17', 6, [], [], 'fam1', 1 ).
test( 't18', 168, [], [], 'fam1', 1 ).
test( 't19', 3, [], [], 'fam1', 1 ).
test( 't20', 143, ['m4','m14','m16','m20','m18'], [], 'fam1', 1 ).
test( 't21', 430, ['m4'], ['r1','r6','r7','r9','r2','r3'], 'fam1', 1 ).
test( 't22', 390, [], [], 'fam1', 1 ).
test( 't23', 534, [], ['r1','r8'], 'fam1', 1 ).
test( 't24', 239, [], [], 'fam1', 1 ).
test( 't25', 361, [], ['r3','r10','r7'], 'fam1', 1 ).
test( 't26', 421, [], [], 'fam1', 1 ).
test( 't27', 58, ['m7','m10','m13','m9'], ['r4','r8','r5','r10','r3','r2','r7','r1'], 'fam1', 1 ).
test( 't28', 273, [], [], 'fam1', 1 ).
test( 't29', 42, [], ['r1','r5','r4','r3'], 'fam1', 1 ).
test( 't30', 324, [], ['r9'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
