%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 20
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 784, [], [], 'fam1', 1 ).
test( 't2', 302, [], [], 'fam1', 1 ).
test( 't3', 608, ['m5','m20'], [], 'fam1', 1 ).
test( 't4', 37, [], ['r10','r4','r6','r1','r8','r2','r5','r3'], 'fam1', 1 ).
test( 't5', 379, [], [], 'fam1', 1 ).
test( 't6', 597, [], [], 'fam1', 1 ).
test( 't7', 35, [], ['r4','r7'], 'fam1', 1 ).
test( 't8', 14, [], ['r1','r3','r9','r5','r2','r8','r4'], 'fam1', 1 ).
test( 't9', 661, [], [], 'fam1', 1 ).
test( 't10', 28, [], [], 'fam1', 1 ).
test( 't11', 624, [], ['r7','r3','r8','r10','r5','r2','r1','r4','r6'], 'fam1', 1 ).
test( 't12', 445, [], [], 'fam1', 1 ).
test( 't13', 230, [], [], 'fam1', 1 ).
test( 't14', 140, [], [], 'fam1', 1 ).
test( 't15', 363, [], [], 'fam1', 1 ).
test( 't16', 440, ['m13'], [], 'fam1', 1 ).
test( 't17', 56, ['m16','m11','m12','m13','m4','m1'], [], 'fam1', 1 ).
test( 't18', 355, [], ['r1','r5','r9','r2','r4','r10','r8'], 'fam1', 1 ).
test( 't19', 612, ['m4','m9','m7','m14'], [], 'fam1', 1 ).
test( 't20', 622, [], [], 'fam1', 1 ).
test( 't21', 275, ['m19','m14','m4','m2'], [], 'fam1', 1 ).
test( 't22', 759, [], [], 'fam1', 1 ).
test( 't23', 174, ['m17'], [], 'fam1', 1 ).
test( 't24', 164, ['m18','m13','m12','m19','m17','m1','m4'], [], 'fam1', 1 ).
test( 't25', 158, [], ['r3','r4','r6','r1','r7','r9','r8','r2','r5','r10'], 'fam1', 1 ).
test( 't26', 471, [], [], 'fam1', 1 ).
test( 't27', 553, [], [], 'fam1', 1 ).
test( 't28', 41, [], [], 'fam1', 1 ).
test( 't29', 244, ['m18','m5'], [], 'fam1', 1 ).
test( 't30', 511, [], [], 'fam1', 1 ).
test( 't31', 521, ['m18','m6','m11','m4','m5','m7','m20'], [], 'fam1', 1 ).
test( 't32', 613, ['m16','m11','m5','m12','m17','m3','m19'], ['r6'], 'fam1', 1 ).
test( 't33', 519, [], ['r3','r10','r9','r1','r8','r6'], 'fam1', 1 ).
test( 't34', 629, [], ['r3','r6','r2','r9'], 'fam1', 1 ).
test( 't35', 758, [], [], 'fam1', 1 ).
test( 't36', 201, ['m1','m12','m3'], ['r9','r4','r3','r10','r7','r5','r2','r6','r1','r8'], 'fam1', 1 ).
test( 't37', 630, [], ['r3','r5','r10','r4','r7'], 'fam1', 1 ).
test( 't38', 66, [], [], 'fam1', 1 ).
test( 't39', 613, [], [], 'fam1', 1 ).
test( 't40', 278, ['m15','m16','m1','m12','m14','m4','m5','m2'], [], 'fam1', 1 ).
test( 't41', 678, ['m18','m4','m1','m16','m8','m3','m20'], [], 'fam1', 1 ).
test( 't42', 296, [], ['r10','r9','r3','r7','r4','r6','r8','r1','r2','r5'], 'fam1', 1 ).
test( 't43', 684, [], [], 'fam1', 1 ).
test( 't44', 180, [], [], 'fam1', 1 ).
test( 't45', 350, [], [], 'fam1', 1 ).
test( 't46', 540, [], [], 'fam1', 1 ).
test( 't47', 618, [], [], 'fam1', 1 ).
test( 't48', 314, [], ['r2'], 'fam1', 1 ).
test( 't49', 603, [], [], 'fam1', 1 ).
test( 't50', 699, [], [], 'fam1', 1 ).
test( 't51', 39, ['m14','m17'], ['r5','r6','r10','r1','r4'], 'fam1', 1 ).
test( 't52', 597, ['m8','m16','m11'], [], 'fam1', 1 ).
test( 't53', 552, [], [], 'fam1', 1 ).
test( 't54', 526, [], [], 'fam1', 1 ).
test( 't55', 524, ['m9','m10'], [], 'fam1', 1 ).
test( 't56', 445, [], [], 'fam1', 1 ).
test( 't57', 522, ['m12','m3','m5','m2','m14','m11','m18'], [], 'fam1', 1 ).
test( 't58', 463, [], [], 'fam1', 1 ).
test( 't59', 145, [], [], 'fam1', 1 ).
test( 't60', 248, [], [], 'fam1', 1 ).
test( 't61', 742, [], ['r8','r5','r6','r4','r7','r1','r3','r2','r9'], 'fam1', 1 ).
test( 't62', 328, [], [], 'fam1', 1 ).
test( 't63', 319, [], ['r8'], 'fam1', 1 ).
test( 't64', 565, [], ['r9','r5','r4','r10'], 'fam1', 1 ).
test( 't65', 25, [], [], 'fam1', 1 ).
test( 't66', 36, [], [], 'fam1', 1 ).
test( 't67', 279, [], [], 'fam1', 1 ).
test( 't68', 437, [], [], 'fam1', 1 ).
test( 't69', 141, [], ['r2','r8','r4','r1'], 'fam1', 1 ).
test( 't70', 688, ['m6'], ['r5','r3','r6','r9','r7'], 'fam1', 1 ).
test( 't71', 691, [], ['r5','r2','r10','r6','r7','r4','r8'], 'fam1', 1 ).
test( 't72', 92, [], [], 'fam1', 1 ).
test( 't73', 616, ['m5','m11','m10','m19','m15','m8'], ['r9','r8','r10','r5','r2','r4'], 'fam1', 1 ).
test( 't74', 617, [], ['r2','r10','r1'], 'fam1', 1 ).
test( 't75', 768, [], ['r2'], 'fam1', 1 ).
test( 't76', 749, [], [], 'fam1', 1 ).
test( 't77', 217, [], [], 'fam1', 1 ).
test( 't78', 33, [], [], 'fam1', 1 ).
test( 't79', 167, ['m15','m20','m1','m14','m16','m8','m11'], [], 'fam1', 1 ).
test( 't80', 258, [], ['r9','r3','r2'], 'fam1', 1 ).
test( 't81', 65, [], [], 'fam1', 1 ).
test( 't82', 312, ['m20','m2','m4','m15','m1','m7'], [], 'fam1', 1 ).
test( 't83', 643, [], [], 'fam1', 1 ).
test( 't84', 491, [], [], 'fam1', 1 ).
test( 't85', 675, ['m3','m14'], [], 'fam1', 1 ).
test( 't86', 452, [], [], 'fam1', 1 ).
test( 't87', 771, [], [], 'fam1', 1 ).
test( 't88', 531, ['m2','m17','m5','m18','m6'], ['r5','r6','r9','r8','r2','r3','r1','r7'], 'fam1', 1 ).
test( 't89', 660, [], ['r3','r6','r8','r4','r2','r5'], 'fam1', 1 ).
test( 't90', 567, [], [], 'fam1', 1 ).
test( 't91', 647, [], [], 'fam1', 1 ).
test( 't92', 117, ['m10','m7','m5','m3'], ['r2'], 'fam1', 1 ).
test( 't93', 491, [], ['r1','r5','r7','r9','r6','r2','r3'], 'fam1', 1 ).
test( 't94', 256, [], ['r4','r1','r5','r6','r9'], 'fam1', 1 ).
test( 't95', 553, [], [], 'fam1', 1 ).
test( 't96', 189, [], [], 'fam1', 1 ).
test( 't97', 21, ['m18','m17','m4','m2','m12'], [], 'fam1', 1 ).
test( 't98', 113, ['m12','m15','m9','m3','m7','m8','m14'], ['r1','r10'], 'fam1', 1 ).
test( 't99', 199, [], ['r8','r7','r4','r1','r5','r6','r2'], 'fam1', 1 ).
test( 't100', 596, ['m15','m11','m14'], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
