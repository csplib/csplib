%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 549, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't2', 717, [], [], 'fam1', 1 ).
test( 't3', 447, [], [], 'fam1', 1 ).
test( 't4', 354, [], [], 'fam1', 1 ).
test( 't5', 272, [], [], 'fam1', 1 ).
test( 't6', 689, [], [], 'fam1', 1 ).
test( 't7', 792, [], [], 'fam1', 1 ).
test( 't8', 580, ['m7'], [], 'fam1', 1 ).
test( 't9', 513, [], [], 'fam1', 1 ).
test( 't10', 91, ['m1','m10'], [], 'fam1', 1 ).
test( 't11', 694, [], [], 'fam1', 1 ).
test( 't12', 724, [], [], 'fam1', 1 ).
test( 't13', 566, ['m3','m8','m1'], [], 'fam1', 1 ).
test( 't14', 290, ['m10'], [], 'fam1', 1 ).
test( 't15', 125, ['m1'], [], 'fam1', 1 ).
test( 't16', 752, ['m8','m3'], ['r3'], 'fam1', 1 ).
test( 't17', 7, [], [], 'fam1', 1 ).
test( 't18', 296, [], [], 'fam1', 1 ).
test( 't19', 322, [], [], 'fam1', 1 ).
test( 't20', 425, [], [], 'fam1', 1 ).
test( 't21', 791, [], [], 'fam1', 1 ).
test( 't22', 554, [], [], 'fam1', 1 ).
test( 't23', 513, [], [], 'fam1', 1 ).
test( 't24', 195, ['m1','m6','m7'], [], 'fam1', 1 ).
test( 't25', 71, [], [], 'fam1', 1 ).
test( 't26', 264, [], ['r2','r1'], 'fam1', 1 ).
test( 't27', 187, [], ['r3'], 'fam1', 1 ).
test( 't28', 422, [], ['r2','r3'], 'fam1', 1 ).
test( 't29', 64, ['m6'], [], 'fam1', 1 ).
test( 't30', 658, [], [], 'fam1', 1 ).
test( 't31', 598, [], [], 'fam1', 1 ).
test( 't32', 72, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't33', 161, ['m9','m2'], [], 'fam1', 1 ).
test( 't34', 208, ['m8','m9'], [], 'fam1', 1 ).
test( 't35', 147, [], ['r3','r2'], 'fam1', 1 ).
test( 't36', 195, [], ['r3','r2'], 'fam1', 1 ).
test( 't37', 344, ['m9','m2'], ['r3'], 'fam1', 1 ).
test( 't38', 148, [], [], 'fam1', 1 ).
test( 't39', 523, [], [], 'fam1', 1 ).
test( 't40', 576, [], ['r1'], 'fam1', 1 ).
test( 't41', 473, [], [], 'fam1', 1 ).
test( 't42', 784, [], [], 'fam1', 1 ).
test( 't43', 52, [], [], 'fam1', 1 ).
test( 't44', 459, [], [], 'fam1', 1 ).
test( 't45', 592, [], [], 'fam1', 1 ).
test( 't46', 792, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't47', 181, ['m8','m1','m2','m9'], [], 'fam1', 1 ).
test( 't48', 532, ['m1'], [], 'fam1', 1 ).
test( 't49', 93, ['m1','m4','m3'], [], 'fam1', 1 ).
test( 't50', 746, [], [], 'fam1', 1 ).
test( 't51', 534, ['m6'], [], 'fam1', 1 ).
test( 't52', 477, ['m3','m2','m10','m7'], [], 'fam1', 1 ).
test( 't53', 655, [], [], 'fam1', 1 ).
test( 't54', 526, [], [], 'fam1', 1 ).
test( 't55', 777, [], [], 'fam1', 1 ).
test( 't56', 171, [], ['r3'], 'fam1', 1 ).
test( 't57', 266, [], [], 'fam1', 1 ).
test( 't58', 517, [], [], 'fam1', 1 ).
test( 't59', 364, [], ['r1'], 'fam1', 1 ).
test( 't60', 617, ['m1','m4'], [], 'fam1', 1 ).
test( 't61', 323, ['m5','m6'], ['r1'], 'fam1', 1 ).
test( 't62', 101, ['m5'], ['r2','r1'], 'fam1', 1 ).
test( 't63', 98, [], [], 'fam1', 1 ).
test( 't64', 164, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't65', 384, [], [], 'fam1', 1 ).
test( 't66', 384, [], ['r3','r1'], 'fam1', 1 ).
test( 't67', 531, [], ['r1','r2'], 'fam1', 1 ).
test( 't68', 678, [], [], 'fam1', 1 ).
test( 't69', 269, [], [], 'fam1', 1 ).
test( 't70', 787, [], [], 'fam1', 1 ).
test( 't71', 414, ['m6','m2','m1'], ['r1','r2','r3'], 'fam1', 1 ).
test( 't72', 676, ['m2','m7'], [], 'fam1', 1 ).
test( 't73', 31, ['m4','m9'], ['r2','r3'], 'fam1', 1 ).
test( 't74', 645, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't75', 261, [], [], 'fam1', 1 ).
test( 't76', 537, [], [], 'fam1', 1 ).
test( 't77', 259, [], [], 'fam1', 1 ).
test( 't78', 324, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't79', 114, ['m6','m10'], [], 'fam1', 1 ).
test( 't80', 499, [], [], 'fam1', 1 ).
test( 't81', 232, [], [], 'fam1', 1 ).
test( 't82', 2, ['m7','m1','m3'], [], 'fam1', 1 ).
test( 't83', 584, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't84', 76, [], ['r3','r1'], 'fam1', 1 ).
test( 't85', 117, [], [], 'fam1', 1 ).
test( 't86', 197, [], [], 'fam1', 1 ).
test( 't87', 792, [], ['r3','r1'], 'fam1', 1 ).
test( 't88', 761, [], ['r2'], 'fam1', 1 ).
test( 't89', 796, [], ['r1','r3'], 'fam1', 1 ).
test( 't90', 286, [], [], 'fam1', 1 ).
test( 't91', 304, [], [], 'fam1', 1 ).
test( 't92', 212, ['m5','m2','m1','m7'], ['r3'], 'fam1', 1 ).
test( 't93', 238, [], ['r2','r1'], 'fam1', 1 ).
test( 't94', 212, [], [], 'fam1', 1 ).
test( 't95', 443, [], [], 'fam1', 1 ).
test( 't96', 569, [], [], 'fam1', 1 ).
test( 't97', 123, [], ['r2','r3'], 'fam1', 1 ).
test( 't98', 551, [], ['r1','r2'], 'fam1', 1 ).
test( 't99', 171, ['m2','m4'], ['r3','r1','r2'], 'fam1', 1 ).
test( 't100', 83, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
