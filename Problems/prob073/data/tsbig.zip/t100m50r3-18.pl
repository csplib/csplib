%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 50
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 261, [], [], 'fam1', 1 ).
test( 't2', 125, [], [], 'fam1', 1 ).
test( 't3', 25, [], [], 'fam1', 1 ).
test( 't4', 638, ['m12','m5'], [], 'fam1', 1 ).
test( 't5', 110, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't6', 579, [], ['r1','r3'], 'fam1', 1 ).
test( 't7', 176, [], [], 'fam1', 1 ).
test( 't8', 59, [], [], 'fam1', 1 ).
test( 't9', 259, [], [], 'fam1', 1 ).
test( 't10', 100, ['m17','m10','m50','m33','m23','m30','m40','m43','m29','m49','m31','m22'], [], 'fam1', 1 ).
test( 't11', 531, [], ['r3'], 'fam1', 1 ).
test( 't12', 68, [], [], 'fam1', 1 ).
test( 't13', 353, ['m25','m38','m26','m21','m46'], [], 'fam1', 1 ).
test( 't14', 238, [], [], 'fam1', 1 ).
test( 't15', 551, [], ['r3'], 'fam1', 1 ).
test( 't16', 58, [], [], 'fam1', 1 ).
test( 't17', 345, [], [], 'fam1', 1 ).
test( 't18', 78, [], ['r2','r1'], 'fam1', 1 ).
test( 't19', 134, [], [], 'fam1', 1 ).
test( 't20', 496, [], [], 'fam1', 1 ).
test( 't21', 645, [], [], 'fam1', 1 ).
test( 't22', 708, [], ['r3','r2'], 'fam1', 1 ).
test( 't23', 24, ['m19','m32','m26','m44','m40','m1','m49','m42','m46','m10','m39','m21','m47'], [], 'fam1', 1 ).
test( 't24', 730, [], ['r2','r3'], 'fam1', 1 ).
test( 't25', 416, [], [], 'fam1', 1 ).
test( 't26', 212, [], [], 'fam1', 1 ).
test( 't27', 108, [], ['r3'], 'fam1', 1 ).
test( 't28', 385, [], [], 'fam1', 1 ).
test( 't29', 277, [], [], 'fam1', 1 ).
test( 't30', 145, ['m42','m37','m32','m3','m33','m45','m16','m24','m18','m21','m31','m12','m23','m44','m48','m40','m4','m17','m10'], [], 'fam1', 1 ).
test( 't31', 311, [], [], 'fam1', 1 ).
test( 't32', 104, ['m5','m33','m4'], ['r1'], 'fam1', 1 ).
test( 't33', 625, ['m14','m24','m20','m32','m23','m8','m1','m26','m13','m39','m4','m46','m19','m21','m16'], [], 'fam1', 1 ).
test( 't34', 287, [], ['r1','r3'], 'fam1', 1 ).
test( 't35', 462, [], [], 'fam1', 1 ).
test( 't36', 116, [], [], 'fam1', 1 ).
test( 't37', 659, [], [], 'fam1', 1 ).
test( 't38', 553, [], [], 'fam1', 1 ).
test( 't39', 791, [], ['r3','r1'], 'fam1', 1 ).
test( 't40', 47, [], [], 'fam1', 1 ).
test( 't41', 408, [], [], 'fam1', 1 ).
test( 't42', 730, [], [], 'fam1', 1 ).
test( 't43', 440, [], [], 'fam1', 1 ).
test( 't44', 641, [], [], 'fam1', 1 ).
test( 't45', 751, [], ['r1'], 'fam1', 1 ).
test( 't46', 702, ['m49','m14','m41','m12','m15','m36','m16'], [], 'fam1', 1 ).
test( 't47', 143, ['m37','m2','m46','m29','m36','m28','m47','m22'], [], 'fam1', 1 ).
test( 't48', 2, [], [], 'fam1', 1 ).
test( 't49', 540, ['m4','m35','m38','m45','m23','m15','m44','m34','m26','m28'], ['r3','r2'], 'fam1', 1 ).
test( 't50', 620, [], ['r3','r2'], 'fam1', 1 ).
test( 't51', 193, [], ['r2','r1'], 'fam1', 1 ).
test( 't52', 532, [], [], 'fam1', 1 ).
test( 't53', 303, ['m31','m48','m18'], [], 'fam1', 1 ).
test( 't54', 285, [], [], 'fam1', 1 ).
test( 't55', 129, [], [], 'fam1', 1 ).
test( 't56', 557, [], [], 'fam1', 1 ).
test( 't57', 121, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't58', 326, [], [], 'fam1', 1 ).
test( 't59', 392, [], [], 'fam1', 1 ).
test( 't60', 323, [], [], 'fam1', 1 ).
test( 't61', 310, [], [], 'fam1', 1 ).
test( 't62', 753, [], [], 'fam1', 1 ).
test( 't63', 652, [], [], 'fam1', 1 ).
test( 't64', 211, ['m20','m26','m19','m39','m21','m24','m43','m45','m22','m5','m34','m16','m29','m42','m41','m32','m1'], [], 'fam1', 1 ).
test( 't65', 97, [], [], 'fam1', 1 ).
test( 't66', 670, ['m18','m9','m38','m48','m8','m6','m11','m33','m46','m42'], [], 'fam1', 1 ).
test( 't67', 7, [], [], 'fam1', 1 ).
test( 't68', 257, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't69', 126, ['m12','m14','m18','m30','m10','m21','m5','m6','m35','m22','m32','m43','m36'], [], 'fam1', 1 ).
test( 't70', 246, [], ['r1','r3'], 'fam1', 1 ).
test( 't71', 625, [], [], 'fam1', 1 ).
test( 't72', 286, [], [], 'fam1', 1 ).
test( 't73', 142, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't74', 182, ['m8','m21','m41','m16','m4','m47','m33','m49','m46','m13','m27','m39','m29','m24','m37','m34','m50','m30'], [], 'fam1', 1 ).
test( 't75', 3, ['m36','m22','m23','m6','m18','m13','m2','m7','m31','m25','m35','m43','m50','m38','m39','m9','m33'], ['r2','r3','r1'], 'fam1', 1 ).
test( 't76', 496, [], ['r2'], 'fam1', 1 ).
test( 't77', 462, [], ['r2','r3'], 'fam1', 1 ).
test( 't78', 602, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't79', 770, [], [], 'fam1', 1 ).
test( 't80', 584, ['m47','m15','m49','m26'], [], 'fam1', 1 ).
test( 't81', 100, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't82', 21, [], [], 'fam1', 1 ).
test( 't83', 311, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't84', 330, [], [], 'fam1', 1 ).
test( 't85', 616, [], [], 'fam1', 1 ).
test( 't86', 94, [], [], 'fam1', 1 ).
test( 't87', 512, [], ['r2'], 'fam1', 1 ).
test( 't88', 624, [], ['r3'], 'fam1', 1 ).
test( 't89', 35, [], [], 'fam1', 1 ).
test( 't90', 344, [], [], 'fam1', 1 ).
test( 't91', 185, [], [], 'fam1', 1 ).
test( 't92', 671, [], [], 'fam1', 1 ).
test( 't93', 136, [], [], 'fam1', 1 ).
test( 't94', 191, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't95', 617, [], [], 'fam1', 1 ).
test( 't96', 504, [], [], 'fam1', 1 ).
test( 't97', 155, [], ['r3','r1'], 'fam1', 1 ).
test( 't98', 332, ['m14','m28','m16','m26'], ['r1','r2','r3'], 'fam1', 1 ).
test( 't99', 129, [], [], 'fam1', 1 ).
test( 't100', 217, ['m5','m11'], ['r1','r3','r2'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').
embedded_board( 'm21').
embedded_board( 'm22').
embedded_board( 'm23').
embedded_board( 'm24').
embedded_board( 'm25').
embedded_board( 'm26').
embedded_board( 'm27').
embedded_board( 'm28').
embedded_board( 'm29').
embedded_board( 'm30').
embedded_board( 'm31').
embedded_board( 'm32').
embedded_board( 'm33').
embedded_board( 'm34').
embedded_board( 'm35').
embedded_board( 'm36').
embedded_board( 'm37').
embedded_board( 'm38').
embedded_board( 'm39').
embedded_board( 'm40').
embedded_board( 'm41').
embedded_board( 'm42').
embedded_board( 'm43').
embedded_board( 'm44').
embedded_board( 'm45').
embedded_board( 'm46').
embedded_board( 'm47').
embedded_board( 'm48').
embedded_board( 'm49').
embedded_board( 'm50').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
