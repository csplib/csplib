%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 20
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 800, [], ['r5','r4'], 'fam1', 1 ).
test( 't2', 173, [], [], 'fam1', 1 ).
test( 't3', 165, [], ['r3','r4'], 'fam1', 1 ).
test( 't4', 33, [], [], 'fam1', 1 ).
test( 't5', 199, [], [], 'fam1', 1 ).
test( 't6', 103, [], ['r3','r5','r4'], 'fam1', 1 ).
test( 't7', 385, [], [], 'fam1', 1 ).
test( 't8', 258, ['m1','m11','m20','m13','m8'], [], 'fam1', 1 ).
test( 't9', 590, [], ['r1','r3','r4'], 'fam1', 1 ).
test( 't10', 600, [], [], 'fam1', 1 ).
test( 't11', 107, ['m15','m6','m20','m5','m17','m2','m8','m1'], [], 'fam1', 1 ).
test( 't12', 367, ['m13'], ['r2'], 'fam1', 1 ).
test( 't13', 777, [], [], 'fam1', 1 ).
test( 't14', 601, [], [], 'fam1', 1 ).
test( 't15', 375, [], [], 'fam1', 1 ).
test( 't16', 520, [], [], 'fam1', 1 ).
test( 't17', 127, [], [], 'fam1', 1 ).
test( 't18', 62, [], [], 'fam1', 1 ).
test( 't19', 328, [], [], 'fam1', 1 ).
test( 't20', 503, ['m5','m17','m7','m19','m9','m8','m16'], [], 'fam1', 1 ).
test( 't21', 175, [], [], 'fam1', 1 ).
test( 't22', 364, [], [], 'fam1', 1 ).
test( 't23', 652, [], ['r2','r1','r4','r5','r3'], 'fam1', 1 ).
test( 't24', 112, [], [], 'fam1', 1 ).
test( 't25', 626, [], [], 'fam1', 1 ).
test( 't26', 27, [], [], 'fam1', 1 ).
test( 't27', 517, [], ['r1','r3','r4'], 'fam1', 1 ).
test( 't28', 113, ['m8','m12','m4','m9'], [], 'fam1', 1 ).
test( 't29', 290, [], ['r2','r5','r1','r4','r3'], 'fam1', 1 ).
test( 't30', 588, [], ['r1','r2'], 'fam1', 1 ).
test( 't31', 688, [], [], 'fam1', 1 ).
test( 't32', 486, [], [], 'fam1', 1 ).
test( 't33', 778, [], [], 'fam1', 1 ).
test( 't34', 353, [], [], 'fam1', 1 ).
test( 't35', 243, [], [], 'fam1', 1 ).
test( 't36', 20, [], ['r5'], 'fam1', 1 ).
test( 't37', 673, [], ['r2'], 'fam1', 1 ).
test( 't38', 330, [], ['r2','r4'], 'fam1', 1 ).
test( 't39', 91, [], [], 'fam1', 1 ).
test( 't40', 526, [], [], 'fam1', 1 ).
test( 't41', 176, ['m1','m10','m18'], [], 'fam1', 1 ).
test( 't42', 519, [], [], 'fam1', 1 ).
test( 't43', 48, [], [], 'fam1', 1 ).
test( 't44', 392, [], [], 'fam1', 1 ).
test( 't45', 344, [], [], 'fam1', 1 ).
test( 't46', 465, [], [], 'fam1', 1 ).
test( 't47', 729, [], [], 'fam1', 1 ).
test( 't48', 316, [], ['r2','r5','r4'], 'fam1', 1 ).
test( 't49', 244, [], [], 'fam1', 1 ).
test( 't50', 693, [], [], 'fam1', 1 ).
test( 't51', 574, [], [], 'fam1', 1 ).
test( 't52', 596, [], [], 'fam1', 1 ).
test( 't53', 771, ['m18','m14','m16','m3','m5','m2','m4'], [], 'fam1', 1 ).
test( 't54', 546, [], [], 'fam1', 1 ).
test( 't55', 258, [], [], 'fam1', 1 ).
test( 't56', 367, ['m20'], [], 'fam1', 1 ).
test( 't57', 583, ['m1','m4','m9','m5','m12','m15','m11'], [], 'fam1', 1 ).
test( 't58', 629, ['m5','m13','m8','m17','m1','m16','m9','m11'], ['r1','r5','r4'], 'fam1', 1 ).
test( 't59', 672, ['m19','m11'], [], 'fam1', 1 ).
test( 't60', 55, [], ['r5','r1','r2','r4'], 'fam1', 1 ).
test( 't61', 1, [], ['r2'], 'fam1', 1 ).
test( 't62', 200, ['m8'], [], 'fam1', 1 ).
test( 't63', 583, [], [], 'fam1', 1 ).
test( 't64', 478, [], ['r5','r2'], 'fam1', 1 ).
test( 't65', 388, [], [], 'fam1', 1 ).
test( 't66', 55, [], ['r4'], 'fam1', 1 ).
test( 't67', 154, ['m6','m2','m15','m12','m18','m11','m3'], [], 'fam1', 1 ).
test( 't68', 225, [], [], 'fam1', 1 ).
test( 't69', 81, [], [], 'fam1', 1 ).
test( 't70', 161, [], [], 'fam1', 1 ).
test( 't71', 294, [], ['r1','r4','r2','r5'], 'fam1', 1 ).
test( 't72', 73, [], [], 'fam1', 1 ).
test( 't73', 111, [], [], 'fam1', 1 ).
test( 't74', 636, [], [], 'fam1', 1 ).
test( 't75', 780, [], [], 'fam1', 1 ).
test( 't76', 631, [], [], 'fam1', 1 ).
test( 't77', 44, ['m17','m16'], [], 'fam1', 1 ).
test( 't78', 26, [], ['r1','r5','r3','r2'], 'fam1', 1 ).
test( 't79', 156, [], [], 'fam1', 1 ).
test( 't80', 493, ['m6','m15','m13'], ['r1','r4','r2'], 'fam1', 1 ).
test( 't81', 417, [], [], 'fam1', 1 ).
test( 't82', 512, [], [], 'fam1', 1 ).
test( 't83', 345, [], [], 'fam1', 1 ).
test( 't84', 71, [], ['r1','r4','r2','r5','r3'], 'fam1', 1 ).
test( 't85', 452, [], ['r2','r1','r3','r4','r5'], 'fam1', 1 ).
test( 't86', 521, [], [], 'fam1', 1 ).
test( 't87', 549, [], [], 'fam1', 1 ).
test( 't88', 132, ['m3','m4','m15','m17','m18','m8'], [], 'fam1', 1 ).
test( 't89', 392, [], [], 'fam1', 1 ).
test( 't90', 469, [], [], 'fam1', 1 ).
test( 't91', 401, [], [], 'fam1', 1 ).
test( 't92', 374, [], [], 'fam1', 1 ).
test( 't93', 312, ['m14','m17','m1','m12'], [], 'fam1', 1 ).
test( 't94', 116, [], ['r1'], 'fam1', 1 ).
test( 't95', 480, [], [], 'fam1', 1 ).
test( 't96', 316, [], [], 'fam1', 1 ).
test( 't97', 143, [], [], 'fam1', 1 ).
test( 't98', 261, ['m20','m17','m11','m2','m4'], [], 'fam1', 1 ).
test( 't99', 482, [], [], 'fam1', 1 ).
test( 't100', 340, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
