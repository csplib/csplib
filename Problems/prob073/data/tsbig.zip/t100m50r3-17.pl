%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 50
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 125, [], [], 'fam1', 1 ).
test( 't2', 787, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't3', 382, [], ['r3'], 'fam1', 1 ).
test( 't4', 394, [], [], 'fam1', 1 ).
test( 't5', 727, [], [], 'fam1', 1 ).
test( 't6', 613, [], [], 'fam1', 1 ).
test( 't7', 694, ['m11','m19','m5','m9','m28','m33','m12'], [], 'fam1', 1 ).
test( 't8', 319, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't9', 345, [], [], 'fam1', 1 ).
test( 't10', 187, [], [], 'fam1', 1 ).
test( 't11', 170, ['m2','m12','m22','m10','m23','m29','m1','m38','m26','m46','m9','m11','m31','m6','m27','m21','m43','m18','m44','m17'], [], 'fam1', 1 ).
test( 't12', 110, [], [], 'fam1', 1 ).
test( 't13', 779, ['m32','m14','m25','m30','m20','m26','m5','m24','m12','m38','m16','m22','m45','m7','m28','m11','m44','m47','m35'], [], 'fam1', 1 ).
test( 't14', 111, [], ['r1'], 'fam1', 1 ).
test( 't15', 515, ['m2','m25'], [], 'fam1', 1 ).
test( 't16', 660, [], [], 'fam1', 1 ).
test( 't17', 63, [], ['r2','r3'], 'fam1', 1 ).
test( 't18', 580, ['m5','m31','m48','m27','m36','m26','m20','m14','m45','m21','m23','m33','m43','m50','m16','m2'], [], 'fam1', 1 ).
test( 't19', 308, [], [], 'fam1', 1 ).
test( 't20', 554, [], [], 'fam1', 1 ).
test( 't21', 379, [], [], 'fam1', 1 ).
test( 't22', 621, [], [], 'fam1', 1 ).
test( 't23', 224, [], [], 'fam1', 1 ).
test( 't24', 219, ['m3','m13','m34','m44','m49','m19','m10','m28','m21','m4','m42','m18','m41','m23','m12','m32','m33','m22'], [], 'fam1', 1 ).
test( 't25', 99, ['m21','m26','m43','m15','m13','m18','m33','m20','m42'], [], 'fam1', 1 ).
test( 't26', 450, [], [], 'fam1', 1 ).
test( 't27', 33, [], [], 'fam1', 1 ).
test( 't28', 191, [], [], 'fam1', 1 ).
test( 't29', 660, ['m11','m5','m1','m43','m17','m9','m49','m45','m36','m15','m25','m10','m40','m42','m20','m39','m12','m27'], [], 'fam1', 1 ).
test( 't30', 748, [], [], 'fam1', 1 ).
test( 't31', 339, [], [], 'fam1', 1 ).
test( 't32', 33, [], [], 'fam1', 1 ).
test( 't33', 620, [], [], 'fam1', 1 ).
test( 't34', 633, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't35', 120, ['m20','m39','m40','m10','m4','m15','m42','m37','m21','m8','m33'], ['r2','r3'], 'fam1', 1 ).
test( 't36', 609, [], ['r2','r3'], 'fam1', 1 ).
test( 't37', 777, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't38', 88, [], [], 'fam1', 1 ).
test( 't39', 773, [], ['r3','r1'], 'fam1', 1 ).
test( 't40', 642, [], [], 'fam1', 1 ).
test( 't41', 201, [], ['r3'], 'fam1', 1 ).
test( 't42', 129, [], [], 'fam1', 1 ).
test( 't43', 477, ['m42','m38','m19','m45','m20','m32','m6','m22','m47','m24','m9'], [], 'fam1', 1 ).
test( 't44', 13, [], [], 'fam1', 1 ).
test( 't45', 362, [], [], 'fam1', 1 ).
test( 't46', 598, [], [], 'fam1', 1 ).
test( 't47', 163, [], ['r3'], 'fam1', 1 ).
test( 't48', 732, [], [], 'fam1', 1 ).
test( 't49', 615, [], [], 'fam1', 1 ).
test( 't50', 471, [], [], 'fam1', 1 ).
test( 't51', 75, [], [], 'fam1', 1 ).
test( 't52', 397, [], ['r3'], 'fam1', 1 ).
test( 't53', 717, ['m50','m43','m20','m19','m9','m41','m2','m7','m26','m11','m36','m40','m28','m14'], ['r1','r3','r2'], 'fam1', 1 ).
test( 't54', 429, ['m41','m39','m32','m19','m18','m29'], [], 'fam1', 1 ).
test( 't55', 562, [], [], 'fam1', 1 ).
test( 't56', 454, [], [], 'fam1', 1 ).
test( 't57', 639, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't58', 157, [], [], 'fam1', 1 ).
test( 't59', 553, [], [], 'fam1', 1 ).
test( 't60', 30, [], [], 'fam1', 1 ).
test( 't61', 445, [], [], 'fam1', 1 ).
test( 't62', 62, [], [], 'fam1', 1 ).
test( 't63', 784, ['m27','m36','m7','m18','m24','m23','m39','m3','m25','m20','m4','m14','m34','m49','m41'], [], 'fam1', 1 ).
test( 't64', 752, ['m31','m46','m5','m27'], [], 'fam1', 1 ).
test( 't65', 562, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't66', 603, [], [], 'fam1', 1 ).
test( 't67', 332, ['m42','m3','m7','m40','m6'], [], 'fam1', 1 ).
test( 't68', 287, [], [], 'fam1', 1 ).
test( 't69', 747, ['m12','m47','m40','m28','m44','m31','m23','m22','m39','m30','m35','m46','m50','m43','m6','m49','m1','m34','m48','m33'], [], 'fam1', 1 ).
test( 't70', 337, ['m39','m45','m40','m16','m9','m36','m8','m37','m25','m13','m5','m15','m34','m18'], [], 'fam1', 1 ).
test( 't71', 113, [], [], 'fam1', 1 ).
test( 't72', 591, [], ['r1','r3'], 'fam1', 1 ).
test( 't73', 476, [], ['r1'], 'fam1', 1 ).
test( 't74', 12, [], [], 'fam1', 1 ).
test( 't75', 499, ['m31','m18','m16','m42','m15','m41'], [], 'fam1', 1 ).
test( 't76', 464, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't77', 614, [], [], 'fam1', 1 ).
test( 't78', 193, ['m28','m44','m48','m31','m39','m34','m47','m1','m32','m17','m20','m23','m5','m3','m38','m14','m30'], [], 'fam1', 1 ).
test( 't79', 3, ['m36','m43','m18','m26','m27','m10','m16','m4','m22','m6','m31','m24','m28','m13','m11','m47','m38','m14','m23','m2'], [], 'fam1', 1 ).
test( 't80', 791, ['m44','m28','m42','m13','m11','m46','m15','m17','m25','m43','m7','m5','m16','m40','m33','m29','m10','m41','m32','m26'], [], 'fam1', 1 ).
test( 't81', 287, [], [], 'fam1', 1 ).
test( 't82', 439, [], [], 'fam1', 1 ).
test( 't83', 583, [], [], 'fam1', 1 ).
test( 't84', 367, [], [], 'fam1', 1 ).
test( 't85', 755, [], [], 'fam1', 1 ).
test( 't86', 272, [], [], 'fam1', 1 ).
test( 't87', 346, ['m22','m33','m44','m27','m31','m50','m20','m26','m17','m21','m19','m2','m47'], [], 'fam1', 1 ).
test( 't88', 96, [], [], 'fam1', 1 ).
test( 't89', 58, [], [], 'fam1', 1 ).
test( 't90', 308, [], [], 'fam1', 1 ).
test( 't91', 148, [], [], 'fam1', 1 ).
test( 't92', 745, ['m3','m36','m14','m13','m2','m9','m34','m43','m32','m39','m48','m24'], [], 'fam1', 1 ).
test( 't93', 577, [], ['r2','r1'], 'fam1', 1 ).
test( 't94', 52, [], [], 'fam1', 1 ).
test( 't95', 29, [], [], 'fam1', 1 ).
test( 't96', 220, ['m29','m24','m9','m37','m44','m45','m22','m46','m11','m1'], [], 'fam1', 1 ).
test( 't97', 683, [], [], 'fam1', 1 ).
test( 't98', 258, ['m16'], [], 'fam1', 1 ).
test( 't99', 458, [], [], 'fam1', 1 ).
test( 't100', 688, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').
embedded_board( 'm21').
embedded_board( 'm22').
embedded_board( 'm23').
embedded_board( 'm24').
embedded_board( 'm25').
embedded_board( 'm26').
embedded_board( 'm27').
embedded_board( 'm28').
embedded_board( 'm29').
embedded_board( 'm30').
embedded_board( 'm31').
embedded_board( 'm32').
embedded_board( 'm33').
embedded_board( 'm34').
embedded_board( 'm35').
embedded_board( 'm36').
embedded_board( 'm37').
embedded_board( 'm38').
embedded_board( 'm39').
embedded_board( 'm40').
embedded_board( 'm41').
embedded_board( 'm42').
embedded_board( 'm43').
embedded_board( 'm44').
embedded_board( 'm45').
embedded_board( 'm46').
embedded_board( 'm47').
embedded_board( 'm48').
embedded_board( 'm49').
embedded_board( 'm50').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
