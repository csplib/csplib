%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 20
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 202, [], [], 'fam1', 1 ).
test( 't2', 466, [], [], 'fam1', 1 ).
test( 't3', 94, [], [], 'fam1', 1 ).
test( 't4', 583, ['m5','m20','m11'], [], 'fam1', 1 ).
test( 't5', 786, [], ['r3','r1'], 'fam1', 1 ).
test( 't6', 70, [], [], 'fam1', 1 ).
test( 't7', 406, [], [], 'fam1', 1 ).
test( 't8', 106, [], ['r2','r3'], 'fam1', 1 ).
test( 't9', 419, [], [], 'fam1', 1 ).
test( 't10', 686, [], [], 'fam1', 1 ).
test( 't11', 469, [], [], 'fam1', 1 ).
test( 't12', 673, ['m5'], ['r1'], 'fam1', 1 ).
test( 't13', 735, [], [], 'fam1', 1 ).
test( 't14', 48, [], [], 'fam1', 1 ).
test( 't15', 634, ['m15','m4','m13','m9','m16','m3','m2'], [], 'fam1', 1 ).
test( 't16', 552, [], [], 'fam1', 1 ).
test( 't17', 126, [], [], 'fam1', 1 ).
test( 't18', 375, [], [], 'fam1', 1 ).
test( 't19', 327, [], [], 'fam1', 1 ).
test( 't20', 630, ['m16','m20'], [], 'fam1', 1 ).
test( 't21', 113, [], [], 'fam1', 1 ).
test( 't22', 587, [], [], 'fam1', 1 ).
test( 't23', 29, [], ['r1'], 'fam1', 1 ).
test( 't24', 456, [], ['r3'], 'fam1', 1 ).
test( 't25', 33, [], [], 'fam1', 1 ).
test( 't26', 278, [], [], 'fam1', 1 ).
test( 't27', 125, [], [], 'fam1', 1 ).
test( 't28', 317, [], [], 'fam1', 1 ).
test( 't29', 311, [], [], 'fam1', 1 ).
test( 't30', 762, [], ['r3','r1','r2'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
