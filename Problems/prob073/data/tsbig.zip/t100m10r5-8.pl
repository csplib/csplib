%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 275, [], [], 'fam1', 1 ).
test( 't2', 790, [], [], 'fam1', 1 ).
test( 't3', 659, [], [], 'fam1', 1 ).
test( 't4', 395, [], ['r4','r5','r3','r1','r2'], 'fam1', 1 ).
test( 't5', 607, [], ['r3','r2','r5','r4'], 'fam1', 1 ).
test( 't6', 795, [], ['r3','r5','r1','r4'], 'fam1', 1 ).
test( 't7', 621, [], [], 'fam1', 1 ).
test( 't8', 668, [], [], 'fam1', 1 ).
test( 't9', 121, [], [], 'fam1', 1 ).
test( 't10', 158, [], ['r4'], 'fam1', 1 ).
test( 't11', 361, ['m3'], [], 'fam1', 1 ).
test( 't12', 88, [], [], 'fam1', 1 ).
test( 't13', 208, [], [], 'fam1', 1 ).
test( 't14', 759, [], [], 'fam1', 1 ).
test( 't15', 624, [], [], 'fam1', 1 ).
test( 't16', 199, [], [], 'fam1', 1 ).
test( 't17', 90, [], [], 'fam1', 1 ).
test( 't18', 79, [], [], 'fam1', 1 ).
test( 't19', 630, [], [], 'fam1', 1 ).
test( 't20', 653, ['m7','m2','m10'], [], 'fam1', 1 ).
test( 't21', 132, ['m4','m5','m2'], [], 'fam1', 1 ).
test( 't22', 541, [], [], 'fam1', 1 ).
test( 't23', 171, [], [], 'fam1', 1 ).
test( 't24', 678, [], [], 'fam1', 1 ).
test( 't25', 389, [], ['r2','r3','r5','r4'], 'fam1', 1 ).
test( 't26', 591, [], [], 'fam1', 1 ).
test( 't27', 60, [], [], 'fam1', 1 ).
test( 't28', 732, [], ['r2','r1','r4'], 'fam1', 1 ).
test( 't29', 694, ['m1','m9','m6','m3'], ['r2'], 'fam1', 1 ).
test( 't30', 283, [], [], 'fam1', 1 ).
test( 't31', 215, ['m9','m4'], ['r3'], 'fam1', 1 ).
test( 't32', 750, [], ['r3','r4','r2','r5'], 'fam1', 1 ).
test( 't33', 130, [], [], 'fam1', 1 ).
test( 't34', 219, [], [], 'fam1', 1 ).
test( 't35', 684, ['m7','m8','m6','m2'], ['r5','r3','r2','r1','r4'], 'fam1', 1 ).
test( 't36', 77, [], ['r2','r4','r1','r5','r3'], 'fam1', 1 ).
test( 't37', 254, [], [], 'fam1', 1 ).
test( 't38', 226, ['m10'], [], 'fam1', 1 ).
test( 't39', 525, [], [], 'fam1', 1 ).
test( 't40', 488, [], [], 'fam1', 1 ).
test( 't41', 541, [], [], 'fam1', 1 ).
test( 't42', 373, [], [], 'fam1', 1 ).
test( 't43', 527, [], ['r1','r4'], 'fam1', 1 ).
test( 't44', 519, [], ['r2','r5','r3','r4','r1'], 'fam1', 1 ).
test( 't45', 784, [], [], 'fam1', 1 ).
test( 't46', 642, ['m9','m7','m1','m5'], [], 'fam1', 1 ).
test( 't47', 650, [], [], 'fam1', 1 ).
test( 't48', 725, [], ['r5','r2','r4','r3'], 'fam1', 1 ).
test( 't49', 299, [], [], 'fam1', 1 ).
test( 't50', 545, ['m6','m4','m2','m9'], [], 'fam1', 1 ).
test( 't51', 405, [], [], 'fam1', 1 ).
test( 't52', 666, [], [], 'fam1', 1 ).
test( 't53', 387, [], ['r1','r2','r4'], 'fam1', 1 ).
test( 't54', 139, [], [], 'fam1', 1 ).
test( 't55', 373, ['m10','m5','m7'], [], 'fam1', 1 ).
test( 't56', 507, [], [], 'fam1', 1 ).
test( 't57', 93, [], [], 'fam1', 1 ).
test( 't58', 496, [], [], 'fam1', 1 ).
test( 't59', 328, [], ['r3','r1','r4','r5'], 'fam1', 1 ).
test( 't60', 183, [], ['r4'], 'fam1', 1 ).
test( 't61', 125, [], ['r4'], 'fam1', 1 ).
test( 't62', 277, ['m3'], [], 'fam1', 1 ).
test( 't63', 327, [], [], 'fam1', 1 ).
test( 't64', 625, [], [], 'fam1', 1 ).
test( 't65', 692, [], [], 'fam1', 1 ).
test( 't66', 382, [], [], 'fam1', 1 ).
test( 't67', 269, [], [], 'fam1', 1 ).
test( 't68', 569, ['m5'], [], 'fam1', 1 ).
test( 't69', 622, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't70', 676, [], ['r2','r3','r5','r1'], 'fam1', 1 ).
test( 't71', 199, [], [], 'fam1', 1 ).
test( 't72', 364, [], ['r2','r3','r4','r1'], 'fam1', 1 ).
test( 't73', 356, [], ['r1','r3','r5'], 'fam1', 1 ).
test( 't74', 125, [], [], 'fam1', 1 ).
test( 't75', 266, [], [], 'fam1', 1 ).
test( 't76', 182, [], [], 'fam1', 1 ).
test( 't77', 730, ['m4','m7','m3'], [], 'fam1', 1 ).
test( 't78', 432, [], [], 'fam1', 1 ).
test( 't79', 304, [], [], 'fam1', 1 ).
test( 't80', 48, [], [], 'fam1', 1 ).
test( 't81', 8, [], ['r2','r3'], 'fam1', 1 ).
test( 't82', 477, [], ['r2','r3','r4'], 'fam1', 1 ).
test( 't83', 507, [], [], 'fam1', 1 ).
test( 't84', 6, [], ['r1','r4','r2','r5'], 'fam1', 1 ).
test( 't85', 397, [], [], 'fam1', 1 ).
test( 't86', 470, [], [], 'fam1', 1 ).
test( 't87', 182, [], ['r5','r3'], 'fam1', 1 ).
test( 't88', 613, [], [], 'fam1', 1 ).
test( 't89', 798, [], ['r4','r2','r1','r3','r5'], 'fam1', 1 ).
test( 't90', 172, [], ['r2','r1'], 'fam1', 1 ).
test( 't91', 396, [], ['r4','r2','r5','r3','r1'], 'fam1', 1 ).
test( 't92', 223, [], [], 'fam1', 1 ).
test( 't93', 54, ['m8','m7'], ['r3','r5','r2','r1'], 'fam1', 1 ).
test( 't94', 18, [], ['r4','r2','r1','r5'], 'fam1', 1 ).
test( 't95', 1, [], [], 'fam1', 1 ).
test( 't96', 404, ['m5','m10','m4'], [], 'fam1', 1 ).
test( 't97', 768, [], [], 'fam1', 1 ).
test( 't98', 529, [], ['r4','r2','r5','r3'], 'fam1', 1 ).
test( 't99', 488, [], [], 'fam1', 1 ).
test( 't100', 260, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
