%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 10
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 348, [], [], 'fam1', 1 ).
test( 't2', 799, [], [], 'fam1', 1 ).
test( 't3', 314, [], ['r3','r7','r4','r5'], 'fam1', 1 ).
test( 't4', 390, [], ['r5','r7','r8','r1','r10'], 'fam1', 1 ).
test( 't5', 767, [], [], 'fam1', 1 ).
test( 't6', 196, [], ['r7','r1','r10','r4','r2'], 'fam1', 1 ).
test( 't7', 645, [], ['r2','r9','r3','r8'], 'fam1', 1 ).
test( 't8', 45, [], [], 'fam1', 1 ).
test( 't9', 148, ['m3','m8','m9'], [], 'fam1', 1 ).
test( 't10', 537, [], [], 'fam1', 1 ).
test( 't11', 184, [], [], 'fam1', 1 ).
test( 't12', 702, [], [], 'fam1', 1 ).
test( 't13', 641, [], [], 'fam1', 1 ).
test( 't14', 759, [], [], 'fam1', 1 ).
test( 't15', 341, [], [], 'fam1', 1 ).
test( 't16', 496, [], ['r1','r2','r8','r4','r6','r3','r7','r5','r9'], 'fam1', 1 ).
test( 't17', 551, [], ['r7','r8','r5','r1','r4','r2','r6','r3','r9','r10'], 'fam1', 1 ).
test( 't18', 61, [], [], 'fam1', 1 ).
test( 't19', 35, [], [], 'fam1', 1 ).
test( 't20', 148, [], [], 'fam1', 1 ).
test( 't21', 563, ['m9','m7','m1','m4'], [], 'fam1', 1 ).
test( 't22', 186, ['m1','m4','m5','m9'], [], 'fam1', 1 ).
test( 't23', 509, [], [], 'fam1', 1 ).
test( 't24', 627, [], [], 'fam1', 1 ).
test( 't25', 134, [], [], 'fam1', 1 ).
test( 't26', 347, [], [], 'fam1', 1 ).
test( 't27', 341, [], [], 'fam1', 1 ).
test( 't28', 41, [], ['r9','r8','r6','r10'], 'fam1', 1 ).
test( 't29', 741, ['m10','m5','m3'], [], 'fam1', 1 ).
test( 't30', 598, [], ['r3','r8','r10','r9'], 'fam1', 1 ).
test( 't31', 489, [], ['r1','r10'], 'fam1', 1 ).
test( 't32', 96, ['m2'], [], 'fam1', 1 ).
test( 't33', 234, [], ['r3'], 'fam1', 1 ).
test( 't34', 726, [], [], 'fam1', 1 ).
test( 't35', 618, [], [], 'fam1', 1 ).
test( 't36', 354, [], [], 'fam1', 1 ).
test( 't37', 56, ['m7','m6','m1'], ['r6','r10','r5','r3','r2','r7','r9','r1','r8'], 'fam1', 1 ).
test( 't38', 213, [], [], 'fam1', 1 ).
test( 't39', 781, [], [], 'fam1', 1 ).
test( 't40', 16, [], ['r10','r5','r3'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
