%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 264, [], [], 'fam1', 1 ).
test( 't2', 345, ['m4'], [], 'fam1', 1 ).
test( 't3', 59, [], [], 'fam1', 1 ).
test( 't4', 292, [], [], 'fam1', 1 ).
test( 't5', 21, [], ['r4','r5','r3','r2'], 'fam1', 1 ).
test( 't6', 106, [], [], 'fam1', 1 ).
test( 't7', 152, [], [], 'fam1', 1 ).
test( 't8', 158, [], [], 'fam1', 1 ).
test( 't9', 211, [], ['r4','r5','r2'], 'fam1', 1 ).
test( 't10', 672, [], [], 'fam1', 1 ).
test( 't11', 747, [], [], 'fam1', 1 ).
test( 't12', 10, [], [], 'fam1', 1 ).
test( 't13', 370, ['m2','m6','m10','m9'], [], 'fam1', 1 ).
test( 't14', 769, ['m3'], [], 'fam1', 1 ).
test( 't15', 375, ['m6'], [], 'fam1', 1 ).
test( 't16', 65, [], ['r5','r4','r3'], 'fam1', 1 ).
test( 't17', 259, [], [], 'fam1', 1 ).
test( 't18', 97, ['m6','m9'], [], 'fam1', 1 ).
test( 't19', 424, ['m4','m8','m7'], [], 'fam1', 1 ).
test( 't20', 586, [], [], 'fam1', 1 ).
test( 't21', 682, [], [], 'fam1', 1 ).
test( 't22', 146, [], ['r2','r4','r1','r5'], 'fam1', 1 ).
test( 't23', 224, [], [], 'fam1', 1 ).
test( 't24', 736, [], [], 'fam1', 1 ).
test( 't25', 464, ['m9','m2','m3'], [], 'fam1', 1 ).
test( 't26', 575, [], [], 'fam1', 1 ).
test( 't27', 731, [], [], 'fam1', 1 ).
test( 't28', 175, [], ['r5'], 'fam1', 1 ).
test( 't29', 484, [], ['r5','r2','r3','r4','r1'], 'fam1', 1 ).
test( 't30', 219, ['m4','m5','m7','m3'], [], 'fam1', 1 ).
test( 't31', 683, [], [], 'fam1', 1 ).
test( 't32', 793, [], ['r3','r5','r4'], 'fam1', 1 ).
test( 't33', 96, [], [], 'fam1', 1 ).
test( 't34', 628, ['m3','m5','m6','m10'], [], 'fam1', 1 ).
test( 't35', 15, ['m10','m6','m8'], ['r1'], 'fam1', 1 ).
test( 't36', 614, [], [], 'fam1', 1 ).
test( 't37', 561, [], [], 'fam1', 1 ).
test( 't38', 79, [], [], 'fam1', 1 ).
test( 't39', 378, [], [], 'fam1', 1 ).
test( 't40', 206, [], ['r1','r4','r3'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
