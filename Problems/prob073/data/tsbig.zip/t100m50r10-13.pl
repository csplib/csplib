%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 50
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 350, ['m24','m23','m33','m4','m27','m2','m48','m35','m20','m6','m47','m32','m16','m13','m41','m9','m5','m17','m8'], [], 'fam1', 1 ).
test( 't2', 133, [], [], 'fam1', 1 ).
test( 't3', 417, [], ['r8','r10','r3','r5','r2','r1','r7','r6','r9','r4'], 'fam1', 1 ).
test( 't4', 293, [], [], 'fam1', 1 ).
test( 't5', 49, [], ['r2'], 'fam1', 1 ).
test( 't6', 350, ['m23','m35','m33','m16','m5','m7','m28','m30','m22','m50','m15','m27','m4'], ['r1','r5','r9','r2','r7','r3','r8'], 'fam1', 1 ).
test( 't7', 420, ['m31','m1','m50','m29','m48','m30','m34','m27','m9','m46','m19','m20'], ['r1','r8','r10','r7','r2','r3'], 'fam1', 1 ).
test( 't8', 36, ['m47','m32','m10','m44'], [], 'fam1', 1 ).
test( 't9', 446, [], ['r1','r4','r8','r2'], 'fam1', 1 ).
test( 't10', 59, [], [], 'fam1', 1 ).
test( 't11', 293, [], [], 'fam1', 1 ).
test( 't12', 738, [], [], 'fam1', 1 ).
test( 't13', 725, [], ['r3','r10','r1','r9','r6','r8'], 'fam1', 1 ).
test( 't14', 754, [], ['r10','r5','r2','r7','r8','r1','r4','r3'], 'fam1', 1 ).
test( 't15', 664, [], [], 'fam1', 1 ).
test( 't16', 589, [], ['r5','r4','r2'], 'fam1', 1 ).
test( 't17', 115, [], ['r3','r5','r6','r1','r2','r4','r8','r7'], 'fam1', 1 ).
test( 't18', 713, [], [], 'fam1', 1 ).
test( 't19', 675, ['m31','m1','m42','m40','m10','m27','m16','m29','m33','m49','m9','m45','m43','m13','m28','m20','m3','m36','m7','m38'], [], 'fam1', 1 ).
test( 't20', 522, [], ['r8','r1','r6'], 'fam1', 1 ).
test( 't21', 34, [], [], 'fam1', 1 ).
test( 't22', 248, [], ['r5','r8','r9','r1','r2','r6','r4'], 'fam1', 1 ).
test( 't23', 624, [], [], 'fam1', 1 ).
test( 't24', 97, [], [], 'fam1', 1 ).
test( 't25', 244, [], [], 'fam1', 1 ).
test( 't26', 765, [], [], 'fam1', 1 ).
test( 't27', 213, [], [], 'fam1', 1 ).
test( 't28', 510, [], [], 'fam1', 1 ).
test( 't29', 138, ['m23','m33','m8','m15','m46','m38','m44'], [], 'fam1', 1 ).
test( 't30', 759, [], [], 'fam1', 1 ).
test( 't31', 793, [], [], 'fam1', 1 ).
test( 't32', 220, [], [], 'fam1', 1 ).
test( 't33', 260, ['m22','m39','m10','m7'], ['r2','r4','r5','r10','r1','r6','r8'], 'fam1', 1 ).
test( 't34', 272, [], [], 'fam1', 1 ).
test( 't35', 173, [], [], 'fam1', 1 ).
test( 't36', 625, [], [], 'fam1', 1 ).
test( 't37', 588, ['m37','m11','m41','m38','m17','m33','m21','m39','m12','m15','m10','m34','m35','m5','m8','m7','m13','m42','m9','m47'], ['r7','r4','r1','r2','r8','r10','r9','r6'], 'fam1', 1 ).
test( 't38', 528, [], [], 'fam1', 1 ).
test( 't39', 268, [], [], 'fam1', 1 ).
test( 't40', 471, [], [], 'fam1', 1 ).
test( 't41', 570, [], [], 'fam1', 1 ).
test( 't42', 130, [], [], 'fam1', 1 ).
test( 't43', 759, [], [], 'fam1', 1 ).
test( 't44', 158, [], [], 'fam1', 1 ).
test( 't45', 497, [], [], 'fam1', 1 ).
test( 't46', 212, [], [], 'fam1', 1 ).
test( 't47', 270, [], [], 'fam1', 1 ).
test( 't48', 281, [], [], 'fam1', 1 ).
test( 't49', 306, [], [], 'fam1', 1 ).
test( 't50', 778, [], ['r1','r2','r6','r5'], 'fam1', 1 ).
test( 't51', 665, [], [], 'fam1', 1 ).
test( 't52', 733, ['m1','m5','m15','m44','m26','m45','m41','m21','m17','m2','m25','m6','m43','m3'], [], 'fam1', 1 ).
test( 't53', 413, [], [], 'fam1', 1 ).
test( 't54', 364, [], [], 'fam1', 1 ).
test( 't55', 283, [], [], 'fam1', 1 ).
test( 't56', 407, [], [], 'fam1', 1 ).
test( 't57', 380, [], [], 'fam1', 1 ).
test( 't58', 548, [], ['r7','r6','r2','r9','r3','r8'], 'fam1', 1 ).
test( 't59', 386, [], [], 'fam1', 1 ).
test( 't60', 145, [], [], 'fam1', 1 ).
test( 't61', 451, [], [], 'fam1', 1 ).
test( 't62', 182, [], ['r5','r2','r10','r4','r8','r6','r1','r7','r9','r3'], 'fam1', 1 ).
test( 't63', 665, [], ['r2','r1','r6','r7','r4','r3'], 'fam1', 1 ).
test( 't64', 96, ['m28','m23','m44','m40','m31','m22','m17','m41'], [], 'fam1', 1 ).
test( 't65', 748, [], [], 'fam1', 1 ).
test( 't66', 101, [], [], 'fam1', 1 ).
test( 't67', 415, ['m30','m38','m11','m37','m18'], [], 'fam1', 1 ).
test( 't68', 600, [], ['r10','r5','r9','r6','r2','r7','r8','r1'], 'fam1', 1 ).
test( 't69', 394, [], [], 'fam1', 1 ).
test( 't70', 342, [], ['r9'], 'fam1', 1 ).
test( 't71', 369, [], [], 'fam1', 1 ).
test( 't72', 165, ['m20','m49','m22','m43','m19','m29','m31','m34','m28','m5','m18','m9','m14','m23','m2','m47','m39','m41','m15','m11'], [], 'fam1', 1 ).
test( 't73', 209, [], [], 'fam1', 1 ).
test( 't74', 545, [], [], 'fam1', 1 ).
test( 't75', 419, [], ['r5','r4','r6','r7','r2','r3','r1'], 'fam1', 1 ).
test( 't76', 8, [], [], 'fam1', 1 ).
test( 't77', 746, [], [], 'fam1', 1 ).
test( 't78', 639, [], [], 'fam1', 1 ).
test( 't79', 205, ['m15','m29','m9','m43','m39','m12','m2','m10','m49','m47','m32','m5','m48','m42','m13','m4','m6','m3','m34'], [], 'fam1', 1 ).
test( 't80', 533, [], ['r9','r8','r4','r7','r5'], 'fam1', 1 ).
test( 't81', 340, ['m4','m9','m19','m22'], ['r7','r6'], 'fam1', 1 ).
test( 't82', 520, [], ['r9','r10'], 'fam1', 1 ).
test( 't83', 229, [], [], 'fam1', 1 ).
test( 't84', 203, [], [], 'fam1', 1 ).
test( 't85', 243, [], [], 'fam1', 1 ).
test( 't86', 7, [], [], 'fam1', 1 ).
test( 't87', 696, [], ['r8','r10','r7','r3'], 'fam1', 1 ).
test( 't88', 647, [], ['r2'], 'fam1', 1 ).
test( 't89', 77, [], [], 'fam1', 1 ).
test( 't90', 436, ['m23','m46','m47','m13','m28'], ['r9','r6','r3','r1','r4'], 'fam1', 1 ).
test( 't91', 753, [], ['r8','r1','r5','r9','r3','r2','r7','r10'], 'fam1', 1 ).
test( 't92', 600, [], [], 'fam1', 1 ).
test( 't93', 385, [], [], 'fam1', 1 ).
test( 't94', 574, [], [], 'fam1', 1 ).
test( 't95', 668, [], ['r6'], 'fam1', 1 ).
test( 't96', 321, [], [], 'fam1', 1 ).
test( 't97', 614, [], [], 'fam1', 1 ).
test( 't98', 434, [], [], 'fam1', 1 ).
test( 't99', 493, [], [], 'fam1', 1 ).
test( 't100', 421, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').
embedded_board( 'm21').
embedded_board( 'm22').
embedded_board( 'm23').
embedded_board( 'm24').
embedded_board( 'm25').
embedded_board( 'm26').
embedded_board( 'm27').
embedded_board( 'm28').
embedded_board( 'm29').
embedded_board( 'm30').
embedded_board( 'm31').
embedded_board( 'm32').
embedded_board( 'm33').
embedded_board( 'm34').
embedded_board( 'm35').
embedded_board( 'm36').
embedded_board( 'm37').
embedded_board( 'm38').
embedded_board( 'm39').
embedded_board( 'm40').
embedded_board( 'm41').
embedded_board( 'm42').
embedded_board( 'm43').
embedded_board( 'm44').
embedded_board( 'm45').
embedded_board( 'm46').
embedded_board( 'm47').
embedded_board( 'm48').
embedded_board( 'm49').
embedded_board( 'm50').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
