%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 20
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 667, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't2', 329, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't3', 330, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't4', 180, [], [], 'fam1', 1 ).
test( 't5', 400, ['m10','m2','m7','m9','m14'], [], 'fam1', 1 ).
test( 't6', 284, [], ['r1'], 'fam1', 1 ).
test( 't7', 433, [], ['r2'], 'fam1', 1 ).
test( 't8', 607, [], ['r1'], 'fam1', 1 ).
test( 't9', 568, ['m6'], [], 'fam1', 1 ).
test( 't10', 5, [], [], 'fam1', 1 ).
test( 't11', 9, [], ['r1'], 'fam1', 1 ).
test( 't12', 735, [], ['r3','r1'], 'fam1', 1 ).
test( 't13', 604, [], [], 'fam1', 1 ).
test( 't14', 699, ['m2','m5','m6','m11'], [], 'fam1', 1 ).
test( 't15', 411, [], [], 'fam1', 1 ).
test( 't16', 225, ['m9','m3','m4','m16','m18','m19'], [], 'fam1', 1 ).
test( 't17', 353, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't18', 431, [], [], 'fam1', 1 ).
test( 't19', 246, [], ['r2','r1'], 'fam1', 1 ).
test( 't20', 157, [], [], 'fam1', 1 ).
test( 't21', 680, ['m5','m2'], [], 'fam1', 1 ).
test( 't22', 228, [], [], 'fam1', 1 ).
test( 't23', 322, [], ['r3','r2'], 'fam1', 1 ).
test( 't24', 734, ['m19','m13','m1','m15','m6','m9','m5'], ['r2'], 'fam1', 1 ).
test( 't25', 87, [], [], 'fam1', 1 ).
test( 't26', 681, [], [], 'fam1', 1 ).
test( 't27', 248, [], [], 'fam1', 1 ).
test( 't28', 125, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't29', 762, [], [], 'fam1', 1 ).
test( 't30', 132, [], ['r2','r3'], 'fam1', 1 ).
test( 't31', 778, [], [], 'fam1', 1 ).
test( 't32', 488, [], [], 'fam1', 1 ).
test( 't33', 81, [], [], 'fam1', 1 ).
test( 't34', 574, [], [], 'fam1', 1 ).
test( 't35', 369, [], [], 'fam1', 1 ).
test( 't36', 606, [], [], 'fam1', 1 ).
test( 't37', 248, ['m16','m6','m10','m11','m18'], [], 'fam1', 1 ).
test( 't38', 634, [], [], 'fam1', 1 ).
test( 't39', 438, [], [], 'fam1', 1 ).
test( 't40', 245, [], [], 'fam1', 1 ).
test( 't41', 616, [], [], 'fam1', 1 ).
test( 't42', 349, [], [], 'fam1', 1 ).
test( 't43', 188, [], [], 'fam1', 1 ).
test( 't44', 206, [], ['r2','r1'], 'fam1', 1 ).
test( 't45', 248, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't46', 725, ['m2','m4','m6','m1','m7'], ['r3'], 'fam1', 1 ).
test( 't47', 199, [], ['r1','r3'], 'fam1', 1 ).
test( 't48', 645, [], [], 'fam1', 1 ).
test( 't49', 724, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't50', 255, [], [], 'fam1', 1 ).
test( 't51', 60, [], [], 'fam1', 1 ).
test( 't52', 746, [], ['r2','r1'], 'fam1', 1 ).
test( 't53', 378, ['m14','m1'], ['r1','r3'], 'fam1', 1 ).
test( 't54', 182, [], [], 'fam1', 1 ).
test( 't55', 760, ['m12','m4'], [], 'fam1', 1 ).
test( 't56', 215, [], [], 'fam1', 1 ).
test( 't57', 147, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't58', 796, [], [], 'fam1', 1 ).
test( 't59', 737, [], [], 'fam1', 1 ).
test( 't60', 718, [], [], 'fam1', 1 ).
test( 't61', 661, [], ['r3','r1'], 'fam1', 1 ).
test( 't62', 294, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't63', 257, [], ['r1','r3'], 'fam1', 1 ).
test( 't64', 11, [], ['r3','r1'], 'fam1', 1 ).
test( 't65', 46, ['m3','m7','m18','m5','m10','m15','m19','m14'], [], 'fam1', 1 ).
test( 't66', 471, [], [], 'fam1', 1 ).
test( 't67', 497, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't68', 179, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't69', 76, [], [], 'fam1', 1 ).
test( 't70', 801, [], [], 'fam1', 1 ).
test( 't71', 664, [], [], 'fam1', 1 ).
test( 't72', 552, ['m7','m9','m14','m15','m8','m1','m17','m13'], [], 'fam1', 1 ).
test( 't73', 791, [], ['r2'], 'fam1', 1 ).
test( 't74', 193, [], [], 'fam1', 1 ).
test( 't75', 484, [], [], 'fam1', 1 ).
test( 't76', 647, [], ['r2'], 'fam1', 1 ).
test( 't77', 28, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't78', 370, [], [], 'fam1', 1 ).
test( 't79', 551, [], [], 'fam1', 1 ).
test( 't80', 453, [], ['r3','r1'], 'fam1', 1 ).
test( 't81', 735, [], [], 'fam1', 1 ).
test( 't82', 31, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't83', 712, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't84', 358, [], [], 'fam1', 1 ).
test( 't85', 86, [], [], 'fam1', 1 ).
test( 't86', 93, ['m18','m6','m14','m10','m17','m8','m13','m15'], ['r2','r1','r3'], 'fam1', 1 ).
test( 't87', 218, ['m19','m7','m10','m6','m14','m15','m8'], [], 'fam1', 1 ).
test( 't88', 341, [], [], 'fam1', 1 ).
test( 't89', 678, [], [], 'fam1', 1 ).
test( 't90', 512, [], [], 'fam1', 1 ).
test( 't91', 509, [], [], 'fam1', 1 ).
test( 't92', 510, [], [], 'fam1', 1 ).
test( 't93', 108, [], [], 'fam1', 1 ).
test( 't94', 650, [], [], 'fam1', 1 ).
test( 't95', 256, [], [], 'fam1', 1 ).
test( 't96', 751, [], ['r1','r2'], 'fam1', 1 ).
test( 't97', 16, ['m15','m12','m4'], [], 'fam1', 1 ).
test( 't98', 685, [], ['r3','r2'], 'fam1', 1 ).
test( 't99', 390, ['m17','m4','m13','m14','m6','m2','m16'], ['r1'], 'fam1', 1 ).
test( 't100', 328, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
