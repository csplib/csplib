%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 20
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 81, [], [], 'fam1', 1 ).
test( 't2', 431, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't3', 448, [], [], 'fam1', 1 ).
test( 't4', 589, ['m7','m11','m9','m1','m4','m13','m5','m16'], [], 'fam1', 1 ).
test( 't5', 236, [], ['r3','r1'], 'fam1', 1 ).
test( 't6', 798, [], [], 'fam1', 1 ).
test( 't7', 118, ['m15','m17','m7','m20','m8'], ['r2','r3'], 'fam1', 1 ).
test( 't8', 249, [], [], 'fam1', 1 ).
test( 't9', 113, [], [], 'fam1', 1 ).
test( 't10', 794, [], [], 'fam1', 1 ).
test( 't11', 254, [], [], 'fam1', 1 ).
test( 't12', 540, [], [], 'fam1', 1 ).
test( 't13', 370, [], [], 'fam1', 1 ).
test( 't14', 760, ['m16','m1'], [], 'fam1', 1 ).
test( 't15', 502, ['m17','m14','m12','m18','m15','m13','m7','m19'], [], 'fam1', 1 ).
test( 't16', 680, ['m13','m2','m7'], ['r3','r2'], 'fam1', 1 ).
test( 't17', 338, [], [], 'fam1', 1 ).
test( 't18', 729, [], [], 'fam1', 1 ).
test( 't19', 382, [], ['r1'], 'fam1', 1 ).
test( 't20', 653, ['m10','m8'], [], 'fam1', 1 ).
test( 't21', 9, ['m4'], [], 'fam1', 1 ).
test( 't22', 478, [], [], 'fam1', 1 ).
test( 't23', 756, [], ['r1','r3'], 'fam1', 1 ).
test( 't24', 67, [], [], 'fam1', 1 ).
test( 't25', 459, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't26', 754, ['m9','m19','m6','m13'], ['r1','r3','r2'], 'fam1', 1 ).
test( 't27', 74, [], [], 'fam1', 1 ).
test( 't28', 341, [], [], 'fam1', 1 ).
test( 't29', 268, [], [], 'fam1', 1 ).
test( 't30', 373, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
