%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 20
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 236, [], [], 'fam1', 1 ).
test( 't2', 222, ['m16'], ['r5'], 'fam1', 1 ).
test( 't3', 335, [], [], 'fam1', 1 ).
test( 't4', 780, [], ['r5','r2','r1'], 'fam1', 1 ).
test( 't5', 449, [], [], 'fam1', 1 ).
test( 't6', 440, [], [], 'fam1', 1 ).
test( 't7', 239, [], [], 'fam1', 1 ).
test( 't8', 493, [], ['r4','r2','r5'], 'fam1', 1 ).
test( 't9', 107, [], [], 'fam1', 1 ).
test( 't10', 604, [], ['r3'], 'fam1', 1 ).
test( 't11', 122, [], [], 'fam1', 1 ).
test( 't12', 724, [], [], 'fam1', 1 ).
test( 't13', 799, [], [], 'fam1', 1 ).
test( 't14', 66, [], [], 'fam1', 1 ).
test( 't15', 58, ['m12','m8','m7','m20','m13','m3','m14'], [], 'fam1', 1 ).
test( 't16', 120, [], [], 'fam1', 1 ).
test( 't17', 437, ['m5','m14','m9'], [], 'fam1', 1 ).
test( 't18', 362, [], [], 'fam1', 1 ).
test( 't19', 744, [], [], 'fam1', 1 ).
test( 't20', 548, [], [], 'fam1', 1 ).
test( 't21', 208, ['m14','m9','m8','m19','m1','m10','m20','m6'], ['r1','r4','r5','r2'], 'fam1', 1 ).
test( 't22', 765, [], ['r2','r5','r3'], 'fam1', 1 ).
test( 't23', 271, [], [], 'fam1', 1 ).
test( 't24', 125, ['m2','m5','m14','m16','m1'], [], 'fam1', 1 ).
test( 't25', 732, [], [], 'fam1', 1 ).
test( 't26', 352, [], ['r4','r3','r1'], 'fam1', 1 ).
test( 't27', 454, [], [], 'fam1', 1 ).
test( 't28', 453, [], [], 'fam1', 1 ).
test( 't29', 6, ['m5','m20','m11','m17','m6'], ['r5','r1','r4'], 'fam1', 1 ).
test( 't30', 516, [], [], 'fam1', 1 ).
test( 't31', 734, [], ['r5','r1','r3','r4','r2'], 'fam1', 1 ).
test( 't32', 278, [], ['r4','r2','r5','r3'], 'fam1', 1 ).
test( 't33', 109, [], [], 'fam1', 1 ).
test( 't34', 318, [], [], 'fam1', 1 ).
test( 't35', 772, ['m20','m3','m12','m1'], ['r1','r2'], 'fam1', 1 ).
test( 't36', 302, ['m1','m7','m6','m19','m10','m18','m2','m13'], [], 'fam1', 1 ).
test( 't37', 389, [], ['r4','r5','r3'], 'fam1', 1 ).
test( 't38', 643, [], [], 'fam1', 1 ).
test( 't39', 367, [], [], 'fam1', 1 ).
test( 't40', 162, [], [], 'fam1', 1 ).
test( 't41', 763, [], [], 'fam1', 1 ).
test( 't42', 68, [], ['r4','r5','r1','r2','r3'], 'fam1', 1 ).
test( 't43', 428, [], ['r4'], 'fam1', 1 ).
test( 't44', 399, [], [], 'fam1', 1 ).
test( 't45', 242, [], ['r2','r5','r4'], 'fam1', 1 ).
test( 't46', 631, [], [], 'fam1', 1 ).
test( 't47', 560, [], [], 'fam1', 1 ).
test( 't48', 287, ['m4','m12','m10','m6','m19'], [], 'fam1', 1 ).
test( 't49', 237, ['m9','m8','m19','m6'], ['r1'], 'fam1', 1 ).
test( 't50', 238, [], [], 'fam1', 1 ).
test( 't51', 83, [], [], 'fam1', 1 ).
test( 't52', 784, [], [], 'fam1', 1 ).
test( 't53', 49, [], [], 'fam1', 1 ).
test( 't54', 64, [], [], 'fam1', 1 ).
test( 't55', 225, ['m6'], [], 'fam1', 1 ).
test( 't56', 370, [], ['r1','r3','r5','r2'], 'fam1', 1 ).
test( 't57', 408, [], ['r1','r2','r4','r5','r3'], 'fam1', 1 ).
test( 't58', 715, [], ['r2'], 'fam1', 1 ).
test( 't59', 430, ['m20','m2'], [], 'fam1', 1 ).
test( 't60', 514, [], [], 'fam1', 1 ).
test( 't61', 652, [], [], 'fam1', 1 ).
test( 't62', 259, [], ['r1','r3','r4'], 'fam1', 1 ).
test( 't63', 47, [], ['r3','r4'], 'fam1', 1 ).
test( 't64', 608, [], [], 'fam1', 1 ).
test( 't65', 474, [], [], 'fam1', 1 ).
test( 't66', 627, [], ['r4','r5','r2','r1'], 'fam1', 1 ).
test( 't67', 35, [], [], 'fam1', 1 ).
test( 't68', 31, [], [], 'fam1', 1 ).
test( 't69', 709, ['m9','m16','m6','m3','m5','m15','m14','m13'], [], 'fam1', 1 ).
test( 't70', 128, [], ['r1','r2'], 'fam1', 1 ).
test( 't71', 776, [], [], 'fam1', 1 ).
test( 't72', 428, [], ['r5'], 'fam1', 1 ).
test( 't73', 186, [], [], 'fam1', 1 ).
test( 't74', 221, [], ['r2','r5','r3','r4'], 'fam1', 1 ).
test( 't75', 30, [], [], 'fam1', 1 ).
test( 't76', 174, [], [], 'fam1', 1 ).
test( 't77', 83, [], [], 'fam1', 1 ).
test( 't78', 699, ['m9','m17'], [], 'fam1', 1 ).
test( 't79', 14, [], [], 'fam1', 1 ).
test( 't80', 280, ['m1','m18','m8','m17'], ['r5'], 'fam1', 1 ).
test( 't81', 597, [], ['r2','r5','r3','r4','r1'], 'fam1', 1 ).
test( 't82', 191, [], ['r3'], 'fam1', 1 ).
test( 't83', 412, ['m19','m13','m18','m10','m14','m20','m5'], [], 'fam1', 1 ).
test( 't84', 181, [], [], 'fam1', 1 ).
test( 't85', 765, [], [], 'fam1', 1 ).
test( 't86', 522, [], [], 'fam1', 1 ).
test( 't87', 747, [], ['r2','r4','r1'], 'fam1', 1 ).
test( 't88', 716, [], [], 'fam1', 1 ).
test( 't89', 554, [], [], 'fam1', 1 ).
test( 't90', 687, [], [], 'fam1', 1 ).
test( 't91', 308, [], ['r1'], 'fam1', 1 ).
test( 't92', 698, ['m6','m4','m10','m2','m7','m14'], [], 'fam1', 1 ).
test( 't93', 535, [], [], 'fam1', 1 ).
test( 't94', 574, [], [], 'fam1', 1 ).
test( 't95', 112, ['m11'], [], 'fam1', 1 ).
test( 't96', 687, [], [], 'fam1', 1 ).
test( 't97', 698, [], [], 'fam1', 1 ).
test( 't98', 800, [], ['r1','r3','r2','r5'], 'fam1', 1 ).
test( 't99', 549, [], [], 'fam1', 1 ).
test( 't100', 308, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
