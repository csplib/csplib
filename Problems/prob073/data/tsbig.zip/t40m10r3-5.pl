%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 663, [], [], 'fam1', 1 ).
test( 't2', 481, ['m5','m6','m10'], [], 'fam1', 1 ).
test( 't3', 108, ['m1'], [], 'fam1', 1 ).
test( 't4', 678, [], [], 'fam1', 1 ).
test( 't5', 4, [], ['r3','r1'], 'fam1', 1 ).
test( 't6', 513, [], [], 'fam1', 1 ).
test( 't7', 165, [], [], 'fam1', 1 ).
test( 't8', 329, [], [], 'fam1', 1 ).
test( 't9', 195, [], [], 'fam1', 1 ).
test( 't10', 76, [], [], 'fam1', 1 ).
test( 't11', 108, [], [], 'fam1', 1 ).
test( 't12', 560, [], [], 'fam1', 1 ).
test( 't13', 530, [], [], 'fam1', 1 ).
test( 't14', 242, [], [], 'fam1', 1 ).
test( 't15', 338, [], ['r2'], 'fam1', 1 ).
test( 't16', 752, [], [], 'fam1', 1 ).
test( 't17', 760, [], ['r1','r3'], 'fam1', 1 ).
test( 't18', 249, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't19', 568, [], [], 'fam1', 1 ).
test( 't20', 257, [], [], 'fam1', 1 ).
test( 't21', 402, [], [], 'fam1', 1 ).
test( 't22', 274, [], [], 'fam1', 1 ).
test( 't23', 241, [], [], 'fam1', 1 ).
test( 't24', 6, [], [], 'fam1', 1 ).
test( 't25', 654, [], [], 'fam1', 1 ).
test( 't26', 463, [], [], 'fam1', 1 ).
test( 't27', 565, ['m1'], ['r3'], 'fam1', 1 ).
test( 't28', 661, [], [], 'fam1', 1 ).
test( 't29', 104, ['m5'], [], 'fam1', 1 ).
test( 't30', 192, [], [], 'fam1', 1 ).
test( 't31', 597, [], [], 'fam1', 1 ).
test( 't32', 429, [], ['r1'], 'fam1', 1 ).
test( 't33', 735, ['m6'], [], 'fam1', 1 ).
test( 't34', 106, [], [], 'fam1', 1 ).
test( 't35', 278, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't36', 536, [], [], 'fam1', 1 ).
test( 't37', 42, [], [], 'fam1', 1 ).
test( 't38', 128, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't39', 368, [], [], 'fam1', 1 ).
test( 't40', 124, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
