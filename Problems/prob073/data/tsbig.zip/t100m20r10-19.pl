%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 20
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 291, [], [], 'fam1', 1 ).
test( 't2', 151, [], [], 'fam1', 1 ).
test( 't3', 638, [], [], 'fam1', 1 ).
test( 't4', 681, [], [], 'fam1', 1 ).
test( 't5', 739, [], ['r8'], 'fam1', 1 ).
test( 't6', 269, [], ['r7','r10'], 'fam1', 1 ).
test( 't7', 679, ['m3','m12','m16','m19','m14','m15'], ['r6'], 'fam1', 1 ).
test( 't8', 563, [], [], 'fam1', 1 ).
test( 't9', 392, [], [], 'fam1', 1 ).
test( 't10', 753, [], [], 'fam1', 1 ).
test( 't11', 784, ['m15','m20','m10','m14','m3','m2','m12','m6'], [], 'fam1', 1 ).
test( 't12', 667, [], ['r10','r4','r8','r7','r6','r1'], 'fam1', 1 ).
test( 't13', 342, ['m18','m3','m4','m7','m15'], [], 'fam1', 1 ).
test( 't14', 101, [], ['r7','r10','r2','r4','r9','r3','r8','r5','r1','r6'], 'fam1', 1 ).
test( 't15', 163, [], [], 'fam1', 1 ).
test( 't16', 565, [], [], 'fam1', 1 ).
test( 't17', 484, ['m19'], [], 'fam1', 1 ).
test( 't18', 190, [], [], 'fam1', 1 ).
test( 't19', 193, [], ['r1','r2','r4','r7','r6','r9','r5','r3','r8'], 'fam1', 1 ).
test( 't20', 615, [], [], 'fam1', 1 ).
test( 't21', 251, [], ['r8','r7','r4','r5','r6','r9','r1'], 'fam1', 1 ).
test( 't22', 101, [], [], 'fam1', 1 ).
test( 't23', 188, [], ['r10'], 'fam1', 1 ).
test( 't24', 552, [], [], 'fam1', 1 ).
test( 't25', 633, ['m12','m19','m5','m15','m9'], [], 'fam1', 1 ).
test( 't26', 119, [], [], 'fam1', 1 ).
test( 't27', 285, [], [], 'fam1', 1 ).
test( 't28', 76, [], ['r9','r7','r5','r4','r3','r1','r2'], 'fam1', 1 ).
test( 't29', 321, [], ['r5','r3','r10','r6'], 'fam1', 1 ).
test( 't30', 282, [], [], 'fam1', 1 ).
test( 't31', 224, [], ['r6'], 'fam1', 1 ).
test( 't32', 610, [], [], 'fam1', 1 ).
test( 't33', 784, [], [], 'fam1', 1 ).
test( 't34', 286, [], ['r1','r5','r6','r2','r8'], 'fam1', 1 ).
test( 't35', 779, ['m18','m12'], [], 'fam1', 1 ).
test( 't36', 217, [], ['r5','r8','r9','r7','r2','r6','r1','r4','r10'], 'fam1', 1 ).
test( 't37', 747, [], ['r4','r3','r10','r7','r9','r6','r2','r5','r8'], 'fam1', 1 ).
test( 't38', 624, [], [], 'fam1', 1 ).
test( 't39', 540, [], ['r9','r7'], 'fam1', 1 ).
test( 't40', 418, ['m4','m8'], [], 'fam1', 1 ).
test( 't41', 543, ['m11','m10','m4','m5','m15'], [], 'fam1', 1 ).
test( 't42', 484, [], [], 'fam1', 1 ).
test( 't43', 734, [], ['r4','r9','r10','r2','r1','r5','r3','r7','r6'], 'fam1', 1 ).
test( 't44', 730, [], ['r5','r9','r6'], 'fam1', 1 ).
test( 't45', 7, [], [], 'fam1', 1 ).
test( 't46', 722, [], [], 'fam1', 1 ).
test( 't47', 366, [], ['r5'], 'fam1', 1 ).
test( 't48', 79, [], [], 'fam1', 1 ).
test( 't49', 166, [], ['r7','r3','r5','r8'], 'fam1', 1 ).
test( 't50', 269, [], ['r5','r7','r3','r10'], 'fam1', 1 ).
test( 't51', 235, [], ['r3','r10','r9','r4','r6','r1','r8','r5','r7'], 'fam1', 1 ).
test( 't52', 772, [], ['r9','r5','r8','r2','r4','r10','r7','r6'], 'fam1', 1 ).
test( 't53', 57, [], [], 'fam1', 1 ).
test( 't54', 760, [], [], 'fam1', 1 ).
test( 't55', 792, [], [], 'fam1', 1 ).
test( 't56', 729, [], ['r8','r10','r2','r5','r9','r3','r1'], 'fam1', 1 ).
test( 't57', 679, [], [], 'fam1', 1 ).
test( 't58', 35, [], [], 'fam1', 1 ).
test( 't59', 625, [], ['r10','r1','r4','r5','r3','r8','r6','r9','r2','r7'], 'fam1', 1 ).
test( 't60', 608, ['m18'], ['r4','r5','r2','r9','r3','r8','r6','r7','r10','r1'], 'fam1', 1 ).
test( 't61', 738, [], [], 'fam1', 1 ).
test( 't62', 466, [], ['r10','r1','r6','r5','r8','r7','r4','r3','r2'], 'fam1', 1 ).
test( 't63', 377, ['m9','m15','m8','m2','m12'], [], 'fam1', 1 ).
test( 't64', 459, ['m3','m1','m14','m6','m15','m4','m2'], [], 'fam1', 1 ).
test( 't65', 423, [], [], 'fam1', 1 ).
test( 't66', 271, [], ['r7'], 'fam1', 1 ).
test( 't67', 745, [], [], 'fam1', 1 ).
test( 't68', 29, [], [], 'fam1', 1 ).
test( 't69', 430, [], [], 'fam1', 1 ).
test( 't70', 79, [], [], 'fam1', 1 ).
test( 't71', 559, [], [], 'fam1', 1 ).
test( 't72', 575, [], ['r6','r10','r8','r5','r2'], 'fam1', 1 ).
test( 't73', 44, [], [], 'fam1', 1 ).
test( 't74', 95, [], [], 'fam1', 1 ).
test( 't75', 119, [], [], 'fam1', 1 ).
test( 't76', 356, [], ['r4','r8','r2','r1','r9','r7','r10','r6','r5','r3'], 'fam1', 1 ).
test( 't77', 456, ['m17','m14','m1','m2','m5'], ['r3','r10','r9','r1','r5'], 'fam1', 1 ).
test( 't78', 765, [], [], 'fam1', 1 ).
test( 't79', 267, [], ['r3','r8','r9','r7','r4'], 'fam1', 1 ).
test( 't80', 703, [], ['r10','r4'], 'fam1', 1 ).
test( 't81', 163, ['m8','m11','m16'], [], 'fam1', 1 ).
test( 't82', 381, [], [], 'fam1', 1 ).
test( 't83', 53, [], [], 'fam1', 1 ).
test( 't84', 669, [], [], 'fam1', 1 ).
test( 't85', 596, [], [], 'fam1', 1 ).
test( 't86', 55, [], ['r3'], 'fam1', 1 ).
test( 't87', 268, [], [], 'fam1', 1 ).
test( 't88', 707, [], ['r6','r7','r2','r3','r4','r8','r9','r5','r1'], 'fam1', 1 ).
test( 't89', 586, [], [], 'fam1', 1 ).
test( 't90', 177, [], [], 'fam1', 1 ).
test( 't91', 155, [], [], 'fam1', 1 ).
test( 't92', 250, [], [], 'fam1', 1 ).
test( 't93', 787, [], [], 'fam1', 1 ).
test( 't94', 305, [], [], 'fam1', 1 ).
test( 't95', 664, [], [], 'fam1', 1 ).
test( 't96', 446, ['m8','m19','m13'], ['r3','r9','r6','r5'], 'fam1', 1 ).
test( 't97', 763, [], [], 'fam1', 1 ).
test( 't98', 357, ['m7','m15','m19','m20','m14','m1'], ['r2','r3'], 'fam1', 1 ).
test( 't99', 606, [], ['r6','r5','r8'], 'fam1', 1 ).
test( 't100', 714, [], ['r3','r6','r5','r4','r2','r8','r9','r10'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
