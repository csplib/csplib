%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 20
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 628, [], [], 'fam1', 1 ).
test( 't2', 325, [], [], 'fam1', 1 ).
test( 't3', 269, [], [], 'fam1', 1 ).
test( 't4', 392, [], [], 'fam1', 1 ).
test( 't5', 412, [], [], 'fam1', 1 ).
test( 't6', 347, [], [], 'fam1', 1 ).
test( 't7', 438, [], ['r2','r3','r1','r5','r4'], 'fam1', 1 ).
test( 't8', 712, [], ['r5','r1','r2'], 'fam1', 1 ).
test( 't9', 203, [], [], 'fam1', 1 ).
test( 't10', 495, [], [], 'fam1', 1 ).
test( 't11', 518, [], [], 'fam1', 1 ).
test( 't12', 104, [], [], 'fam1', 1 ).
test( 't13', 156, ['m18','m15','m4','m7','m19','m5','m2'], ['r4','r1','r5','r2'], 'fam1', 1 ).
test( 't14', 185, [], [], 'fam1', 1 ).
test( 't15', 109, ['m3','m4','m14','m19','m9','m11','m1','m13'], [], 'fam1', 1 ).
test( 't16', 239, [], ['r5'], 'fam1', 1 ).
test( 't17', 716, [], [], 'fam1', 1 ).
test( 't18', 601, [], [], 'fam1', 1 ).
test( 't19', 172, [], ['r3','r5','r4','r2'], 'fam1', 1 ).
test( 't20', 183, [], [], 'fam1', 1 ).
test( 't21', 528, ['m20','m14'], [], 'fam1', 1 ).
test( 't22', 388, [], ['r2','r1','r5'], 'fam1', 1 ).
test( 't23', 648, [], [], 'fam1', 1 ).
test( 't24', 381, [], [], 'fam1', 1 ).
test( 't25', 145, [], [], 'fam1', 1 ).
test( 't26', 534, ['m9','m19'], ['r5','r2','r3','r1'], 'fam1', 1 ).
test( 't27', 523, [], [], 'fam1', 1 ).
test( 't28', 493, ['m6','m17','m7','m4','m19','m16','m18','m20'], [], 'fam1', 1 ).
test( 't29', 247, [], [], 'fam1', 1 ).
test( 't30', 299, [], [], 'fam1', 1 ).
test( 't31', 727, ['m1','m12','m20','m14','m19'], [], 'fam1', 1 ).
test( 't32', 488, ['m10','m7','m6','m4','m18','m19'], [], 'fam1', 1 ).
test( 't33', 700, ['m4','m13','m20','m6','m15'], ['r1'], 'fam1', 1 ).
test( 't34', 511, [], [], 'fam1', 1 ).
test( 't35', 160, [], [], 'fam1', 1 ).
test( 't36', 465, [], [], 'fam1', 1 ).
test( 't37', 610, [], ['r4','r5','r3','r1'], 'fam1', 1 ).
test( 't38', 372, [], [], 'fam1', 1 ).
test( 't39', 386, [], [], 'fam1', 1 ).
test( 't40', 605, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
