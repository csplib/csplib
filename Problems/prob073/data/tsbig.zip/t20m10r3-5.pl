%% ****  Testsuite  ****
% Number of tests                  : 20
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 482, [], ['r3'], 'fam1', 1 ).
test( 't2', 575, [], [], 'fam1', 1 ).
test( 't3', 144, [], ['r3'], 'fam1', 1 ).
test( 't4', 489, [], ['r2','r3'], 'fam1', 1 ).
test( 't5', 502, [], [], 'fam1', 1 ).
test( 't6', 713, [], ['r2'], 'fam1', 1 ).
test( 't7', 599, [], [], 'fam1', 1 ).
test( 't8', 182, [], [], 'fam1', 1 ).
test( 't9', 487, [], ['r2'], 'fam1', 1 ).
test( 't10', 694, [], [], 'fam1', 1 ).
test( 't11', 692, [], ['r2'], 'fam1', 1 ).
test( 't12', 41, ['m6','m8'], [], 'fam1', 1 ).
test( 't13', 61, ['m10','m8'], [], 'fam1', 1 ).
test( 't14', 622, ['m7','m9','m8','m1'], [], 'fam1', 1 ).
test( 't15', 413, [], [], 'fam1', 1 ).
test( 't16', 274, [], [], 'fam1', 1 ).
test( 't17', 506, [], [], 'fam1', 1 ).
test( 't18', 358, [], ['r1'], 'fam1', 1 ).
test( 't19', 496, [], ['r3','r1'], 'fam1', 1 ).
test( 't20', 505, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
