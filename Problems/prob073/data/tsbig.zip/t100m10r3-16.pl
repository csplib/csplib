%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 354, [], [], 'fam1', 1 ).
test( 't2', 207, [], ['r1'], 'fam1', 1 ).
test( 't3', 298, ['m8'], [], 'fam1', 1 ).
test( 't4', 555, [], [], 'fam1', 1 ).
test( 't5', 679, ['m3','m4','m9','m2'], [], 'fam1', 1 ).
test( 't6', 692, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't7', 268, ['m4'], [], 'fam1', 1 ).
test( 't8', 677, ['m3'], [], 'fam1', 1 ).
test( 't9', 139, ['m8'], [], 'fam1', 1 ).
test( 't10', 490, ['m3','m6','m10'], ['r1','r2','r3'], 'fam1', 1 ).
test( 't11', 405, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't12', 574, [], [], 'fam1', 1 ).
test( 't13', 59, ['m8','m3','m7'], [], 'fam1', 1 ).
test( 't14', 701, [], ['r3','r1'], 'fam1', 1 ).
test( 't15', 59, [], [], 'fam1', 1 ).
test( 't16', 626, [], ['r2','r1'], 'fam1', 1 ).
test( 't17', 473, [], [], 'fam1', 1 ).
test( 't18', 402, [], [], 'fam1', 1 ).
test( 't19', 725, [], [], 'fam1', 1 ).
test( 't20', 614, [], [], 'fam1', 1 ).
test( 't21', 395, [], ['r3','r2'], 'fam1', 1 ).
test( 't22', 798, [], ['r3'], 'fam1', 1 ).
test( 't23', 122, [], [], 'fam1', 1 ).
test( 't24', 61, [], [], 'fam1', 1 ).
test( 't25', 1, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't26', 25, ['m7','m2','m8'], [], 'fam1', 1 ).
test( 't27', 499, [], [], 'fam1', 1 ).
test( 't28', 344, [], [], 'fam1', 1 ).
test( 't29', 351, [], [], 'fam1', 1 ).
test( 't30', 263, ['m9','m2','m8','m4'], [], 'fam1', 1 ).
test( 't31', 740, ['m2','m5','m4'], [], 'fam1', 1 ).
test( 't32', 36, [], [], 'fam1', 1 ).
test( 't33', 798, [], [], 'fam1', 1 ).
test( 't34', 159, [], [], 'fam1', 1 ).
test( 't35', 389, [], [], 'fam1', 1 ).
test( 't36', 729, ['m1','m10'], ['r2'], 'fam1', 1 ).
test( 't37', 391, [], ['r2'], 'fam1', 1 ).
test( 't38', 563, [], [], 'fam1', 1 ).
test( 't39', 611, [], ['r1'], 'fam1', 1 ).
test( 't40', 9, [], [], 'fam1', 1 ).
test( 't41', 770, [], [], 'fam1', 1 ).
test( 't42', 403, ['m7'], [], 'fam1', 1 ).
test( 't43', 689, [], [], 'fam1', 1 ).
test( 't44', 371, [], [], 'fam1', 1 ).
test( 't45', 501, [], ['r2'], 'fam1', 1 ).
test( 't46', 438, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't47', 569, [], ['r2','r1'], 'fam1', 1 ).
test( 't48', 185, ['m6','m3','m10','m7'], [], 'fam1', 1 ).
test( 't49', 625, ['m1'], [], 'fam1', 1 ).
test( 't50', 298, [], [], 'fam1', 1 ).
test( 't51', 344, ['m6','m10','m9'], [], 'fam1', 1 ).
test( 't52', 574, ['m6'], [], 'fam1', 1 ).
test( 't53', 334, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't54', 291, ['m3'], [], 'fam1', 1 ).
test( 't55', 266, [], [], 'fam1', 1 ).
test( 't56', 692, ['m2','m5','m6','m3'], ['r1','r2','r3'], 'fam1', 1 ).
test( 't57', 262, [], [], 'fam1', 1 ).
test( 't58', 443, [], ['r2','r1'], 'fam1', 1 ).
test( 't59', 633, [], ['r3'], 'fam1', 1 ).
test( 't60', 767, [], [], 'fam1', 1 ).
test( 't61', 392, [], ['r1'], 'fam1', 1 ).
test( 't62', 627, [], [], 'fam1', 1 ).
test( 't63', 325, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't64', 663, ['m10'], [], 'fam1', 1 ).
test( 't65', 297, ['m2','m6','m5'], ['r3'], 'fam1', 1 ).
test( 't66', 498, ['m3'], ['r3','r1'], 'fam1', 1 ).
test( 't67', 552, [], [], 'fam1', 1 ).
test( 't68', 216, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't69', 686, [], [], 'fam1', 1 ).
test( 't70', 261, ['m10'], [], 'fam1', 1 ).
test( 't71', 378, ['m10'], [], 'fam1', 1 ).
test( 't72', 454, ['m3','m5','m7','m1'], [], 'fam1', 1 ).
test( 't73', 562, [], [], 'fam1', 1 ).
test( 't74', 687, [], [], 'fam1', 1 ).
test( 't75', 250, ['m6','m9','m7','m5'], [], 'fam1', 1 ).
test( 't76', 401, [], ['r2'], 'fam1', 1 ).
test( 't77', 677, [], ['r3','r2'], 'fam1', 1 ).
test( 't78', 42, [], [], 'fam1', 1 ).
test( 't79', 279, [], ['r1'], 'fam1', 1 ).
test( 't80', 214, ['m4','m9'], ['r1','r2'], 'fam1', 1 ).
test( 't81', 730, [], [], 'fam1', 1 ).
test( 't82', 419, [], [], 'fam1', 1 ).
test( 't83', 71, [], ['r3'], 'fam1', 1 ).
test( 't84', 2, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't85', 364, [], ['r3','r2'], 'fam1', 1 ).
test( 't86', 224, [], [], 'fam1', 1 ).
test( 't87', 600, ['m7','m3','m10','m2'], [], 'fam1', 1 ).
test( 't88', 213, ['m10','m8'], [], 'fam1', 1 ).
test( 't89', 605, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't90', 85, [], [], 'fam1', 1 ).
test( 't91', 319, [], [], 'fam1', 1 ).
test( 't92', 773, [], [], 'fam1', 1 ).
test( 't93', 228, [], [], 'fam1', 1 ).
test( 't94', 116, [], ['r2','r1'], 'fam1', 1 ).
test( 't95', 169, [], ['r2','r3'], 'fam1', 1 ).
test( 't96', 735, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't97', 348, [], [], 'fam1', 1 ).
test( 't98', 607, [], [], 'fam1', 1 ).
test( 't99', 652, [], ['r3','r2'], 'fam1', 1 ).
test( 't100', 694, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
