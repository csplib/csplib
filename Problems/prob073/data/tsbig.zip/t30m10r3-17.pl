%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 417, [], [], 'fam1', 1 ).
test( 't2', 27, [], [], 'fam1', 1 ).
test( 't3', 782, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't4', 277, [], [], 'fam1', 1 ).
test( 't5', 384, [], [], 'fam1', 1 ).
test( 't6', 272, [], ['r2'], 'fam1', 1 ).
test( 't7', 713, [], [], 'fam1', 1 ).
test( 't8', 281, [], [], 'fam1', 1 ).
test( 't9', 133, [], [], 'fam1', 1 ).
test( 't10', 451, ['m4'], [], 'fam1', 1 ).
test( 't11', 260, ['m10','m9'], ['r3'], 'fam1', 1 ).
test( 't12', 141, ['m5'], ['r2'], 'fam1', 1 ).
test( 't13', 581, [], [], 'fam1', 1 ).
test( 't14', 490, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't15', 616, ['m7','m4'], [], 'fam1', 1 ).
test( 't16', 337, ['m3','m8','m4'], [], 'fam1', 1 ).
test( 't17', 668, ['m2','m7'], [], 'fam1', 1 ).
test( 't18', 281, [], ['r3','r2'], 'fam1', 1 ).
test( 't19', 147, [], [], 'fam1', 1 ).
test( 't20', 419, ['m6','m2'], [], 'fam1', 1 ).
test( 't21', 373, [], ['r2','r3'], 'fam1', 1 ).
test( 't22', 43, [], ['r3','r1'], 'fam1', 1 ).
test( 't23', 243, [], [], 'fam1', 1 ).
test( 't24', 603, ['m4','m2','m1'], ['r3'], 'fam1', 1 ).
test( 't25', 621, [], [], 'fam1', 1 ).
test( 't26', 434, [], ['r2'], 'fam1', 1 ).
test( 't27', 275, [], [], 'fam1', 1 ).
test( 't28', 143, [], ['r2','r3'], 'fam1', 1 ).
test( 't29', 388, ['m9'], [], 'fam1', 1 ).
test( 't30', 48, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
