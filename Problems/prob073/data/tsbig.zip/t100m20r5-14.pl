%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 20
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 288, [], [], 'fam1', 1 ).
test( 't2', 666, [], [], 'fam1', 1 ).
test( 't3', 738, [], [], 'fam1', 1 ).
test( 't4', 390, [], [], 'fam1', 1 ).
test( 't5', 206, [], [], 'fam1', 1 ).
test( 't6', 748, [], [], 'fam1', 1 ).
test( 't7', 335, [], [], 'fam1', 1 ).
test( 't8', 147, [], [], 'fam1', 1 ).
test( 't9', 550, [], [], 'fam1', 1 ).
test( 't10', 255, [], ['r5','r2','r4'], 'fam1', 1 ).
test( 't11', 743, [], [], 'fam1', 1 ).
test( 't12', 597, [], [], 'fam1', 1 ).
test( 't13', 74, [], ['r3','r1'], 'fam1', 1 ).
test( 't14', 683, [], ['r4'], 'fam1', 1 ).
test( 't15', 383, [], [], 'fam1', 1 ).
test( 't16', 778, [], ['r3','r5','r2','r1'], 'fam1', 1 ).
test( 't17', 259, [], [], 'fam1', 1 ).
test( 't18', 651, [], [], 'fam1', 1 ).
test( 't19', 7, ['m9','m17','m20','m7','m2'], [], 'fam1', 1 ).
test( 't20', 539, [], [], 'fam1', 1 ).
test( 't21', 598, [], [], 'fam1', 1 ).
test( 't22', 799, [], [], 'fam1', 1 ).
test( 't23', 83, [], [], 'fam1', 1 ).
test( 't24', 785, ['m1','m3','m14'], [], 'fam1', 1 ).
test( 't25', 377, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't26', 8, [], [], 'fam1', 1 ).
test( 't27', 54, [], [], 'fam1', 1 ).
test( 't28', 364, [], [], 'fam1', 1 ).
test( 't29', 730, [], [], 'fam1', 1 ).
test( 't30', 405, [], [], 'fam1', 1 ).
test( 't31', 693, ['m13','m10','m1'], ['r4','r2','r1'], 'fam1', 1 ).
test( 't32', 559, [], ['r3','r4','r5'], 'fam1', 1 ).
test( 't33', 436, ['m16','m20','m17','m5','m9','m3','m18'], [], 'fam1', 1 ).
test( 't34', 52, [], [], 'fam1', 1 ).
test( 't35', 269, ['m10','m12','m3'], [], 'fam1', 1 ).
test( 't36', 654, [], [], 'fam1', 1 ).
test( 't37', 584, [], [], 'fam1', 1 ).
test( 't38', 727, [], [], 'fam1', 1 ).
test( 't39', 172, ['m6','m1','m19','m7','m9'], ['r4','r3','r1','r2'], 'fam1', 1 ).
test( 't40', 280, ['m6','m7','m16','m20','m10','m18'], ['r1','r2','r5','r4','r3'], 'fam1', 1 ).
test( 't41', 391, [], ['r1','r4'], 'fam1', 1 ).
test( 't42', 109, [], [], 'fam1', 1 ).
test( 't43', 354, [], [], 'fam1', 1 ).
test( 't44', 120, ['m10'], [], 'fam1', 1 ).
test( 't45', 304, [], [], 'fam1', 1 ).
test( 't46', 244, [], [], 'fam1', 1 ).
test( 't47', 495, [], [], 'fam1', 1 ).
test( 't48', 113, [], [], 'fam1', 1 ).
test( 't49', 465, [], ['r2','r3'], 'fam1', 1 ).
test( 't50', 337, [], [], 'fam1', 1 ).
test( 't51', 655, ['m1','m20','m12','m6','m15','m11','m13','m8'], [], 'fam1', 1 ).
test( 't52', 503, ['m12','m13','m15','m1','m11','m17','m6'], ['r4','r5','r1'], 'fam1', 1 ).
test( 't53', 532, ['m15','m2','m19','m14'], [], 'fam1', 1 ).
test( 't54', 584, [], ['r5','r4','r2'], 'fam1', 1 ).
test( 't55', 463, [], [], 'fam1', 1 ).
test( 't56', 336, [], [], 'fam1', 1 ).
test( 't57', 136, [], [], 'fam1', 1 ).
test( 't58', 360, [], [], 'fam1', 1 ).
test( 't59', 57, ['m5','m19','m15'], ['r1','r2','r3'], 'fam1', 1 ).
test( 't60', 40, ['m7','m17','m13','m16','m20'], ['r3','r1','r4','r2','r5'], 'fam1', 1 ).
test( 't61', 477, [], ['r1','r5'], 'fam1', 1 ).
test( 't62', 126, [], ['r1'], 'fam1', 1 ).
test( 't63', 177, [], [], 'fam1', 1 ).
test( 't64', 362, [], [], 'fam1', 1 ).
test( 't65', 57, [], [], 'fam1', 1 ).
test( 't66', 662, [], [], 'fam1', 1 ).
test( 't67', 182, [], [], 'fam1', 1 ).
test( 't68', 473, [], [], 'fam1', 1 ).
test( 't69', 732, [], ['r5','r2','r4','r1','r3'], 'fam1', 1 ).
test( 't70', 431, [], ['r3','r2','r5'], 'fam1', 1 ).
test( 't71', 671, ['m2','m12','m10','m5'], [], 'fam1', 1 ).
test( 't72', 86, [], [], 'fam1', 1 ).
test( 't73', 593, ['m1'], [], 'fam1', 1 ).
test( 't74', 433, ['m1','m12','m6','m18'], [], 'fam1', 1 ).
test( 't75', 620, [], [], 'fam1', 1 ).
test( 't76', 480, [], ['r5','r2','r4','r1','r3'], 'fam1', 1 ).
test( 't77', 564, [], ['r4','r1','r2'], 'fam1', 1 ).
test( 't78', 68, ['m17','m1'], ['r2','r3','r1','r4'], 'fam1', 1 ).
test( 't79', 800, [], ['r3','r4','r5'], 'fam1', 1 ).
test( 't80', 353, [], ['r2','r1'], 'fam1', 1 ).
test( 't81', 315, [], [], 'fam1', 1 ).
test( 't82', 145, [], ['r2','r4','r3'], 'fam1', 1 ).
test( 't83', 152, [], [], 'fam1', 1 ).
test( 't84', 54, [], ['r4','r1'], 'fam1', 1 ).
test( 't85', 749, [], ['r1','r3','r4','r5'], 'fam1', 1 ).
test( 't86', 339, [], [], 'fam1', 1 ).
test( 't87', 593, [], ['r1','r5','r3','r4','r2'], 'fam1', 1 ).
test( 't88', 97, ['m13','m7','m18','m10','m2','m6','m1'], [], 'fam1', 1 ).
test( 't89', 782, [], [], 'fam1', 1 ).
test( 't90', 450, [], [], 'fam1', 1 ).
test( 't91', 2, [], ['r2','r1','r3','r5'], 'fam1', 1 ).
test( 't92', 41, [], [], 'fam1', 1 ).
test( 't93', 205, [], ['r5'], 'fam1', 1 ).
test( 't94', 340, ['m10','m15','m7','m9','m13','m11','m1'], [], 'fam1', 1 ).
test( 't95', 59, [], [], 'fam1', 1 ).
test( 't96', 776, ['m19','m13','m1','m12','m11'], [], 'fam1', 1 ).
test( 't97', 685, [], ['r5','r3','r4'], 'fam1', 1 ).
test( 't98', 552, [], ['r3','r2','r5','r1','r4'], 'fam1', 1 ).
test( 't99', 145, [], ['r3','r4','r1','r2'], 'fam1', 1 ).
test( 't100', 405, [], ['r5'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
