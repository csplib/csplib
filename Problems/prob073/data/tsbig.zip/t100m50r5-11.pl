%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 50
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 389, [], [], 'fam1', 1 ).
test( 't2', 459, [], [], 'fam1', 1 ).
test( 't3', 283, [], ['r5','r2'], 'fam1', 1 ).
test( 't4', 143, [], [], 'fam1', 1 ).
test( 't5', 596, ['m45','m48','m47','m38','m29','m14','m43','m3'], [], 'fam1', 1 ).
test( 't6', 18, ['m36','m23','m24','m15','m1','m20','m49','m7','m40','m47'], ['r5','r3','r4','r1'], 'fam1', 1 ).
test( 't7', 779, [], [], 'fam1', 1 ).
test( 't8', 791, [], ['r1','r5'], 'fam1', 1 ).
test( 't9', 14, [], [], 'fam1', 1 ).
test( 't10', 654, [], ['r4','r5','r2','r1','r3'], 'fam1', 1 ).
test( 't11', 54, [], [], 'fam1', 1 ).
test( 't12', 636, [], ['r2','r1','r5','r4','r3'], 'fam1', 1 ).
test( 't13', 261, ['m33','m2','m36','m6','m26','m47','m16','m22','m46','m31','m14','m38','m15','m43','m13','m5','m50','m23','m12'], ['r3'], 'fam1', 1 ).
test( 't14', 542, ['m46','m45','m11','m47','m7','m40','m1','m42','m35','m22','m26','m30','m4','m25','m49','m27'], [], 'fam1', 1 ).
test( 't15', 575, [], [], 'fam1', 1 ).
test( 't16', 281, [], ['r4','r5','r1','r3'], 'fam1', 1 ).
test( 't17', 111, [], ['r3'], 'fam1', 1 ).
test( 't18', 770, [], ['r3','r2'], 'fam1', 1 ).
test( 't19', 328, [], [], 'fam1', 1 ).
test( 't20', 200, [], [], 'fam1', 1 ).
test( 't21', 102, [], [], 'fam1', 1 ).
test( 't22', 402, [], [], 'fam1', 1 ).
test( 't23', 18, [], [], 'fam1', 1 ).
test( 't24', 586, [], [], 'fam1', 1 ).
test( 't25', 686, [], ['r2','r5','r3'], 'fam1', 1 ).
test( 't26', 393, ['m46','m26','m50','m9','m30','m10','m17','m47'], [], 'fam1', 1 ).
test( 't27', 700, [], [], 'fam1', 1 ).
test( 't28', 147, [], [], 'fam1', 1 ).
test( 't29', 381, [], [], 'fam1', 1 ).
test( 't30', 149, [], [], 'fam1', 1 ).
test( 't31', 6, ['m33','m20','m31','m43','m44'], [], 'fam1', 1 ).
test( 't32', 718, ['m40','m14','m34','m4','m29','m42','m9','m7','m35','m46','m8','m19','m17','m21','m49'], ['r4','r5','r1'], 'fam1', 1 ).
test( 't33', 269, [], [], 'fam1', 1 ).
test( 't34', 638, [], ['r5'], 'fam1', 1 ).
test( 't35', 762, ['m17','m12','m45','m27','m22','m5','m10','m28','m24','m47','m35','m33','m46'], [], 'fam1', 1 ).
test( 't36', 798, [], ['r1','r3'], 'fam1', 1 ).
test( 't37', 31, [], [], 'fam1', 1 ).
test( 't38', 39, [], [], 'fam1', 1 ).
test( 't39', 223, ['m37','m5','m24','m16','m2','m3','m30','m39'], ['r3'], 'fam1', 1 ).
test( 't40', 2, [], [], 'fam1', 1 ).
test( 't41', 669, [], [], 'fam1', 1 ).
test( 't42', 683, [], [], 'fam1', 1 ).
test( 't43', 495, [], [], 'fam1', 1 ).
test( 't44', 793, [], ['r4','r3'], 'fam1', 1 ).
test( 't45', 365, [], [], 'fam1', 1 ).
test( 't46', 674, [], ['r5','r1','r3','r2','r4'], 'fam1', 1 ).
test( 't47', 173, ['m1','m19','m12','m14','m3','m48','m49','m16','m40','m20','m47','m37','m39','m36'], [], 'fam1', 1 ).
test( 't48', 154, [], ['r1','r3','r2','r4','r5'], 'fam1', 1 ).
test( 't49', 746, [], [], 'fam1', 1 ).
test( 't50', 403, [], [], 'fam1', 1 ).
test( 't51', 416, ['m44','m43','m19','m41','m25','m2'], ['r1','r5','r4'], 'fam1', 1 ).
test( 't52', 530, [], ['r3','r1','r4','r5','r2'], 'fam1', 1 ).
test( 't53', 283, ['m20','m25','m37','m13','m4','m30','m10','m50','m38','m33','m45','m14'], [], 'fam1', 1 ).
test( 't54', 369, [], [], 'fam1', 1 ).
test( 't55', 320, [], [], 'fam1', 1 ).
test( 't56', 667, [], [], 'fam1', 1 ).
test( 't57', 476, [], [], 'fam1', 1 ).
test( 't58', 683, [], ['r4','r3'], 'fam1', 1 ).
test( 't59', 237, [], [], 'fam1', 1 ).
test( 't60', 95, [], [], 'fam1', 1 ).
test( 't61', 66, [], [], 'fam1', 1 ).
test( 't62', 419, [], [], 'fam1', 1 ).
test( 't63', 770, [], [], 'fam1', 1 ).
test( 't64', 6, [], [], 'fam1', 1 ).
test( 't65', 448, [], ['r5'], 'fam1', 1 ).
test( 't66', 139, [], ['r1','r5','r3'], 'fam1', 1 ).
test( 't67', 225, [], [], 'fam1', 1 ).
test( 't68', 75, [], ['r1','r2'], 'fam1', 1 ).
test( 't69', 248, [], ['r2','r4','r1','r3'], 'fam1', 1 ).
test( 't70', 733, [], ['r1','r3','r5'], 'fam1', 1 ).
test( 't71', 658, [], [], 'fam1', 1 ).
test( 't72', 181, [], [], 'fam1', 1 ).
test( 't73', 513, [], [], 'fam1', 1 ).
test( 't74', 338, [], [], 'fam1', 1 ).
test( 't75', 486, ['m32','m46','m47','m45','m21','m11','m41','m50','m14','m22','m16','m27','m3','m12','m37','m9'], [], 'fam1', 1 ).
test( 't76', 533, [], [], 'fam1', 1 ).
test( 't77', 383, [], [], 'fam1', 1 ).
test( 't78', 437, [], [], 'fam1', 1 ).
test( 't79', 147, ['m30','m16','m33','m18','m21','m36','m44','m1','m32'], [], 'fam1', 1 ).
test( 't80', 686, ['m43'], ['r5','r4'], 'fam1', 1 ).
test( 't81', 31, ['m10','m20','m31','m25','m8','m45','m4','m13','m26','m46'], [], 'fam1', 1 ).
test( 't82', 114, [], [], 'fam1', 1 ).
test( 't83', 87, [], ['r3','r4'], 'fam1', 1 ).
test( 't84', 300, [], ['r1','r3','r2','r5','r4'], 'fam1', 1 ).
test( 't85', 260, [], [], 'fam1', 1 ).
test( 't86', 41, [], ['r3','r2','r5','r4','r1'], 'fam1', 1 ).
test( 't87', 740, [], [], 'fam1', 1 ).
test( 't88', 799, [], [], 'fam1', 1 ).
test( 't89', 739, [], [], 'fam1', 1 ).
test( 't90', 286, [], [], 'fam1', 1 ).
test( 't91', 763, [], [], 'fam1', 1 ).
test( 't92', 217, ['m41','m16','m28','m39','m36','m35','m32','m30','m22','m33','m13','m8','m29'], [], 'fam1', 1 ).
test( 't93', 326, [], [], 'fam1', 1 ).
test( 't94', 78, ['m39','m26','m23','m38','m25','m17','m1','m43','m45','m49','m15','m37','m32','m20','m19'], [], 'fam1', 1 ).
test( 't95', 650, [], [], 'fam1', 1 ).
test( 't96', 292, [], [], 'fam1', 1 ).
test( 't97', 25, [], [], 'fam1', 1 ).
test( 't98', 591, [], ['r1','r5','r2'], 'fam1', 1 ).
test( 't99', 582, [], [], 'fam1', 1 ).
test( 't100', 162, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').
embedded_board( 'm21').
embedded_board( 'm22').
embedded_board( 'm23').
embedded_board( 'm24').
embedded_board( 'm25').
embedded_board( 'm26').
embedded_board( 'm27').
embedded_board( 'm28').
embedded_board( 'm29').
embedded_board( 'm30').
embedded_board( 'm31').
embedded_board( 'm32').
embedded_board( 'm33').
embedded_board( 'm34').
embedded_board( 'm35').
embedded_board( 'm36').
embedded_board( 'm37').
embedded_board( 'm38').
embedded_board( 'm39').
embedded_board( 'm40').
embedded_board( 'm41').
embedded_board( 'm42').
embedded_board( 'm43').
embedded_board( 'm44').
embedded_board( 'm45').
embedded_board( 'm46').
embedded_board( 'm47').
embedded_board( 'm48').
embedded_board( 'm49').
embedded_board( 'm50').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
