%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 50
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 129, [], [], 'fam1', 1 ).
test( 't2', 510, [], [], 'fam1', 1 ).
test( 't3', 345, [], [], 'fam1', 1 ).
test( 't4', 87, [], [], 'fam1', 1 ).
test( 't5', 792, [], [], 'fam1', 1 ).
test( 't6', 344, ['m5','m38','m19','m32','m15','m21'], [], 'fam1', 1 ).
test( 't7', 34, [], [], 'fam1', 1 ).
test( 't8', 679, [], ['r2'], 'fam1', 1 ).
test( 't9', 535, [], [], 'fam1', 1 ).
test( 't10', 773, [], ['r3','r2','r10','r5','r8','r4','r1','r9'], 'fam1', 1 ).
test( 't11', 704, ['m26','m17','m34','m40','m47','m27','m10','m23','m20','m14','m50','m4','m32','m12','m39','m35','m15','m37','m49'], [], 'fam1', 1 ).
test( 't12', 235, [], [], 'fam1', 1 ).
test( 't13', 696, [], ['r10','r2'], 'fam1', 1 ).
test( 't14', 131, [], [], 'fam1', 1 ).
test( 't15', 286, [], [], 'fam1', 1 ).
test( 't16', 343, [], ['r8','r9','r3','r7','r6','r2','r5'], 'fam1', 1 ).
test( 't17', 625, [], [], 'fam1', 1 ).
test( 't18', 509, ['m2'], [], 'fam1', 1 ).
test( 't19', 530, [], ['r8','r2','r5','r6','r4','r7','r1'], 'fam1', 1 ).
test( 't20', 290, [], [], 'fam1', 1 ).
test( 't21', 733, [], ['r3','r4','r6','r9','r1','r2'], 'fam1', 1 ).
test( 't22', 21, [], [], 'fam1', 1 ).
test( 't23', 282, [], ['r3','r7','r2','r8','r9','r5','r1','r4','r6','r10'], 'fam1', 1 ).
test( 't24', 55, ['m10','m24','m4','m23','m26','m19'], [], 'fam1', 1 ).
test( 't25', 316, [], [], 'fam1', 1 ).
test( 't26', 532, [], ['r5','r2','r1','r9','r4','r8','r7','r10'], 'fam1', 1 ).
test( 't27', 704, [], [], 'fam1', 1 ).
test( 't28', 770, [], [], 'fam1', 1 ).
test( 't29', 631, ['m34','m28','m26','m38','m11','m25','m10','m9','m20','m7','m30','m44'], [], 'fam1', 1 ).
test( 't30', 416, [], [], 'fam1', 1 ).
test( 't31', 622, [], [], 'fam1', 1 ).
test( 't32', 553, [], ['r9','r6','r10','r5','r2','r8'], 'fam1', 1 ).
test( 't33', 36, [], [], 'fam1', 1 ).
test( 't34', 787, [], [], 'fam1', 1 ).
test( 't35', 470, [], ['r10','r6','r2','r5','r1','r4','r9','r3'], 'fam1', 1 ).
test( 't36', 157, [], [], 'fam1', 1 ).
test( 't37', 311, [], [], 'fam1', 1 ).
test( 't38', 415, [], [], 'fam1', 1 ).
test( 't39', 515, [], [], 'fam1', 1 ).
test( 't40', 662, [], [], 'fam1', 1 ).
test( 't41', 734, [], ['r10'], 'fam1', 1 ).
test( 't42', 722, [], [], 'fam1', 1 ).
test( 't43', 84, ['m28','m11'], [], 'fam1', 1 ).
test( 't44', 236, [], [], 'fam1', 1 ).
test( 't45', 134, [], ['r9','r3'], 'fam1', 1 ).
test( 't46', 645, [], [], 'fam1', 1 ).
test( 't47', 338, ['m41','m43','m33','m16','m39','m2','m23','m24','m13','m36','m11','m26'], ['r8','r3','r4','r1','r5','r10','r9'], 'fam1', 1 ).
test( 't48', 495, [], [], 'fam1', 1 ).
test( 't49', 428, [], ['r2','r7','r10','r3','r5'], 'fam1', 1 ).
test( 't50', 235, [], [], 'fam1', 1 ).
test( 't51', 132, [], [], 'fam1', 1 ).
test( 't52', 376, [], ['r1','r3','r2','r8','r9','r6','r5','r10'], 'fam1', 1 ).
test( 't53', 323, [], [], 'fam1', 1 ).
test( 't54', 286, [], ['r7','r4','r5','r1','r2'], 'fam1', 1 ).
test( 't55', 84, [], [], 'fam1', 1 ).
test( 't56', 146, [], ['r1','r10','r4','r5','r9','r6','r2'], 'fam1', 1 ).
test( 't57', 394, ['m1','m41','m21','m25','m7','m20','m26','m37','m14','m36','m10','m13','m4','m22','m17','m16','m34','m12'], [], 'fam1', 1 ).
test( 't58', 109, [], [], 'fam1', 1 ).
test( 't59', 396, [], ['r3','r9','r5','r1','r6','r10','r2','r7','r4','r8'], 'fam1', 1 ).
test( 't60', 231, [], [], 'fam1', 1 ).
test( 't61', 685, [], [], 'fam1', 1 ).
test( 't62', 478, [], [], 'fam1', 1 ).
test( 't63', 211, [], [], 'fam1', 1 ).
test( 't64', 669, [], [], 'fam1', 1 ).
test( 't65', 283, [], [], 'fam1', 1 ).
test( 't66', 220, ['m32','m17','m21','m20'], [], 'fam1', 1 ).
test( 't67', 44, ['m21','m36','m2','m18','m5','m10','m39','m4','m24','m17','m47','m15','m11','m35','m14','m38','m50','m8'], [], 'fam1', 1 ).
test( 't68', 309, [], ['r4','r6','r9'], 'fam1', 1 ).
test( 't69', 188, [], ['r7','r10','r9','r5'], 'fam1', 1 ).
test( 't70', 640, [], [], 'fam1', 1 ).
test( 't71', 555, [], [], 'fam1', 1 ).
test( 't72', 688, [], [], 'fam1', 1 ).
test( 't73', 147, [], [], 'fam1', 1 ).
test( 't74', 446, [], [], 'fam1', 1 ).
test( 't75', 409, [], [], 'fam1', 1 ).
test( 't76', 527, [], ['r10'], 'fam1', 1 ).
test( 't77', 202, [], [], 'fam1', 1 ).
test( 't78', 111, [], ['r8','r9','r4','r3','r1','r2','r7','r10','r6','r5'], 'fam1', 1 ).
test( 't79', 28, [], [], 'fam1', 1 ).
test( 't80', 769, [], [], 'fam1', 1 ).
test( 't81', 761, [], ['r4','r5','r9','r6'], 'fam1', 1 ).
test( 't82', 27, [], [], 'fam1', 1 ).
test( 't83', 513, [], [], 'fam1', 1 ).
test( 't84', 792, [], ['r7','r10','r9','r2','r5','r4','r3','r8'], 'fam1', 1 ).
test( 't85', 67, [], [], 'fam1', 1 ).
test( 't86', 171, [], [], 'fam1', 1 ).
test( 't87', 192, [], [], 'fam1', 1 ).
test( 't88', 143, [], [], 'fam1', 1 ).
test( 't89', 739, [], [], 'fam1', 1 ).
test( 't90', 57, [], [], 'fam1', 1 ).
test( 't91', 603, ['m28','m32','m30','m19','m26','m43','m44','m37','m47','m46','m42'], [], 'fam1', 1 ).
test( 't92', 210, ['m2','m27','m49','m11','m47','m17','m22','m19','m36','m28','m38','m32','m4','m44','m18','m48'], [], 'fam1', 1 ).
test( 't93', 11, [], ['r5','r7'], 'fam1', 1 ).
test( 't94', 767, [], ['r6','r4','r5','r7','r1','r9','r8','r2','r10'], 'fam1', 1 ).
test( 't95', 483, ['m40','m31','m25','m10','m22','m41','m38','m39','m4','m13','m12','m45'], ['r9'], 'fam1', 1 ).
test( 't96', 301, ['m33','m25','m35','m20','m4','m36','m23','m11','m31','m49','m43','m47','m12','m7','m13','m21','m42','m10','m17'], ['r3','r4','r1','r10','r8'], 'fam1', 1 ).
test( 't97', 229, ['m16','m17','m15','m2','m41','m28','m20','m26','m31','m45','m48','m23','m43','m39','m11'], ['r4','r10','r7','r9','r2','r5','r3','r6','r8'], 'fam1', 1 ).
test( 't98', 741, [], [], 'fam1', 1 ).
test( 't99', 559, [], [], 'fam1', 1 ).
test( 't100', 204, ['m48','m33','m34','m11','m37'], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').
embedded_board( 'm21').
embedded_board( 'm22').
embedded_board( 'm23').
embedded_board( 'm24').
embedded_board( 'm25').
embedded_board( 'm26').
embedded_board( 'm27').
embedded_board( 'm28').
embedded_board( 'm29').
embedded_board( 'm30').
embedded_board( 'm31').
embedded_board( 'm32').
embedded_board( 'm33').
embedded_board( 'm34').
embedded_board( 'm35').
embedded_board( 'm36').
embedded_board( 'm37').
embedded_board( 'm38').
embedded_board( 'm39').
embedded_board( 'm40').
embedded_board( 'm41').
embedded_board( 'm42').
embedded_board( 'm43').
embedded_board( 'm44').
embedded_board( 'm45').
embedded_board( 'm46').
embedded_board( 'm47').
embedded_board( 'm48').
embedded_board( 'm49').
embedded_board( 'm50').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
