%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 788, [], [], 'fam1', 1 ).
test( 't2', 409, ['m2','m10','m9'], [], 'fam1', 1 ).
test( 't3', 361, [], [], 'fam1', 1 ).
test( 't4', 573, ['m10'], [], 'fam1', 1 ).
test( 't5', 608, ['m7','m3'], ['r2','r3','r1'], 'fam1', 1 ).
test( 't6', 336, ['m10','m8','m4'], [], 'fam1', 1 ).
test( 't7', 728, ['m9'], [], 'fam1', 1 ).
test( 't8', 464, ['m5'], [], 'fam1', 1 ).
test( 't9', 316, [], [], 'fam1', 1 ).
test( 't10', 512, [], [], 'fam1', 1 ).
test( 't11', 315, [], [], 'fam1', 1 ).
test( 't12', 457, ['m10','m2','m5'], [], 'fam1', 1 ).
test( 't13', 319, [], [], 'fam1', 1 ).
test( 't14', 111, [], ['r1'], 'fam1', 1 ).
test( 't15', 474, [], ['r3','r1'], 'fam1', 1 ).
test( 't16', 592, [], [], 'fam1', 1 ).
test( 't17', 560, [], [], 'fam1', 1 ).
test( 't18', 796, [], [], 'fam1', 1 ).
test( 't19', 791, ['m7'], [], 'fam1', 1 ).
test( 't20', 208, [], [], 'fam1', 1 ).
test( 't21', 331, [], [], 'fam1', 1 ).
test( 't22', 263, [], [], 'fam1', 1 ).
test( 't23', 303, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't24', 147, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't25', 503, [], [], 'fam1', 1 ).
test( 't26', 445, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't27', 464, [], [], 'fam1', 1 ).
test( 't28', 97, [], ['r2'], 'fam1', 1 ).
test( 't29', 295, [], [], 'fam1', 1 ).
test( 't30', 705, [], ['r1'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
