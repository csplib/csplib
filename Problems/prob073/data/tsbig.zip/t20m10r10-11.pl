%% ****  Testsuite  ****
% Number of tests                  : 20
% Number of machines               : 10
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 635, [], [], 'fam1', 1 ).
test( 't2', 480, [], ['r7','r2'], 'fam1', 1 ).
test( 't3', 485, [], [], 'fam1', 1 ).
test( 't4', 354, [], [], 'fam1', 1 ).
test( 't5', 718, [], [], 'fam1', 1 ).
test( 't6', 783, [], [], 'fam1', 1 ).
test( 't7', 440, [], [], 'fam1', 1 ).
test( 't8', 407, [], ['r8','r5'], 'fam1', 1 ).
test( 't9', 172, ['m7'], ['r6','r7','r8','r3','r9','r5','r4','r2'], 'fam1', 1 ).
test( 't10', 723, [], ['r3','r6','r1','r5','r4','r9','r2'], 'fam1', 1 ).
test( 't11', 226, ['m8','m9','m3','m2'], [], 'fam1', 1 ).
test( 't12', 35, [], ['r4','r8','r6','r5','r9','r3','r10','r7','r1','r2'], 'fam1', 1 ).
test( 't13', 86, [], [], 'fam1', 1 ).
test( 't14', 74, [], [], 'fam1', 1 ).
test( 't15', 6, [], [], 'fam1', 1 ).
test( 't16', 20, [], [], 'fam1', 1 ).
test( 't17', 592, [], ['r4','r7','r10','r5','r3','r2'], 'fam1', 1 ).
test( 't18', 603, ['m9','m2','m8','m3'], [], 'fam1', 1 ).
test( 't19', 737, [], [], 'fam1', 1 ).
test( 't20', 322, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
