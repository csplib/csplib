%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 10
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 561, [], ['r2','r7','r8','r6','r1','r5','r3'], 'fam1', 1 ).
test( 't2', 478, ['m6'], ['r2','r5','r6','r10'], 'fam1', 1 ).
test( 't3', 376, [], [], 'fam1', 1 ).
test( 't4', 40, [], ['r6','r5','r2','r8','r1'], 'fam1', 1 ).
test( 't5', 244, [], ['r10','r1','r2','r9'], 'fam1', 1 ).
test( 't6', 262, [], [], 'fam1', 1 ).
test( 't7', 637, [], [], 'fam1', 1 ).
test( 't8', 711, [], [], 'fam1', 1 ).
test( 't9', 335, ['m9','m6'], [], 'fam1', 1 ).
test( 't10', 49, [], [], 'fam1', 1 ).
test( 't11', 583, [], ['r3','r5','r4','r7','r9','r10','r6','r2'], 'fam1', 1 ).
test( 't12', 580, ['m4','m7','m8'], ['r3','r7','r8','r1','r6'], 'fam1', 1 ).
test( 't13', 51, [], [], 'fam1', 1 ).
test( 't14', 695, [], [], 'fam1', 1 ).
test( 't15', 745, [], [], 'fam1', 1 ).
test( 't16', 459, [], [], 'fam1', 1 ).
test( 't17', 427, [], ['r8','r9','r4','r6','r2','r7','r5'], 'fam1', 1 ).
test( 't18', 60, [], ['r6','r2','r7','r8','r5'], 'fam1', 1 ).
test( 't19', 463, [], [], 'fam1', 1 ).
test( 't20', 122, [], ['r7','r10','r3','r6'], 'fam1', 1 ).
test( 't21', 774, [], [], 'fam1', 1 ).
test( 't22', 625, [], [], 'fam1', 1 ).
test( 't23', 250, [], [], 'fam1', 1 ).
test( 't24', 122, [], [], 'fam1', 1 ).
test( 't25', 265, ['m5','m8','m1','m4'], ['r4','r10','r8','r7','r2','r1','r5'], 'fam1', 1 ).
test( 't26', 589, [], [], 'fam1', 1 ).
test( 't27', 229, [], [], 'fam1', 1 ).
test( 't28', 590, [], [], 'fam1', 1 ).
test( 't29', 183, [], [], 'fam1', 1 ).
test( 't30', 607, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
