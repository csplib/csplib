%% ****  Testsuite  ****
% Number of tests                  : 20
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 559, [], [], 'fam1', 1 ).
test( 't2', 392, ['m3'], ['r2','r1'], 'fam1', 1 ).
test( 't3', 240, [], [], 'fam1', 1 ).
test( 't4', 583, [], [], 'fam1', 1 ).
test( 't5', 411, [], ['r2'], 'fam1', 1 ).
test( 't6', 654, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't7', 480, [], [], 'fam1', 1 ).
test( 't8', 609, [], [], 'fam1', 1 ).
test( 't9', 360, [], [], 'fam1', 1 ).
test( 't10', 542, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't11', 593, [], ['r1'], 'fam1', 1 ).
test( 't12', 291, [], [], 'fam1', 1 ).
test( 't13', 430, [], [], 'fam1', 1 ).
test( 't14', 509, ['m1','m2'], [], 'fam1', 1 ).
test( 't15', 234, [], [], 'fam1', 1 ).
test( 't16', 344, [], [], 'fam1', 1 ).
test( 't17', 480, [], [], 'fam1', 1 ).
test( 't18', 660, [], [], 'fam1', 1 ).
test( 't19', 148, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't20', 714, ['m5','m7'], ['r2','r3','r1'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
