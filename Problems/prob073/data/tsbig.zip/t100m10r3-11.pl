%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 485, [], ['r1'], 'fam1', 1 ).
test( 't2', 43, [], [], 'fam1', 1 ).
test( 't3', 341, ['m3'], ['r3'], 'fam1', 1 ).
test( 't4', 631, [], [], 'fam1', 1 ).
test( 't5', 415, [], [], 'fam1', 1 ).
test( 't6', 603, [], [], 'fam1', 1 ).
test( 't7', 89, [], [], 'fam1', 1 ).
test( 't8', 529, ['m9','m6','m8','m7'], [], 'fam1', 1 ).
test( 't9', 428, ['m8','m9'], [], 'fam1', 1 ).
test( 't10', 95, ['m9'], [], 'fam1', 1 ).
test( 't11', 145, [], [], 'fam1', 1 ).
test( 't12', 130, [], [], 'fam1', 1 ).
test( 't13', 673, [], ['r2'], 'fam1', 1 ).
test( 't14', 95, [], [], 'fam1', 1 ).
test( 't15', 85, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't16', 20, [], [], 'fam1', 1 ).
test( 't17', 754, ['m9','m5','m8'], [], 'fam1', 1 ).
test( 't18', 507, [], [], 'fam1', 1 ).
test( 't19', 204, ['m4'], [], 'fam1', 1 ).
test( 't20', 412, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't21', 743, [], ['r2','r1'], 'fam1', 1 ).
test( 't22', 574, [], [], 'fam1', 1 ).
test( 't23', 289, [], [], 'fam1', 1 ).
test( 't24', 92, [], [], 'fam1', 1 ).
test( 't25', 514, [], [], 'fam1', 1 ).
test( 't26', 511, [], ['r3','r1'], 'fam1', 1 ).
test( 't27', 677, ['m1'], [], 'fam1', 1 ).
test( 't28', 147, ['m6'], ['r3','r2'], 'fam1', 1 ).
test( 't29', 667, [], [], 'fam1', 1 ).
test( 't30', 148, [], ['r2'], 'fam1', 1 ).
test( 't31', 237, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't32', 620, ['m3','m7'], [], 'fam1', 1 ).
test( 't33', 485, [], [], 'fam1', 1 ).
test( 't34', 457, [], [], 'fam1', 1 ).
test( 't35', 167, [], [], 'fam1', 1 ).
test( 't36', 124, [], [], 'fam1', 1 ).
test( 't37', 401, [], [], 'fam1', 1 ).
test( 't38', 469, [], [], 'fam1', 1 ).
test( 't39', 589, ['m7','m6','m8'], [], 'fam1', 1 ).
test( 't40', 227, [], [], 'fam1', 1 ).
test( 't41', 376, [], [], 'fam1', 1 ).
test( 't42', 339, [], ['r1'], 'fam1', 1 ).
test( 't43', 363, [], [], 'fam1', 1 ).
test( 't44', 595, [], [], 'fam1', 1 ).
test( 't45', 702, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't46', 596, [], ['r2'], 'fam1', 1 ).
test( 't47', 135, [], [], 'fam1', 1 ).
test( 't48', 416, ['m9','m1'], ['r2'], 'fam1', 1 ).
test( 't49', 435, ['m5'], ['r2'], 'fam1', 1 ).
test( 't50', 560, ['m6'], [], 'fam1', 1 ).
test( 't51', 418, ['m3','m9','m8','m10'], [], 'fam1', 1 ).
test( 't52', 299, [], [], 'fam1', 1 ).
test( 't53', 124, ['m3','m1','m9'], ['r3'], 'fam1', 1 ).
test( 't54', 242, [], [], 'fam1', 1 ).
test( 't55', 166, [], [], 'fam1', 1 ).
test( 't56', 372, [], [], 'fam1', 1 ).
test( 't57', 731, [], [], 'fam1', 1 ).
test( 't58', 680, ['m9'], [], 'fam1', 1 ).
test( 't59', 787, [], ['r1'], 'fam1', 1 ).
test( 't60', 534, ['m10'], [], 'fam1', 1 ).
test( 't61', 330, [], [], 'fam1', 1 ).
test( 't62', 139, ['m5'], [], 'fam1', 1 ).
test( 't63', 135, [], ['r2'], 'fam1', 1 ).
test( 't64', 289, [], [], 'fam1', 1 ).
test( 't65', 724, ['m9'], ['r3','r2','r1'], 'fam1', 1 ).
test( 't66', 446, ['m10','m8','m1'], ['r1','r2'], 'fam1', 1 ).
test( 't67', 286, [], [], 'fam1', 1 ).
test( 't68', 43, [], ['r3','r1'], 'fam1', 1 ).
test( 't69', 514, [], ['r1','r2'], 'fam1', 1 ).
test( 't70', 713, [], [], 'fam1', 1 ).
test( 't71', 523, [], [], 'fam1', 1 ).
test( 't72', 624, ['m4','m9','m5','m8'], [], 'fam1', 1 ).
test( 't73', 369, [], [], 'fam1', 1 ).
test( 't74', 572, [], [], 'fam1', 1 ).
test( 't75', 380, [], ['r2','r3'], 'fam1', 1 ).
test( 't76', 672, [], [], 'fam1', 1 ).
test( 't77', 156, [], [], 'fam1', 1 ).
test( 't78', 545, [], [], 'fam1', 1 ).
test( 't79', 490, [], [], 'fam1', 1 ).
test( 't80', 70, [], [], 'fam1', 1 ).
test( 't81', 439, [], [], 'fam1', 1 ).
test( 't82', 616, ['m5','m9','m1','m4'], ['r2','r1'], 'fam1', 1 ).
test( 't83', 626, [], [], 'fam1', 1 ).
test( 't84', 646, [], [], 'fam1', 1 ).
test( 't85', 219, [], [], 'fam1', 1 ).
test( 't86', 609, [], ['r1','r2'], 'fam1', 1 ).
test( 't87', 163, [], [], 'fam1', 1 ).
test( 't88', 548, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't89', 406, [], [], 'fam1', 1 ).
test( 't90', 652, [], ['r1'], 'fam1', 1 ).
test( 't91', 432, [], [], 'fam1', 1 ).
test( 't92', 166, ['m7','m6','m1','m9'], [], 'fam1', 1 ).
test( 't93', 737, [], [], 'fam1', 1 ).
test( 't94', 80, [], [], 'fam1', 1 ).
test( 't95', 160, [], ['r3'], 'fam1', 1 ).
test( 't96', 632, [], ['r1','r3'], 'fam1', 1 ).
test( 't97', 475, [], ['r1'], 'fam1', 1 ).
test( 't98', 129, [], [], 'fam1', 1 ).
test( 't99', 67, ['m8','m9','m10'], [], 'fam1', 1 ).
test( 't100', 303, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
