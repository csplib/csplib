%% ****  Testsuite  ****
% Number of tests                  : 20
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 710, [], ['r2'], 'fam1', 1 ).
test( 't2', 116, [], ['r2'], 'fam1', 1 ).
test( 't3', 710, [], [], 'fam1', 1 ).
test( 't4', 679, ['m1','m4','m5'], [], 'fam1', 1 ).
test( 't5', 142, [], [], 'fam1', 1 ).
test( 't6', 700, [], [], 'fam1', 1 ).
test( 't7', 738, [], [], 'fam1', 1 ).
test( 't8', 785, [], [], 'fam1', 1 ).
test( 't9', 753, [], [], 'fam1', 1 ).
test( 't10', 57, [], [], 'fam1', 1 ).
test( 't11', 256, ['m4'], [], 'fam1', 1 ).
test( 't12', 438, [], [], 'fam1', 1 ).
test( 't13', 462, [], [], 'fam1', 1 ).
test( 't14', 650, ['m9','m2'], [], 'fam1', 1 ).
test( 't15', 270, [], [], 'fam1', 1 ).
test( 't16', 723, ['m4','m10'], [], 'fam1', 1 ).
test( 't17', 628, ['m2','m8','m7'], [], 'fam1', 1 ).
test( 't18', 81, ['m4','m5','m8','m7'], [], 'fam1', 1 ).
test( 't19', 710, ['m5','m4','m3','m6'], [], 'fam1', 1 ).
test( 't20', 377, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
