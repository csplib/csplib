%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 20
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 256, [], [], 'fam1', 1 ).
test( 't2', 231, [], [], 'fam1', 1 ).
test( 't3', 48, [], [], 'fam1', 1 ).
test( 't4', 388, [], [], 'fam1', 1 ).
test( 't5', 293, [], ['r3'], 'fam1', 1 ).
test( 't6', 658, [], [], 'fam1', 1 ).
test( 't7', 742, ['m6','m2'], [], 'fam1', 1 ).
test( 't8', 685, [], [], 'fam1', 1 ).
test( 't9', 424, ['m15','m10','m11','m17'], [], 'fam1', 1 ).
test( 't10', 85, ['m1','m16','m17','m2','m14','m11','m8','m20'], [], 'fam1', 1 ).
test( 't11', 412, [], ['r2'], 'fam1', 1 ).
test( 't12', 187, [], [], 'fam1', 1 ).
test( 't13', 137, [], [], 'fam1', 1 ).
test( 't14', 153, [], [], 'fam1', 1 ).
test( 't15', 351, [], [], 'fam1', 1 ).
test( 't16', 392, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't17', 607, [], [], 'fam1', 1 ).
test( 't18', 378, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't19', 216, ['m13','m12','m9','m16','m1','m2','m20'], ['r2','r3','r1'], 'fam1', 1 ).
test( 't20', 541, [], [], 'fam1', 1 ).
test( 't21', 768, ['m11','m20','m4','m9','m7','m1'], ['r1','r3','r2'], 'fam1', 1 ).
test( 't22', 245, ['m3','m6'], [], 'fam1', 1 ).
test( 't23', 396, [], ['r1','r3'], 'fam1', 1 ).
test( 't24', 675, ['m5'], [], 'fam1', 1 ).
test( 't25', 792, ['m18','m17','m9','m19','m2','m4'], [], 'fam1', 1 ).
test( 't26', 425, [], [], 'fam1', 1 ).
test( 't27', 607, ['m2','m14','m15','m10','m11','m20','m6'], [], 'fam1', 1 ).
test( 't28', 740, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't29', 141, [], [], 'fam1', 1 ).
test( 't30', 510, [], [], 'fam1', 1 ).
test( 't31', 594, [], [], 'fam1', 1 ).
test( 't32', 234, [], ['r2','r3'], 'fam1', 1 ).
test( 't33', 281, ['m18','m15','m19','m8'], [], 'fam1', 1 ).
test( 't34', 240, [], [], 'fam1', 1 ).
test( 't35', 220, [], [], 'fam1', 1 ).
test( 't36', 520, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't37', 108, [], ['r2','r1'], 'fam1', 1 ).
test( 't38', 92, [], [], 'fam1', 1 ).
test( 't39', 193, [], ['r3'], 'fam1', 1 ).
test( 't40', 111, [], [], 'fam1', 1 ).
test( 't41', 558, ['m2','m1','m6','m12','m14'], [], 'fam1', 1 ).
test( 't42', 694, ['m5','m12','m16'], [], 'fam1', 1 ).
test( 't43', 645, [], [], 'fam1', 1 ).
test( 't44', 520, ['m5','m1','m8','m12'], ['r3'], 'fam1', 1 ).
test( 't45', 123, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't46', 467, [], [], 'fam1', 1 ).
test( 't47', 674, ['m18','m8','m14','m1','m13','m12','m2','m10'], [], 'fam1', 1 ).
test( 't48', 391, [], [], 'fam1', 1 ).
test( 't49', 309, [], [], 'fam1', 1 ).
test( 't50', 718, ['m19','m10','m4','m11'], [], 'fam1', 1 ).
test( 't51', 504, [], ['r3'], 'fam1', 1 ).
test( 't52', 259, [], [], 'fam1', 1 ).
test( 't53', 475, [], [], 'fam1', 1 ).
test( 't54', 415, [], ['r3'], 'fam1', 1 ).
test( 't55', 752, [], ['r2'], 'fam1', 1 ).
test( 't56', 123, [], [], 'fam1', 1 ).
test( 't57', 284, [], ['r1'], 'fam1', 1 ).
test( 't58', 99, [], [], 'fam1', 1 ).
test( 't59', 340, [], [], 'fam1', 1 ).
test( 't60', 665, [], [], 'fam1', 1 ).
test( 't61', 230, [], [], 'fam1', 1 ).
test( 't62', 283, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't63', 444, [], [], 'fam1', 1 ).
test( 't64', 68, [], ['r3'], 'fam1', 1 ).
test( 't65', 218, ['m3','m2','m14','m13','m4','m7','m18'], [], 'fam1', 1 ).
test( 't66', 656, [], ['r3','r2'], 'fam1', 1 ).
test( 't67', 413, ['m19','m1','m14','m17','m7','m8','m11'], ['r3'], 'fam1', 1 ).
test( 't68', 594, [], [], 'fam1', 1 ).
test( 't69', 607, [], [], 'fam1', 1 ).
test( 't70', 157, [], [], 'fam1', 1 ).
test( 't71', 585, [], [], 'fam1', 1 ).
test( 't72', 218, [], [], 'fam1', 1 ).
test( 't73', 246, [], [], 'fam1', 1 ).
test( 't74', 219, ['m17','m3','m6'], ['r2','r3','r1'], 'fam1', 1 ).
test( 't75', 232, [], [], 'fam1', 1 ).
test( 't76', 566, [], [], 'fam1', 1 ).
test( 't77', 288, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't78', 419, [], [], 'fam1', 1 ).
test( 't79', 94, ['m8','m17','m2'], [], 'fam1', 1 ).
test( 't80', 310, [], [], 'fam1', 1 ).
test( 't81', 73, [], [], 'fam1', 1 ).
test( 't82', 297, [], [], 'fam1', 1 ).
test( 't83', 650, [], ['r3'], 'fam1', 1 ).
test( 't84', 634, [], [], 'fam1', 1 ).
test( 't85', 359, [], [], 'fam1', 1 ).
test( 't86', 618, [], [], 'fam1', 1 ).
test( 't87', 534, [], [], 'fam1', 1 ).
test( 't88', 411, ['m1','m5','m3'], ['r3','r1','r2'], 'fam1', 1 ).
test( 't89', 399, [], [], 'fam1', 1 ).
test( 't90', 605, [], [], 'fam1', 1 ).
test( 't91', 390, [], [], 'fam1', 1 ).
test( 't92', 368, [], [], 'fam1', 1 ).
test( 't93', 521, [], [], 'fam1', 1 ).
test( 't94', 234, [], [], 'fam1', 1 ).
test( 't95', 232, [], [], 'fam1', 1 ).
test( 't96', 60, [], [], 'fam1', 1 ).
test( 't97', 367, [], [], 'fam1', 1 ).
test( 't98', 315, ['m14','m4'], [], 'fam1', 1 ).
test( 't99', 386, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't100', 261, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
