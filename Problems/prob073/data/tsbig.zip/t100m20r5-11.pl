%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 20
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 334, [], ['r4','r2'], 'fam1', 1 ).
test( 't2', 645, [], ['r2','r4','r5'], 'fam1', 1 ).
test( 't3', 623, [], [], 'fam1', 1 ).
test( 't4', 622, [], [], 'fam1', 1 ).
test( 't5', 710, [], ['r5','r4','r1','r2'], 'fam1', 1 ).
test( 't6', 166, [], [], 'fam1', 1 ).
test( 't7', 338, [], [], 'fam1', 1 ).
test( 't8', 672, [], [], 'fam1', 1 ).
test( 't9', 138, [], [], 'fam1', 1 ).
test( 't10', 288, [], [], 'fam1', 1 ).
test( 't11', 97, [], [], 'fam1', 1 ).
test( 't12', 706, [], [], 'fam1', 1 ).
test( 't13', 156, [], [], 'fam1', 1 ).
test( 't14', 366, [], ['r3','r2','r1','r4'], 'fam1', 1 ).
test( 't15', 795, [], [], 'fam1', 1 ).
test( 't16', 750, [], [], 'fam1', 1 ).
test( 't17', 20, [], [], 'fam1', 1 ).
test( 't18', 58, [], [], 'fam1', 1 ).
test( 't19', 596, [], [], 'fam1', 1 ).
test( 't20', 432, [], [], 'fam1', 1 ).
test( 't21', 562, [], [], 'fam1', 1 ).
test( 't22', 745, ['m7','m6','m10','m12','m3','m4','m18'], [], 'fam1', 1 ).
test( 't23', 636, [], [], 'fam1', 1 ).
test( 't24', 266, [], [], 'fam1', 1 ).
test( 't25', 227, ['m14'], [], 'fam1', 1 ).
test( 't26', 790, [], [], 'fam1', 1 ).
test( 't27', 301, [], [], 'fam1', 1 ).
test( 't28', 644, ['m8','m5','m18','m9','m2','m17'], [], 'fam1', 1 ).
test( 't29', 660, ['m18','m11','m13'], ['r3','r1','r2'], 'fam1', 1 ).
test( 't30', 481, [], [], 'fam1', 1 ).
test( 't31', 330, [], ['r3','r4','r2'], 'fam1', 1 ).
test( 't32', 292, ['m1','m17','m14','m19','m12','m20','m9','m10'], ['r5','r4','r3','r1','r2'], 'fam1', 1 ).
test( 't33', 98, ['m20','m13','m6','m19','m16','m8','m14','m4'], ['r1'], 'fam1', 1 ).
test( 't34', 616, [], [], 'fam1', 1 ).
test( 't35', 38, ['m15','m8','m1'], ['r2','r1'], 'fam1', 1 ).
test( 't36', 338, ['m4','m7','m10','m1','m17'], [], 'fam1', 1 ).
test( 't37', 667, ['m8','m6','m4','m2','m12'], [], 'fam1', 1 ).
test( 't38', 266, [], ['r5','r4'], 'fam1', 1 ).
test( 't39', 501, [], [], 'fam1', 1 ).
test( 't40', 751, [], ['r5','r3'], 'fam1', 1 ).
test( 't41', 323, ['m12','m7','m4','m6','m18','m20'], [], 'fam1', 1 ).
test( 't42', 364, [], ['r5'], 'fam1', 1 ).
test( 't43', 559, [], [], 'fam1', 1 ).
test( 't44', 575, [], [], 'fam1', 1 ).
test( 't45', 173, [], [], 'fam1', 1 ).
test( 't46', 732, [], [], 'fam1', 1 ).
test( 't47', 261, [], [], 'fam1', 1 ).
test( 't48', 513, [], [], 'fam1', 1 ).
test( 't49', 272, [], [], 'fam1', 1 ).
test( 't50', 490, [], [], 'fam1', 1 ).
test( 't51', 760, ['m8','m4','m16','m5','m15'], [], 'fam1', 1 ).
test( 't52', 594, [], [], 'fam1', 1 ).
test( 't53', 173, [], [], 'fam1', 1 ).
test( 't54', 187, [], ['r5','r3'], 'fam1', 1 ).
test( 't55', 640, [], ['r1'], 'fam1', 1 ).
test( 't56', 184, [], [], 'fam1', 1 ).
test( 't57', 270, [], [], 'fam1', 1 ).
test( 't58', 488, ['m17','m5','m14','m11','m13','m3','m4','m16'], [], 'fam1', 1 ).
test( 't59', 412, [], [], 'fam1', 1 ).
test( 't60', 519, ['m9'], [], 'fam1', 1 ).
test( 't61', 689, [], [], 'fam1', 1 ).
test( 't62', 496, [], ['r2','r3','r5','r4','r1'], 'fam1', 1 ).
test( 't63', 707, [], [], 'fam1', 1 ).
test( 't64', 65, [], ['r4','r2','r5','r3'], 'fam1', 1 ).
test( 't65', 335, [], [], 'fam1', 1 ).
test( 't66', 79, [], [], 'fam1', 1 ).
test( 't67', 196, [], [], 'fam1', 1 ).
test( 't68', 82, [], [], 'fam1', 1 ).
test( 't69', 320, ['m9'], [], 'fam1', 1 ).
test( 't70', 470, [], [], 'fam1', 1 ).
test( 't71', 234, [], [], 'fam1', 1 ).
test( 't72', 771, [], ['r4','r1','r3','r2'], 'fam1', 1 ).
test( 't73', 340, [], [], 'fam1', 1 ).
test( 't74', 132, [], [], 'fam1', 1 ).
test( 't75', 627, ['m6','m1','m4'], [], 'fam1', 1 ).
test( 't76', 267, ['m12','m6','m7','m3','m20'], ['r5','r4','r3','r2','r1'], 'fam1', 1 ).
test( 't77', 85, ['m13','m7','m17','m5','m3','m19','m8'], ['r5','r1','r2','r4'], 'fam1', 1 ).
test( 't78', 506, [], [], 'fam1', 1 ).
test( 't79', 96, [], [], 'fam1', 1 ).
test( 't80', 503, [], [], 'fam1', 1 ).
test( 't81', 541, [], [], 'fam1', 1 ).
test( 't82', 560, [], [], 'fam1', 1 ).
test( 't83', 438, ['m3','m8','m12','m13','m19','m15'], ['r1','r3'], 'fam1', 1 ).
test( 't84', 319, [], [], 'fam1', 1 ).
test( 't85', 228, [], [], 'fam1', 1 ).
test( 't86', 3, [], ['r3','r1','r5','r4'], 'fam1', 1 ).
test( 't87', 122, ['m19','m6','m17','m4','m2','m14'], [], 'fam1', 1 ).
test( 't88', 326, [], [], 'fam1', 1 ).
test( 't89', 129, [], ['r5','r2'], 'fam1', 1 ).
test( 't90', 482, [], [], 'fam1', 1 ).
test( 't91', 279, [], [], 'fam1', 1 ).
test( 't92', 718, [], [], 'fam1', 1 ).
test( 't93', 755, ['m13','m14','m19','m17','m16','m11','m6'], [], 'fam1', 1 ).
test( 't94', 781, [], [], 'fam1', 1 ).
test( 't95', 638, [], [], 'fam1', 1 ).
test( 't96', 695, ['m13','m19','m15','m20','m3','m9'], ['r5','r3'], 'fam1', 1 ).
test( 't97', 171, ['m4','m9'], ['r1','r5'], 'fam1', 1 ).
test( 't98', 376, [], ['r2','r5','r1'], 'fam1', 1 ).
test( 't99', 794, [], [], 'fam1', 1 ).
test( 't100', 704, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
