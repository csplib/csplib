%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 50
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 699, [], [], 'fam1', 1 ).
test( 't2', 601, ['m2'], [], 'fam1', 1 ).
test( 't3', 332, [], [], 'fam1', 1 ).
test( 't4', 488, [], [], 'fam1', 1 ).
test( 't5', 466, [], [], 'fam1', 1 ).
test( 't6', 134, [], ['r1','r5','r2','r3'], 'fam1', 1 ).
test( 't7', 283, ['m44','m26','m47','m3','m41','m21','m5','m43','m14'], ['r2','r4','r1','r5','r3'], 'fam1', 1 ).
test( 't8', 402, [], [], 'fam1', 1 ).
test( 't9', 552, ['m50','m30','m23','m29','m15','m36','m18','m31','m34','m46','m12','m11'], [], 'fam1', 1 ).
test( 't10', 84, [], [], 'fam1', 1 ).
test( 't11', 489, [], ['r4'], 'fam1', 1 ).
test( 't12', 570, [], [], 'fam1', 1 ).
test( 't13', 634, [], [], 'fam1', 1 ).
test( 't14', 262, [], [], 'fam1', 1 ).
test( 't15', 753, [], [], 'fam1', 1 ).
test( 't16', 399, ['m8','m32','m2','m19','m26','m4','m3'], [], 'fam1', 1 ).
test( 't17', 782, ['m43','m32'], ['r4','r2'], 'fam1', 1 ).
test( 't18', 501, [], [], 'fam1', 1 ).
test( 't19', 407, [], [], 'fam1', 1 ).
test( 't20', 679, [], [], 'fam1', 1 ).
test( 't21', 589, [], [], 'fam1', 1 ).
test( 't22', 535, ['m49','m1','m43','m11','m45','m19','m5','m48','m7','m6','m25','m20'], [], 'fam1', 1 ).
test( 't23', 66, [], [], 'fam1', 1 ).
test( 't24', 226, [], ['r3'], 'fam1', 1 ).
test( 't25', 623, [], [], 'fam1', 1 ).
test( 't26', 112, [], ['r1','r4','r5','r2'], 'fam1', 1 ).
test( 't27', 583, [], [], 'fam1', 1 ).
test( 't28', 306, [], ['r4','r5','r3','r2'], 'fam1', 1 ).
test( 't29', 367, ['m38','m49','m5','m9','m10','m25','m16','m7','m42','m47','m45','m14','m36','m39','m13','m6'], [], 'fam1', 1 ).
test( 't30', 464, [], [], 'fam1', 1 ).
test( 't31', 148, ['m45','m37','m1','m30','m17','m31','m27','m29','m48','m4','m7','m21','m8','m40','m16','m20','m3','m18','m32','m26'], ['r4','r3','r5','r2','r1'], 'fam1', 1 ).
test( 't32', 94, [], [], 'fam1', 1 ).
test( 't33', 392, [], [], 'fam1', 1 ).
test( 't34', 259, [], [], 'fam1', 1 ).
test( 't35', 701, [], [], 'fam1', 1 ).
test( 't36', 437, [], [], 'fam1', 1 ).
test( 't37', 691, [], ['r1','r4','r3','r2'], 'fam1', 1 ).
test( 't38', 96, [], [], 'fam1', 1 ).
test( 't39', 55, [], [], 'fam1', 1 ).
test( 't40', 414, [], [], 'fam1', 1 ).
test( 't41', 282, [], [], 'fam1', 1 ).
test( 't42', 330, [], [], 'fam1', 1 ).
test( 't43', 731, [], [], 'fam1', 1 ).
test( 't44', 527, [], [], 'fam1', 1 ).
test( 't45', 262, [], [], 'fam1', 1 ).
test( 't46', 357, [], [], 'fam1', 1 ).
test( 't47', 421, [], ['r1','r2'], 'fam1', 1 ).
test( 't48', 6, [], [], 'fam1', 1 ).
test( 't49', 762, [], [], 'fam1', 1 ).
test( 't50', 6, [], [], 'fam1', 1 ).
test( 't51', 329, [], [], 'fam1', 1 ).
test( 't52', 385, [], ['r2','r5','r1','r4','r3'], 'fam1', 1 ).
test( 't53', 581, [], [], 'fam1', 1 ).
test( 't54', 358, [], [], 'fam1', 1 ).
test( 't55', 50, [], ['r3'], 'fam1', 1 ).
test( 't56', 344, ['m37','m31','m42','m34','m29'], ['r3','r1','r4'], 'fam1', 1 ).
test( 't57', 330, [], [], 'fam1', 1 ).
test( 't58', 131, ['m39','m31','m8','m4','m5','m18'], [], 'fam1', 1 ).
test( 't59', 295, [], ['r5','r3'], 'fam1', 1 ).
test( 't60', 26, [], ['r4','r5','r1'], 'fam1', 1 ).
test( 't61', 495, [], [], 'fam1', 1 ).
test( 't62', 5, ['m29','m48','m7','m38','m33','m8','m32','m37','m23','m5','m45','m14','m26','m15'], ['r4','r5'], 'fam1', 1 ).
test( 't63', 420, [], ['r1','r2','r5','r4'], 'fam1', 1 ).
test( 't64', 782, [], [], 'fam1', 1 ).
test( 't65', 358, [], ['r5','r2','r4'], 'fam1', 1 ).
test( 't66', 497, [], ['r4','r5'], 'fam1', 1 ).
test( 't67', 126, [], [], 'fam1', 1 ).
test( 't68', 707, [], [], 'fam1', 1 ).
test( 't69', 118, [], ['r2','r5','r1'], 'fam1', 1 ).
test( 't70', 403, [], [], 'fam1', 1 ).
test( 't71', 425, ['m21','m22','m37','m17','m5','m30'], [], 'fam1', 1 ).
test( 't72', 322, ['m1','m19','m17','m46','m40','m41','m6','m27','m36','m4','m3','m30','m15','m50','m23','m47'], [], 'fam1', 1 ).
test( 't73', 147, ['m36','m21','m6','m22','m45','m41','m33','m46','m32','m24','m1','m4','m16','m10','m38','m26','m40'], [], 'fam1', 1 ).
test( 't74', 576, [], ['r1','r4'], 'fam1', 1 ).
test( 't75', 1, [], [], 'fam1', 1 ).
test( 't76', 769, [], ['r4','r1','r5','r3','r2'], 'fam1', 1 ).
test( 't77', 290, [], [], 'fam1', 1 ).
test( 't78', 14, ['m28','m26','m47','m3','m17','m2','m6','m31','m9','m10','m21','m40','m14','m50','m38','m33','m30','m29','m27','m4'], ['r2','r5','r1','r3','r4'], 'fam1', 1 ).
test( 't79', 617, [], [], 'fam1', 1 ).
test( 't80', 417, [], [], 'fam1', 1 ).
test( 't81', 452, [], [], 'fam1', 1 ).
test( 't82', 358, ['m28','m2','m11','m48','m14','m33','m36','m12','m5','m7','m31','m46','m44'], ['r3','r5','r2'], 'fam1', 1 ).
test( 't83', 174, [], [], 'fam1', 1 ).
test( 't84', 374, [], [], 'fam1', 1 ).
test( 't85', 479, ['m5','m13','m19','m10','m45','m44','m46','m15','m48','m43','m40','m25','m20','m27','m33','m30','m29','m12'], [], 'fam1', 1 ).
test( 't86', 633, [], ['r1'], 'fam1', 1 ).
test( 't87', 35, [], ['r2'], 'fam1', 1 ).
test( 't88', 612, [], [], 'fam1', 1 ).
test( 't89', 715, [], [], 'fam1', 1 ).
test( 't90', 62, ['m42','m2','m34','m38','m1','m21','m43','m24','m30','m44','m39','m31','m50'], [], 'fam1', 1 ).
test( 't91', 122, [], [], 'fam1', 1 ).
test( 't92', 462, [], ['r3','r1','r2','r5','r4'], 'fam1', 1 ).
test( 't93', 566, [], [], 'fam1', 1 ).
test( 't94', 593, [], [], 'fam1', 1 ).
test( 't95', 56, [], [], 'fam1', 1 ).
test( 't96', 297, [], [], 'fam1', 1 ).
test( 't97', 604, [], [], 'fam1', 1 ).
test( 't98', 403, ['m45'], [], 'fam1', 1 ).
test( 't99', 464, [], ['r2','r1','r5'], 'fam1', 1 ).
test( 't100', 5, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').
embedded_board( 'm21').
embedded_board( 'm22').
embedded_board( 'm23').
embedded_board( 'm24').
embedded_board( 'm25').
embedded_board( 'm26').
embedded_board( 'm27').
embedded_board( 'm28').
embedded_board( 'm29').
embedded_board( 'm30').
embedded_board( 'm31').
embedded_board( 'm32').
embedded_board( 'm33').
embedded_board( 'm34').
embedded_board( 'm35').
embedded_board( 'm36').
embedded_board( 'm37').
embedded_board( 'm38').
embedded_board( 'm39').
embedded_board( 'm40').
embedded_board( 'm41').
embedded_board( 'm42').
embedded_board( 'm43').
embedded_board( 'm44').
embedded_board( 'm45').
embedded_board( 'm46').
embedded_board( 'm47').
embedded_board( 'm48').
embedded_board( 'm49').
embedded_board( 'm50').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
