%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 20
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 770, [], [], 'fam1', 1 ).
test( 't2', 507, ['m7','m11','m6','m3','m13','m18','m2','m4'], ['r3','r4','r5','r1','r2'], 'fam1', 1 ).
test( 't3', 670, ['m16','m20'], [], 'fam1', 1 ).
test( 't4', 485, [], [], 'fam1', 1 ).
test( 't5', 577, [], [], 'fam1', 1 ).
test( 't6', 207, [], [], 'fam1', 1 ).
test( 't7', 385, ['m4','m20','m16','m18','m5','m6'], [], 'fam1', 1 ).
test( 't8', 400, [], [], 'fam1', 1 ).
test( 't9', 301, [], [], 'fam1', 1 ).
test( 't10', 714, [], [], 'fam1', 1 ).
test( 't11', 695, [], [], 'fam1', 1 ).
test( 't12', 747, [], [], 'fam1', 1 ).
test( 't13', 124, ['m14','m11','m18','m4','m2','m12','m16','m17'], [], 'fam1', 1 ).
test( 't14', 303, [], [], 'fam1', 1 ).
test( 't15', 483, [], ['r2','r1'], 'fam1', 1 ).
test( 't16', 480, [], [], 'fam1', 1 ).
test( 't17', 559, ['m4','m14','m6','m8'], ['r2','r4','r1','r5'], 'fam1', 1 ).
test( 't18', 288, ['m4','m6','m14','m10','m13','m19'], [], 'fam1', 1 ).
test( 't19', 439, [], ['r5','r4','r3'], 'fam1', 1 ).
test( 't20', 770, [], [], 'fam1', 1 ).
test( 't21', 436, [], [], 'fam1', 1 ).
test( 't22', 492, [], [], 'fam1', 1 ).
test( 't23', 345, ['m15'], [], 'fam1', 1 ).
test( 't24', 534, [], [], 'fam1', 1 ).
test( 't25', 189, [], [], 'fam1', 1 ).
test( 't26', 123, [], ['r2','r1','r5','r3'], 'fam1', 1 ).
test( 't27', 354, ['m7','m1','m9','m6','m13','m19'], [], 'fam1', 1 ).
test( 't28', 297, ['m15','m1','m20','m14','m6','m5','m19'], ['r5','r4','r1','r2'], 'fam1', 1 ).
test( 't29', 302, [], [], 'fam1', 1 ).
test( 't30', 30, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
