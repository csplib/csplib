%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 20
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 664, [], [], 'fam1', 1 ).
test( 't2', 76, [], [], 'fam1', 1 ).
test( 't3', 425, [], ['r3','r2'], 'fam1', 1 ).
test( 't4', 293, [], ['r1'], 'fam1', 1 ).
test( 't5', 239, ['m16'], [], 'fam1', 1 ).
test( 't6', 130, [], [], 'fam1', 1 ).
test( 't7', 217, [], [], 'fam1', 1 ).
test( 't8', 80, [], ['r3','r1'], 'fam1', 1 ).
test( 't9', 404, [], ['r3'], 'fam1', 1 ).
test( 't10', 300, [], [], 'fam1', 1 ).
test( 't11', 801, [], ['r3'], 'fam1', 1 ).
test( 't12', 54, ['m10','m9','m12','m15','m6'], [], 'fam1', 1 ).
test( 't13', 412, ['m11','m15'], ['r3'], 'fam1', 1 ).
test( 't14', 119, ['m4','m8','m17','m6','m14','m1'], [], 'fam1', 1 ).
test( 't15', 444, [], [], 'fam1', 1 ).
test( 't16', 767, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't17', 353, ['m1','m5','m6','m20','m17','m9','m4','m7'], [], 'fam1', 1 ).
test( 't18', 675, [], [], 'fam1', 1 ).
test( 't19', 99, [], ['r3','r1'], 'fam1', 1 ).
test( 't20', 517, ['m14'], [], 'fam1', 1 ).
test( 't21', 446, [], [], 'fam1', 1 ).
test( 't22', 782, [], [], 'fam1', 1 ).
test( 't23', 673, [], ['r1','r2'], 'fam1', 1 ).
test( 't24', 342, [], [], 'fam1', 1 ).
test( 't25', 614, [], [], 'fam1', 1 ).
test( 't26', 449, [], ['r1','r2'], 'fam1', 1 ).
test( 't27', 145, [], [], 'fam1', 1 ).
test( 't28', 269, [], [], 'fam1', 1 ).
test( 't29', 230, [], [], 'fam1', 1 ).
test( 't30', 526, [], ['r3','r1'], 'fam1', 1 ).
test( 't31', 564, [], [], 'fam1', 1 ).
test( 't32', 105, [], [], 'fam1', 1 ).
test( 't33', 168, [], [], 'fam1', 1 ).
test( 't34', 417, [], [], 'fam1', 1 ).
test( 't35', 123, [], [], 'fam1', 1 ).
test( 't36', 191, [], [], 'fam1', 1 ).
test( 't37', 246, [], [], 'fam1', 1 ).
test( 't38', 159, [], [], 'fam1', 1 ).
test( 't39', 755, [], [], 'fam1', 1 ).
test( 't40', 206, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
