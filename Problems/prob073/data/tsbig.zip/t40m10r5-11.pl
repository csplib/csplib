%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 104, [], [], 'fam1', 1 ).
test( 't2', 446, [], [], 'fam1', 1 ).
test( 't3', 419, [], [], 'fam1', 1 ).
test( 't4', 87, [], ['r4','r1'], 'fam1', 1 ).
test( 't5', 687, ['m6','m8','m7','m5'], [], 'fam1', 1 ).
test( 't6', 629, ['m3','m7','m5','m9'], ['r3'], 'fam1', 1 ).
test( 't7', 199, [], [], 'fam1', 1 ).
test( 't8', 351, [], [], 'fam1', 1 ).
test( 't9', 37, ['m5','m2','m9'], ['r3'], 'fam1', 1 ).
test( 't10', 729, [], ['r4','r5','r2','r1','r3'], 'fam1', 1 ).
test( 't11', 302, [], [], 'fam1', 1 ).
test( 't12', 204, [], [], 'fam1', 1 ).
test( 't13', 751, [], ['r5','r4','r3','r1'], 'fam1', 1 ).
test( 't14', 315, [], [], 'fam1', 1 ).
test( 't15', 515, [], ['r1','r2','r5','r4','r3'], 'fam1', 1 ).
test( 't16', 534, [], [], 'fam1', 1 ).
test( 't17', 673, [], [], 'fam1', 1 ).
test( 't18', 127, [], [], 'fam1', 1 ).
test( 't19', 32, [], [], 'fam1', 1 ).
test( 't20', 148, [], [], 'fam1', 1 ).
test( 't21', 150, [], ['r3','r5','r4','r1','r2'], 'fam1', 1 ).
test( 't22', 537, ['m9','m7'], [], 'fam1', 1 ).
test( 't23', 391, [], [], 'fam1', 1 ).
test( 't24', 766, [], ['r4','r1'], 'fam1', 1 ).
test( 't25', 519, ['m1'], [], 'fam1', 1 ).
test( 't26', 330, [], [], 'fam1', 1 ).
test( 't27', 203, [], [], 'fam1', 1 ).
test( 't28', 408, ['m6','m2','m9'], ['r1','r4','r5','r3'], 'fam1', 1 ).
test( 't29', 465, [], ['r2'], 'fam1', 1 ).
test( 't30', 371, [], [], 'fam1', 1 ).
test( 't31', 730, [], [], 'fam1', 1 ).
test( 't32', 337, [], [], 'fam1', 1 ).
test( 't33', 288, [], ['r1','r5','r2','r3','r4'], 'fam1', 1 ).
test( 't34', 778, [], [], 'fam1', 1 ).
test( 't35', 395, [], ['r3','r4','r5','r1','r2'], 'fam1', 1 ).
test( 't36', 121, [], ['r3','r1','r4','r5'], 'fam1', 1 ).
test( 't37', 681, [], [], 'fam1', 1 ).
test( 't38', 645, [], ['r1','r4'], 'fam1', 1 ).
test( 't39', 383, [], ['r1','r4'], 'fam1', 1 ).
test( 't40', 211, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
