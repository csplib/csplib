%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 10
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 269, [], ['r10','r5','r7','r6','r3','r1','r8'], 'fam1', 1 ).
test( 't2', 794, ['m9'], [], 'fam1', 1 ).
test( 't3', 314, [], [], 'fam1', 1 ).
test( 't4', 509, ['m2','m10'], [], 'fam1', 1 ).
test( 't5', 684, ['m10','m7'], ['r8','r7','r2','r4','r6','r9','r1'], 'fam1', 1 ).
test( 't6', 726, [], [], 'fam1', 1 ).
test( 't7', 577, [], [], 'fam1', 1 ).
test( 't8', 430, [], [], 'fam1', 1 ).
test( 't9', 279, [], ['r5','r6','r9','r4','r1','r3','r10','r2','r7','r8'], 'fam1', 1 ).
test( 't10', 435, [], [], 'fam1', 1 ).
test( 't11', 430, [], [], 'fam1', 1 ).
test( 't12', 424, [], [], 'fam1', 1 ).
test( 't13', 358, [], ['r1','r8','r9','r6','r4','r2'], 'fam1', 1 ).
test( 't14', 444, [], [], 'fam1', 1 ).
test( 't15', 773, [], [], 'fam1', 1 ).
test( 't16', 611, [], ['r6','r10','r7','r2','r9','r8'], 'fam1', 1 ).
test( 't17', 182, [], [], 'fam1', 1 ).
test( 't18', 84, [], [], 'fam1', 1 ).
test( 't19', 604, [], [], 'fam1', 1 ).
test( 't20', 615, ['m8'], [], 'fam1', 1 ).
test( 't21', 455, [], [], 'fam1', 1 ).
test( 't22', 676, [], [], 'fam1', 1 ).
test( 't23', 575, [], [], 'fam1', 1 ).
test( 't24', 152, ['m4','m8','m10'], ['r1','r2','r5','r9','r4','r8','r6'], 'fam1', 1 ).
test( 't25', 192, [], [], 'fam1', 1 ).
test( 't26', 277, [], [], 'fam1', 1 ).
test( 't27', 653, [], [], 'fam1', 1 ).
test( 't28', 492, [], [], 'fam1', 1 ).
test( 't29', 149, [], [], 'fam1', 1 ).
test( 't30', 338, ['m4','m2','m10'], ['r3','r9','r6','r10','r8'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
