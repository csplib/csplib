%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 50
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 124, [], ['r2','r5','r1','r4','r3'], 'fam1', 1 ).
test( 't2', 185, ['m40','m13','m6','m3','m48','m17','m38','m16','m21','m26','m1'], [], 'fam1', 1 ).
test( 't3', 613, [], [], 'fam1', 1 ).
test( 't4', 231, [], [], 'fam1', 1 ).
test( 't5', 233, [], [], 'fam1', 1 ).
test( 't6', 792, [], ['r4','r5','r3','r2','r1'], 'fam1', 1 ).
test( 't7', 567, ['m30','m25','m21','m33','m41','m3','m31','m1','m19','m5','m39','m6','m26','m12','m35'], [], 'fam1', 1 ).
test( 't8', 378, ['m8','m46','m2','m14','m32','m21','m26'], [], 'fam1', 1 ).
test( 't9', 427, ['m22','m4','m11','m47','m27','m50','m32'], [], 'fam1', 1 ).
test( 't10', 382, [], [], 'fam1', 1 ).
test( 't11', 621, [], ['r5','r2','r3','r4'], 'fam1', 1 ).
test( 't12', 86, [], [], 'fam1', 1 ).
test( 't13', 704, [], [], 'fam1', 1 ).
test( 't14', 90, ['m30','m9','m24'], [], 'fam1', 1 ).
test( 't15', 709, [], ['r4','r5','r1','r3'], 'fam1', 1 ).
test( 't16', 647, ['m36','m35','m47','m16','m46','m42','m11','m5','m30'], [], 'fam1', 1 ).
test( 't17', 652, [], [], 'fam1', 1 ).
test( 't18', 350, [], [], 'fam1', 1 ).
test( 't19', 32, ['m48','m17','m44','m14','m31','m46','m40','m32','m45','m27','m15','m39','m8','m37','m16','m7','m4'], [], 'fam1', 1 ).
test( 't20', 381, [], [], 'fam1', 1 ).
test( 't21', 317, ['m20','m8','m33','m48'], [], 'fam1', 1 ).
test( 't22', 584, [], [], 'fam1', 1 ).
test( 't23', 399, [], [], 'fam1', 1 ).
test( 't24', 256, [], [], 'fam1', 1 ).
test( 't25', 309, [], ['r2','r5'], 'fam1', 1 ).
test( 't26', 593, ['m44','m3','m32','m43','m31','m37','m26','m15','m47','m7','m11'], [], 'fam1', 1 ).
test( 't27', 489, ['m39','m34','m28','m8','m23','m29','m22','m33','m21','m49','m6','m41','m10','m46','m25'], [], 'fam1', 1 ).
test( 't28', 164, [], [], 'fam1', 1 ).
test( 't29', 56, [], [], 'fam1', 1 ).
test( 't30', 412, ['m25','m49','m34','m41'], [], 'fam1', 1 ).
test( 't31', 143, [], ['r1'], 'fam1', 1 ).
test( 't32', 322, [], ['r1','r4','r5'], 'fam1', 1 ).
test( 't33', 266, [], [], 'fam1', 1 ).
test( 't34', 178, ['m6','m47','m44','m12','m36','m45','m30','m38','m28','m18','m29','m15','m41','m5'], [], 'fam1', 1 ).
test( 't35', 553, [], ['r5','r4','r1','r3'], 'fam1', 1 ).
test( 't36', 210, [], [], 'fam1', 1 ).
test( 't37', 638, [], [], 'fam1', 1 ).
test( 't38', 346, [], [], 'fam1', 1 ).
test( 't39', 539, [], [], 'fam1', 1 ).
test( 't40', 237, ['m8','m25','m28','m21','m45','m26','m18'], [], 'fam1', 1 ).
test( 't41', 692, [], [], 'fam1', 1 ).
test( 't42', 544, [], [], 'fam1', 1 ).
test( 't43', 186, [], ['r4'], 'fam1', 1 ).
test( 't44', 761, ['m33','m29','m50','m44','m37','m1','m41','m48','m28','m46','m10','m7','m34','m14','m22','m21','m8','m15'], ['r2','r1','r5'], 'fam1', 1 ).
test( 't45', 144, [], [], 'fam1', 1 ).
test( 't46', 489, [], [], 'fam1', 1 ).
test( 't47', 154, [], [], 'fam1', 1 ).
test( 't48', 759, [], ['r3','r2','r5','r4','r1'], 'fam1', 1 ).
test( 't49', 737, ['m44','m30'], [], 'fam1', 1 ).
test( 't50', 690, [], ['r1'], 'fam1', 1 ).
test( 't51', 738, [], [], 'fam1', 1 ).
test( 't52', 605, [], [], 'fam1', 1 ).
test( 't53', 791, [], [], 'fam1', 1 ).
test( 't54', 758, [], [], 'fam1', 1 ).
test( 't55', 25, [], ['r4','r5','r1','r3','r2'], 'fam1', 1 ).
test( 't56', 301, ['m27','m20','m29'], ['r1','r2','r4'], 'fam1', 1 ).
test( 't57', 515, ['m47','m23','m18','m15','m5','m26'], ['r1','r5','r2'], 'fam1', 1 ).
test( 't58', 445, [], ['r1','r3','r5','r4'], 'fam1', 1 ).
test( 't59', 202, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't60', 689, [], [], 'fam1', 1 ).
test( 't61', 103, [], [], 'fam1', 1 ).
test( 't62', 421, [], ['r2','r3','r1','r5'], 'fam1', 1 ).
test( 't63', 438, [], [], 'fam1', 1 ).
test( 't64', 303, [], ['r4','r3'], 'fam1', 1 ).
test( 't65', 732, [], ['r3','r4','r2','r5'], 'fam1', 1 ).
test( 't66', 342, [], [], 'fam1', 1 ).
test( 't67', 322, ['m41','m12','m14','m30','m13','m49','m5','m26','m39','m28','m15','m34','m25','m9'], ['r4'], 'fam1', 1 ).
test( 't68', 73, [], ['r2','r5','r3'], 'fam1', 1 ).
test( 't69', 426, ['m15','m9','m30','m5','m7','m22','m28','m45','m23','m12','m1'], ['r4','r5','r2'], 'fam1', 1 ).
test( 't70', 667, ['m31','m17','m36','m11','m2','m15','m50','m49','m4','m47','m10','m27','m8'], [], 'fam1', 1 ).
test( 't71', 631, ['m49','m11'], [], 'fam1', 1 ).
test( 't72', 453, [], ['r2'], 'fam1', 1 ).
test( 't73', 468, [], [], 'fam1', 1 ).
test( 't74', 569, [], [], 'fam1', 1 ).
test( 't75', 625, ['m30','m48'], ['r1','r4','r5'], 'fam1', 1 ).
test( 't76', 105, [], [], 'fam1', 1 ).
test( 't77', 107, [], [], 'fam1', 1 ).
test( 't78', 52, [], [], 'fam1', 1 ).
test( 't79', 524, ['m15','m4','m47','m24','m39','m10'], [], 'fam1', 1 ).
test( 't80', 123, [], ['r4'], 'fam1', 1 ).
test( 't81', 612, [], ['r5'], 'fam1', 1 ).
test( 't82', 16, [], [], 'fam1', 1 ).
test( 't83', 124, [], [], 'fam1', 1 ).
test( 't84', 329, [], ['r4'], 'fam1', 1 ).
test( 't85', 687, [], [], 'fam1', 1 ).
test( 't86', 799, [], ['r2'], 'fam1', 1 ).
test( 't87', 23, [], [], 'fam1', 1 ).
test( 't88', 639, [], [], 'fam1', 1 ).
test( 't89', 595, [], [], 'fam1', 1 ).
test( 't90', 268, ['m16','m12','m33','m32','m3','m9','m7','m4','m19','m1','m44'], [], 'fam1', 1 ).
test( 't91', 87, [], [], 'fam1', 1 ).
test( 't92', 548, [], [], 'fam1', 1 ).
test( 't93', 239, [], [], 'fam1', 1 ).
test( 't94', 720, [], [], 'fam1', 1 ).
test( 't95', 582, [], [], 'fam1', 1 ).
test( 't96', 695, [], [], 'fam1', 1 ).
test( 't97', 281, [], [], 'fam1', 1 ).
test( 't98', 16, [], [], 'fam1', 1 ).
test( 't99', 303, [], [], 'fam1', 1 ).
test( 't100', 512, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').
embedded_board( 'm21').
embedded_board( 'm22').
embedded_board( 'm23').
embedded_board( 'm24').
embedded_board( 'm25').
embedded_board( 'm26').
embedded_board( 'm27').
embedded_board( 'm28').
embedded_board( 'm29').
embedded_board( 'm30').
embedded_board( 'm31').
embedded_board( 'm32').
embedded_board( 'm33').
embedded_board( 'm34').
embedded_board( 'm35').
embedded_board( 'm36').
embedded_board( 'm37').
embedded_board( 'm38').
embedded_board( 'm39').
embedded_board( 'm40').
embedded_board( 'm41').
embedded_board( 'm42').
embedded_board( 'm43').
embedded_board( 'm44').
embedded_board( 'm45').
embedded_board( 'm46').
embedded_board( 'm47').
embedded_board( 'm48').
embedded_board( 'm49').
embedded_board( 'm50').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
