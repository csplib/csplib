%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 20
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 540, [], ['r2'], 'fam1', 1 ).
test( 't2', 255, [], [], 'fam1', 1 ).
test( 't3', 227, ['m6','m2','m1','m8','m7','m20','m19'], ['r3'], 'fam1', 1 ).
test( 't4', 714, [], [], 'fam1', 1 ).
test( 't5', 504, [], [], 'fam1', 1 ).
test( 't6', 424, ['m2','m17','m11'], [], 'fam1', 1 ).
test( 't7', 385, [], [], 'fam1', 1 ).
test( 't8', 239, ['m14','m19','m5','m3','m6','m13','m8','m12'], [], 'fam1', 1 ).
test( 't9', 550, [], ['r2'], 'fam1', 1 ).
test( 't10', 136, [], [], 'fam1', 1 ).
test( 't11', 571, [], [], 'fam1', 1 ).
test( 't12', 1, [], [], 'fam1', 1 ).
test( 't13', 265, ['m20','m6','m19','m12','m2'], ['r3','r2'], 'fam1', 1 ).
test( 't14', 381, [], [], 'fam1', 1 ).
test( 't15', 518, [], ['r3'], 'fam1', 1 ).
test( 't16', 763, ['m19'], [], 'fam1', 1 ).
test( 't17', 144, [], [], 'fam1', 1 ).
test( 't18', 101, [], [], 'fam1', 1 ).
test( 't19', 512, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't20', 427, [], [], 'fam1', 1 ).
test( 't21', 256, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't22', 402, [], [], 'fam1', 1 ).
test( 't23', 250, [], [], 'fam1', 1 ).
test( 't24', 155, [], ['r2'], 'fam1', 1 ).
test( 't25', 125, [], ['r1','r3'], 'fam1', 1 ).
test( 't26', 701, [], [], 'fam1', 1 ).
test( 't27', 555, ['m13','m3','m5','m7','m6','m9'], [], 'fam1', 1 ).
test( 't28', 335, [], [], 'fam1', 1 ).
test( 't29', 196, [], [], 'fam1', 1 ).
test( 't30', 499, ['m7','m1','m3','m11','m19','m20','m18'], [], 'fam1', 1 ).
test( 't31', 148, [], [], 'fam1', 1 ).
test( 't32', 119, [], [], 'fam1', 1 ).
test( 't33', 801, [], [], 'fam1', 1 ).
test( 't34', 468, [], [], 'fam1', 1 ).
test( 't35', 424, [], [], 'fam1', 1 ).
test( 't36', 58, [], [], 'fam1', 1 ).
test( 't37', 225, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't38', 233, ['m5','m8','m18','m12','m1'], ['r3','r1'], 'fam1', 1 ).
test( 't39', 322, [], [], 'fam1', 1 ).
test( 't40', 245, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
