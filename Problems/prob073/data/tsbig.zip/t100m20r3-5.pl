%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 20
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 771, ['m17','m8','m3','m18','m12','m9','m6'], [], 'fam1', 1 ).
test( 't2', 727, [], [], 'fam1', 1 ).
test( 't3', 356, [], [], 'fam1', 1 ).
test( 't4', 724, [], [], 'fam1', 1 ).
test( 't5', 57, [], [], 'fam1', 1 ).
test( 't6', 25, ['m9','m19','m17','m5','m11','m2','m8','m16'], ['r1'], 'fam1', 1 ).
test( 't7', 733, ['m15','m9','m5','m14','m11'], ['r1'], 'fam1', 1 ).
test( 't8', 435, [], [], 'fam1', 1 ).
test( 't9', 286, [], ['r1','r2'], 'fam1', 1 ).
test( 't10', 182, ['m10','m18','m11','m8','m19'], [], 'fam1', 1 ).
test( 't11', 159, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't12', 647, [], [], 'fam1', 1 ).
test( 't13', 356, ['m9','m1','m3','m7','m10','m2'], ['r2','r3','r1'], 'fam1', 1 ).
test( 't14', 766, [], [], 'fam1', 1 ).
test( 't15', 107, [], [], 'fam1', 1 ).
test( 't16', 1, [], [], 'fam1', 1 ).
test( 't17', 338, [], [], 'fam1', 1 ).
test( 't18', 300, ['m2','m15','m8','m4'], [], 'fam1', 1 ).
test( 't19', 620, [], [], 'fam1', 1 ).
test( 't20', 470, [], [], 'fam1', 1 ).
test( 't21', 591, [], [], 'fam1', 1 ).
test( 't22', 294, [], ['r2','r3'], 'fam1', 1 ).
test( 't23', 598, [], ['r3','r2'], 'fam1', 1 ).
test( 't24', 426, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't25', 201, [], [], 'fam1', 1 ).
test( 't26', 258, ['m1'], [], 'fam1', 1 ).
test( 't27', 577, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't28', 382, [], [], 'fam1', 1 ).
test( 't29', 693, [], [], 'fam1', 1 ).
test( 't30', 130, [], [], 'fam1', 1 ).
test( 't31', 784, ['m8'], ['r3','r2','r1'], 'fam1', 1 ).
test( 't32', 311, ['m13','m11','m1','m8','m18','m2','m4'], [], 'fam1', 1 ).
test( 't33', 584, [], [], 'fam1', 1 ).
test( 't34', 126, [], [], 'fam1', 1 ).
test( 't35', 606, [], ['r1'], 'fam1', 1 ).
test( 't36', 480, [], [], 'fam1', 1 ).
test( 't37', 282, ['m6','m1','m15'], ['r2'], 'fam1', 1 ).
test( 't38', 654, [], [], 'fam1', 1 ).
test( 't39', 251, [], [], 'fam1', 1 ).
test( 't40', 494, ['m15','m20','m11','m17','m14'], [], 'fam1', 1 ).
test( 't41', 584, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't42', 216, ['m13','m11'], [], 'fam1', 1 ).
test( 't43', 421, [], [], 'fam1', 1 ).
test( 't44', 503, [], [], 'fam1', 1 ).
test( 't45', 234, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't46', 385, [], [], 'fam1', 1 ).
test( 't47', 602, [], [], 'fam1', 1 ).
test( 't48', 590, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't49', 430, ['m9','m12','m6'], [], 'fam1', 1 ).
test( 't50', 81, [], [], 'fam1', 1 ).
test( 't51', 273, [], [], 'fam1', 1 ).
test( 't52', 20, [], [], 'fam1', 1 ).
test( 't53', 511, [], ['r1'], 'fam1', 1 ).
test( 't54', 378, [], [], 'fam1', 1 ).
test( 't55', 493, [], [], 'fam1', 1 ).
test( 't56', 574, [], [], 'fam1', 1 ).
test( 't57', 501, [], [], 'fam1', 1 ).
test( 't58', 112, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't59', 493, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't60', 771, [], ['r2','r1'], 'fam1', 1 ).
test( 't61', 660, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't62', 752, [], [], 'fam1', 1 ).
test( 't63', 363, [], [], 'fam1', 1 ).
test( 't64', 95, [], [], 'fam1', 1 ).
test( 't65', 8, [], [], 'fam1', 1 ).
test( 't66', 328, [], ['r3','r1'], 'fam1', 1 ).
test( 't67', 632, [], ['r3'], 'fam1', 1 ).
test( 't68', 71, [], [], 'fam1', 1 ).
test( 't69', 407, [], ['r3','r1'], 'fam1', 1 ).
test( 't70', 206, [], ['r2'], 'fam1', 1 ).
test( 't71', 575, [], [], 'fam1', 1 ).
test( 't72', 717, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't73', 9, [], [], 'fam1', 1 ).
test( 't74', 36, [], [], 'fam1', 1 ).
test( 't75', 720, [], [], 'fam1', 1 ).
test( 't76', 144, [], [], 'fam1', 1 ).
test( 't77', 16, ['m20','m12','m5','m1'], ['r1','r3','r2'], 'fam1', 1 ).
test( 't78', 353, [], [], 'fam1', 1 ).
test( 't79', 598, [], [], 'fam1', 1 ).
test( 't80', 627, [], [], 'fam1', 1 ).
test( 't81', 554, [], ['r1'], 'fam1', 1 ).
test( 't82', 151, [], [], 'fam1', 1 ).
test( 't83', 440, ['m17','m13','m18'], ['r3'], 'fam1', 1 ).
test( 't84', 12, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't85', 570, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't86', 670, [], [], 'fam1', 1 ).
test( 't87', 443, [], [], 'fam1', 1 ).
test( 't88', 347, ['m13','m8','m6','m14','m19','m2','m4'], [], 'fam1', 1 ).
test( 't89', 539, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't90', 423, [], [], 'fam1', 1 ).
test( 't91', 488, [], [], 'fam1', 1 ).
test( 't92', 121, ['m11','m4','m1','m17','m15'], [], 'fam1', 1 ).
test( 't93', 560, [], [], 'fam1', 1 ).
test( 't94', 223, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't95', 659, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't96', 202, [], ['r2'], 'fam1', 1 ).
test( 't97', 16, [], [], 'fam1', 1 ).
test( 't98', 290, [], [], 'fam1', 1 ).
test( 't99', 476, [], [], 'fam1', 1 ).
test( 't100', 9, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
