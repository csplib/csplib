%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 10
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 15, [], ['r10','r4'], 'fam1', 1 ).
test( 't2', 662, [], [], 'fam1', 1 ).
test( 't3', 406, ['m2','m7'], ['r1','r7','r9'], 'fam1', 1 ).
test( 't4', 582, [], [], 'fam1', 1 ).
test( 't5', 151, [], [], 'fam1', 1 ).
test( 't6', 402, [], ['r9','r2','r7','r8','r4','r3','r6','r10'], 'fam1', 1 ).
test( 't7', 764, [], [], 'fam1', 1 ).
test( 't8', 408, [], [], 'fam1', 1 ).
test( 't9', 242, [], [], 'fam1', 1 ).
test( 't10', 173, [], [], 'fam1', 1 ).
test( 't11', 525, [], [], 'fam1', 1 ).
test( 't12', 431, ['m6','m9','m2'], [], 'fam1', 1 ).
test( 't13', 338, [], ['r8','r6','r2','r4','r7','r5'], 'fam1', 1 ).
test( 't14', 251, [], [], 'fam1', 1 ).
test( 't15', 556, [], ['r4','r8','r9','r6','r5','r2','r1','r7','r10','r3'], 'fam1', 1 ).
test( 't16', 218, [], [], 'fam1', 1 ).
test( 't17', 252, ['m3','m1','m7'], [], 'fam1', 1 ).
test( 't18', 638, [], ['r10'], 'fam1', 1 ).
test( 't19', 33, [], [], 'fam1', 1 ).
test( 't20', 679, [], [], 'fam1', 1 ).
test( 't21', 85, ['m4','m8','m5','m10'], ['r1','r7','r6','r2'], 'fam1', 1 ).
test( 't22', 276, [], [], 'fam1', 1 ).
test( 't23', 220, [], [], 'fam1', 1 ).
test( 't24', 218, [], [], 'fam1', 1 ).
test( 't25', 609, [], ['r4','r7','r2','r1'], 'fam1', 1 ).
test( 't26', 502, [], ['r5','r10'], 'fam1', 1 ).
test( 't27', 345, [], [], 'fam1', 1 ).
test( 't28', 473, [], ['r3','r9','r4'], 'fam1', 1 ).
test( 't29', 313, [], [], 'fam1', 1 ).
test( 't30', 222, [], [], 'fam1', 1 ).
test( 't31', 211, [], [], 'fam1', 1 ).
test( 't32', 653, [], [], 'fam1', 1 ).
test( 't33', 332, [], ['r2','r4','r8','r7','r9'], 'fam1', 1 ).
test( 't34', 634, [], [], 'fam1', 1 ).
test( 't35', 384, [], [], 'fam1', 1 ).
test( 't36', 660, [], ['r10','r4','r3','r9','r6','r2','r5','r1','r8'], 'fam1', 1 ).
test( 't37', 36, [], [], 'fam1', 1 ).
test( 't38', 551, [], [], 'fam1', 1 ).
test( 't39', 178, [], [], 'fam1', 1 ).
test( 't40', 108, [], ['r10','r2','r6'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
