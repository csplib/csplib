%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 50
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 779, [], ['r3','r1'], 'fam1', 1 ).
test( 't2', 214, [], [], 'fam1', 1 ).
test( 't3', 33, [], [], 'fam1', 1 ).
test( 't4', 730, [], [], 'fam1', 1 ).
test( 't5', 364, [], [], 'fam1', 1 ).
test( 't6', 307, ['m50'], [], 'fam1', 1 ).
test( 't7', 317, [], [], 'fam1', 1 ).
test( 't8', 600, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't9', 794, [], [], 'fam1', 1 ).
test( 't10', 218, ['m47','m16','m28','m38'], [], 'fam1', 1 ).
test( 't11', 16, ['m42','m49','m36','m12','m15','m28','m25','m19','m44','m17','m31','m46','m48'], [], 'fam1', 1 ).
test( 't12', 741, [], [], 'fam1', 1 ).
test( 't13', 788, ['m23','m4','m24','m44','m30','m25','m9','m20','m41','m14','m48','m13','m1','m12','m16','m15','m37','m40'], [], 'fam1', 1 ).
test( 't14', 565, [], ['r2'], 'fam1', 1 ).
test( 't15', 198, [], [], 'fam1', 1 ).
test( 't16', 348, ['m7','m1','m10'], ['r1'], 'fam1', 1 ).
test( 't17', 381, ['m50','m13','m28','m34','m22'], ['r2','r1','r3'], 'fam1', 1 ).
test( 't18', 355, [], [], 'fam1', 1 ).
test( 't19', 536, ['m34','m18','m13','m15','m48','m20','m40','m11','m41','m6','m37','m16'], [], 'fam1', 1 ).
test( 't20', 279, [], [], 'fam1', 1 ).
test( 't21', 401, [], [], 'fam1', 1 ).
test( 't22', 793, [], [], 'fam1', 1 ).
test( 't23', 334, ['m48','m50','m20','m27','m38','m43','m18','m3','m22','m26','m16','m35','m4','m41','m6','m36'], ['r3','r1'], 'fam1', 1 ).
test( 't24', 189, ['m13','m43','m39','m49','m12'], ['r3','r1'], 'fam1', 1 ).
test( 't25', 493, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't26', 666, ['m7','m16','m46','m17','m29','m43','m8','m18','m49','m32','m47','m22','m2','m28','m13','m1','m30','m11','m3','m39'], ['r1'], 'fam1', 1 ).
test( 't27', 722, [], [], 'fam1', 1 ).
test( 't28', 308, [], ['r3','r2'], 'fam1', 1 ).
test( 't29', 112, [], [], 'fam1', 1 ).
test( 't30', 495, [], [], 'fam1', 1 ).
test( 't31', 49, [], [], 'fam1', 1 ).
test( 't32', 197, [], ['r3'], 'fam1', 1 ).
test( 't33', 597, ['m11','m32','m43','m24','m14','m2'], [], 'fam1', 1 ).
test( 't34', 463, [], [], 'fam1', 1 ).
test( 't35', 25, [], [], 'fam1', 1 ).
test( 't36', 222, [], [], 'fam1', 1 ).
test( 't37', 790, ['m21','m50','m14','m18','m26','m46','m42','m3'], [], 'fam1', 1 ).
test( 't38', 623, ['m10','m36','m14','m16','m9','m39','m32','m7','m12'], [], 'fam1', 1 ).
test( 't39', 83, [], ['r3'], 'fam1', 1 ).
test( 't40', 326, [], [], 'fam1', 1 ).
test( 't41', 459, [], [], 'fam1', 1 ).
test( 't42', 696, [], ['r3'], 'fam1', 1 ).
test( 't43', 648, [], [], 'fam1', 1 ).
test( 't44', 260, [], [], 'fam1', 1 ).
test( 't45', 468, ['m6','m5','m28','m7','m34','m15','m45','m23','m42','m3','m26','m25'], ['r1','r3'], 'fam1', 1 ).
test( 't46', 707, [], [], 'fam1', 1 ).
test( 't47', 565, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't48', 160, [], [], 'fam1', 1 ).
test( 't49', 281, [], [], 'fam1', 1 ).
test( 't50', 311, ['m4','m40','m44','m30','m49','m37','m15','m22','m18','m11','m42'], [], 'fam1', 1 ).
test( 't51', 674, [], [], 'fam1', 1 ).
test( 't52', 89, [], [], 'fam1', 1 ).
test( 't53', 418, [], [], 'fam1', 1 ).
test( 't54', 242, ['m1','m18','m8','m9'], [], 'fam1', 1 ).
test( 't55', 205, ['m2','m24','m15','m8','m34','m45','m7','m42','m5','m39','m44','m47','m6','m16','m1','m50','m25','m14','m23','m40'], [], 'fam1', 1 ).
test( 't56', 639, ['m16','m5','m26','m31','m3','m12','m6','m22','m24','m25','m42','m14','m21','m1','m39','m15','m48','m49','m43','m4'], [], 'fam1', 1 ).
test( 't57', 454, [], ['r2'], 'fam1', 1 ).
test( 't58', 666, [], ['r2'], 'fam1', 1 ).
test( 't59', 95, [], [], 'fam1', 1 ).
test( 't60', 541, [], [], 'fam1', 1 ).
test( 't61', 400, [], ['r1','r2'], 'fam1', 1 ).
test( 't62', 717, [], [], 'fam1', 1 ).
test( 't63', 15, [], ['r3','r1'], 'fam1', 1 ).
test( 't64', 161, [], [], 'fam1', 1 ).
test( 't65', 569, [], [], 'fam1', 1 ).
test( 't66', 77, [], [], 'fam1', 1 ).
test( 't67', 403, [], [], 'fam1', 1 ).
test( 't68', 183, [], [], 'fam1', 1 ).
test( 't69', 573, [], [], 'fam1', 1 ).
test( 't70', 591, ['m11','m32','m39'], [], 'fam1', 1 ).
test( 't71', 345, [], [], 'fam1', 1 ).
test( 't72', 790, ['m43','m7','m1','m41'], [], 'fam1', 1 ).
test( 't73', 374, [], ['r1'], 'fam1', 1 ).
test( 't74', 493, [], ['r1','r3'], 'fam1', 1 ).
test( 't75', 676, ['m49','m9','m17','m34','m31','m1','m5','m13','m35'], ['r1'], 'fam1', 1 ).
test( 't76', 260, [], [], 'fam1', 1 ).
test( 't77', 481, [], [], 'fam1', 1 ).
test( 't78', 525, [], [], 'fam1', 1 ).
test( 't79', 33, [], ['r3','r1'], 'fam1', 1 ).
test( 't80', 757, [], [], 'fam1', 1 ).
test( 't81', 322, [], [], 'fam1', 1 ).
test( 't82', 613, [], [], 'fam1', 1 ).
test( 't83', 599, ['m34','m12','m42','m45','m19','m16','m8','m17','m20','m50','m2'], [], 'fam1', 1 ).
test( 't84', 650, [], ['r3','r1'], 'fam1', 1 ).
test( 't85', 770, [], [], 'fam1', 1 ).
test( 't86', 739, ['m36','m32','m43','m30','m10','m21'], [], 'fam1', 1 ).
test( 't87', 611, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't88', 426, [], [], 'fam1', 1 ).
test( 't89', 358, [], [], 'fam1', 1 ).
test( 't90', 463, [], [], 'fam1', 1 ).
test( 't91', 705, [], ['r2','r3'], 'fam1', 1 ).
test( 't92', 444, [], [], 'fam1', 1 ).
test( 't93', 318, [], [], 'fam1', 1 ).
test( 't94', 203, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't95', 375, [], ['r1'], 'fam1', 1 ).
test( 't96', 75, [], [], 'fam1', 1 ).
test( 't97', 470, [], [], 'fam1', 1 ).
test( 't98', 403, [], [], 'fam1', 1 ).
test( 't99', 629, [], [], 'fam1', 1 ).
test( 't100', 294, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').
embedded_board( 'm21').
embedded_board( 'm22').
embedded_board( 'm23').
embedded_board( 'm24').
embedded_board( 'm25').
embedded_board( 'm26').
embedded_board( 'm27').
embedded_board( 'm28').
embedded_board( 'm29').
embedded_board( 'm30').
embedded_board( 'm31').
embedded_board( 'm32').
embedded_board( 'm33').
embedded_board( 'm34').
embedded_board( 'm35').
embedded_board( 'm36').
embedded_board( 'm37').
embedded_board( 'm38').
embedded_board( 'm39').
embedded_board( 'm40').
embedded_board( 'm41').
embedded_board( 'm42').
embedded_board( 'm43').
embedded_board( 'm44').
embedded_board( 'm45').
embedded_board( 'm46').
embedded_board( 'm47').
embedded_board( 'm48').
embedded_board( 'm49').
embedded_board( 'm50').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
