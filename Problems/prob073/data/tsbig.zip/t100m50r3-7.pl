%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 50
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 186, [], [], 'fam1', 1 ).
test( 't2', 727, ['m8','m40','m20','m31'], ['r2','r1'], 'fam1', 1 ).
test( 't3', 21, [], [], 'fam1', 1 ).
test( 't4', 754, ['m48','m38','m50','m44','m36','m11','m43','m49','m24','m42','m29','m13','m14','m9','m41','m21','m33'], ['r2','r3','r1'], 'fam1', 1 ).
test( 't5', 331, ['m42','m49','m17','m23','m29','m45','m30','m12','m15','m2','m41','m46','m48','m40','m31','m24'], [], 'fam1', 1 ).
test( 't6', 58, ['m12','m14','m15','m32','m41'], ['r1'], 'fam1', 1 ).
test( 't7', 106, [], [], 'fam1', 1 ).
test( 't8', 286, [], [], 'fam1', 1 ).
test( 't9', 285, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't10', 243, [], [], 'fam1', 1 ).
test( 't11', 758, [], [], 'fam1', 1 ).
test( 't12', 525, [], [], 'fam1', 1 ).
test( 't13', 733, [], [], 'fam1', 1 ).
test( 't14', 8, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't15', 38, [], [], 'fam1', 1 ).
test( 't16', 771, [], [], 'fam1', 1 ).
test( 't17', 649, [], [], 'fam1', 1 ).
test( 't18', 252, [], [], 'fam1', 1 ).
test( 't19', 469, [], [], 'fam1', 1 ).
test( 't20', 84, [], ['r3'], 'fam1', 1 ).
test( 't21', 281, [], [], 'fam1', 1 ).
test( 't22', 552, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't23', 392, ['m19','m12','m18','m42','m50','m46'], [], 'fam1', 1 ).
test( 't24', 625, [], [], 'fam1', 1 ).
test( 't25', 486, [], [], 'fam1', 1 ).
test( 't26', 686, [], [], 'fam1', 1 ).
test( 't27', 390, [], [], 'fam1', 1 ).
test( 't28', 150, [], [], 'fam1', 1 ).
test( 't29', 607, ['m4','m21','m9','m22','m16','m7','m37','m43','m31','m5','m41'], [], 'fam1', 1 ).
test( 't30', 55, [], [], 'fam1', 1 ).
test( 't31', 755, [], [], 'fam1', 1 ).
test( 't32', 203, [], [], 'fam1', 1 ).
test( 't33', 232, [], [], 'fam1', 1 ).
test( 't34', 463, [], [], 'fam1', 1 ).
test( 't35', 529, ['m37','m32','m5','m13','m23','m40','m16','m15'], [], 'fam1', 1 ).
test( 't36', 202, [], [], 'fam1', 1 ).
test( 't37', 609, [], [], 'fam1', 1 ).
test( 't38', 522, ['m47'], [], 'fam1', 1 ).
test( 't39', 207, [], [], 'fam1', 1 ).
test( 't40', 315, [], [], 'fam1', 1 ).
test( 't41', 337, [], [], 'fam1', 1 ).
test( 't42', 708, [], [], 'fam1', 1 ).
test( 't43', 91, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't44', 155, [], [], 'fam1', 1 ).
test( 't45', 204, ['m44','m3'], [], 'fam1', 1 ).
test( 't46', 631, [], [], 'fam1', 1 ).
test( 't47', 364, [], [], 'fam1', 1 ).
test( 't48', 625, ['m7','m45','m20','m8','m29','m26','m34','m48','m13','m16','m47','m3','m2','m15','m46','m42','m24','m39','m27','m9'], ['r3'], 'fam1', 1 ).
test( 't49', 677, [], [], 'fam1', 1 ).
test( 't50', 515, [], [], 'fam1', 1 ).
test( 't51', 311, [], [], 'fam1', 1 ).
test( 't52', 389, [], ['r2','r3'], 'fam1', 1 ).
test( 't53', 549, [], [], 'fam1', 1 ).
test( 't54', 717, [], [], 'fam1', 1 ).
test( 't55', 721, [], [], 'fam1', 1 ).
test( 't56', 253, [], [], 'fam1', 1 ).
test( 't57', 692, [], [], 'fam1', 1 ).
test( 't58', 794, ['m11','m38','m24','m23','m43','m18','m9','m49','m22','m44','m34','m37','m1'], ['r2'], 'fam1', 1 ).
test( 't59', 705, [], [], 'fam1', 1 ).
test( 't60', 772, [], [], 'fam1', 1 ).
test( 't61', 126, [], ['r3','r1'], 'fam1', 1 ).
test( 't62', 308, [], [], 'fam1', 1 ).
test( 't63', 519, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't64', 362, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't65', 801, [], [], 'fam1', 1 ).
test( 't66', 607, ['m1','m22','m14','m11','m8','m50','m33','m31','m43','m12','m37'], [], 'fam1', 1 ).
test( 't67', 699, [], [], 'fam1', 1 ).
test( 't68', 761, [], [], 'fam1', 1 ).
test( 't69', 271, ['m37','m40','m31','m50'], [], 'fam1', 1 ).
test( 't70', 798, [], [], 'fam1', 1 ).
test( 't71', 478, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't72', 68, [], [], 'fam1', 1 ).
test( 't73', 424, ['m8','m27','m33','m24','m20','m18'], [], 'fam1', 1 ).
test( 't74', 191, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't75', 513, ['m15','m2','m36','m32','m1','m35','m3'], ['r1','r2','r3'], 'fam1', 1 ).
test( 't76', 725, [], [], 'fam1', 1 ).
test( 't77', 345, ['m36','m5','m8','m32','m7','m45','m29','m38','m13','m2','m40','m44','m50','m15','m24'], [], 'fam1', 1 ).
test( 't78', 677, [], [], 'fam1', 1 ).
test( 't79', 743, [], ['r1'], 'fam1', 1 ).
test( 't80', 649, ['m34','m50','m30','m24','m29','m7','m16','m3','m6','m38','m36','m14','m15','m8','m39'], [], 'fam1', 1 ).
test( 't81', 256, [], [], 'fam1', 1 ).
test( 't82', 691, [], [], 'fam1', 1 ).
test( 't83', 11, [], ['r2','r1'], 'fam1', 1 ).
test( 't84', 499, ['m20','m31','m46'], [], 'fam1', 1 ).
test( 't85', 147, [], [], 'fam1', 1 ).
test( 't86', 771, [], [], 'fam1', 1 ).
test( 't87', 223, ['m17','m14','m46','m5','m11','m49','m20'], [], 'fam1', 1 ).
test( 't88', 585, [], [], 'fam1', 1 ).
test( 't89', 612, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't90', 721, [], [], 'fam1', 1 ).
test( 't91', 253, [], [], 'fam1', 1 ).
test( 't92', 545, [], [], 'fam1', 1 ).
test( 't93', 739, ['m32'], [], 'fam1', 1 ).
test( 't94', 29, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't95', 628, ['m47','m49','m16','m20','m26','m7','m35'], [], 'fam1', 1 ).
test( 't96', 791, ['m11','m1','m34','m25','m41','m29','m42','m45','m9','m47','m30'], [], 'fam1', 1 ).
test( 't97', 797, [], ['r1','r2'], 'fam1', 1 ).
test( 't98', 137, [], [], 'fam1', 1 ).
test( 't99', 714, [], ['r2','r3'], 'fam1', 1 ).
test( 't100', 761, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').
embedded_board( 'm21').
embedded_board( 'm22').
embedded_board( 'm23').
embedded_board( 'm24').
embedded_board( 'm25').
embedded_board( 'm26').
embedded_board( 'm27').
embedded_board( 'm28').
embedded_board( 'm29').
embedded_board( 'm30').
embedded_board( 'm31').
embedded_board( 'm32').
embedded_board( 'm33').
embedded_board( 'm34').
embedded_board( 'm35').
embedded_board( 'm36').
embedded_board( 'm37').
embedded_board( 'm38').
embedded_board( 'm39').
embedded_board( 'm40').
embedded_board( 'm41').
embedded_board( 'm42').
embedded_board( 'm43').
embedded_board( 'm44').
embedded_board( 'm45').
embedded_board( 'm46').
embedded_board( 'm47').
embedded_board( 'm48').
embedded_board( 'm49').
embedded_board( 'm50').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
