%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 10
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 211, [], ['r3','r5','r2','r1','r8','r7'], 'fam1', 1 ).
test( 't2', 599, [], ['r4','r2','r3','r5','r7','r8','r1','r6'], 'fam1', 1 ).
test( 't3', 303, [], [], 'fam1', 1 ).
test( 't4', 271, [], [], 'fam1', 1 ).
test( 't5', 332, [], [], 'fam1', 1 ).
test( 't6', 4, [], [], 'fam1', 1 ).
test( 't7', 74, ['m4'], [], 'fam1', 1 ).
test( 't8', 300, [], [], 'fam1', 1 ).
test( 't9', 354, [], [], 'fam1', 1 ).
test( 't10', 348, ['m7'], [], 'fam1', 1 ).
test( 't11', 522, [], [], 'fam1', 1 ).
test( 't12', 86, [], [], 'fam1', 1 ).
test( 't13', 247, [], [], 'fam1', 1 ).
test( 't14', 685, [], [], 'fam1', 1 ).
test( 't15', 114, ['m6','m3','m7','m10'], [], 'fam1', 1 ).
test( 't16', 577, [], ['r10','r4','r1','r7','r6','r5','r3','r8','r2','r9'], 'fam1', 1 ).
test( 't17', 786, [], [], 'fam1', 1 ).
test( 't18', 639, [], ['r4','r10','r9','r1','r2','r3','r8','r5','r6','r7'], 'fam1', 1 ).
test( 't19', 336, [], ['r2','r8','r7','r6','r9','r3','r4'], 'fam1', 1 ).
test( 't20', 239, ['m8'], [], 'fam1', 1 ).
test( 't21', 125, [], ['r5','r9','r8','r7','r6','r3','r10','r1'], 'fam1', 1 ).
test( 't22', 282, [], [], 'fam1', 1 ).
test( 't23', 182, [], [], 'fam1', 1 ).
test( 't24', 56, [], [], 'fam1', 1 ).
test( 't25', 77, [], [], 'fam1', 1 ).
test( 't26', 661, ['m10'], [], 'fam1', 1 ).
test( 't27', 512, [], [], 'fam1', 1 ).
test( 't28', 233, [], [], 'fam1', 1 ).
test( 't29', 249, [], [], 'fam1', 1 ).
test( 't30', 442, [], [], 'fam1', 1 ).
test( 't31', 506, [], [], 'fam1', 1 ).
test( 't32', 728, [], ['r5','r7','r1','r9','r10','r3','r2','r6','r8'], 'fam1', 1 ).
test( 't33', 535, [], ['r1','r8','r5','r2','r10','r6','r3','r7'], 'fam1', 1 ).
test( 't34', 361, [], ['r3','r10','r6','r8','r4','r9','r1','r7'], 'fam1', 1 ).
test( 't35', 368, [], [], 'fam1', 1 ).
test( 't36', 273, [], ['r4','r6','r10','r9','r3','r2','r7'], 'fam1', 1 ).
test( 't37', 188, [], ['r8','r6','r5','r4','r10','r3','r7'], 'fam1', 1 ).
test( 't38', 635, [], [], 'fam1', 1 ).
test( 't39', 566, ['m6','m1','m3','m10'], [], 'fam1', 1 ).
test( 't40', 412, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
