%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 786, [], ['r4','r5','r2'], 'fam1', 1 ).
test( 't2', 666, ['m6','m10','m9'], [], 'fam1', 1 ).
test( 't3', 254, [], ['r5','r4','r1','r2','r3'], 'fam1', 1 ).
test( 't4', 420, [], ['r1','r2','r5','r3'], 'fam1', 1 ).
test( 't5', 382, [], [], 'fam1', 1 ).
test( 't6', 336, [], ['r1','r2','r4','r3','r5'], 'fam1', 1 ).
test( 't7', 15, [], [], 'fam1', 1 ).
test( 't8', 520, [], [], 'fam1', 1 ).
test( 't9', 467, [], [], 'fam1', 1 ).
test( 't10', 712, [], ['r1','r3','r5','r2'], 'fam1', 1 ).
test( 't11', 227, ['m7','m3','m9','m10'], [], 'fam1', 1 ).
test( 't12', 595, [], ['r4','r3','r5'], 'fam1', 1 ).
test( 't13', 665, ['m3','m10','m1'], [], 'fam1', 1 ).
test( 't14', 30, ['m5','m7'], [], 'fam1', 1 ).
test( 't15', 458, [], [], 'fam1', 1 ).
test( 't16', 275, [], [], 'fam1', 1 ).
test( 't17', 370, [], ['r5','r4','r3','r2','r1'], 'fam1', 1 ).
test( 't18', 746, ['m6','m2','m5'], [], 'fam1', 1 ).
test( 't19', 354, [], [], 'fam1', 1 ).
test( 't20', 734, ['m5'], ['r2','r4','r1','r5','r3'], 'fam1', 1 ).
test( 't21', 467, [], [], 'fam1', 1 ).
test( 't22', 134, [], ['r5','r1','r4'], 'fam1', 1 ).
test( 't23', 707, [], [], 'fam1', 1 ).
test( 't24', 278, ['m1'], [], 'fam1', 1 ).
test( 't25', 464, ['m6','m5','m4'], ['r1','r4'], 'fam1', 1 ).
test( 't26', 38, [], [], 'fam1', 1 ).
test( 't27', 345, [], [], 'fam1', 1 ).
test( 't28', 513, [], [], 'fam1', 1 ).
test( 't29', 160, [], ['r5','r4','r3','r1','r2'], 'fam1', 1 ).
test( 't30', 742, [], [], 'fam1', 1 ).
test( 't31', 353, ['m6','m1'], [], 'fam1', 1 ).
test( 't32', 268, [], [], 'fam1', 1 ).
test( 't33', 412, [], ['r2','r3','r4','r5','r1'], 'fam1', 1 ).
test( 't34', 583, [], [], 'fam1', 1 ).
test( 't35', 429, ['m4','m5'], [], 'fam1', 1 ).
test( 't36', 667, [], [], 'fam1', 1 ).
test( 't37', 203, [], [], 'fam1', 1 ).
test( 't38', 783, [], [], 'fam1', 1 ).
test( 't39', 531, [], [], 'fam1', 1 ).
test( 't40', 726, [], [], 'fam1', 1 ).
test( 't41', 430, [], [], 'fam1', 1 ).
test( 't42', 756, [], [], 'fam1', 1 ).
test( 't43', 636, [], [], 'fam1', 1 ).
test( 't44', 683, [], [], 'fam1', 1 ).
test( 't45', 404, [], [], 'fam1', 1 ).
test( 't46', 96, [], [], 'fam1', 1 ).
test( 't47', 741, [], [], 'fam1', 1 ).
test( 't48', 233, [], [], 'fam1', 1 ).
test( 't49', 252, ['m7','m8'], [], 'fam1', 1 ).
test( 't50', 67, [], [], 'fam1', 1 ).
test( 't51', 616, ['m10'], ['r2','r1','r3'], 'fam1', 1 ).
test( 't52', 352, [], [], 'fam1', 1 ).
test( 't53', 726, ['m6','m5'], [], 'fam1', 1 ).
test( 't54', 740, [], ['r2','r4'], 'fam1', 1 ).
test( 't55', 297, [], [], 'fam1', 1 ).
test( 't56', 572, [], [], 'fam1', 1 ).
test( 't57', 125, [], ['r5','r4','r2'], 'fam1', 1 ).
test( 't58', 621, [], [], 'fam1', 1 ).
test( 't59', 359, [], ['r4','r2'], 'fam1', 1 ).
test( 't60', 461, [], ['r1'], 'fam1', 1 ).
test( 't61', 343, [], [], 'fam1', 1 ).
test( 't62', 723, [], ['r2','r5','r1','r4'], 'fam1', 1 ).
test( 't63', 179, [], [], 'fam1', 1 ).
test( 't64', 403, ['m6'], [], 'fam1', 1 ).
test( 't65', 317, ['m8','m10','m2'], [], 'fam1', 1 ).
test( 't66', 99, [], [], 'fam1', 1 ).
test( 't67', 157, ['m3','m7'], ['r1','r3','r2'], 'fam1', 1 ).
test( 't68', 222, [], [], 'fam1', 1 ).
test( 't69', 404, [], ['r4','r2','r1','r5'], 'fam1', 1 ).
test( 't70', 216, [], [], 'fam1', 1 ).
test( 't71', 754, [], [], 'fam1', 1 ).
test( 't72', 524, [], [], 'fam1', 1 ).
test( 't73', 267, [], ['r3','r1','r5','r2'], 'fam1', 1 ).
test( 't74', 175, [], [], 'fam1', 1 ).
test( 't75', 260, [], [], 'fam1', 1 ).
test( 't76', 43, [], [], 'fam1', 1 ).
test( 't77', 197, [], ['r2'], 'fam1', 1 ).
test( 't78', 180, [], [], 'fam1', 1 ).
test( 't79', 534, [], ['r5','r1','r3'], 'fam1', 1 ).
test( 't80', 357, ['m10'], [], 'fam1', 1 ).
test( 't81', 340, [], ['r2','r3','r5','r4','r1'], 'fam1', 1 ).
test( 't82', 198, [], [], 'fam1', 1 ).
test( 't83', 410, [], [], 'fam1', 1 ).
test( 't84', 322, [], ['r4','r2','r3'], 'fam1', 1 ).
test( 't85', 29, [], [], 'fam1', 1 ).
test( 't86', 139, [], [], 'fam1', 1 ).
test( 't87', 316, [], [], 'fam1', 1 ).
test( 't88', 87, [], [], 'fam1', 1 ).
test( 't89', 22, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't90', 756, ['m8'], [], 'fam1', 1 ).
test( 't91', 254, ['m3','m5'], [], 'fam1', 1 ).
test( 't92', 32, [], [], 'fam1', 1 ).
test( 't93', 106, [], [], 'fam1', 1 ).
test( 't94', 285, ['m4','m10','m5','m1'], [], 'fam1', 1 ).
test( 't95', 52, [], ['r4'], 'fam1', 1 ).
test( 't96', 107, [], [], 'fam1', 1 ).
test( 't97', 578, [], [], 'fam1', 1 ).
test( 't98', 160, [], [], 'fam1', 1 ).
test( 't99', 618, [], [], 'fam1', 1 ).
test( 't100', 404, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
