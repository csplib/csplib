%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 20
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 542, [], ['r3','r2'], 'fam1', 1 ).
test( 't2', 633, [], [], 'fam1', 1 ).
test( 't3', 262, [], [], 'fam1', 1 ).
test( 't4', 680, [], ['r2','r3'], 'fam1', 1 ).
test( 't5', 349, ['m15','m9','m6','m11'], [], 'fam1', 1 ).
test( 't6', 35, [], [], 'fam1', 1 ).
test( 't7', 266, [], [], 'fam1', 1 ).
test( 't8', 444, [], [], 'fam1', 1 ).
test( 't9', 344, [], ['r2','r3'], 'fam1', 1 ).
test( 't10', 430, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't11', 670, [], [], 'fam1', 1 ).
test( 't12', 144, ['m12','m11','m10','m15'], [], 'fam1', 1 ).
test( 't13', 254, ['m8','m2','m19','m9','m1'], ['r3','r1'], 'fam1', 1 ).
test( 't14', 339, [], ['r2','r3'], 'fam1', 1 ).
test( 't15', 724, [], [], 'fam1', 1 ).
test( 't16', 519, [], [], 'fam1', 1 ).
test( 't17', 562, [], [], 'fam1', 1 ).
test( 't18', 700, [], [], 'fam1', 1 ).
test( 't19', 629, ['m14'], [], 'fam1', 1 ).
test( 't20', 563, [], [], 'fam1', 1 ).
test( 't21', 14, ['m8','m19','m4','m9'], [], 'fam1', 1 ).
test( 't22', 231, [], [], 'fam1', 1 ).
test( 't23', 598, ['m8'], [], 'fam1', 1 ).
test( 't24', 403, [], [], 'fam1', 1 ).
test( 't25', 781, [], ['r2'], 'fam1', 1 ).
test( 't26', 750, [], [], 'fam1', 1 ).
test( 't27', 8, ['m20'], ['r1'], 'fam1', 1 ).
test( 't28', 690, [], [], 'fam1', 1 ).
test( 't29', 420, [], ['r1','r2'], 'fam1', 1 ).
test( 't30', 432, [], ['r1'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
