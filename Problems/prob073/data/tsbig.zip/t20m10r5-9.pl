%% ****  Testsuite  ****
% Number of tests                  : 20
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 576, ['m7','m6'], ['r1','r5','r4','r2'], 'fam1', 1 ).
test( 't2', 751, [], [], 'fam1', 1 ).
test( 't3', 398, ['m3','m4','m1','m9'], ['r2','r4','r3','r1'], 'fam1', 1 ).
test( 't4', 343, [], ['r3'], 'fam1', 1 ).
test( 't5', 503, [], [], 'fam1', 1 ).
test( 't6', 797, [], [], 'fam1', 1 ).
test( 't7', 347, [], [], 'fam1', 1 ).
test( 't8', 7, [], [], 'fam1', 1 ).
test( 't9', 792, ['m6'], [], 'fam1', 1 ).
test( 't10', 132, [], ['r3','r5','r1','r2'], 'fam1', 1 ).
test( 't11', 664, [], [], 'fam1', 1 ).
test( 't12', 365, [], ['r4','r3','r1','r2','r5'], 'fam1', 1 ).
test( 't13', 547, [], [], 'fam1', 1 ).
test( 't14', 184, [], [], 'fam1', 1 ).
test( 't15', 490, [], [], 'fam1', 1 ).
test( 't16', 356, [], [], 'fam1', 1 ).
test( 't17', 606, [], ['r2','r4','r1'], 'fam1', 1 ).
test( 't18', 356, ['m9'], ['r2','r3','r4'], 'fam1', 1 ).
test( 't19', 665, [], [], 'fam1', 1 ).
test( 't20', 520, [], ['r1','r4','r2'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
