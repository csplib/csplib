%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 20
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 620, [], [], 'fam1', 1 ).
test( 't2', 440, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't3', 720, ['m3','m13','m2','m12'], ['r2','r3','r1'], 'fam1', 1 ).
test( 't4', 579, ['m15','m6'], ['r1','r3'], 'fam1', 1 ).
test( 't5', 95, [], [], 'fam1', 1 ).
test( 't6', 599, [], ['r3'], 'fam1', 1 ).
test( 't7', 110, [], [], 'fam1', 1 ).
test( 't8', 714, [], [], 'fam1', 1 ).
test( 't9', 760, ['m9','m12','m11','m3','m7','m4','m14'], [], 'fam1', 1 ).
test( 't10', 24, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't11', 206, [], [], 'fam1', 1 ).
test( 't12', 551, [], [], 'fam1', 1 ).
test( 't13', 673, [], [], 'fam1', 1 ).
test( 't14', 511, [], [], 'fam1', 1 ).
test( 't15', 493, [], [], 'fam1', 1 ).
test( 't16', 453, ['m11','m20','m17','m16','m6'], [], 'fam1', 1 ).
test( 't17', 540, [], ['r3'], 'fam1', 1 ).
test( 't18', 278, ['m9','m16','m10','m4','m3','m6','m15'], [], 'fam1', 1 ).
test( 't19', 148, ['m15','m6'], ['r1'], 'fam1', 1 ).
test( 't20', 544, [], [], 'fam1', 1 ).
test( 't21', 370, [], [], 'fam1', 1 ).
test( 't22', 591, [], [], 'fam1', 1 ).
test( 't23', 92, [], [], 'fam1', 1 ).
test( 't24', 318, [], [], 'fam1', 1 ).
test( 't25', 792, [], [], 'fam1', 1 ).
test( 't26', 561, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't27', 338, [], [], 'fam1', 1 ).
test( 't28', 733, [], [], 'fam1', 1 ).
test( 't29', 95, ['m12'], [], 'fam1', 1 ).
test( 't30', 221, [], ['r1','r3'], 'fam1', 1 ).
test( 't31', 331, [], ['r3'], 'fam1', 1 ).
test( 't32', 67, [], ['r1','r2'], 'fam1', 1 ).
test( 't33', 457, [], [], 'fam1', 1 ).
test( 't34', 314, [], [], 'fam1', 1 ).
test( 't35', 10, [], [], 'fam1', 1 ).
test( 't36', 558, [], [], 'fam1', 1 ).
test( 't37', 242, [], [], 'fam1', 1 ).
test( 't38', 794, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't39', 252, [], [], 'fam1', 1 ).
test( 't40', 82, [], ['r1','r3'], 'fam1', 1 ).
test( 't41', 484, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't42', 690, [], ['r2','r3'], 'fam1', 1 ).
test( 't43', 381, ['m8','m10','m17','m2','m6'], ['r2'], 'fam1', 1 ).
test( 't44', 415, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't45', 404, [], ['r1','r2'], 'fam1', 1 ).
test( 't46', 723, ['m9','m16','m1','m15','m18','m2'], [], 'fam1', 1 ).
test( 't47', 518, [], [], 'fam1', 1 ).
test( 't48', 281, [], ['r3','r1'], 'fam1', 1 ).
test( 't49', 152, [], [], 'fam1', 1 ).
test( 't50', 293, [], [], 'fam1', 1 ).
test( 't51', 438, ['m8','m6','m14'], [], 'fam1', 1 ).
test( 't52', 56, [], [], 'fam1', 1 ).
test( 't53', 279, [], [], 'fam1', 1 ).
test( 't54', 639, ['m1','m4','m3','m6','m19'], [], 'fam1', 1 ).
test( 't55', 682, [], ['r3','r2'], 'fam1', 1 ).
test( 't56', 69, ['m14','m13','m8','m11','m15','m4','m6'], [], 'fam1', 1 ).
test( 't57', 407, [], [], 'fam1', 1 ).
test( 't58', 498, [], [], 'fam1', 1 ).
test( 't59', 594, [], [], 'fam1', 1 ).
test( 't60', 341, [], [], 'fam1', 1 ).
test( 't61', 148, ['m2','m11','m3','m13','m6','m14'], [], 'fam1', 1 ).
test( 't62', 404, [], [], 'fam1', 1 ).
test( 't63', 122, ['m8','m11','m19'], ['r3','r2'], 'fam1', 1 ).
test( 't64', 246, [], ['r3','r1'], 'fam1', 1 ).
test( 't65', 667, [], [], 'fam1', 1 ).
test( 't66', 90, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't67', 141, [], [], 'fam1', 1 ).
test( 't68', 776, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't69', 724, [], ['r1'], 'fam1', 1 ).
test( 't70', 32, [], [], 'fam1', 1 ).
test( 't71', 722, [], [], 'fam1', 1 ).
test( 't72', 118, [], [], 'fam1', 1 ).
test( 't73', 22, ['m8'], ['r1','r3','r2'], 'fam1', 1 ).
test( 't74', 527, [], ['r1','r3'], 'fam1', 1 ).
test( 't75', 213, [], [], 'fam1', 1 ).
test( 't76', 511, [], ['r3','r1'], 'fam1', 1 ).
test( 't77', 729, [], ['r1','r2'], 'fam1', 1 ).
test( 't78', 360, ['m19','m12','m17'], [], 'fam1', 1 ).
test( 't79', 254, [], [], 'fam1', 1 ).
test( 't80', 572, [], [], 'fam1', 1 ).
test( 't81', 664, [], ['r3','r1'], 'fam1', 1 ).
test( 't82', 593, [], [], 'fam1', 1 ).
test( 't83', 183, [], [], 'fam1', 1 ).
test( 't84', 123, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't85', 759, [], [], 'fam1', 1 ).
test( 't86', 157, ['m2','m20','m17'], [], 'fam1', 1 ).
test( 't87', 424, [], ['r1','r3'], 'fam1', 1 ).
test( 't88', 96, [], ['r1','r3'], 'fam1', 1 ).
test( 't89', 133, [], [], 'fam1', 1 ).
test( 't90', 284, [], [], 'fam1', 1 ).
test( 't91', 430, [], [], 'fam1', 1 ).
test( 't92', 96, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't93', 17, [], [], 'fam1', 1 ).
test( 't94', 338, ['m7'], ['r3','r1','r2'], 'fam1', 1 ).
test( 't95', 316, [], [], 'fam1', 1 ).
test( 't96', 554, [], [], 'fam1', 1 ).
test( 't97', 201, ['m16','m6','m15','m17'], [], 'fam1', 1 ).
test( 't98', 780, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't99', 375, [], [], 'fam1', 1 ).
test( 't100', 218, [], ['r1'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
