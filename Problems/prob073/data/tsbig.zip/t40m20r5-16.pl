%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 20
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 209, ['m6','m3','m15'], [], 'fam1', 1 ).
test( 't2', 138, ['m17','m19','m15','m11','m10','m13'], [], 'fam1', 1 ).
test( 't3', 460, [], ['r5','r2','r1','r4'], 'fam1', 1 ).
test( 't4', 430, [], [], 'fam1', 1 ).
test( 't5', 390, [], [], 'fam1', 1 ).
test( 't6', 577, [], ['r2','r1','r4','r5'], 'fam1', 1 ).
test( 't7', 378, [], [], 'fam1', 1 ).
test( 't8', 696, ['m15','m11','m5','m3','m1','m19'], [], 'fam1', 1 ).
test( 't9', 461, ['m7','m1','m17','m8','m9','m13'], [], 'fam1', 1 ).
test( 't10', 800, [], [], 'fam1', 1 ).
test( 't11', 102, [], [], 'fam1', 1 ).
test( 't12', 385, [], [], 'fam1', 1 ).
test( 't13', 555, [], [], 'fam1', 1 ).
test( 't14', 93, [], [], 'fam1', 1 ).
test( 't15', 392, [], [], 'fam1', 1 ).
test( 't16', 704, [], [], 'fam1', 1 ).
test( 't17', 229, [], [], 'fam1', 1 ).
test( 't18', 578, [], ['r1','r5'], 'fam1', 1 ).
test( 't19', 222, [], [], 'fam1', 1 ).
test( 't20', 510, [], [], 'fam1', 1 ).
test( 't21', 742, [], [], 'fam1', 1 ).
test( 't22', 296, ['m4'], ['r4','r5','r2','r1'], 'fam1', 1 ).
test( 't23', 581, ['m17','m18','m6','m12','m8','m16','m20'], [], 'fam1', 1 ).
test( 't24', 362, [], ['r5','r3','r4','r2','r1'], 'fam1', 1 ).
test( 't25', 363, [], [], 'fam1', 1 ).
test( 't26', 649, [], ['r2'], 'fam1', 1 ).
test( 't27', 24, ['m9','m17','m5','m2'], ['r1','r3','r2','r4','r5'], 'fam1', 1 ).
test( 't28', 687, [], ['r1','r3','r5','r2'], 'fam1', 1 ).
test( 't29', 18, [], ['r2'], 'fam1', 1 ).
test( 't30', 312, [], [], 'fam1', 1 ).
test( 't31', 255, [], [], 'fam1', 1 ).
test( 't32', 29, [], [], 'fam1', 1 ).
test( 't33', 741, [], [], 'fam1', 1 ).
test( 't34', 290, [], [], 'fam1', 1 ).
test( 't35', 451, [], [], 'fam1', 1 ).
test( 't36', 713, [], [], 'fam1', 1 ).
test( 't37', 303, [], [], 'fam1', 1 ).
test( 't38', 396, [], [], 'fam1', 1 ).
test( 't39', 689, [], ['r5','r2','r3','r1','r4'], 'fam1', 1 ).
test( 't40', 557, [], ['r1','r5','r2'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
