%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 20
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 97, [], [], 'fam1', 1 ).
test( 't2', 46, [], [], 'fam1', 1 ).
test( 't3', 613, [], [], 'fam1', 1 ).
test( 't4', 712, [], [], 'fam1', 1 ).
test( 't5', 485, [], [], 'fam1', 1 ).
test( 't6', 656, ['m19'], [], 'fam1', 1 ).
test( 't7', 498, [], ['r1','r4','r3'], 'fam1', 1 ).
test( 't8', 302, [], [], 'fam1', 1 ).
test( 't9', 675, [], [], 'fam1', 1 ).
test( 't10', 13, [], [], 'fam1', 1 ).
test( 't11', 427, ['m15','m1','m8','m5','m11'], ['r5','r3','r2'], 'fam1', 1 ).
test( 't12', 741, [], ['r3','r4','r1','r5','r2'], 'fam1', 1 ).
test( 't13', 128, [], [], 'fam1', 1 ).
test( 't14', 769, ['m16','m5','m12'], [], 'fam1', 1 ).
test( 't15', 533, [], [], 'fam1', 1 ).
test( 't16', 625, [], [], 'fam1', 1 ).
test( 't17', 264, [], ['r5','r1','r4'], 'fam1', 1 ).
test( 't18', 18, [], ['r1','r4','r5','r3','r2'], 'fam1', 1 ).
test( 't19', 783, [], ['r2'], 'fam1', 1 ).
test( 't20', 18, ['m17'], [], 'fam1', 1 ).
test( 't21', 428, [], [], 'fam1', 1 ).
test( 't22', 748, [], ['r3','r5','r2'], 'fam1', 1 ).
test( 't23', 786, [], [], 'fam1', 1 ).
test( 't24', 643, [], ['r3','r2','r5','r4'], 'fam1', 1 ).
test( 't25', 492, ['m18','m15','m12','m19','m10','m17','m14'], ['r5','r3'], 'fam1', 1 ).
test( 't26', 162, [], ['r3','r4','r1','r5','r2'], 'fam1', 1 ).
test( 't27', 694, [], ['r1','r2'], 'fam1', 1 ).
test( 't28', 239, [], ['r3','r2','r1','r5'], 'fam1', 1 ).
test( 't29', 730, [], ['r3'], 'fam1', 1 ).
test( 't30', 486, [], [], 'fam1', 1 ).
test( 't31', 742, ['m4','m15','m2','m9'], [], 'fam1', 1 ).
test( 't32', 699, [], [], 'fam1', 1 ).
test( 't33', 464, ['m6','m16'], [], 'fam1', 1 ).
test( 't34', 216, ['m2','m1','m11','m16'], [], 'fam1', 1 ).
test( 't35', 525, ['m20'], ['r4','r2','r1','r3','r5'], 'fam1', 1 ).
test( 't36', 105, [], ['r2'], 'fam1', 1 ).
test( 't37', 587, [], [], 'fam1', 1 ).
test( 't38', 21, ['m2','m20','m6'], [], 'fam1', 1 ).
test( 't39', 579, [], ['r5','r3','r4','r2','r1'], 'fam1', 1 ).
test( 't40', 662, ['m19','m7','m5','m9','m13','m2','m15'], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
