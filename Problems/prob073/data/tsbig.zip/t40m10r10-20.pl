%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 10
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 225, [], [], 'fam1', 1 ).
test( 't2', 690, [], ['r5','r3'], 'fam1', 1 ).
test( 't3', 773, [], [], 'fam1', 1 ).
test( 't4', 637, [], [], 'fam1', 1 ).
test( 't5', 748, [], [], 'fam1', 1 ).
test( 't6', 110, [], ['r7','r9','r10','r8','r5','r4','r1'], 'fam1', 1 ).
test( 't7', 48, ['m9'], [], 'fam1', 1 ).
test( 't8', 476, [], ['r1','r3','r6','r5','r9','r4','r2','r7'], 'fam1', 1 ).
test( 't9', 710, [], [], 'fam1', 1 ).
test( 't10', 705, ['m4','m7'], [], 'fam1', 1 ).
test( 't11', 256, ['m5','m10','m6','m3'], [], 'fam1', 1 ).
test( 't12', 505, [], ['r1','r7','r4','r8','r2','r9'], 'fam1', 1 ).
test( 't13', 634, [], [], 'fam1', 1 ).
test( 't14', 48, [], [], 'fam1', 1 ).
test( 't15', 440, [], [], 'fam1', 1 ).
test( 't16', 75, [], ['r7','r3','r1','r4','r8','r2','r10','r5','r6'], 'fam1', 1 ).
test( 't17', 438, [], [], 'fam1', 1 ).
test( 't18', 223, ['m1'], [], 'fam1', 1 ).
test( 't19', 672, [], [], 'fam1', 1 ).
test( 't20', 645, [], [], 'fam1', 1 ).
test( 't21', 271, [], [], 'fam1', 1 ).
test( 't22', 665, [], [], 'fam1', 1 ).
test( 't23', 752, [], [], 'fam1', 1 ).
test( 't24', 521, [], ['r3','r9','r1'], 'fam1', 1 ).
test( 't25', 158, [], [], 'fam1', 1 ).
test( 't26', 473, ['m4'], [], 'fam1', 1 ).
test( 't27', 557, [], [], 'fam1', 1 ).
test( 't28', 11, [], [], 'fam1', 1 ).
test( 't29', 527, ['m1','m9'], [], 'fam1', 1 ).
test( 't30', 605, [], [], 'fam1', 1 ).
test( 't31', 341, [], [], 'fam1', 1 ).
test( 't32', 98, [], ['r8','r2','r5','r9','r3','r4'], 'fam1', 1 ).
test( 't33', 96, [], [], 'fam1', 1 ).
test( 't34', 503, [], ['r5','r9','r10','r2','r1','r7','r4','r8'], 'fam1', 1 ).
test( 't35', 703, [], [], 'fam1', 1 ).
test( 't36', 657, [], [], 'fam1', 1 ).
test( 't37', 168, [], ['r9','r5','r1','r2','r6','r10','r8'], 'fam1', 1 ).
test( 't38', 89, [], ['r10','r8','r3','r5','r9','r2','r1','r6','r7','r4'], 'fam1', 1 ).
test( 't39', 708, [], [], 'fam1', 1 ).
test( 't40', 767, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
