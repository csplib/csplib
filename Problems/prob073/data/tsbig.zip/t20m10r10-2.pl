%% ****  Testsuite  ****
% Number of tests                  : 20
% Number of machines               : 10
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 72, [], [], 'fam1', 1 ).
test( 't2', 662, [], [], 'fam1', 1 ).
test( 't3', 282, [], ['r3','r4','r2','r7','r10','r5','r6','r8'], 'fam1', 1 ).
test( 't4', 493, [], ['r5','r2','r9','r4','r7','r6','r10'], 'fam1', 1 ).
test( 't5', 87, [], [], 'fam1', 1 ).
test( 't6', 273, [], [], 'fam1', 1 ).
test( 't7', 329, [], [], 'fam1', 1 ).
test( 't8', 542, [], ['r3','r4','r7','r2'], 'fam1', 1 ).
test( 't9', 249, ['m2','m3','m8','m6'], [], 'fam1', 1 ).
test( 't10', 203, [], [], 'fam1', 1 ).
test( 't11', 469, ['m4','m7'], ['r5','r8','r6','r2','r4','r10','r7','r1','r3'], 'fam1', 1 ).
test( 't12', 33, [], ['r6','r8','r2','r10','r3','r4','r7','r1','r5'], 'fam1', 1 ).
test( 't13', 587, [], [], 'fam1', 1 ).
test( 't14', 76, ['m1','m3','m4','m5'], [], 'fam1', 1 ).
test( 't15', 472, [], [], 'fam1', 1 ).
test( 't16', 290, [], [], 'fam1', 1 ).
test( 't17', 266, [], [], 'fam1', 1 ).
test( 't18', 750, [], [], 'fam1', 1 ).
test( 't19', 528, [], [], 'fam1', 1 ).
test( 't20', 28, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
