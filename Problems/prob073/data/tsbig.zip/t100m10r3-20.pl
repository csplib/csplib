%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 607, ['m10','m5','m9'], [], 'fam1', 1 ).
test( 't2', 669, [], [], 'fam1', 1 ).
test( 't3', 68, ['m9','m5'], [], 'fam1', 1 ).
test( 't4', 127, [], [], 'fam1', 1 ).
test( 't5', 455, [], [], 'fam1', 1 ).
test( 't6', 442, ['m8','m6','m10'], ['r1','r3','r2'], 'fam1', 1 ).
test( 't7', 379, [], [], 'fam1', 1 ).
test( 't8', 200, [], [], 'fam1', 1 ).
test( 't9', 692, [], [], 'fam1', 1 ).
test( 't10', 38, ['m2','m8','m7'], [], 'fam1', 1 ).
test( 't11', 798, [], [], 'fam1', 1 ).
test( 't12', 459, [], [], 'fam1', 1 ).
test( 't13', 66, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't14', 87, ['m4','m7','m5','m9'], [], 'fam1', 1 ).
test( 't15', 89, ['m7'], [], 'fam1', 1 ).
test( 't16', 292, [], [], 'fam1', 1 ).
test( 't17', 308, [], [], 'fam1', 1 ).
test( 't18', 131, [], [], 'fam1', 1 ).
test( 't19', 613, [], [], 'fam1', 1 ).
test( 't20', 591, [], ['r2'], 'fam1', 1 ).
test( 't21', 671, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't22', 544, [], [], 'fam1', 1 ).
test( 't23', 794, [], [], 'fam1', 1 ).
test( 't24', 600, [], [], 'fam1', 1 ).
test( 't25', 223, [], [], 'fam1', 1 ).
test( 't26', 547, [], [], 'fam1', 1 ).
test( 't27', 404, [], ['r3','r1'], 'fam1', 1 ).
test( 't28', 579, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't29', 612, [], [], 'fam1', 1 ).
test( 't30', 570, ['m6','m9','m8','m5'], ['r1'], 'fam1', 1 ).
test( 't31', 730, ['m3','m2','m10','m9'], [], 'fam1', 1 ).
test( 't32', 67, [], [], 'fam1', 1 ).
test( 't33', 178, [], [], 'fam1', 1 ).
test( 't34', 138, [], [], 'fam1', 1 ).
test( 't35', 5, [], [], 'fam1', 1 ).
test( 't36', 554, ['m8','m10','m4','m9'], ['r3'], 'fam1', 1 ).
test( 't37', 620, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't38', 519, ['m7','m8','m2','m10'], ['r1'], 'fam1', 1 ).
test( 't39', 91, [], ['r1'], 'fam1', 1 ).
test( 't40', 496, ['m8'], [], 'fam1', 1 ).
test( 't41', 113, [], [], 'fam1', 1 ).
test( 't42', 169, [], [], 'fam1', 1 ).
test( 't43', 350, [], [], 'fam1', 1 ).
test( 't44', 684, [], [], 'fam1', 1 ).
test( 't45', 601, [], ['r1'], 'fam1', 1 ).
test( 't46', 226, [], [], 'fam1', 1 ).
test( 't47', 13, [], [], 'fam1', 1 ).
test( 't48', 131, [], [], 'fam1', 1 ).
test( 't49', 483, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't50', 671, [], [], 'fam1', 1 ).
test( 't51', 728, ['m8','m5'], ['r2','r1','r3'], 'fam1', 1 ).
test( 't52', 694, [], [], 'fam1', 1 ).
test( 't53', 465, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't54', 579, [], [], 'fam1', 1 ).
test( 't55', 83, ['m8','m6','m4'], [], 'fam1', 1 ).
test( 't56', 389, [], [], 'fam1', 1 ).
test( 't57', 373, [], [], 'fam1', 1 ).
test( 't58', 104, [], [], 'fam1', 1 ).
test( 't59', 559, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't60', 124, [], [], 'fam1', 1 ).
test( 't61', 521, [], [], 'fam1', 1 ).
test( 't62', 99, [], [], 'fam1', 1 ).
test( 't63', 157, [], [], 'fam1', 1 ).
test( 't64', 236, [], [], 'fam1', 1 ).
test( 't65', 673, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't66', 631, [], [], 'fam1', 1 ).
test( 't67', 270, [], [], 'fam1', 1 ).
test( 't68', 513, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't69', 36, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't70', 738, [], [], 'fam1', 1 ).
test( 't71', 255, ['m4','m5'], [], 'fam1', 1 ).
test( 't72', 581, [], [], 'fam1', 1 ).
test( 't73', 561, ['m3'], [], 'fam1', 1 ).
test( 't74', 592, [], [], 'fam1', 1 ).
test( 't75', 145, [], ['r1','r2'], 'fam1', 1 ).
test( 't76', 83, [], ['r1','r2'], 'fam1', 1 ).
test( 't77', 694, ['m7','m6','m10'], [], 'fam1', 1 ).
test( 't78', 217, [], [], 'fam1', 1 ).
test( 't79', 589, ['m10','m5','m8'], [], 'fam1', 1 ).
test( 't80', 385, [], [], 'fam1', 1 ).
test( 't81', 772, [], [], 'fam1', 1 ).
test( 't82', 221, [], [], 'fam1', 1 ).
test( 't83', 285, ['m3','m5','m9'], [], 'fam1', 1 ).
test( 't84', 368, [], [], 'fam1', 1 ).
test( 't85', 493, [], [], 'fam1', 1 ).
test( 't86', 715, [], [], 'fam1', 1 ).
test( 't87', 8, [], [], 'fam1', 1 ).
test( 't88', 415, [], [], 'fam1', 1 ).
test( 't89', 340, [], [], 'fam1', 1 ).
test( 't90', 114, [], [], 'fam1', 1 ).
test( 't91', 753, [], [], 'fam1', 1 ).
test( 't92', 291, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't93', 330, [], [], 'fam1', 1 ).
test( 't94', 402, ['m2','m8'], [], 'fam1', 1 ).
test( 't95', 265, [], [], 'fam1', 1 ).
test( 't96', 189, [], [], 'fam1', 1 ).
test( 't97', 369, ['m1','m5','m2'], ['r1','r3','r2'], 'fam1', 1 ).
test( 't98', 117, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't99', 317, [], [], 'fam1', 1 ).
test( 't100', 219, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
