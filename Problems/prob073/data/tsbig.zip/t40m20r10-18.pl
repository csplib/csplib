%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 20
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 486, ['m12','m19','m11','m1','m2','m3'], [], 'fam1', 1 ).
test( 't2', 513, [], ['r6'], 'fam1', 1 ).
test( 't3', 706, [], [], 'fam1', 1 ).
test( 't4', 115, [], [], 'fam1', 1 ).
test( 't5', 5, [], [], 'fam1', 1 ).
test( 't6', 86, [], [], 'fam1', 1 ).
test( 't7', 576, ['m16','m3','m14','m5','m9','m10'], ['r3'], 'fam1', 1 ).
test( 't8', 201, ['m5','m15','m8','m18','m7'], [], 'fam1', 1 ).
test( 't9', 5, ['m2','m6'], [], 'fam1', 1 ).
test( 't10', 620, [], [], 'fam1', 1 ).
test( 't11', 324, ['m6','m1'], ['r6','r2','r3','r5','r7','r10'], 'fam1', 1 ).
test( 't12', 298, [], [], 'fam1', 1 ).
test( 't13', 696, [], [], 'fam1', 1 ).
test( 't14', 425, ['m4','m2','m15','m19','m12'], [], 'fam1', 1 ).
test( 't15', 21, [], ['r9','r8','r1','r5','r7','r3','r6','r4'], 'fam1', 1 ).
test( 't16', 273, [], [], 'fam1', 1 ).
test( 't17', 130, [], [], 'fam1', 1 ).
test( 't18', 786, ['m7'], [], 'fam1', 1 ).
test( 't19', 174, [], [], 'fam1', 1 ).
test( 't20', 31, ['m15','m2','m18','m3','m19','m12','m8'], ['r1','r9','r10','r5','r8','r3'], 'fam1', 1 ).
test( 't21', 323, [], [], 'fam1', 1 ).
test( 't22', 435, [], [], 'fam1', 1 ).
test( 't23', 89, [], ['r1','r3','r6'], 'fam1', 1 ).
test( 't24', 225, ['m7','m8','m4','m17','m12','m1','m20','m9'], [], 'fam1', 1 ).
test( 't25', 95, [], [], 'fam1', 1 ).
test( 't26', 153, [], [], 'fam1', 1 ).
test( 't27', 426, [], [], 'fam1', 1 ).
test( 't28', 718, [], [], 'fam1', 1 ).
test( 't29', 86, [], [], 'fam1', 1 ).
test( 't30', 660, ['m15','m16','m2'], ['r7','r5','r1'], 'fam1', 1 ).
test( 't31', 608, [], [], 'fam1', 1 ).
test( 't32', 333, [], ['r1','r10'], 'fam1', 1 ).
test( 't33', 528, [], [], 'fam1', 1 ).
test( 't34', 676, [], ['r3','r10','r6','r5'], 'fam1', 1 ).
test( 't35', 459, [], [], 'fam1', 1 ).
test( 't36', 742, ['m13','m7'], ['r4','r9','r6','r5','r3','r1'], 'fam1', 1 ).
test( 't37', 735, [], ['r7','r3','r8','r1'], 'fam1', 1 ).
test( 't38', 222, [], [], 'fam1', 1 ).
test( 't39', 603, [], [], 'fam1', 1 ).
test( 't40', 268, ['m17','m6'], ['r7','r4','r8','r2'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
