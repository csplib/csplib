%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 20
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 456, [], [], 'fam1', 1 ).
test( 't2', 57, [], [], 'fam1', 1 ).
test( 't3', 248, [], ['r6','r1','r2','r7','r5'], 'fam1', 1 ).
test( 't4', 373, [], [], 'fam1', 1 ).
test( 't5', 517, [], [], 'fam1', 1 ).
test( 't6', 17, [], [], 'fam1', 1 ).
test( 't7', 558, [], ['r2','r9','r6','r1','r4','r7','r3','r5','r8','r10'], 'fam1', 1 ).
test( 't8', 535, [], [], 'fam1', 1 ).
test( 't9', 140, ['m1','m15','m19'], [], 'fam1', 1 ).
test( 't10', 407, [], [], 'fam1', 1 ).
test( 't11', 434, [], ['r9','r6','r8','r4','r2','r1','r5','r10','r7','r3'], 'fam1', 1 ).
test( 't12', 674, [], ['r7','r6','r10','r2','r4','r8'], 'fam1', 1 ).
test( 't13', 399, [], [], 'fam1', 1 ).
test( 't14', 298, [], [], 'fam1', 1 ).
test( 't15', 471, [], [], 'fam1', 1 ).
test( 't16', 387, [], [], 'fam1', 1 ).
test( 't17', 801, [], [], 'fam1', 1 ).
test( 't18', 775, [], [], 'fam1', 1 ).
test( 't19', 166, [], [], 'fam1', 1 ).
test( 't20', 649, [], [], 'fam1', 1 ).
test( 't21', 18, [], ['r3','r10'], 'fam1', 1 ).
test( 't22', 250, [], ['r5','r9','r10','r4','r7','r8','r3'], 'fam1', 1 ).
test( 't23', 587, [], [], 'fam1', 1 ).
test( 't24', 597, [], ['r10','r9'], 'fam1', 1 ).
test( 't25', 604, [], [], 'fam1', 1 ).
test( 't26', 260, [], [], 'fam1', 1 ).
test( 't27', 457, [], ['r8','r1','r4','r9','r2','r6','r3','r5'], 'fam1', 1 ).
test( 't28', 158, [], [], 'fam1', 1 ).
test( 't29', 770, [], [], 'fam1', 1 ).
test( 't30', 378, [], ['r1','r7','r5','r9','r4','r8','r10','r3','r6','r2'], 'fam1', 1 ).
test( 't31', 609, [], [], 'fam1', 1 ).
test( 't32', 550, [], [], 'fam1', 1 ).
test( 't33', 219, [], [], 'fam1', 1 ).
test( 't34', 273, [], [], 'fam1', 1 ).
test( 't35', 367, ['m2','m13'], [], 'fam1', 1 ).
test( 't36', 207, ['m6','m11'], ['r5','r8','r10','r3','r6','r9','r7','r2','r1'], 'fam1', 1 ).
test( 't37', 143, [], [], 'fam1', 1 ).
test( 't38', 406, [], [], 'fam1', 1 ).
test( 't39', 369, [], ['r8','r7','r4','r9'], 'fam1', 1 ).
test( 't40', 82, ['m9','m3','m5','m14','m17','m8'], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
