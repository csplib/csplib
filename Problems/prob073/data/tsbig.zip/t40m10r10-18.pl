%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 10
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 47, [], [], 'fam1', 1 ).
test( 't2', 365, [], ['r2','r8','r9','r3','r7','r10','r5','r4'], 'fam1', 1 ).
test( 't3', 660, [], [], 'fam1', 1 ).
test( 't4', 115, ['m2','m7','m3'], [], 'fam1', 1 ).
test( 't5', 183, [], [], 'fam1', 1 ).
test( 't6', 716, [], [], 'fam1', 1 ).
test( 't7', 263, ['m8','m5','m1'], [], 'fam1', 1 ).
test( 't8', 273, [], [], 'fam1', 1 ).
test( 't9', 3, [], [], 'fam1', 1 ).
test( 't10', 692, [], [], 'fam1', 1 ).
test( 't11', 209, ['m7','m8','m4','m2'], [], 'fam1', 1 ).
test( 't12', 599, [], [], 'fam1', 1 ).
test( 't13', 745, [], [], 'fam1', 1 ).
test( 't14', 716, [], [], 'fam1', 1 ).
test( 't15', 364, [], [], 'fam1', 1 ).
test( 't16', 779, [], ['r3','r8','r7','r5','r1','r10','r6'], 'fam1', 1 ).
test( 't17', 318, [], [], 'fam1', 1 ).
test( 't18', 482, [], [], 'fam1', 1 ).
test( 't19', 226, [], [], 'fam1', 1 ).
test( 't20', 601, ['m7','m8'], [], 'fam1', 1 ).
test( 't21', 436, [], [], 'fam1', 1 ).
test( 't22', 559, [], ['r8','r3','r9','r4','r10','r7','r5','r6','r2','r1'], 'fam1', 1 ).
test( 't23', 54, [], ['r7'], 'fam1', 1 ).
test( 't24', 748, [], ['r10','r9','r4','r1','r8','r5','r3','r6'], 'fam1', 1 ).
test( 't25', 47, [], [], 'fam1', 1 ).
test( 't26', 800, [], [], 'fam1', 1 ).
test( 't27', 308, [], [], 'fam1', 1 ).
test( 't28', 538, [], [], 'fam1', 1 ).
test( 't29', 572, ['m9','m1','m5','m8'], ['r7','r10','r6','r5','r4','r1','r9','r2','r8','r3'], 'fam1', 1 ).
test( 't30', 742, [], ['r3','r10','r8','r2','r4','r7','r5','r1','r6','r9'], 'fam1', 1 ).
test( 't31', 39, ['m7'], ['r6'], 'fam1', 1 ).
test( 't32', 764, [], [], 'fam1', 1 ).
test( 't33', 49, [], [], 'fam1', 1 ).
test( 't34', 356, [], ['r1'], 'fam1', 1 ).
test( 't35', 675, ['m9','m5'], [], 'fam1', 1 ).
test( 't36', 783, ['m6','m3'], [], 'fam1', 1 ).
test( 't37', 125, [], [], 'fam1', 1 ).
test( 't38', 778, [], ['r6','r2','r3','r7','r8','r4','r5'], 'fam1', 1 ).
test( 't39', 189, [], [], 'fam1', 1 ).
test( 't40', 430, [], ['r6','r10','r9','r4','r7','r8'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
