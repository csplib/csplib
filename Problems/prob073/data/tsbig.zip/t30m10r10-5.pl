%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 10
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 348, [], [], 'fam1', 1 ).
test( 't2', 609, [], [], 'fam1', 1 ).
test( 't3', 132, [], [], 'fam1', 1 ).
test( 't4', 799, [], [], 'fam1', 1 ).
test( 't5', 90, ['m1'], [], 'fam1', 1 ).
test( 't6', 530, [], [], 'fam1', 1 ).
test( 't7', 385, [], [], 'fam1', 1 ).
test( 't8', 686, [], ['r4','r6','r5','r7','r2','r8','r10'], 'fam1', 1 ).
test( 't9', 239, [], [], 'fam1', 1 ).
test( 't10', 58, [], ['r8','r9','r1','r3','r10','r4','r6','r7'], 'fam1', 1 ).
test( 't11', 546, [], [], 'fam1', 1 ).
test( 't12', 577, [], [], 'fam1', 1 ).
test( 't13', 360, [], ['r8','r6','r2','r4'], 'fam1', 1 ).
test( 't14', 530, [], ['r10','r8','r5','r2','r3','r9','r4','r6'], 'fam1', 1 ).
test( 't15', 60, [], [], 'fam1', 1 ).
test( 't16', 419, [], [], 'fam1', 1 ).
test( 't17', 731, ['m3','m1','m9','m2'], [], 'fam1', 1 ).
test( 't18', 423, [], [], 'fam1', 1 ).
test( 't19', 714, [], [], 'fam1', 1 ).
test( 't20', 223, ['m1','m6','m4'], [], 'fam1', 1 ).
test( 't21', 292, [], [], 'fam1', 1 ).
test( 't22', 656, [], [], 'fam1', 1 ).
test( 't23', 2, [], ['r5','r4','r7','r8','r9','r10'], 'fam1', 1 ).
test( 't24', 300, [], ['r4','r8','r5','r9','r7','r6','r3','r2','r1','r10'], 'fam1', 1 ).
test( 't25', 544, [], ['r1'], 'fam1', 1 ).
test( 't26', 338, [], [], 'fam1', 1 ).
test( 't27', 490, [], [], 'fam1', 1 ).
test( 't28', 655, [], ['r4','r10','r3','r9','r6','r2','r8','r1','r5'], 'fam1', 1 ).
test( 't29', 194, ['m3','m8','m7'], ['r9','r8','r4'], 'fam1', 1 ).
test( 't30', 337, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
