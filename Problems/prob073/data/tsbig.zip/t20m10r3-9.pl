%% ****  Testsuite  ****
% Number of tests                  : 20
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 291, ['m4','m2','m5'], [], 'fam1', 1 ).
test( 't2', 76, [], [], 'fam1', 1 ).
test( 't3', 565, [], ['r3','r2'], 'fam1', 1 ).
test( 't4', 259, [], [], 'fam1', 1 ).
test( 't5', 300, ['m10','m6','m1','m8'], ['r3'], 'fam1', 1 ).
test( 't6', 753, [], ['r3','r2'], 'fam1', 1 ).
test( 't7', 465, [], [], 'fam1', 1 ).
test( 't8', 501, [], [], 'fam1', 1 ).
test( 't9', 152, [], ['r1','r3'], 'fam1', 1 ).
test( 't10', 451, [], [], 'fam1', 1 ).
test( 't11', 200, [], [], 'fam1', 1 ).
test( 't12', 267, [], [], 'fam1', 1 ).
test( 't13', 332, [], ['r1','r2'], 'fam1', 1 ).
test( 't14', 615, ['m2','m5','m9'], ['r3','r2','r1'], 'fam1', 1 ).
test( 't15', 365, ['m6'], ['r3'], 'fam1', 1 ).
test( 't16', 116, ['m10','m9','m1','m5'], [], 'fam1', 1 ).
test( 't17', 748, [], [], 'fam1', 1 ).
test( 't18', 186, ['m9','m2'], [], 'fam1', 1 ).
test( 't19', 408, [], [], 'fam1', 1 ).
test( 't20', 124, [], ['r1','r3','r2'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
