%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 20
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 298, [], [], 'fam1', 1 ).
test( 't2', 613, [], [], 'fam1', 1 ).
test( 't3', 789, [], ['r2','r1'], 'fam1', 1 ).
test( 't4', 258, [], [], 'fam1', 1 ).
test( 't5', 369, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't6', 251, [], ['r2','r1'], 'fam1', 1 ).
test( 't7', 582, [], [], 'fam1', 1 ).
test( 't8', 753, [], ['r3','r2'], 'fam1', 1 ).
test( 't9', 598, [], [], 'fam1', 1 ).
test( 't10', 563, [], [], 'fam1', 1 ).
test( 't11', 658, [], [], 'fam1', 1 ).
test( 't12', 182, ['m6','m17','m18','m10','m9','m2','m12'], ['r3','r1','r2'], 'fam1', 1 ).
test( 't13', 440, [], [], 'fam1', 1 ).
test( 't14', 772, [], ['r3','r2'], 'fam1', 1 ).
test( 't15', 297, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't16', 508, [], [], 'fam1', 1 ).
test( 't17', 483, [], [], 'fam1', 1 ).
test( 't18', 62, [], ['r3'], 'fam1', 1 ).
test( 't19', 694, [], [], 'fam1', 1 ).
test( 't20', 318, [], [], 'fam1', 1 ).
test( 't21', 263, ['m16','m17','m14','m8','m15','m2','m1'], [], 'fam1', 1 ).
test( 't22', 22, [], [], 'fam1', 1 ).
test( 't23', 230, ['m7'], [], 'fam1', 1 ).
test( 't24', 696, [], ['r1','r2'], 'fam1', 1 ).
test( 't25', 31, ['m19','m13','m2','m18','m10','m11','m14','m8'], [], 'fam1', 1 ).
test( 't26', 96, [], ['r1'], 'fam1', 1 ).
test( 't27', 235, [], [], 'fam1', 1 ).
test( 't28', 739, [], [], 'fam1', 1 ).
test( 't29', 241, ['m14','m12','m8','m17','m4'], [], 'fam1', 1 ).
test( 't30', 364, [], ['r3','r2'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
