%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 20
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 755, [], [], 'fam1', 1 ).
test( 't2', 788, ['m14','m1','m6'], ['r2'], 'fam1', 1 ).
test( 't3', 679, [], ['r3','r2'], 'fam1', 1 ).
test( 't4', 342, [], ['r1'], 'fam1', 1 ).
test( 't5', 47, [], [], 'fam1', 1 ).
test( 't6', 769, [], [], 'fam1', 1 ).
test( 't7', 91, [], [], 'fam1', 1 ).
test( 't8', 391, [], ['r3'], 'fam1', 1 ).
test( 't9', 20, [], [], 'fam1', 1 ).
test( 't10', 6, [], [], 'fam1', 1 ).
test( 't11', 753, ['m16','m3','m7','m10','m1','m12'], [], 'fam1', 1 ).
test( 't12', 335, [], [], 'fam1', 1 ).
test( 't13', 67, [], [], 'fam1', 1 ).
test( 't14', 175, ['m12','m1'], [], 'fam1', 1 ).
test( 't15', 66, [], ['r3','r1'], 'fam1', 1 ).
test( 't16', 747, [], [], 'fam1', 1 ).
test( 't17', 266, [], ['r3'], 'fam1', 1 ).
test( 't18', 686, [], [], 'fam1', 1 ).
test( 't19', 522, [], ['r1'], 'fam1', 1 ).
test( 't20', 290, [], [], 'fam1', 1 ).
test( 't21', 606, [], [], 'fam1', 1 ).
test( 't22', 2, [], [], 'fam1', 1 ).
test( 't23', 302, [], [], 'fam1', 1 ).
test( 't24', 358, [], ['r3','r1'], 'fam1', 1 ).
test( 't25', 610, [], ['r2','r3'], 'fam1', 1 ).
test( 't26', 66, [], [], 'fam1', 1 ).
test( 't27', 732, [], ['r1'], 'fam1', 1 ).
test( 't28', 592, [], [], 'fam1', 1 ).
test( 't29', 219, [], [], 'fam1', 1 ).
test( 't30', 619, [], [], 'fam1', 1 ).
test( 't31', 590, [], [], 'fam1', 1 ).
test( 't32', 259, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't33', 580, ['m20','m2','m10','m18','m13','m4','m5','m7'], [], 'fam1', 1 ).
test( 't34', 332, ['m8','m15','m12','m10','m19','m4','m6','m11'], [], 'fam1', 1 ).
test( 't35', 568, [], [], 'fam1', 1 ).
test( 't36', 619, [], [], 'fam1', 1 ).
test( 't37', 31, ['m8','m19','m15','m7','m5','m11'], [], 'fam1', 1 ).
test( 't38', 731, [], [], 'fam1', 1 ).
test( 't39', 101, ['m20','m8'], [], 'fam1', 1 ).
test( 't40', 481, ['m19','m7','m20','m12'], ['r1','r3','r2'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
