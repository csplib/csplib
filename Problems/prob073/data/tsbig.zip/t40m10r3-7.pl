%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 552, [], [], 'fam1', 1 ).
test( 't2', 353, [], [], 'fam1', 1 ).
test( 't3', 144, [], ['r3','r1'], 'fam1', 1 ).
test( 't4', 341, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't5', 95, [], [], 'fam1', 1 ).
test( 't6', 668, ['m9','m3','m6'], [], 'fam1', 1 ).
test( 't7', 468, [], [], 'fam1', 1 ).
test( 't8', 5, [], [], 'fam1', 1 ).
test( 't9', 9, ['m3'], [], 'fam1', 1 ).
test( 't10', 554, [], ['r1','r2'], 'fam1', 1 ).
test( 't11', 519, ['m9','m10'], [], 'fam1', 1 ).
test( 't12', 565, [], [], 'fam1', 1 ).
test( 't13', 669, [], ['r2','r1'], 'fam1', 1 ).
test( 't14', 233, [], [], 'fam1', 1 ).
test( 't15', 89, [], [], 'fam1', 1 ).
test( 't16', 436, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't17', 59, [], [], 'fam1', 1 ).
test( 't18', 684, [], ['r3','r1'], 'fam1', 1 ).
test( 't19', 635, [], [], 'fam1', 1 ).
test( 't20', 549, [], [], 'fam1', 1 ).
test( 't21', 423, [], ['r2','r1'], 'fam1', 1 ).
test( 't22', 24, [], [], 'fam1', 1 ).
test( 't23', 23, [], [], 'fam1', 1 ).
test( 't24', 739, [], [], 'fam1', 1 ).
test( 't25', 191, [], [], 'fam1', 1 ).
test( 't26', 303, ['m9','m1','m7'], [], 'fam1', 1 ).
test( 't27', 507, [], ['r1','r2'], 'fam1', 1 ).
test( 't28', 707, [], ['r1','r2'], 'fam1', 1 ).
test( 't29', 481, [], [], 'fam1', 1 ).
test( 't30', 189, [], ['r3','r2'], 'fam1', 1 ).
test( 't31', 293, [], [], 'fam1', 1 ).
test( 't32', 324, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't33', 450, [], [], 'fam1', 1 ).
test( 't34', 672, [], [], 'fam1', 1 ).
test( 't35', 399, [], ['r1','r2'], 'fam1', 1 ).
test( 't36', 614, ['m6','m8'], [], 'fam1', 1 ).
test( 't37', 733, ['m9','m8'], [], 'fam1', 1 ).
test( 't38', 249, [], [], 'fam1', 1 ).
test( 't39', 168, [], ['r3','r2'], 'fam1', 1 ).
test( 't40', 56, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
