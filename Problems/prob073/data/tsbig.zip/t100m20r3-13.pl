%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 20
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 714, [], ['r1','r2'], 'fam1', 1 ).
test( 't2', 230, [], ['r1'], 'fam1', 1 ).
test( 't3', 548, [], [], 'fam1', 1 ).
test( 't4', 793, [], [], 'fam1', 1 ).
test( 't5', 553, ['m18','m11'], ['r3','r1','r2'], 'fam1', 1 ).
test( 't6', 199, [], [], 'fam1', 1 ).
test( 't7', 334, [], [], 'fam1', 1 ).
test( 't8', 727, [], [], 'fam1', 1 ).
test( 't9', 733, ['m12','m3','m16','m1'], [], 'fam1', 1 ).
test( 't10', 381, ['m12','m18','m20','m15','m4','m9','m7','m19'], ['r2'], 'fam1', 1 ).
test( 't11', 521, [], [], 'fam1', 1 ).
test( 't12', 258, ['m11','m3','m20','m16','m17','m5','m1','m14'], [], 'fam1', 1 ).
test( 't13', 613, [], [], 'fam1', 1 ).
test( 't14', 621, [], [], 'fam1', 1 ).
test( 't15', 352, [], ['r3','r2'], 'fam1', 1 ).
test( 't16', 197, [], [], 'fam1', 1 ).
test( 't17', 548, ['m20','m5'], [], 'fam1', 1 ).
test( 't18', 244, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't19', 736, ['m2','m4','m9','m14','m5','m12','m20','m11'], [], 'fam1', 1 ).
test( 't20', 332, [], ['r1','r3'], 'fam1', 1 ).
test( 't21', 672, [], [], 'fam1', 1 ).
test( 't22', 398, [], [], 'fam1', 1 ).
test( 't23', 364, [], ['r1'], 'fam1', 1 ).
test( 't24', 592, [], [], 'fam1', 1 ).
test( 't25', 490, [], ['r1','r3'], 'fam1', 1 ).
test( 't26', 121, [], ['r3'], 'fam1', 1 ).
test( 't27', 489, [], [], 'fam1', 1 ).
test( 't28', 90, ['m3','m15','m5','m17','m11','m9','m7','m18'], [], 'fam1', 1 ).
test( 't29', 393, ['m12','m7','m19','m15','m11','m5','m4'], ['r3'], 'fam1', 1 ).
test( 't30', 510, [], [], 'fam1', 1 ).
test( 't31', 468, [], ['r2','r1'], 'fam1', 1 ).
test( 't32', 310, [], [], 'fam1', 1 ).
test( 't33', 512, [], [], 'fam1', 1 ).
test( 't34', 34, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't35', 310, ['m18','m9','m11','m20','m7','m6'], ['r3','r2','r1'], 'fam1', 1 ).
test( 't36', 8, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't37', 385, ['m19'], ['r2','r1','r3'], 'fam1', 1 ).
test( 't38', 31, ['m20','m11','m9','m2','m3','m15','m12','m14'], [], 'fam1', 1 ).
test( 't39', 659, ['m20','m9','m10','m17','m14','m8'], [], 'fam1', 1 ).
test( 't40', 324, [], ['r2'], 'fam1', 1 ).
test( 't41', 589, [], [], 'fam1', 1 ).
test( 't42', 17, [], ['r1'], 'fam1', 1 ).
test( 't43', 63, [], ['r2'], 'fam1', 1 ).
test( 't44', 366, ['m12','m15','m14','m11'], [], 'fam1', 1 ).
test( 't45', 712, ['m20','m2'], [], 'fam1', 1 ).
test( 't46', 57, [], [], 'fam1', 1 ).
test( 't47', 663, [], [], 'fam1', 1 ).
test( 't48', 641, ['m3','m1','m17','m12','m16','m15','m10'], [], 'fam1', 1 ).
test( 't49', 562, ['m17','m11'], [], 'fam1', 1 ).
test( 't50', 335, ['m3'], [], 'fam1', 1 ).
test( 't51', 726, [], ['r3','r2'], 'fam1', 1 ).
test( 't52', 687, [], ['r1','r3'], 'fam1', 1 ).
test( 't53', 184, [], [], 'fam1', 1 ).
test( 't54', 740, [], [], 'fam1', 1 ).
test( 't55', 737, [], ['r2','r3'], 'fam1', 1 ).
test( 't56', 4, [], ['r1','r3'], 'fam1', 1 ).
test( 't57', 7, [], [], 'fam1', 1 ).
test( 't58', 527, [], [], 'fam1', 1 ).
test( 't59', 233, ['m14','m10','m1','m2','m11','m8','m16'], [], 'fam1', 1 ).
test( 't60', 62, [], [], 'fam1', 1 ).
test( 't61', 796, [], ['r1','r2'], 'fam1', 1 ).
test( 't62', 480, [], ['r3','r2'], 'fam1', 1 ).
test( 't63', 636, [], [], 'fam1', 1 ).
test( 't64', 40, [], [], 'fam1', 1 ).
test( 't65', 351, [], [], 'fam1', 1 ).
test( 't66', 369, [], [], 'fam1', 1 ).
test( 't67', 216, [], [], 'fam1', 1 ).
test( 't68', 141, [], ['r1','r3'], 'fam1', 1 ).
test( 't69', 656, [], [], 'fam1', 1 ).
test( 't70', 583, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't71', 368, [], [], 'fam1', 1 ).
test( 't72', 43, [], ['r3'], 'fam1', 1 ).
test( 't73', 481, [], [], 'fam1', 1 ).
test( 't74', 536, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't75', 758, [], [], 'fam1', 1 ).
test( 't76', 160, [], [], 'fam1', 1 ).
test( 't77', 558, [], ['r2','r1'], 'fam1', 1 ).
test( 't78', 336, [], [], 'fam1', 1 ).
test( 't79', 431, [], ['r3'], 'fam1', 1 ).
test( 't80', 353, [], [], 'fam1', 1 ).
test( 't81', 367, [], [], 'fam1', 1 ).
test( 't82', 455, [], [], 'fam1', 1 ).
test( 't83', 552, ['m17'], ['r3','r1'], 'fam1', 1 ).
test( 't84', 397, [], [], 'fam1', 1 ).
test( 't85', 210, [], [], 'fam1', 1 ).
test( 't86', 74, [], [], 'fam1', 1 ).
test( 't87', 696, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't88', 325, [], [], 'fam1', 1 ).
test( 't89', 6, [], [], 'fam1', 1 ).
test( 't90', 313, [], [], 'fam1', 1 ).
test( 't91', 156, [], [], 'fam1', 1 ).
test( 't92', 397, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't93', 322, [], [], 'fam1', 1 ).
test( 't94', 468, ['m20','m7'], [], 'fam1', 1 ).
test( 't95', 791, [], [], 'fam1', 1 ).
test( 't96', 629, ['m18','m16','m17'], ['r3','r2','r1'], 'fam1', 1 ).
test( 't97', 518, [], [], 'fam1', 1 ).
test( 't98', 469, ['m15','m13','m8','m19'], [], 'fam1', 1 ).
test( 't99', 620, [], [], 'fam1', 1 ).
test( 't100', 188, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
