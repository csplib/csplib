%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 589, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't2', 622, ['m10','m4','m8'], ['r3','r2','r1'], 'fam1', 1 ).
test( 't3', 291, [], [], 'fam1', 1 ).
test( 't4', 226, ['m10'], [], 'fam1', 1 ).
test( 't5', 419, [], [], 'fam1', 1 ).
test( 't6', 211, [], [], 'fam1', 1 ).
test( 't7', 35, ['m6','m5','m9','m1'], ['r3','r2','r1'], 'fam1', 1 ).
test( 't8', 388, [], ['r1','r2'], 'fam1', 1 ).
test( 't9', 331, [], [], 'fam1', 1 ).
test( 't10', 242, [], [], 'fam1', 1 ).
test( 't11', 662, [], ['r1'], 'fam1', 1 ).
test( 't12', 493, [], [], 'fam1', 1 ).
test( 't13', 450, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't14', 741, [], [], 'fam1', 1 ).
test( 't15', 604, ['m5','m4','m3'], ['r1'], 'fam1', 1 ).
test( 't16', 509, [], [], 'fam1', 1 ).
test( 't17', 102, [], ['r1'], 'fam1', 1 ).
test( 't18', 750, [], ['r3','r2'], 'fam1', 1 ).
test( 't19', 52, [], ['r2','r1'], 'fam1', 1 ).
test( 't20', 359, [], [], 'fam1', 1 ).
test( 't21', 174, [], [], 'fam1', 1 ).
test( 't22', 387, [], [], 'fam1', 1 ).
test( 't23', 733, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't24', 226, [], [], 'fam1', 1 ).
test( 't25', 735, [], ['r3','r1'], 'fam1', 1 ).
test( 't26', 31, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't27', 474, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't28', 38, ['m2','m8','m4','m9'], [], 'fam1', 1 ).
test( 't29', 570, [], [], 'fam1', 1 ).
test( 't30', 389, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
