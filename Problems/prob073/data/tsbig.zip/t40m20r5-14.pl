%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 20
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 636, ['m13','m15'], ['r5','r4','r3'], 'fam1', 1 ).
test( 't2', 739, [], ['r4','r2'], 'fam1', 1 ).
test( 't3', 316, [], ['r3','r4','r2'], 'fam1', 1 ).
test( 't4', 458, [], [], 'fam1', 1 ).
test( 't5', 107, [], [], 'fam1', 1 ).
test( 't6', 449, [], [], 'fam1', 1 ).
test( 't7', 647, [], [], 'fam1', 1 ).
test( 't8', 152, [], [], 'fam1', 1 ).
test( 't9', 500, [], [], 'fam1', 1 ).
test( 't10', 769, [], [], 'fam1', 1 ).
test( 't11', 332, [], [], 'fam1', 1 ).
test( 't12', 691, [], [], 'fam1', 1 ).
test( 't13', 25, [], ['r2'], 'fam1', 1 ).
test( 't14', 682, [], [], 'fam1', 1 ).
test( 't15', 535, [], [], 'fam1', 1 ).
test( 't16', 769, [], [], 'fam1', 1 ).
test( 't17', 754, [], [], 'fam1', 1 ).
test( 't18', 678, ['m16'], [], 'fam1', 1 ).
test( 't19', 491, [], [], 'fam1', 1 ).
test( 't20', 702, ['m2','m20','m15','m16','m10','m4','m8','m7'], [], 'fam1', 1 ).
test( 't21', 247, [], [], 'fam1', 1 ).
test( 't22', 756, ['m12','m18','m17','m9'], [], 'fam1', 1 ).
test( 't23', 484, [], [], 'fam1', 1 ).
test( 't24', 367, [], ['r1','r5'], 'fam1', 1 ).
test( 't25', 650, [], [], 'fam1', 1 ).
test( 't26', 401, [], [], 'fam1', 1 ).
test( 't27', 605, [], [], 'fam1', 1 ).
test( 't28', 328, [], ['r4','r1','r5','r3','r2'], 'fam1', 1 ).
test( 't29', 524, [], [], 'fam1', 1 ).
test( 't30', 447, [], ['r1'], 'fam1', 1 ).
test( 't31', 801, ['m6','m18'], ['r2'], 'fam1', 1 ).
test( 't32', 453, [], ['r1','r3','r5'], 'fam1', 1 ).
test( 't33', 34, [], ['r4','r2'], 'fam1', 1 ).
test( 't34', 676, ['m20','m4','m15'], [], 'fam1', 1 ).
test( 't35', 66, [], [], 'fam1', 1 ).
test( 't36', 787, [], [], 'fam1', 1 ).
test( 't37', 97, [], [], 'fam1', 1 ).
test( 't38', 53, ['m6'], [], 'fam1', 1 ).
test( 't39', 255, [], [], 'fam1', 1 ).
test( 't40', 89, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
