%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 10
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 727, [], [], 'fam1', 1 ).
test( 't2', 235, [], [], 'fam1', 1 ).
test( 't3', 471, [], [], 'fam1', 1 ).
test( 't4', 81, [], ['r4','r7','r9','r8','r5'], 'fam1', 1 ).
test( 't5', 463, ['m2','m9'], [], 'fam1', 1 ).
test( 't6', 58, [], ['r4','r1','r5','r8'], 'fam1', 1 ).
test( 't7', 433, [], [], 'fam1', 1 ).
test( 't8', 768, [], ['r3','r9','r7','r6','r5','r2','r10','r8','r4','r1'], 'fam1', 1 ).
test( 't9', 473, [], ['r10','r6','r2','r8','r4','r1','r3','r5','r7','r9'], 'fam1', 1 ).
test( 't10', 305, [], [], 'fam1', 1 ).
test( 't11', 617, [], ['r3','r7'], 'fam1', 1 ).
test( 't12', 649, ['m3'], [], 'fam1', 1 ).
test( 't13', 698, [], ['r4','r7'], 'fam1', 1 ).
test( 't14', 595, [], [], 'fam1', 1 ).
test( 't15', 291, [], [], 'fam1', 1 ).
test( 't16', 140, [], [], 'fam1', 1 ).
test( 't17', 258, [], ['r7','r9','r10','r1'], 'fam1', 1 ).
test( 't18', 184, [], ['r9','r4','r7'], 'fam1', 1 ).
test( 't19', 425, [], [], 'fam1', 1 ).
test( 't20', 415, ['m1','m5','m10'], ['r4','r2','r9','r10','r3'], 'fam1', 1 ).
test( 't21', 507, [], [], 'fam1', 1 ).
test( 't22', 306, [], [], 'fam1', 1 ).
test( 't23', 788, [], ['r3','r6','r5','r2','r7','r10'], 'fam1', 1 ).
test( 't24', 682, [], [], 'fam1', 1 ).
test( 't25', 766, [], [], 'fam1', 1 ).
test( 't26', 228, [], ['r4','r8','r5','r3','r7','r2','r9','r10','r1'], 'fam1', 1 ).
test( 't27', 504, [], ['r4','r10','r1'], 'fam1', 1 ).
test( 't28', 310, [], [], 'fam1', 1 ).
test( 't29', 186, [], ['r8','r4','r10','r6'], 'fam1', 1 ).
test( 't30', 51, ['m6','m9'], ['r3','r9','r1','r6','r2','r7','r8','r4'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
