%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 408, [], [], 'fam1', 1 ).
test( 't2', 11, ['m6'], [], 'fam1', 1 ).
test( 't3', 366, ['m7','m6','m4','m1'], [], 'fam1', 1 ).
test( 't4', 283, [], [], 'fam1', 1 ).
test( 't5', 348, [], ['r3'], 'fam1', 1 ).
test( 't6', 167, [], [], 'fam1', 1 ).
test( 't7', 384, [], ['r1'], 'fam1', 1 ).
test( 't8', 230, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't9', 399, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't10', 403, ['m7','m3','m10','m8'], [], 'fam1', 1 ).
test( 't11', 706, [], [], 'fam1', 1 ).
test( 't12', 579, ['m1','m4','m7'], [], 'fam1', 1 ).
test( 't13', 386, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't14', 471, ['m2','m8'], [], 'fam1', 1 ).
test( 't15', 663, [], ['r2'], 'fam1', 1 ).
test( 't16', 176, [], [], 'fam1', 1 ).
test( 't17', 162, ['m6'], ['r1','r2','r3'], 'fam1', 1 ).
test( 't18', 527, [], ['r1'], 'fam1', 1 ).
test( 't19', 241, [], [], 'fam1', 1 ).
test( 't20', 242, [], [], 'fam1', 1 ).
test( 't21', 276, [], [], 'fam1', 1 ).
test( 't22', 176, [], ['r3'], 'fam1', 1 ).
test( 't23', 781, [], [], 'fam1', 1 ).
test( 't24', 200, [], [], 'fam1', 1 ).
test( 't25', 352, [], [], 'fam1', 1 ).
test( 't26', 597, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't27', 747, ['m10'], ['r3'], 'fam1', 1 ).
test( 't28', 575, [], [], 'fam1', 1 ).
test( 't29', 290, [], [], 'fam1', 1 ).
test( 't30', 285, [], [], 'fam1', 1 ).
test( 't31', 744, [], [], 'fam1', 1 ).
test( 't32', 511, [], [], 'fam1', 1 ).
test( 't33', 47, [], [], 'fam1', 1 ).
test( 't34', 631, [], [], 'fam1', 1 ).
test( 't35', 542, [], ['r3'], 'fam1', 1 ).
test( 't36', 87, [], ['r1'], 'fam1', 1 ).
test( 't37', 722, [], [], 'fam1', 1 ).
test( 't38', 438, [], ['r2'], 'fam1', 1 ).
test( 't39', 197, [], [], 'fam1', 1 ).
test( 't40', 752, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't41', 3, [], ['r1'], 'fam1', 1 ).
test( 't42', 183, [], [], 'fam1', 1 ).
test( 't43', 754, [], [], 'fam1', 1 ).
test( 't44', 38, [], [], 'fam1', 1 ).
test( 't45', 290, [], ['r3','r2'], 'fam1', 1 ).
test( 't46', 764, [], [], 'fam1', 1 ).
test( 't47', 28, [], ['r2','r3'], 'fam1', 1 ).
test( 't48', 333, ['m4','m10','m5','m2'], [], 'fam1', 1 ).
test( 't49', 190, ['m3','m2','m9','m10'], [], 'fam1', 1 ).
test( 't50', 489, [], ['r1','r3'], 'fam1', 1 ).
test( 't51', 702, [], ['r1'], 'fam1', 1 ).
test( 't52', 777, [], [], 'fam1', 1 ).
test( 't53', 462, [], ['r2','r3'], 'fam1', 1 ).
test( 't54', 644, [], [], 'fam1', 1 ).
test( 't55', 422, ['m6'], [], 'fam1', 1 ).
test( 't56', 438, [], [], 'fam1', 1 ).
test( 't57', 751, [], [], 'fam1', 1 ).
test( 't58', 789, [], [], 'fam1', 1 ).
test( 't59', 589, ['m1','m2','m3','m10'], [], 'fam1', 1 ).
test( 't60', 475, [], ['r1'], 'fam1', 1 ).
test( 't61', 333, [], [], 'fam1', 1 ).
test( 't62', 31, ['m1','m6','m2','m10'], [], 'fam1', 1 ).
test( 't63', 428, [], [], 'fam1', 1 ).
test( 't64', 291, [], [], 'fam1', 1 ).
test( 't65', 326, [], [], 'fam1', 1 ).
test( 't66', 121, [], [], 'fam1', 1 ).
test( 't67', 145, [], ['r3','r2'], 'fam1', 1 ).
test( 't68', 78, [], [], 'fam1', 1 ).
test( 't69', 677, [], [], 'fam1', 1 ).
test( 't70', 416, [], [], 'fam1', 1 ).
test( 't71', 669, [], [], 'fam1', 1 ).
test( 't72', 485, [], [], 'fam1', 1 ).
test( 't73', 113, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't74', 91, [], [], 'fam1', 1 ).
test( 't75', 561, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't76', 103, [], ['r2'], 'fam1', 1 ).
test( 't77', 39, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't78', 2, [], [], 'fam1', 1 ).
test( 't79', 513, [], [], 'fam1', 1 ).
test( 't80', 720, ['m9','m8','m4'], ['r3','r2','r1'], 'fam1', 1 ).
test( 't81', 37, [], [], 'fam1', 1 ).
test( 't82', 618, [], [], 'fam1', 1 ).
test( 't83', 392, [], [], 'fam1', 1 ).
test( 't84', 602, [], [], 'fam1', 1 ).
test( 't85', 669, [], [], 'fam1', 1 ).
test( 't86', 457, [], [], 'fam1', 1 ).
test( 't87', 423, [], [], 'fam1', 1 ).
test( 't88', 164, ['m2','m1','m8'], [], 'fam1', 1 ).
test( 't89', 790, [], [], 'fam1', 1 ).
test( 't90', 297, [], ['r2','r1'], 'fam1', 1 ).
test( 't91', 578, [], [], 'fam1', 1 ).
test( 't92', 167, [], [], 'fam1', 1 ).
test( 't93', 270, ['m2','m10'], ['r3','r1','r2'], 'fam1', 1 ).
test( 't94', 242, [], ['r2','r1'], 'fam1', 1 ).
test( 't95', 761, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't96', 733, [], ['r2'], 'fam1', 1 ).
test( 't97', 472, ['m10','m9','m3','m8'], [], 'fam1', 1 ).
test( 't98', 373, [], [], 'fam1', 1 ).
test( 't99', 272, ['m5','m10'], [], 'fam1', 1 ).
test( 't100', 567, ['m9','m4','m6','m7'], ['r2','r3'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
