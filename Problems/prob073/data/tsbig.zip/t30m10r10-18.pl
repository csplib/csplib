%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 10
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 653, ['m8','m2'], [], 'fam1', 1 ).
test( 't2', 419, [], ['r8','r9'], 'fam1', 1 ).
test( 't3', 299, ['m7'], [], 'fam1', 1 ).
test( 't4', 215, [], [], 'fam1', 1 ).
test( 't5', 651, [], [], 'fam1', 1 ).
test( 't6', 758, ['m2','m1'], ['r4','r5','r6','r1'], 'fam1', 1 ).
test( 't7', 137, [], [], 'fam1', 1 ).
test( 't8', 372, [], [], 'fam1', 1 ).
test( 't9', 138, [], ['r10','r6','r3','r7','r4','r1','r9','r2','r8'], 'fam1', 1 ).
test( 't10', 616, [], [], 'fam1', 1 ).
test( 't11', 762, ['m2','m7','m5','m3'], [], 'fam1', 1 ).
test( 't12', 160, [], [], 'fam1', 1 ).
test( 't13', 405, ['m10','m1','m5','m6'], ['r8','r2','r10','r9','r3','r1','r6','r5'], 'fam1', 1 ).
test( 't14', 769, [], ['r4','r8'], 'fam1', 1 ).
test( 't15', 694, [], [], 'fam1', 1 ).
test( 't16', 364, [], ['r10','r2','r4','r7'], 'fam1', 1 ).
test( 't17', 214, [], [], 'fam1', 1 ).
test( 't18', 39, [], [], 'fam1', 1 ).
test( 't19', 152, [], ['r2','r10','r5','r9','r3','r6','r8','r7','r1'], 'fam1', 1 ).
test( 't20', 282, [], [], 'fam1', 1 ).
test( 't21', 180, [], ['r1','r6','r10','r4'], 'fam1', 1 ).
test( 't22', 563, [], [], 'fam1', 1 ).
test( 't23', 73, [], [], 'fam1', 1 ).
test( 't24', 483, [], ['r4','r8','r3','r7'], 'fam1', 1 ).
test( 't25', 38, ['m10','m2','m8'], ['r3','r2','r5','r9','r7','r1','r8','r4','r6','r10'], 'fam1', 1 ).
test( 't26', 462, [], [], 'fam1', 1 ).
test( 't27', 681, ['m6','m4','m7'], [], 'fam1', 1 ).
test( 't28', 235, [], [], 'fam1', 1 ).
test( 't29', 667, [], [], 'fam1', 1 ).
test( 't30', 374, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
