%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 578, ['m1','m4'], [], 'fam1', 1 ).
test( 't2', 25, [], [], 'fam1', 1 ).
test( 't3', 177, [], ['r2','r1'], 'fam1', 1 ).
test( 't4', 388, [], ['r1','r2'], 'fam1', 1 ).
test( 't5', 337, [], ['r2','r3'], 'fam1', 1 ).
test( 't6', 707, [], [], 'fam1', 1 ).
test( 't7', 453, ['m7','m5','m4'], [], 'fam1', 1 ).
test( 't8', 135, [], [], 'fam1', 1 ).
test( 't9', 592, [], [], 'fam1', 1 ).
test( 't10', 268, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't11', 384, [], [], 'fam1', 1 ).
test( 't12', 24, ['m10'], [], 'fam1', 1 ).
test( 't13', 565, [], [], 'fam1', 1 ).
test( 't14', 432, [], ['r3'], 'fam1', 1 ).
test( 't15', 724, ['m1','m2','m10','m8'], ['r2'], 'fam1', 1 ).
test( 't16', 643, [], ['r3'], 'fam1', 1 ).
test( 't17', 588, ['m6'], [], 'fam1', 1 ).
test( 't18', 178, [], [], 'fam1', 1 ).
test( 't19', 118, [], ['r1','r2'], 'fam1', 1 ).
test( 't20', 69, [], [], 'fam1', 1 ).
test( 't21', 608, [], [], 'fam1', 1 ).
test( 't22', 227, [], [], 'fam1', 1 ).
test( 't23', 518, [], [], 'fam1', 1 ).
test( 't24', 562, ['m6','m8'], ['r1','r2'], 'fam1', 1 ).
test( 't25', 418, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't26', 255, [], ['r3'], 'fam1', 1 ).
test( 't27', 116, [], [], 'fam1', 1 ).
test( 't28', 739, [], [], 'fam1', 1 ).
test( 't29', 42, [], [], 'fam1', 1 ).
test( 't30', 81, [], [], 'fam1', 1 ).
test( 't31', 786, [], [], 'fam1', 1 ).
test( 't32', 191, [], ['r3'], 'fam1', 1 ).
test( 't33', 20, [], [], 'fam1', 1 ).
test( 't34', 463, [], [], 'fam1', 1 ).
test( 't35', 148, [], [], 'fam1', 1 ).
test( 't36', 267, [], [], 'fam1', 1 ).
test( 't37', 135, [], [], 'fam1', 1 ).
test( 't38', 650, [], [], 'fam1', 1 ).
test( 't39', 361, [], ['r2'], 'fam1', 1 ).
test( 't40', 495, ['m3','m9','m4','m2'], ['r1','r3','r2'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
