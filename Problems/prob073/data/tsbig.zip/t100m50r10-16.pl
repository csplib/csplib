%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 50
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 653, [], ['r7','r9','r6','r3','r2'], 'fam1', 1 ).
test( 't2', 84, [], [], 'fam1', 1 ).
test( 't3', 66, ['m45','m25','m48','m15','m28','m20','m4','m32','m12','m34','m14'], [], 'fam1', 1 ).
test( 't4', 117, [], [], 'fam1', 1 ).
test( 't5', 275, [], [], 'fam1', 1 ).
test( 't6', 295, [], ['r4','r3','r6','r8','r2','r9','r1'], 'fam1', 1 ).
test( 't7', 565, [], ['r4','r10'], 'fam1', 1 ).
test( 't8', 158, [], ['r8','r10','r3','r6'], 'fam1', 1 ).
test( 't9', 744, [], [], 'fam1', 1 ).
test( 't10', 510, [], [], 'fam1', 1 ).
test( 't11', 714, [], [], 'fam1', 1 ).
test( 't12', 335, [], ['r8','r6','r1','r10','r5','r4','r2','r9'], 'fam1', 1 ).
test( 't13', 284, [], ['r1','r10','r6','r5','r8'], 'fam1', 1 ).
test( 't14', 380, [], [], 'fam1', 1 ).
test( 't15', 466, [], ['r6','r1','r4','r5','r9','r3','r8'], 'fam1', 1 ).
test( 't16', 78, ['m49','m2','m20','m6','m35'], [], 'fam1', 1 ).
test( 't17', 729, [], ['r5','r9','r7','r6','r2'], 'fam1', 1 ).
test( 't18', 422, [], [], 'fam1', 1 ).
test( 't19', 250, ['m14','m18','m1','m31','m17','m6','m7','m8'], [], 'fam1', 1 ).
test( 't20', 327, ['m41','m19','m47','m14','m4','m45','m44','m21','m17','m29','m13','m10','m24','m38','m32','m5','m16','m48','m43','m1'], [], 'fam1', 1 ).
test( 't21', 704, [], ['r7','r6','r2','r1','r9','r5','r3'], 'fam1', 1 ).
test( 't22', 339, [], [], 'fam1', 1 ).
test( 't23', 594, [], ['r10','r2','r9','r1','r8','r7','r6','r4','r3','r5'], 'fam1', 1 ).
test( 't24', 658, [], [], 'fam1', 1 ).
test( 't25', 673, ['m15','m42','m19','m3','m37','m2','m11','m25','m49','m27','m34','m13','m9','m28'], ['r9','r7','r2','r6','r10'], 'fam1', 1 ).
test( 't26', 790, [], [], 'fam1', 1 ).
test( 't27', 261, [], ['r10','r9','r7','r5','r4','r1','r8'], 'fam1', 1 ).
test( 't28', 502, [], [], 'fam1', 1 ).
test( 't29', 598, ['m29','m23','m18','m43','m10'], [], 'fam1', 1 ).
test( 't30', 726, [], [], 'fam1', 1 ).
test( 't31', 615, [], [], 'fam1', 1 ).
test( 't32', 622, [], [], 'fam1', 1 ).
test( 't33', 452, ['m47','m17','m40'], [], 'fam1', 1 ).
test( 't34', 177, [], [], 'fam1', 1 ).
test( 't35', 233, [], ['r7','r3','r5','r6','r4','r9','r8','r2','r10','r1'], 'fam1', 1 ).
test( 't36', 527, [], [], 'fam1', 1 ).
test( 't37', 614, [], ['r8','r9','r3','r1','r10','r2','r6','r5','r7','r4'], 'fam1', 1 ).
test( 't38', 550, [], [], 'fam1', 1 ).
test( 't39', 532, [], ['r7','r8','r6','r9','r1'], 'fam1', 1 ).
test( 't40', 383, [], ['r7','r3','r2','r10','r5','r1','r8','r9','r4'], 'fam1', 1 ).
test( 't41', 709, [], [], 'fam1', 1 ).
test( 't42', 233, [], [], 'fam1', 1 ).
test( 't43', 111, [], [], 'fam1', 1 ).
test( 't44', 738, [], [], 'fam1', 1 ).
test( 't45', 265, [], ['r9','r1','r2','r7','r10','r8','r4','r6','r5','r3'], 'fam1', 1 ).
test( 't46', 352, [], [], 'fam1', 1 ).
test( 't47', 313, ['m22','m35','m9','m25','m18','m14','m30','m44','m8','m46'], [], 'fam1', 1 ).
test( 't48', 544, [], [], 'fam1', 1 ).
test( 't49', 661, [], [], 'fam1', 1 ).
test( 't50', 290, [], [], 'fam1', 1 ).
test( 't51', 155, [], [], 'fam1', 1 ).
test( 't52', 180, [], [], 'fam1', 1 ).
test( 't53', 210, [], [], 'fam1', 1 ).
test( 't54', 725, [], ['r9','r7','r8','r1','r2','r6','r3','r5','r10'], 'fam1', 1 ).
test( 't55', 478, [], [], 'fam1', 1 ).
test( 't56', 112, ['m26','m39','m13','m3','m22','m40','m36','m17','m28','m42','m50'], ['r9','r3','r5','r7','r10','r2','r8','r4'], 'fam1', 1 ).
test( 't57', 642, [], ['r8','r7','r6','r4','r1'], 'fam1', 1 ).
test( 't58', 560, [], [], 'fam1', 1 ).
test( 't59', 482, [], [], 'fam1', 1 ).
test( 't60', 233, [], [], 'fam1', 1 ).
test( 't61', 268, [], ['r5','r2','r7','r9','r8','r6','r4','r10','r3','r1'], 'fam1', 1 ).
test( 't62', 516, [], ['r8','r6','r1','r5','r2','r7'], 'fam1', 1 ).
test( 't63', 362, [], [], 'fam1', 1 ).
test( 't64', 609, [], ['r9','r6','r8','r1','r3','r7'], 'fam1', 1 ).
test( 't65', 511, [], ['r3','r2','r10','r9'], 'fam1', 1 ).
test( 't66', 308, [], [], 'fam1', 1 ).
test( 't67', 725, [], ['r6','r2'], 'fam1', 1 ).
test( 't68', 616, [], ['r8','r2','r4','r5','r10'], 'fam1', 1 ).
test( 't69', 70, [], ['r10','r6'], 'fam1', 1 ).
test( 't70', 560, [], ['r7','r10','r5','r9','r1','r3'], 'fam1', 1 ).
test( 't71', 224, ['m39','m30','m7','m6','m42','m16','m43','m5','m27','m8','m23','m44'], [], 'fam1', 1 ).
test( 't72', 671, [], [], 'fam1', 1 ).
test( 't73', 358, ['m45','m34','m5','m14','m36','m43'], [], 'fam1', 1 ).
test( 't74', 538, [], [], 'fam1', 1 ).
test( 't75', 11, [], ['r8','r7','r10','r9','r1','r6','r3','r5','r4','r2'], 'fam1', 1 ).
test( 't76', 318, [], [], 'fam1', 1 ).
test( 't77', 510, [], ['r8'], 'fam1', 1 ).
test( 't78', 416, [], [], 'fam1', 1 ).
test( 't79', 32, [], [], 'fam1', 1 ).
test( 't80', 499, [], ['r8','r10','r3','r5','r1','r4','r7','r2'], 'fam1', 1 ).
test( 't81', 514, [], [], 'fam1', 1 ).
test( 't82', 30, [], [], 'fam1', 1 ).
test( 't83', 192, [], ['r3','r2'], 'fam1', 1 ).
test( 't84', 157, [], [], 'fam1', 1 ).
test( 't85', 743, [], ['r6','r9','r3','r4','r8','r10','r7','r1'], 'fam1', 1 ).
test( 't86', 90, [], [], 'fam1', 1 ).
test( 't87', 764, ['m45','m41','m27','m37','m1','m46','m34','m48','m43','m12','m30','m49'], ['r9','r3','r1','r2','r6'], 'fam1', 1 ).
test( 't88', 178, [], [], 'fam1', 1 ).
test( 't89', 633, [], [], 'fam1', 1 ).
test( 't90', 30, [], ['r2','r8','r1','r6','r7','r10','r5','r9','r3'], 'fam1', 1 ).
test( 't91', 626, [], [], 'fam1', 1 ).
test( 't92', 262, [], ['r8','r5','r10','r3','r1','r6','r9'], 'fam1', 1 ).
test( 't93', 358, [], [], 'fam1', 1 ).
test( 't94', 254, [], [], 'fam1', 1 ).
test( 't95', 473, [], [], 'fam1', 1 ).
test( 't96', 166, [], ['r8','r3','r6','r7','r10','r1','r4','r5'], 'fam1', 1 ).
test( 't97', 257, [], [], 'fam1', 1 ).
test( 't98', 315, ['m50'], ['r1','r2','r7','r6','r5','r9','r10','r8'], 'fam1', 1 ).
test( 't99', 223, ['m26','m2','m36','m45'], [], 'fam1', 1 ).
test( 't100', 387, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').
embedded_board( 'm21').
embedded_board( 'm22').
embedded_board( 'm23').
embedded_board( 'm24').
embedded_board( 'm25').
embedded_board( 'm26').
embedded_board( 'm27').
embedded_board( 'm28').
embedded_board( 'm29').
embedded_board( 'm30').
embedded_board( 'm31').
embedded_board( 'm32').
embedded_board( 'm33').
embedded_board( 'm34').
embedded_board( 'm35').
embedded_board( 'm36').
embedded_board( 'm37').
embedded_board( 'm38').
embedded_board( 'm39').
embedded_board( 'm40').
embedded_board( 'm41').
embedded_board( 'm42').
embedded_board( 'm43').
embedded_board( 'm44').
embedded_board( 'm45').
embedded_board( 'm46').
embedded_board( 'm47').
embedded_board( 'm48').
embedded_board( 'm49').
embedded_board( 'm50').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
