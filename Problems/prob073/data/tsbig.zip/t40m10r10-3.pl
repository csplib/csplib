%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 10
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 314, ['m7','m9','m5','m2'], [], 'fam1', 1 ).
test( 't2', 334, [], [], 'fam1', 1 ).
test( 't3', 292, [], [], 'fam1', 1 ).
test( 't4', 154, [], ['r8','r3','r6'], 'fam1', 1 ).
test( 't5', 683, [], [], 'fam1', 1 ).
test( 't6', 745, [], [], 'fam1', 1 ).
test( 't7', 577, [], [], 'fam1', 1 ).
test( 't8', 498, [], ['r10','r3','r4','r9','r7'], 'fam1', 1 ).
test( 't9', 17, [], [], 'fam1', 1 ).
test( 't10', 102, [], ['r10','r6','r8'], 'fam1', 1 ).
test( 't11', 226, [], ['r4','r2','r7','r3'], 'fam1', 1 ).
test( 't12', 60, ['m4','m3','m1','m7'], [], 'fam1', 1 ).
test( 't13', 284, [], ['r4','r2','r9','r3','r10','r1','r7','r6'], 'fam1', 1 ).
test( 't14', 514, [], ['r7','r2','r9','r6','r10','r3','r5','r4','r1','r8'], 'fam1', 1 ).
test( 't15', 586, [], [], 'fam1', 1 ).
test( 't16', 51, [], ['r2','r8','r3','r6','r5','r10','r4','r9','r1'], 'fam1', 1 ).
test( 't17', 494, ['m9','m6'], [], 'fam1', 1 ).
test( 't18', 470, [], [], 'fam1', 1 ).
test( 't19', 670, [], [], 'fam1', 1 ).
test( 't20', 769, [], ['r3','r1'], 'fam1', 1 ).
test( 't21', 627, [], [], 'fam1', 1 ).
test( 't22', 2, ['m6'], [], 'fam1', 1 ).
test( 't23', 599, [], [], 'fam1', 1 ).
test( 't24', 16, [], ['r2','r10','r3','r9','r5'], 'fam1', 1 ).
test( 't25', 115, [], [], 'fam1', 1 ).
test( 't26', 337, [], [], 'fam1', 1 ).
test( 't27', 479, [], [], 'fam1', 1 ).
test( 't28', 472, ['m5'], [], 'fam1', 1 ).
test( 't29', 691, ['m1','m5','m9','m2'], [], 'fam1', 1 ).
test( 't30', 717, ['m6','m5','m2'], ['r5','r9','r3','r10'], 'fam1', 1 ).
test( 't31', 12, [], [], 'fam1', 1 ).
test( 't32', 488, [], ['r3'], 'fam1', 1 ).
test( 't33', 508, [], [], 'fam1', 1 ).
test( 't34', 463, [], [], 'fam1', 1 ).
test( 't35', 56, [], [], 'fam1', 1 ).
test( 't36', 450, ['m2'], [], 'fam1', 1 ).
test( 't37', 17, [], [], 'fam1', 1 ).
test( 't38', 486, [], [], 'fam1', 1 ).
test( 't39', 54, ['m5','m10'], [], 'fam1', 1 ).
test( 't40', 116, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
