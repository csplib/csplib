%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 20
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 573, [], [], 'fam1', 1 ).
test( 't2', 430, [], ['r4','r1','r5','r3'], 'fam1', 1 ).
test( 't3', 342, [], [], 'fam1', 1 ).
test( 't4', 633, [], [], 'fam1', 1 ).
test( 't5', 33, [], [], 'fam1', 1 ).
test( 't6', 495, [], [], 'fam1', 1 ).
test( 't7', 620, [], ['r5','r1','r4','r3'], 'fam1', 1 ).
test( 't8', 665, [], [], 'fam1', 1 ).
test( 't9', 592, [], [], 'fam1', 1 ).
test( 't10', 526, [], [], 'fam1', 1 ).
test( 't11', 461, [], [], 'fam1', 1 ).
test( 't12', 299, [], [], 'fam1', 1 ).
test( 't13', 729, [], [], 'fam1', 1 ).
test( 't14', 681, ['m13','m20','m2','m4','m19','m11','m5','m18'], [], 'fam1', 1 ).
test( 't15', 106, [], ['r3','r2','r1','r4','r5'], 'fam1', 1 ).
test( 't16', 86, [], [], 'fam1', 1 ).
test( 't17', 440, ['m19','m18','m4','m6'], ['r2','r4','r5','r3'], 'fam1', 1 ).
test( 't18', 210, [], [], 'fam1', 1 ).
test( 't19', 180, ['m13','m11','m7'], [], 'fam1', 1 ).
test( 't20', 4, [], [], 'fam1', 1 ).
test( 't21', 118, [], [], 'fam1', 1 ).
test( 't22', 578, [], [], 'fam1', 1 ).
test( 't23', 450, [], [], 'fam1', 1 ).
test( 't24', 453, [], ['r5','r3','r2'], 'fam1', 1 ).
test( 't25', 145, ['m17'], ['r1','r4'], 'fam1', 1 ).
test( 't26', 113, [], [], 'fam1', 1 ).
test( 't27', 284, ['m11','m16','m4','m7','m3'], [], 'fam1', 1 ).
test( 't28', 481, [], [], 'fam1', 1 ).
test( 't29', 468, [], [], 'fam1', 1 ).
test( 't30', 434, [], [], 'fam1', 1 ).
test( 't31', 219, ['m4'], [], 'fam1', 1 ).
test( 't32', 476, [], [], 'fam1', 1 ).
test( 't33', 694, [], [], 'fam1', 1 ).
test( 't34', 113, ['m5','m2','m6','m11','m8','m14','m9','m16'], ['r3'], 'fam1', 1 ).
test( 't35', 796, [], ['r4','r5','r1','r3'], 'fam1', 1 ).
test( 't36', 118, [], ['r2','r3'], 'fam1', 1 ).
test( 't37', 130, [], [], 'fam1', 1 ).
test( 't38', 427, [], ['r1','r2','r5'], 'fam1', 1 ).
test( 't39', 78, [], ['r5','r4','r2','r3','r1'], 'fam1', 1 ).
test( 't40', 184, [], [], 'fam1', 1 ).
test( 't41', 202, [], ['r2','r3','r4'], 'fam1', 1 ).
test( 't42', 482, ['m15','m10','m2'], ['r2','r3'], 'fam1', 1 ).
test( 't43', 51, [], [], 'fam1', 1 ).
test( 't44', 777, [], [], 'fam1', 1 ).
test( 't45', 126, [], ['r1','r2'], 'fam1', 1 ).
test( 't46', 189, [], [], 'fam1', 1 ).
test( 't47', 646, [], [], 'fam1', 1 ).
test( 't48', 44, ['m1','m12','m20','m4','m18','m2'], [], 'fam1', 1 ).
test( 't49', 144, [], [], 'fam1', 1 ).
test( 't50', 225, [], [], 'fam1', 1 ).
test( 't51', 466, [], ['r3','r5','r1','r4'], 'fam1', 1 ).
test( 't52', 179, [], [], 'fam1', 1 ).
test( 't53', 317, [], [], 'fam1', 1 ).
test( 't54', 234, [], ['r4','r2','r3','r5'], 'fam1', 1 ).
test( 't55', 576, [], [], 'fam1', 1 ).
test( 't56', 624, [], [], 'fam1', 1 ).
test( 't57', 215, [], [], 'fam1', 1 ).
test( 't58', 488, [], [], 'fam1', 1 ).
test( 't59', 631, [], ['r2','r3','r4'], 'fam1', 1 ).
test( 't60', 339, [], [], 'fam1', 1 ).
test( 't61', 135, [], ['r2'], 'fam1', 1 ).
test( 't62', 121, [], ['r1','r4'], 'fam1', 1 ).
test( 't63', 515, [], [], 'fam1', 1 ).
test( 't64', 287, ['m14','m1','m19','m11','m8'], [], 'fam1', 1 ).
test( 't65', 791, [], [], 'fam1', 1 ).
test( 't66', 462, ['m14','m7','m6','m11','m16','m3'], [], 'fam1', 1 ).
test( 't67', 306, [], [], 'fam1', 1 ).
test( 't68', 502, [], [], 'fam1', 1 ).
test( 't69', 622, ['m18','m10','m6','m11'], [], 'fam1', 1 ).
test( 't70', 649, ['m20','m11','m19','m18','m16','m7','m9','m3'], [], 'fam1', 1 ).
test( 't71', 518, [], [], 'fam1', 1 ).
test( 't72', 321, [], [], 'fam1', 1 ).
test( 't73', 415, [], [], 'fam1', 1 ).
test( 't74', 259, [], [], 'fam1', 1 ).
test( 't75', 549, [], ['r2','r5'], 'fam1', 1 ).
test( 't76', 296, ['m18','m20','m7','m12','m17','m9','m4','m8'], [], 'fam1', 1 ).
test( 't77', 385, [], [], 'fam1', 1 ).
test( 't78', 139, ['m9','m10','m12','m5','m14'], [], 'fam1', 1 ).
test( 't79', 84, [], ['r4','r2','r3','r1','r5'], 'fam1', 1 ).
test( 't80', 298, [], ['r2','r3','r1','r5'], 'fam1', 1 ).
test( 't81', 441, ['m13'], [], 'fam1', 1 ).
test( 't82', 370, [], [], 'fam1', 1 ).
test( 't83', 363, ['m12','m11','m17','m15','m14','m9','m2'], [], 'fam1', 1 ).
test( 't84', 261, [], [], 'fam1', 1 ).
test( 't85', 767, [], [], 'fam1', 1 ).
test( 't86', 563, [], [], 'fam1', 1 ).
test( 't87', 8, [], [], 'fam1', 1 ).
test( 't88', 614, [], [], 'fam1', 1 ).
test( 't89', 741, [], [], 'fam1', 1 ).
test( 't90', 214, ['m3','m7','m17','m6','m14','m10'], [], 'fam1', 1 ).
test( 't91', 707, [], [], 'fam1', 1 ).
test( 't92', 773, [], [], 'fam1', 1 ).
test( 't93', 119, [], [], 'fam1', 1 ).
test( 't94', 788, [], [], 'fam1', 1 ).
test( 't95', 196, [], [], 'fam1', 1 ).
test( 't96', 292, [], ['r4','r1','r3','r2'], 'fam1', 1 ).
test( 't97', 43, [], ['r2'], 'fam1', 1 ).
test( 't98', 696, [], ['r3','r2'], 'fam1', 1 ).
test( 't99', 224, [], [], 'fam1', 1 ).
test( 't100', 557, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
