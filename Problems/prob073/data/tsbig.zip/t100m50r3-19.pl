%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 50
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 680, [], [], 'fam1', 1 ).
test( 't2', 155, [], [], 'fam1', 1 ).
test( 't3', 642, [], ['r1','r2'], 'fam1', 1 ).
test( 't4', 376, ['m27','m39','m41','m26','m16','m2','m1','m22','m12','m4','m31','m15','m33','m13','m29','m34','m3','m37'], [], 'fam1', 1 ).
test( 't5', 29, ['m42','m2','m23','m5','m45','m30'], ['r3','r1','r2'], 'fam1', 1 ).
test( 't6', 156, ['m27','m2','m44','m28','m40','m37','m32','m7','m17','m50','m24','m41','m3','m16','m38','m30','m47','m4','m19','m34'], [], 'fam1', 1 ).
test( 't7', 59, [], ['r2'], 'fam1', 1 ).
test( 't8', 628, [], [], 'fam1', 1 ).
test( 't9', 588, [], [], 'fam1', 1 ).
test( 't10', 770, ['m17','m20','m37','m49','m4','m3','m40','m19','m45'], ['r3','r2','r1'], 'fam1', 1 ).
test( 't11', 539, [], ['r1','r2'], 'fam1', 1 ).
test( 't12', 155, [], ['r3'], 'fam1', 1 ).
test( 't13', 717, ['m32','m4','m42','m2','m46','m50','m1','m8','m35','m7','m16','m45','m34','m22','m25','m43','m49'], [], 'fam1', 1 ).
test( 't14', 302, ['m17','m6','m43','m42','m32','m48','m45','m8','m4'], [], 'fam1', 1 ).
test( 't15', 155, [], [], 'fam1', 1 ).
test( 't16', 596, [], ['r2'], 'fam1', 1 ).
test( 't17', 68, [], [], 'fam1', 1 ).
test( 't18', 601, [], [], 'fam1', 1 ).
test( 't19', 373, [], [], 'fam1', 1 ).
test( 't20', 726, [], [], 'fam1', 1 ).
test( 't21', 318, [], [], 'fam1', 1 ).
test( 't22', 271, [], ['r1','r2'], 'fam1', 1 ).
test( 't23', 589, [], [], 'fam1', 1 ).
test( 't24', 537, ['m19','m48','m46','m26'], [], 'fam1', 1 ).
test( 't25', 127, ['m1','m43','m17','m50','m24','m12'], [], 'fam1', 1 ).
test( 't26', 254, ['m46','m32','m45','m30','m3','m6','m11','m27','m21','m33','m13','m23','m12','m41','m1','m48','m24'], [], 'fam1', 1 ).
test( 't27', 346, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't28', 197, ['m25','m41','m7','m27','m6','m16','m21','m44','m10','m20','m49','m12','m29'], [], 'fam1', 1 ).
test( 't29', 212, [], [], 'fam1', 1 ).
test( 't30', 314, [], ['r1','r3'], 'fam1', 1 ).
test( 't31', 246, [], [], 'fam1', 1 ).
test( 't32', 620, [], [], 'fam1', 1 ).
test( 't33', 322, [], [], 'fam1', 1 ).
test( 't34', 423, [], [], 'fam1', 1 ).
test( 't35', 560, [], [], 'fam1', 1 ).
test( 't36', 649, [], [], 'fam1', 1 ).
test( 't37', 228, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't38', 277, [], [], 'fam1', 1 ).
test( 't39', 81, [], ['r3'], 'fam1', 1 ).
test( 't40', 296, ['m49','m45','m50','m17','m30','m23','m21','m13','m26'], ['r2','r3','r1'], 'fam1', 1 ).
test( 't41', 447, ['m4','m13'], [], 'fam1', 1 ).
test( 't42', 565, ['m20','m24','m45','m49','m14','m33','m50','m42','m22','m26','m48','m47','m3','m35','m43','m5','m7','m38','m40'], [], 'fam1', 1 ).
test( 't43', 752, [], ['r1'], 'fam1', 1 ).
test( 't44', 341, ['m24','m40','m32','m7','m47','m49','m22','m33','m17','m20','m23'], [], 'fam1', 1 ).
test( 't45', 66, [], ['r1','r3'], 'fam1', 1 ).
test( 't46', 414, [], ['r2','r3'], 'fam1', 1 ).
test( 't47', 328, [], ['r1','r2'], 'fam1', 1 ).
test( 't48', 602, [], [], 'fam1', 1 ).
test( 't49', 432, [], [], 'fam1', 1 ).
test( 't50', 449, [], ['r1'], 'fam1', 1 ).
test( 't51', 434, [], [], 'fam1', 1 ).
test( 't52', 614, [], ['r2','r1'], 'fam1', 1 ).
test( 't53', 588, [], [], 'fam1', 1 ).
test( 't54', 692, [], ['r2','r1'], 'fam1', 1 ).
test( 't55', 283, [], [], 'fam1', 1 ).
test( 't56', 592, ['m36','m5','m14','m49','m19','m45','m29','m3','m22','m44','m48','m20'], [], 'fam1', 1 ).
test( 't57', 45, [], ['r3'], 'fam1', 1 ).
test( 't58', 757, ['m18','m25','m21','m50','m29','m10','m36'], [], 'fam1', 1 ).
test( 't59', 330, ['m50','m4','m16','m1','m21','m39','m12'], [], 'fam1', 1 ).
test( 't60', 92, [], ['r1','r3'], 'fam1', 1 ).
test( 't61', 560, [], [], 'fam1', 1 ).
test( 't62', 239, [], ['r3','r2'], 'fam1', 1 ).
test( 't63', 393, [], [], 'fam1', 1 ).
test( 't64', 568, ['m25','m17','m20','m13','m44','m5','m4','m16'], ['r1','r3'], 'fam1', 1 ).
test( 't65', 769, [], [], 'fam1', 1 ).
test( 't66', 83, [], [], 'fam1', 1 ).
test( 't67', 393, ['m13','m43','m32','m27','m26'], [], 'fam1', 1 ).
test( 't68', 86, [], [], 'fam1', 1 ).
test( 't69', 533, [], [], 'fam1', 1 ).
test( 't70', 525, ['m44','m10','m40','m16','m27','m42','m46','m50'], ['r3'], 'fam1', 1 ).
test( 't71', 127, [], ['r3','r2'], 'fam1', 1 ).
test( 't72', 291, [], ['r2','r1'], 'fam1', 1 ).
test( 't73', 426, [], [], 'fam1', 1 ).
test( 't74', 68, ['m50','m9','m11','m35','m26','m29','m41','m38','m17','m46','m32'], [], 'fam1', 1 ).
test( 't75', 248, [], [], 'fam1', 1 ).
test( 't76', 232, [], [], 'fam1', 1 ).
test( 't77', 486, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't78', 251, ['m29','m12','m47','m44','m33','m13','m1','m35','m32','m49','m40','m10','m9','m14','m19','m18','m16','m4'], [], 'fam1', 1 ).
test( 't79', 252, ['m46','m2','m27','m20','m50','m31','m10','m34','m42','m37','m18','m11','m47'], [], 'fam1', 1 ).
test( 't80', 667, [], ['r2','r3'], 'fam1', 1 ).
test( 't81', 470, [], [], 'fam1', 1 ).
test( 't82', 112, [], [], 'fam1', 1 ).
test( 't83', 103, ['m49','m20','m48','m14','m43','m32','m45','m37','m7'], ['r3','r1'], 'fam1', 1 ).
test( 't84', 438, ['m7','m12','m33','m13','m25','m37','m50','m34','m45'], [], 'fam1', 1 ).
test( 't85', 753, [], ['r2','r1'], 'fam1', 1 ).
test( 't86', 763, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't87', 420, [], [], 'fam1', 1 ).
test( 't88', 321, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't89', 760, [], ['r1'], 'fam1', 1 ).
test( 't90', 69, [], ['r3','r1'], 'fam1', 1 ).
test( 't91', 221, ['m26','m23','m29','m18'], ['r1','r2'], 'fam1', 1 ).
test( 't92', 652, [], [], 'fam1', 1 ).
test( 't93', 462, [], [], 'fam1', 1 ).
test( 't94', 410, [], [], 'fam1', 1 ).
test( 't95', 642, [], ['r1'], 'fam1', 1 ).
test( 't96', 378, [], [], 'fam1', 1 ).
test( 't97', 370, ['m25','m15','m17','m11','m6','m29','m24','m21','m37','m34','m35','m3','m18','m31','m7','m20','m28','m49'], ['r3','r1','r2'], 'fam1', 1 ).
test( 't98', 490, [], ['r1','r3'], 'fam1', 1 ).
test( 't99', 481, [], [], 'fam1', 1 ).
test( 't100', 539, ['m34','m11','m31','m6','m25','m42','m35'], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').
embedded_board( 'm21').
embedded_board( 'm22').
embedded_board( 'm23').
embedded_board( 'm24').
embedded_board( 'm25').
embedded_board( 'm26').
embedded_board( 'm27').
embedded_board( 'm28').
embedded_board( 'm29').
embedded_board( 'm30').
embedded_board( 'm31').
embedded_board( 'm32').
embedded_board( 'm33').
embedded_board( 'm34').
embedded_board( 'm35').
embedded_board( 'm36').
embedded_board( 'm37').
embedded_board( 'm38').
embedded_board( 'm39').
embedded_board( 'm40').
embedded_board( 'm41').
embedded_board( 'm42').
embedded_board( 'm43').
embedded_board( 'm44').
embedded_board( 'm45').
embedded_board( 'm46').
embedded_board( 'm47').
embedded_board( 'm48').
embedded_board( 'm49').
embedded_board( 'm50').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
