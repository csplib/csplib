%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 10
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 374, [], [], 'fam1', 1 ).
test( 't2', 574, [], [], 'fam1', 1 ).
test( 't3', 724, [], [], 'fam1', 1 ).
test( 't4', 62, [], [], 'fam1', 1 ).
test( 't5', 406, [], [], 'fam1', 1 ).
test( 't6', 462, [], [], 'fam1', 1 ).
test( 't7', 375, [], [], 'fam1', 1 ).
test( 't8', 229, ['m3','m5','m9'], ['r10','r9','r5','r1'], 'fam1', 1 ).
test( 't9', 313, [], [], 'fam1', 1 ).
test( 't10', 29, ['m10','m7','m9','m5'], [], 'fam1', 1 ).
test( 't11', 468, [], [], 'fam1', 1 ).
test( 't12', 59, [], [], 'fam1', 1 ).
test( 't13', 405, [], [], 'fam1', 1 ).
test( 't14', 228, ['m6','m10'], [], 'fam1', 1 ).
test( 't15', 567, ['m4','m2'], [], 'fam1', 1 ).
test( 't16', 553, ['m1','m9','m10'], ['r7','r4','r10','r8','r6','r1','r3','r2','r5','r9'], 'fam1', 1 ).
test( 't17', 76, [], [], 'fam1', 1 ).
test( 't18', 144, [], [], 'fam1', 1 ).
test( 't19', 786, [], ['r9','r6','r8','r4','r10','r2','r3','r1'], 'fam1', 1 ).
test( 't20', 712, [], [], 'fam1', 1 ).
test( 't21', 318, [], [], 'fam1', 1 ).
test( 't22', 265, [], [], 'fam1', 1 ).
test( 't23', 176, ['m10','m2'], ['r8','r4','r1','r2','r10','r6'], 'fam1', 1 ).
test( 't24', 690, [], ['r5'], 'fam1', 1 ).
test( 't25', 206, [], ['r7'], 'fam1', 1 ).
test( 't26', 272, [], [], 'fam1', 1 ).
test( 't27', 5, [], [], 'fam1', 1 ).
test( 't28', 704, ['m4'], [], 'fam1', 1 ).
test( 't29', 66, [], [], 'fam1', 1 ).
test( 't30', 135, [], ['r2','r5','r7','r6','r8','r1'], 'fam1', 1 ).
test( 't31', 750, [], [], 'fam1', 1 ).
test( 't32', 727, [], [], 'fam1', 1 ).
test( 't33', 196, [], [], 'fam1', 1 ).
test( 't34', 342, [], ['r6','r9','r5','r8'], 'fam1', 1 ).
test( 't35', 507, ['m6','m4'], [], 'fam1', 1 ).
test( 't36', 643, [], [], 'fam1', 1 ).
test( 't37', 382, ['m10','m3','m6','m1'], [], 'fam1', 1 ).
test( 't38', 631, ['m10','m2','m7'], ['r9','r4','r5','r10'], 'fam1', 1 ).
test( 't39', 131, [], ['r5','r7'], 'fam1', 1 ).
test( 't40', 677, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
