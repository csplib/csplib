%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 145, [], [], 'fam1', 1 ).
test( 't2', 770, ['m8','m1'], [], 'fam1', 1 ).
test( 't3', 496, [], [], 'fam1', 1 ).
test( 't4', 567, ['m2','m7','m10','m5'], ['r3'], 'fam1', 1 ).
test( 't5', 163, [], [], 'fam1', 1 ).
test( 't6', 106, [], [], 'fam1', 1 ).
test( 't7', 305, [], ['r3','r1'], 'fam1', 1 ).
test( 't8', 274, ['m2','m6'], ['r3','r1'], 'fam1', 1 ).
test( 't9', 120, [], [], 'fam1', 1 ).
test( 't10', 82, [], [], 'fam1', 1 ).
test( 't11', 269, [], [], 'fam1', 1 ).
test( 't12', 571, [], ['r3'], 'fam1', 1 ).
test( 't13', 157, ['m10','m1','m6'], [], 'fam1', 1 ).
test( 't14', 42, [], [], 'fam1', 1 ).
test( 't15', 263, [], [], 'fam1', 1 ).
test( 't16', 339, ['m2','m4'], [], 'fam1', 1 ).
test( 't17', 480, [], ['r1'], 'fam1', 1 ).
test( 't18', 488, ['m3'], [], 'fam1', 1 ).
test( 't19', 661, [], [], 'fam1', 1 ).
test( 't20', 160, [], [], 'fam1', 1 ).
test( 't21', 346, ['m7','m9','m1'], ['r3'], 'fam1', 1 ).
test( 't22', 332, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't23', 443, [], [], 'fam1', 1 ).
test( 't24', 190, [], [], 'fam1', 1 ).
test( 't25', 686, ['m3'], [], 'fam1', 1 ).
test( 't26', 641, [], [], 'fam1', 1 ).
test( 't27', 291, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't28', 7, [], [], 'fam1', 1 ).
test( 't29', 724, ['m6','m4','m8','m5'], [], 'fam1', 1 ).
test( 't30', 480, [], [], 'fam1', 1 ).
test( 't31', 344, [], ['r1'], 'fam1', 1 ).
test( 't32', 231, [], [], 'fam1', 1 ).
test( 't33', 233, [], [], 'fam1', 1 ).
test( 't34', 416, [], ['r3'], 'fam1', 1 ).
test( 't35', 13, [], ['r3'], 'fam1', 1 ).
test( 't36', 604, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't37', 433, ['m7','m9'], [], 'fam1', 1 ).
test( 't38', 96, [], [], 'fam1', 1 ).
test( 't39', 438, [], ['r2','r3'], 'fam1', 1 ).
test( 't40', 368, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
