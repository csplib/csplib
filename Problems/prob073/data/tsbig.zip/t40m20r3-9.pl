%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 20
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 690, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't2', 415, [], [], 'fam1', 1 ).
test( 't3', 321, [], [], 'fam1', 1 ).
test( 't4', 498, [], [], 'fam1', 1 ).
test( 't5', 741, [], [], 'fam1', 1 ).
test( 't6', 789, [], [], 'fam1', 1 ).
test( 't7', 691, [], [], 'fam1', 1 ).
test( 't8', 313, [], ['r2'], 'fam1', 1 ).
test( 't9', 591, [], [], 'fam1', 1 ).
test( 't10', 224, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't11', 576, [], [], 'fam1', 1 ).
test( 't12', 229, ['m5','m15','m20','m19'], ['r3','r2'], 'fam1', 1 ).
test( 't13', 463, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't14', 516, [], ['r2','r1'], 'fam1', 1 ).
test( 't15', 393, [], ['r3'], 'fam1', 1 ).
test( 't16', 642, [], ['r2','r3'], 'fam1', 1 ).
test( 't17', 82, [], [], 'fam1', 1 ).
test( 't18', 510, [], [], 'fam1', 1 ).
test( 't19', 76, [], [], 'fam1', 1 ).
test( 't20', 35, ['m11','m13','m2','m15'], ['r2','r1'], 'fam1', 1 ).
test( 't21', 434, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't22', 492, [], [], 'fam1', 1 ).
test( 't23', 219, [], [], 'fam1', 1 ).
test( 't24', 503, [], [], 'fam1', 1 ).
test( 't25', 197, [], [], 'fam1', 1 ).
test( 't26', 244, [], [], 'fam1', 1 ).
test( 't27', 92, ['m2','m17','m12','m15','m10','m6','m18','m3'], [], 'fam1', 1 ).
test( 't28', 761, [], ['r2','r3'], 'fam1', 1 ).
test( 't29', 112, ['m16','m19','m8','m13'], [], 'fam1', 1 ).
test( 't30', 349, [], ['r2'], 'fam1', 1 ).
test( 't31', 229, [], [], 'fam1', 1 ).
test( 't32', 62, ['m12','m11','m17','m20','m1','m6'], ['r3'], 'fam1', 1 ).
test( 't33', 424, ['m7','m9'], [], 'fam1', 1 ).
test( 't34', 441, ['m6'], [], 'fam1', 1 ).
test( 't35', 432, ['m15','m2','m9','m8','m20'], ['r1'], 'fam1', 1 ).
test( 't36', 134, [], [], 'fam1', 1 ).
test( 't37', 685, [], [], 'fam1', 1 ).
test( 't38', 344, [], [], 'fam1', 1 ).
test( 't39', 680, ['m16','m17','m3','m12','m14','m13','m11'], [], 'fam1', 1 ).
test( 't40', 632, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
