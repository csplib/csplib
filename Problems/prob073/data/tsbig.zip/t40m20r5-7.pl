%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 20
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 260, [], [], 'fam1', 1 ).
test( 't2', 88, [], ['r2','r1'], 'fam1', 1 ).
test( 't3', 160, [], [], 'fam1', 1 ).
test( 't4', 190, [], ['r2'], 'fam1', 1 ).
test( 't5', 762, [], [], 'fam1', 1 ).
test( 't6', 625, [], ['r4','r3','r2','r1','r5'], 'fam1', 1 ).
test( 't7', 792, [], [], 'fam1', 1 ).
test( 't8', 556, [], [], 'fam1', 1 ).
test( 't9', 231, [], ['r2','r4','r3','r1','r5'], 'fam1', 1 ).
test( 't10', 113, [], [], 'fam1', 1 ).
test( 't11', 525, [], [], 'fam1', 1 ).
test( 't12', 767, [], [], 'fam1', 1 ).
test( 't13', 21, [], [], 'fam1', 1 ).
test( 't14', 533, [], [], 'fam1', 1 ).
test( 't15', 414, [], [], 'fam1', 1 ).
test( 't16', 697, ['m9','m14','m15'], [], 'fam1', 1 ).
test( 't17', 94, ['m11','m20'], [], 'fam1', 1 ).
test( 't18', 19, ['m6','m17','m15','m1','m14','m12','m16','m5'], [], 'fam1', 1 ).
test( 't19', 506, ['m12','m11','m20'], [], 'fam1', 1 ).
test( 't20', 51, [], [], 'fam1', 1 ).
test( 't21', 127, [], [], 'fam1', 1 ).
test( 't22', 575, [], [], 'fam1', 1 ).
test( 't23', 99, [], ['r1'], 'fam1', 1 ).
test( 't24', 237, [], [], 'fam1', 1 ).
test( 't25', 308, [], [], 'fam1', 1 ).
test( 't26', 665, ['m10','m17','m15','m19','m2'], [], 'fam1', 1 ).
test( 't27', 351, [], [], 'fam1', 1 ).
test( 't28', 278, ['m10','m9','m5'], [], 'fam1', 1 ).
test( 't29', 2, [], [], 'fam1', 1 ).
test( 't30', 517, [], [], 'fam1', 1 ).
test( 't31', 640, [], [], 'fam1', 1 ).
test( 't32', 132, [], [], 'fam1', 1 ).
test( 't33', 801, [], [], 'fam1', 1 ).
test( 't34', 236, [], [], 'fam1', 1 ).
test( 't35', 175, [], ['r1','r5'], 'fam1', 1 ).
test( 't36', 226, [], [], 'fam1', 1 ).
test( 't37', 58, [], [], 'fam1', 1 ).
test( 't38', 509, [], [], 'fam1', 1 ).
test( 't39', 492, [], [], 'fam1', 1 ).
test( 't40', 312, [], ['r4'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
