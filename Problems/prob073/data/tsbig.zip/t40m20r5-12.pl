%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 20
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 640, [], [], 'fam1', 1 ).
test( 't2', 800, [], [], 'fam1', 1 ).
test( 't3', 724, [], [], 'fam1', 1 ).
test( 't4', 685, [], [], 'fam1', 1 ).
test( 't5', 801, [], [], 'fam1', 1 ).
test( 't6', 233, [], [], 'fam1', 1 ).
test( 't7', 370, [], [], 'fam1', 1 ).
test( 't8', 418, [], [], 'fam1', 1 ).
test( 't9', 286, [], [], 'fam1', 1 ).
test( 't10', 88, [], [], 'fam1', 1 ).
test( 't11', 343, ['m18','m10','m6','m19'], ['r5','r4','r1','r2','r3'], 'fam1', 1 ).
test( 't12', 64, [], ['r1','r4','r3'], 'fam1', 1 ).
test( 't13', 556, [], ['r4','r1','r3','r2'], 'fam1', 1 ).
test( 't14', 314, [], [], 'fam1', 1 ).
test( 't15', 591, [], ['r5','r3'], 'fam1', 1 ).
test( 't16', 581, [], [], 'fam1', 1 ).
test( 't17', 776, [], ['r5','r2','r3'], 'fam1', 1 ).
test( 't18', 626, ['m9','m17','m19','m3','m11'], [], 'fam1', 1 ).
test( 't19', 551, [], [], 'fam1', 1 ).
test( 't20', 180, [], ['r3','r2','r4','r1'], 'fam1', 1 ).
test( 't21', 374, [], [], 'fam1', 1 ).
test( 't22', 791, [], ['r5','r2','r3','r1'], 'fam1', 1 ).
test( 't23', 752, [], ['r1'], 'fam1', 1 ).
test( 't24', 20, [], ['r1','r3'], 'fam1', 1 ).
test( 't25', 722, [], [], 'fam1', 1 ).
test( 't26', 357, [], ['r3','r2'], 'fam1', 1 ).
test( 't27', 419, [], ['r3','r4'], 'fam1', 1 ).
test( 't28', 82, [], [], 'fam1', 1 ).
test( 't29', 358, [], [], 'fam1', 1 ).
test( 't30', 279, [], [], 'fam1', 1 ).
test( 't31', 450, [], ['r1','r4','r2','r5','r3'], 'fam1', 1 ).
test( 't32', 785, [], [], 'fam1', 1 ).
test( 't33', 339, [], ['r3','r2','r5','r4'], 'fam1', 1 ).
test( 't34', 169, ['m6','m7','m12','m18','m11','m19'], [], 'fam1', 1 ).
test( 't35', 234, [], ['r4','r5'], 'fam1', 1 ).
test( 't36', 89, [], ['r5','r1','r2','r3','r4'], 'fam1', 1 ).
test( 't37', 347, [], [], 'fam1', 1 ).
test( 't38', 371, ['m15','m14','m12','m4'], ['r1','r2','r3'], 'fam1', 1 ).
test( 't39', 125, [], [], 'fam1', 1 ).
test( 't40', 130, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
