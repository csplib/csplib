%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 454, [], ['r1'], 'fam1', 1 ).
test( 't2', 249, ['m4','m10','m6'], [], 'fam1', 1 ).
test( 't3', 268, [], [], 'fam1', 1 ).
test( 't4', 789, [], [], 'fam1', 1 ).
test( 't5', 609, [], [], 'fam1', 1 ).
test( 't6', 554, [], ['r4','r3','r1','r2'], 'fam1', 1 ).
test( 't7', 228, ['m4','m7','m8'], ['r1','r5','r2','r3'], 'fam1', 1 ).
test( 't8', 562, [], ['r4','r2','r1'], 'fam1', 1 ).
test( 't9', 14, [], [], 'fam1', 1 ).
test( 't10', 548, [], [], 'fam1', 1 ).
test( 't11', 666, [], [], 'fam1', 1 ).
test( 't12', 552, ['m9'], [], 'fam1', 1 ).
test( 't13', 256, [], [], 'fam1', 1 ).
test( 't14', 107, [], ['r5','r2','r1','r3'], 'fam1', 1 ).
test( 't15', 291, [], [], 'fam1', 1 ).
test( 't16', 268, [], ['r2'], 'fam1', 1 ).
test( 't17', 642, [], [], 'fam1', 1 ).
test( 't18', 662, [], [], 'fam1', 1 ).
test( 't19', 438, [], [], 'fam1', 1 ).
test( 't20', 614, [], [], 'fam1', 1 ).
test( 't21', 112, [], [], 'fam1', 1 ).
test( 't22', 281, [], [], 'fam1', 1 ).
test( 't23', 113, ['m10','m3'], [], 'fam1', 1 ).
test( 't24', 26, [], [], 'fam1', 1 ).
test( 't25', 722, [], ['r1'], 'fam1', 1 ).
test( 't26', 335, ['m9','m5','m4','m8'], ['r5','r1','r4'], 'fam1', 1 ).
test( 't27', 81, [], [], 'fam1', 1 ).
test( 't28', 75, [], [], 'fam1', 1 ).
test( 't29', 420, [], [], 'fam1', 1 ).
test( 't30', 41, [], ['r2','r3'], 'fam1', 1 ).
test( 't31', 383, [], ['r2','r5'], 'fam1', 1 ).
test( 't32', 92, [], [], 'fam1', 1 ).
test( 't33', 210, [], ['r2','r1','r3','r5','r4'], 'fam1', 1 ).
test( 't34', 580, [], [], 'fam1', 1 ).
test( 't35', 270, [], ['r4'], 'fam1', 1 ).
test( 't36', 67, [], ['r5','r1','r4'], 'fam1', 1 ).
test( 't37', 125, [], [], 'fam1', 1 ).
test( 't38', 241, [], [], 'fam1', 1 ).
test( 't39', 616, [], ['r5'], 'fam1', 1 ).
test( 't40', 189, [], [], 'fam1', 1 ).
test( 't41', 60, ['m3'], [], 'fam1', 1 ).
test( 't42', 745, [], [], 'fam1', 1 ).
test( 't43', 446, ['m8','m6'], [], 'fam1', 1 ).
test( 't44', 165, [], [], 'fam1', 1 ).
test( 't45', 21, [], ['r3','r5','r4'], 'fam1', 1 ).
test( 't46', 87, [], [], 'fam1', 1 ).
test( 't47', 13, [], ['r5'], 'fam1', 1 ).
test( 't48', 723, [], [], 'fam1', 1 ).
test( 't49', 227, [], [], 'fam1', 1 ).
test( 't50', 256, ['m3','m9','m1','m10'], ['r4','r1','r3','r2','r5'], 'fam1', 1 ).
test( 't51', 662, ['m2','m3','m9'], [], 'fam1', 1 ).
test( 't52', 470, [], [], 'fam1', 1 ).
test( 't53', 81, [], [], 'fam1', 1 ).
test( 't54', 105, ['m2'], [], 'fam1', 1 ).
test( 't55', 217, [], ['r5','r3'], 'fam1', 1 ).
test( 't56', 580, ['m6','m10','m7'], ['r4'], 'fam1', 1 ).
test( 't57', 744, [], [], 'fam1', 1 ).
test( 't58', 309, [], ['r4','r3','r5','r2'], 'fam1', 1 ).
test( 't59', 343, [], ['r5'], 'fam1', 1 ).
test( 't60', 677, [], [], 'fam1', 1 ).
test( 't61', 700, [], ['r2','r1','r4','r5'], 'fam1', 1 ).
test( 't62', 718, [], [], 'fam1', 1 ).
test( 't63', 155, [], [], 'fam1', 1 ).
test( 't64', 717, [], [], 'fam1', 1 ).
test( 't65', 62, [], [], 'fam1', 1 ).
test( 't66', 793, [], [], 'fam1', 1 ).
test( 't67', 540, [], [], 'fam1', 1 ).
test( 't68', 534, [], ['r5','r1','r3'], 'fam1', 1 ).
test( 't69', 86, ['m1','m8'], ['r4'], 'fam1', 1 ).
test( 't70', 431, [], [], 'fam1', 1 ).
test( 't71', 115, [], [], 'fam1', 1 ).
test( 't72', 205, [], [], 'fam1', 1 ).
test( 't73', 341, [], [], 'fam1', 1 ).
test( 't74', 715, [], [], 'fam1', 1 ).
test( 't75', 618, [], [], 'fam1', 1 ).
test( 't76', 118, ['m10','m5'], [], 'fam1', 1 ).
test( 't77', 642, [], ['r3','r2'], 'fam1', 1 ).
test( 't78', 466, [], [], 'fam1', 1 ).
test( 't79', 603, [], [], 'fam1', 1 ).
test( 't80', 406, [], [], 'fam1', 1 ).
test( 't81', 483, [], [], 'fam1', 1 ).
test( 't82', 801, ['m2'], ['r3','r4','r1','r5'], 'fam1', 1 ).
test( 't83', 75, [], ['r3','r2'], 'fam1', 1 ).
test( 't84', 320, ['m1'], ['r4','r2','r1','r5','r3'], 'fam1', 1 ).
test( 't85', 613, [], [], 'fam1', 1 ).
test( 't86', 11, [], ['r3','r1','r5'], 'fam1', 1 ).
test( 't87', 330, [], [], 'fam1', 1 ).
test( 't88', 681, [], [], 'fam1', 1 ).
test( 't89', 433, [], [], 'fam1', 1 ).
test( 't90', 378, [], [], 'fam1', 1 ).
test( 't91', 104, ['m2','m7','m10'], ['r1','r2'], 'fam1', 1 ).
test( 't92', 602, [], ['r3'], 'fam1', 1 ).
test( 't93', 755, [], ['r2'], 'fam1', 1 ).
test( 't94', 390, [], [], 'fam1', 1 ).
test( 't95', 643, [], ['r5','r3','r1'], 'fam1', 1 ).
test( 't96', 179, [], ['r4','r5'], 'fam1', 1 ).
test( 't97', 589, [], [], 'fam1', 1 ).
test( 't98', 409, ['m6','m9'], [], 'fam1', 1 ).
test( 't99', 24, [], [], 'fam1', 1 ).
test( 't100', 786, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
