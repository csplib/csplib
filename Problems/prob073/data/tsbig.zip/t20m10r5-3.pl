%% ****  Testsuite  ****
% Number of tests                  : 20
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 348, [], [], 'fam1', 1 ).
test( 't2', 176, [], ['r5','r4','r3','r1'], 'fam1', 1 ).
test( 't3', 305, [], [], 'fam1', 1 ).
test( 't4', 664, [], [], 'fam1', 1 ).
test( 't5', 382, ['m4','m6','m7'], [], 'fam1', 1 ).
test( 't6', 459, ['m8','m4','m2','m9'], [], 'fam1', 1 ).
test( 't7', 768, [], ['r3','r5','r4','r1'], 'fam1', 1 ).
test( 't8', 126, [], [], 'fam1', 1 ).
test( 't9', 801, [], [], 'fam1', 1 ).
test( 't10', 589, [], [], 'fam1', 1 ).
test( 't11', 595, [], [], 'fam1', 1 ).
test( 't12', 87, [], ['r3'], 'fam1', 1 ).
test( 't13', 263, [], ['r3','r1'], 'fam1', 1 ).
test( 't14', 778, [], [], 'fam1', 1 ).
test( 't15', 462, [], ['r5','r2'], 'fam1', 1 ).
test( 't16', 512, ['m6','m2','m10','m4'], [], 'fam1', 1 ).
test( 't17', 573, [], [], 'fam1', 1 ).
test( 't18', 234, ['m6','m2'], [], 'fam1', 1 ).
test( 't19', 527, [], [], 'fam1', 1 ).
test( 't20', 793, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
