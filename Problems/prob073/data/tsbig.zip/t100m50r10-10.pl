%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 50
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 568, [], [], 'fam1', 1 ).
test( 't2', 551, [], [], 'fam1', 1 ).
test( 't3', 781, ['m41','m40','m27','m1','m31','m2','m32','m48','m14','m46','m11','m49','m4'], [], 'fam1', 1 ).
test( 't4', 630, [], [], 'fam1', 1 ).
test( 't5', 354, [], ['r7','r1'], 'fam1', 1 ).
test( 't6', 51, ['m19','m25','m47','m16','m33','m4','m46','m31','m6','m32','m13','m15'], ['r5','r10'], 'fam1', 1 ).
test( 't7', 399, [], [], 'fam1', 1 ).
test( 't8', 180, [], ['r3','r2'], 'fam1', 1 ).
test( 't9', 677, [], [], 'fam1', 1 ).
test( 't10', 782, [], [], 'fam1', 1 ).
test( 't11', 254, [], [], 'fam1', 1 ).
test( 't12', 125, [], [], 'fam1', 1 ).
test( 't13', 689, [], [], 'fam1', 1 ).
test( 't14', 59, [], [], 'fam1', 1 ).
test( 't15', 526, ['m27','m49','m1','m40','m11','m14','m15','m6','m17','m16','m7','m46','m8','m26','m29','m32'], ['r3','r6','r5'], 'fam1', 1 ).
test( 't16', 179, ['m12','m11','m1','m43','m44','m16','m20','m38','m4','m29'], [], 'fam1', 1 ).
test( 't17', 770, ['m28','m48','m34','m1','m25','m20'], [], 'fam1', 1 ).
test( 't18', 56, [], ['r4','r6'], 'fam1', 1 ).
test( 't19', 711, ['m5','m19','m33','m12','m27','m2','m26','m20','m49','m13','m50','m36','m17','m28','m11','m8'], [], 'fam1', 1 ).
test( 't20', 539, [], [], 'fam1', 1 ).
test( 't21', 733, ['m35','m3','m27','m47','m17','m45'], [], 'fam1', 1 ).
test( 't22', 793, [], [], 'fam1', 1 ).
test( 't23', 245, [], ['r5','r6','r7','r9','r3','r1'], 'fam1', 1 ).
test( 't24', 412, ['m45','m20','m38','m25','m10','m2','m15','m7','m27','m4','m30','m29','m13'], [], 'fam1', 1 ).
test( 't25', 316, ['m17','m31','m16','m28','m11','m39'], [], 'fam1', 1 ).
test( 't26', 196, [], [], 'fam1', 1 ).
test( 't27', 554, [], [], 'fam1', 1 ).
test( 't28', 127, [], ['r6'], 'fam1', 1 ).
test( 't29', 392, [], ['r8','r9','r1'], 'fam1', 1 ).
test( 't30', 258, ['m9','m10','m23','m49','m41'], [], 'fam1', 1 ).
test( 't31', 100, [], ['r7','r10','r4','r6','r5','r8','r1','r9','r3','r2'], 'fam1', 1 ).
test( 't32', 552, [], [], 'fam1', 1 ).
test( 't33', 292, [], [], 'fam1', 1 ).
test( 't34', 675, [], [], 'fam1', 1 ).
test( 't35', 435, ['m29','m35','m23','m45','m30','m5','m9','m18','m12','m31','m43','m25'], [], 'fam1', 1 ).
test( 't36', 534, [], [], 'fam1', 1 ).
test( 't37', 446, [], [], 'fam1', 1 ).
test( 't38', 247, [], [], 'fam1', 1 ).
test( 't39', 496, [], [], 'fam1', 1 ).
test( 't40', 268, [], ['r8','r6','r3','r1','r5','r9','r7','r2','r4'], 'fam1', 1 ).
test( 't41', 84, [], ['r1','r4','r3','r2','r9','r8','r6','r5','r7'], 'fam1', 1 ).
test( 't42', 243, [], ['r1','r7','r9','r8','r2','r5','r3','r10'], 'fam1', 1 ).
test( 't43', 109, [], [], 'fam1', 1 ).
test( 't44', 624, [], ['r8','r9','r7','r6'], 'fam1', 1 ).
test( 't45', 244, [], [], 'fam1', 1 ).
test( 't46', 17, [], ['r6','r8','r10','r2','r5','r3','r9'], 'fam1', 1 ).
test( 't47', 598, [], ['r6','r9'], 'fam1', 1 ).
test( 't48', 796, [], [], 'fam1', 1 ).
test( 't49', 387, [], [], 'fam1', 1 ).
test( 't50', 63, [], ['r4','r10','r1','r5','r6','r8','r2'], 'fam1', 1 ).
test( 't51', 736, [], [], 'fam1', 1 ).
test( 't52', 7, [], [], 'fam1', 1 ).
test( 't53', 412, ['m44','m40','m6','m10','m24','m4','m48','m14','m42'], [], 'fam1', 1 ).
test( 't54', 169, [], [], 'fam1', 1 ).
test( 't55', 387, [], [], 'fam1', 1 ).
test( 't56', 321, ['m17','m29','m25','m33','m50','m47','m11'], [], 'fam1', 1 ).
test( 't57', 377, [], [], 'fam1', 1 ).
test( 't58', 99, [], ['r10'], 'fam1', 1 ).
test( 't59', 765, ['m12','m21','m39','m27','m10','m7','m18','m41','m6','m23','m49','m34','m1','m15','m19','m16','m24','m14','m42','m26'], [], 'fam1', 1 ).
test( 't60', 428, [], [], 'fam1', 1 ).
test( 't61', 503, [], [], 'fam1', 1 ).
test( 't62', 509, [], ['r3','r10','r1'], 'fam1', 1 ).
test( 't63', 132, [], ['r5','r6','r7','r2','r4','r8','r9','r1'], 'fam1', 1 ).
test( 't64', 121, ['m21','m16','m7','m50','m13','m28','m36','m31','m40'], [], 'fam1', 1 ).
test( 't65', 211, [], [], 'fam1', 1 ).
test( 't66', 205, ['m1','m39','m8','m10','m47','m19','m23','m45','m44','m20','m31','m40','m28','m38','m43','m41','m9'], [], 'fam1', 1 ).
test( 't67', 241, [], [], 'fam1', 1 ).
test( 't68', 98, [], [], 'fam1', 1 ).
test( 't69', 592, [], [], 'fam1', 1 ).
test( 't70', 108, [], [], 'fam1', 1 ).
test( 't71', 148, [], ['r3'], 'fam1', 1 ).
test( 't72', 610, [], [], 'fam1', 1 ).
test( 't73', 437, [], [], 'fam1', 1 ).
test( 't74', 300, [], [], 'fam1', 1 ).
test( 't75', 467, [], [], 'fam1', 1 ).
test( 't76', 122, [], ['r4'], 'fam1', 1 ).
test( 't77', 568, [], ['r7','r5','r3','r6','r2','r8','r10','r9','r1','r4'], 'fam1', 1 ).
test( 't78', 376, [], [], 'fam1', 1 ).
test( 't79', 109, [], [], 'fam1', 1 ).
test( 't80', 693, [], [], 'fam1', 1 ).
test( 't81', 717, [], [], 'fam1', 1 ).
test( 't82', 370, ['m29','m12','m27','m8','m2','m42','m44','m7','m37','m43','m23','m31','m10','m19','m20'], [], 'fam1', 1 ).
test( 't83', 719, [], ['r7','r8','r5','r2','r3','r1','r10','r4','r6','r9'], 'fam1', 1 ).
test( 't84', 218, ['m6','m20'], ['r5','r7','r10'], 'fam1', 1 ).
test( 't85', 157, [], [], 'fam1', 1 ).
test( 't86', 21, [], [], 'fam1', 1 ).
test( 't87', 306, [], ['r1','r5','r6','r8','r10','r4','r7','r2'], 'fam1', 1 ).
test( 't88', 413, [], ['r1','r7','r5'], 'fam1', 1 ).
test( 't89', 323, [], ['r4','r10','r2','r8'], 'fam1', 1 ).
test( 't90', 775, [], [], 'fam1', 1 ).
test( 't91', 716, ['m4','m15','m20','m23','m28','m22','m11','m36','m42'], ['r8'], 'fam1', 1 ).
test( 't92', 331, [], ['r7','r10','r6','r3'], 'fam1', 1 ).
test( 't93', 17, [], [], 'fam1', 1 ).
test( 't94', 344, [], ['r3','r4','r8','r7','r10','r2','r6','r1','r5','r9'], 'fam1', 1 ).
test( 't95', 332, ['m21','m50','m35','m14','m40','m9','m1','m41','m3','m25','m17','m37','m27'], [], 'fam1', 1 ).
test( 't96', 146, [], [], 'fam1', 1 ).
test( 't97', 732, [], [], 'fam1', 1 ).
test( 't98', 320, [], [], 'fam1', 1 ).
test( 't99', 227, [], [], 'fam1', 1 ).
test( 't100', 215, ['m31','m38'], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').
embedded_board( 'm21').
embedded_board( 'm22').
embedded_board( 'm23').
embedded_board( 'm24').
embedded_board( 'm25').
embedded_board( 'm26').
embedded_board( 'm27').
embedded_board( 'm28').
embedded_board( 'm29').
embedded_board( 'm30').
embedded_board( 'm31').
embedded_board( 'm32').
embedded_board( 'm33').
embedded_board( 'm34').
embedded_board( 'm35').
embedded_board( 'm36').
embedded_board( 'm37').
embedded_board( 'm38').
embedded_board( 'm39').
embedded_board( 'm40').
embedded_board( 'm41').
embedded_board( 'm42').
embedded_board( 'm43').
embedded_board( 'm44').
embedded_board( 'm45').
embedded_board( 'm46').
embedded_board( 'm47').
embedded_board( 'm48').
embedded_board( 'm49').
embedded_board( 'm50').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
