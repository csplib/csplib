%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 118, [], [], 'fam1', 1 ).
test( 't2', 308, [], [], 'fam1', 1 ).
test( 't3', 218, ['m9','m5','m8','m4'], ['r1'], 'fam1', 1 ).
test( 't4', 635, ['m9','m2','m5','m1'], [], 'fam1', 1 ).
test( 't5', 187, ['m4'], [], 'fam1', 1 ).
test( 't6', 747, ['m7','m4','m3'], [], 'fam1', 1 ).
test( 't7', 487, [], ['r1'], 'fam1', 1 ).
test( 't8', 535, ['m5','m10','m9','m7'], ['r1','r3','r2'], 'fam1', 1 ).
test( 't9', 220, [], [], 'fam1', 1 ).
test( 't10', 392, [], ['r1'], 'fam1', 1 ).
test( 't11', 704, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't12', 376, [], [], 'fam1', 1 ).
test( 't13', 490, [], [], 'fam1', 1 ).
test( 't14', 639, [], ['r2','r3'], 'fam1', 1 ).
test( 't15', 520, [], [], 'fam1', 1 ).
test( 't16', 378, [], [], 'fam1', 1 ).
test( 't17', 419, [], [], 'fam1', 1 ).
test( 't18', 399, ['m5'], ['r1','r3','r2'], 'fam1', 1 ).
test( 't19', 53, [], [], 'fam1', 1 ).
test( 't20', 686, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't21', 307, ['m6','m8','m5','m4'], ['r2','r1'], 'fam1', 1 ).
test( 't22', 428, [], [], 'fam1', 1 ).
test( 't23', 525, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't24', 353, [], [], 'fam1', 1 ).
test( 't25', 9, [], [], 'fam1', 1 ).
test( 't26', 279, [], [], 'fam1', 1 ).
test( 't27', 719, [], [], 'fam1', 1 ).
test( 't28', 188, [], [], 'fam1', 1 ).
test( 't29', 633, [], [], 'fam1', 1 ).
test( 't30', 4, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
