%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 20
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 350, [], [], 'fam1', 1 ).
test( 't2', 432, [], ['r4','r5'], 'fam1', 1 ).
test( 't3', 800, [], [], 'fam1', 1 ).
test( 't4', 214, [], ['r5','r2'], 'fam1', 1 ).
test( 't5', 313, [], ['r3','r1'], 'fam1', 1 ).
test( 't6', 343, [], ['r5','r4'], 'fam1', 1 ).
test( 't7', 240, ['m16','m6','m20','m5','m10'], [], 'fam1', 1 ).
test( 't8', 740, [], [], 'fam1', 1 ).
test( 't9', 267, ['m10','m20','m2'], ['r1','r2','r3','r5','r4'], 'fam1', 1 ).
test( 't10', 212, [], [], 'fam1', 1 ).
test( 't11', 404, [], [], 'fam1', 1 ).
test( 't12', 270, [], ['r3'], 'fam1', 1 ).
test( 't13', 770, [], [], 'fam1', 1 ).
test( 't14', 715, [], [], 'fam1', 1 ).
test( 't15', 377, [], [], 'fam1', 1 ).
test( 't16', 346, [], ['r3','r5'], 'fam1', 1 ).
test( 't17', 204, [], ['r3','r5','r4'], 'fam1', 1 ).
test( 't18', 122, [], [], 'fam1', 1 ).
test( 't19', 169, [], [], 'fam1', 1 ).
test( 't20', 198, [], [], 'fam1', 1 ).
test( 't21', 252, [], ['r3','r2','r5','r1'], 'fam1', 1 ).
test( 't22', 243, [], [], 'fam1', 1 ).
test( 't23', 116, [], ['r4','r5','r2'], 'fam1', 1 ).
test( 't24', 140, [], [], 'fam1', 1 ).
test( 't25', 653, [], ['r3','r5','r4','r2','r1'], 'fam1', 1 ).
test( 't26', 80, [], [], 'fam1', 1 ).
test( 't27', 758, ['m17','m13','m16','m11','m8','m19','m14'], [], 'fam1', 1 ).
test( 't28', 743, ['m1'], ['r4'], 'fam1', 1 ).
test( 't29', 164, [], ['r4','r5'], 'fam1', 1 ).
test( 't30', 329, ['m5','m19','m14','m6','m9'], [], 'fam1', 1 ).
test( 't31', 647, [], [], 'fam1', 1 ).
test( 't32', 590, [], [], 'fam1', 1 ).
test( 't33', 20, [], [], 'fam1', 1 ).
test( 't34', 733, ['m20','m13','m9','m8','m14','m12'], [], 'fam1', 1 ).
test( 't35', 753, ['m16'], [], 'fam1', 1 ).
test( 't36', 324, [], [], 'fam1', 1 ).
test( 't37', 608, [], ['r2','r4','r3','r5','r1'], 'fam1', 1 ).
test( 't38', 267, [], [], 'fam1', 1 ).
test( 't39', 555, [], [], 'fam1', 1 ).
test( 't40', 579, ['m20'], [], 'fam1', 1 ).
test( 't41', 596, [], [], 'fam1', 1 ).
test( 't42', 482, [], [], 'fam1', 1 ).
test( 't43', 471, [], ['r1','r5','r2','r4'], 'fam1', 1 ).
test( 't44', 442, ['m5','m9','m1','m3','m8','m11'], ['r1'], 'fam1', 1 ).
test( 't45', 281, [], [], 'fam1', 1 ).
test( 't46', 267, [], [], 'fam1', 1 ).
test( 't47', 662, [], ['r3'], 'fam1', 1 ).
test( 't48', 694, [], [], 'fam1', 1 ).
test( 't49', 457, [], [], 'fam1', 1 ).
test( 't50', 453, [], [], 'fam1', 1 ).
test( 't51', 346, [], [], 'fam1', 1 ).
test( 't52', 168, [], [], 'fam1', 1 ).
test( 't53', 323, [], [], 'fam1', 1 ).
test( 't54', 551, ['m9','m5','m16','m13','m10'], ['r1'], 'fam1', 1 ).
test( 't55', 84, [], [], 'fam1', 1 ).
test( 't56', 593, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't57', 621, [], ['r1','r3','r4','r2'], 'fam1', 1 ).
test( 't58', 705, [], [], 'fam1', 1 ).
test( 't59', 736, [], [], 'fam1', 1 ).
test( 't60', 697, [], [], 'fam1', 1 ).
test( 't61', 194, [], [], 'fam1', 1 ).
test( 't62', 405, ['m16','m1','m10','m14'], [], 'fam1', 1 ).
test( 't63', 448, [], [], 'fam1', 1 ).
test( 't64', 47, [], ['r2','r5'], 'fam1', 1 ).
test( 't65', 244, [], ['r1'], 'fam1', 1 ).
test( 't66', 120, [], [], 'fam1', 1 ).
test( 't67', 372, ['m19','m11','m13','m18','m5','m20','m9'], ['r2'], 'fam1', 1 ).
test( 't68', 35, ['m1','m18','m7'], [], 'fam1', 1 ).
test( 't69', 671, [], ['r5','r4','r1','r3'], 'fam1', 1 ).
test( 't70', 50, [], [], 'fam1', 1 ).
test( 't71', 130, [], [], 'fam1', 1 ).
test( 't72', 209, [], [], 'fam1', 1 ).
test( 't73', 784, ['m9'], [], 'fam1', 1 ).
test( 't74', 83, [], [], 'fam1', 1 ).
test( 't75', 531, ['m20','m19','m13'], [], 'fam1', 1 ).
test( 't76', 591, [], [], 'fam1', 1 ).
test( 't77', 670, [], ['r2','r5','r3'], 'fam1', 1 ).
test( 't78', 500, ['m15','m19','m10','m3','m11','m1'], ['r5'], 'fam1', 1 ).
test( 't79', 232, [], [], 'fam1', 1 ).
test( 't80', 77, [], [], 'fam1', 1 ).
test( 't81', 9, [], [], 'fam1', 1 ).
test( 't82', 66, [], [], 'fam1', 1 ).
test( 't83', 444, [], [], 'fam1', 1 ).
test( 't84', 529, [], [], 'fam1', 1 ).
test( 't85', 638, [], [], 'fam1', 1 ).
test( 't86', 481, [], [], 'fam1', 1 ).
test( 't87', 344, [], [], 'fam1', 1 ).
test( 't88', 279, [], ['r3','r5','r4','r1'], 'fam1', 1 ).
test( 't89', 70, [], [], 'fam1', 1 ).
test( 't90', 117, [], [], 'fam1', 1 ).
test( 't91', 203, ['m1','m12','m3'], ['r3','r5','r1','r4','r2'], 'fam1', 1 ).
test( 't92', 525, [], ['r3','r2'], 'fam1', 1 ).
test( 't93', 770, [], ['r5'], 'fam1', 1 ).
test( 't94', 372, ['m14','m13','m16','m8','m2','m18','m15','m19'], [], 'fam1', 1 ).
test( 't95', 181, [], [], 'fam1', 1 ).
test( 't96', 100, [], [], 'fam1', 1 ).
test( 't97', 341, ['m2','m14','m5'], ['r4','r1','r3','r2','r5'], 'fam1', 1 ).
test( 't98', 370, [], ['r3','r5','r1','r4','r2'], 'fam1', 1 ).
test( 't99', 783, ['m9','m1'], ['r3','r2','r5'], 'fam1', 1 ).
test( 't100', 428, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
