%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 50
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 557, ['m40','m3','m25','m33','m29','m15','m18','m4'], [], 'fam1', 1 ).
test( 't2', 783, [], ['r1','r3','r5','r2'], 'fam1', 1 ).
test( 't3', 236, [], [], 'fam1', 1 ).
test( 't4', 428, ['m29','m39','m21','m18'], [], 'fam1', 1 ).
test( 't5', 509, [], ['r5','r1','r2','r4'], 'fam1', 1 ).
test( 't6', 436, ['m19','m3','m9','m43','m39','m33','m38'], [], 'fam1', 1 ).
test( 't7', 212, [], [], 'fam1', 1 ).
test( 't8', 481, [], ['r4','r1'], 'fam1', 1 ).
test( 't9', 616, ['m19','m44','m29','m9','m20','m26','m46','m11','m21','m39'], ['r1'], 'fam1', 1 ).
test( 't10', 581, [], ['r1','r5','r2','r3','r4'], 'fam1', 1 ).
test( 't11', 361, ['m20','m28','m31','m14','m38','m2'], [], 'fam1', 1 ).
test( 't12', 517, ['m7','m33','m22','m11','m20'], ['r2','r4'], 'fam1', 1 ).
test( 't13', 224, [], [], 'fam1', 1 ).
test( 't14', 126, [], [], 'fam1', 1 ).
test( 't15', 57, [], [], 'fam1', 1 ).
test( 't16', 135, [], [], 'fam1', 1 ).
test( 't17', 387, [], [], 'fam1', 1 ).
test( 't18', 744, [], [], 'fam1', 1 ).
test( 't19', 111, ['m8','m23','m27','m13','m6','m25','m41','m34','m36','m48','m3','m19','m33','m20'], ['r2','r4','r5','r3','r1'], 'fam1', 1 ).
test( 't20', 530, [], [], 'fam1', 1 ).
test( 't21', 178, [], [], 'fam1', 1 ).
test( 't22', 268, [], [], 'fam1', 1 ).
test( 't23', 241, [], [], 'fam1', 1 ).
test( 't24', 513, [], [], 'fam1', 1 ).
test( 't25', 104, [], [], 'fam1', 1 ).
test( 't26', 179, [], [], 'fam1', 1 ).
test( 't27', 212, [], [], 'fam1', 1 ).
test( 't28', 397, [], ['r2'], 'fam1', 1 ).
test( 't29', 669, [], ['r1'], 'fam1', 1 ).
test( 't30', 740, ['m29','m46','m27','m20','m6','m7','m15','m24','m19','m2','m44','m12','m43','m31','m50','m10','m4','m18'], [], 'fam1', 1 ).
test( 't31', 728, [], [], 'fam1', 1 ).
test( 't32', 749, [], [], 'fam1', 1 ).
test( 't33', 194, [], ['r1','r5','r2','r3','r4'], 'fam1', 1 ).
test( 't34', 374, [], [], 'fam1', 1 ).
test( 't35', 95, [], [], 'fam1', 1 ).
test( 't36', 272, [], [], 'fam1', 1 ).
test( 't37', 48, ['m12','m40','m9','m20','m21'], ['r2','r3','r1'], 'fam1', 1 ).
test( 't38', 230, ['m27','m29','m2','m6','m18','m16','m13','m12','m35','m40','m3','m5','m34','m14','m41','m1','m4','m21','m8','m28'], [], 'fam1', 1 ).
test( 't39', 71, [], [], 'fam1', 1 ).
test( 't40', 124, [], [], 'fam1', 1 ).
test( 't41', 611, [], [], 'fam1', 1 ).
test( 't42', 468, [], [], 'fam1', 1 ).
test( 't43', 233, [], [], 'fam1', 1 ).
test( 't44', 657, [], [], 'fam1', 1 ).
test( 't45', 548, [], [], 'fam1', 1 ).
test( 't46', 390, [], ['r2'], 'fam1', 1 ).
test( 't47', 726, [], [], 'fam1', 1 ).
test( 't48', 479, [], [], 'fam1', 1 ).
test( 't49', 67, [], [], 'fam1', 1 ).
test( 't50', 693, [], [], 'fam1', 1 ).
test( 't51', 290, [], ['r4'], 'fam1', 1 ).
test( 't52', 720, [], ['r1','r5','r3','r4'], 'fam1', 1 ).
test( 't53', 325, [], [], 'fam1', 1 ).
test( 't54', 318, [], [], 'fam1', 1 ).
test( 't55', 51, ['m8','m14','m13','m37','m33','m31','m44','m1'], ['r2','r5'], 'fam1', 1 ).
test( 't56', 539, [], [], 'fam1', 1 ).
test( 't57', 22, [], [], 'fam1', 1 ).
test( 't58', 442, [], [], 'fam1', 1 ).
test( 't59', 570, [], ['r5'], 'fam1', 1 ).
test( 't60', 427, [], [], 'fam1', 1 ).
test( 't61', 673, [], [], 'fam1', 1 ).
test( 't62', 225, [], ['r3','r5','r2','r4'], 'fam1', 1 ).
test( 't63', 200, [], [], 'fam1', 1 ).
test( 't64', 146, [], [], 'fam1', 1 ).
test( 't65', 63, ['m18','m37','m50','m49','m45','m10','m8','m48','m15','m7','m4','m27','m21','m11','m14','m1','m44','m19','m33'], [], 'fam1', 1 ).
test( 't66', 583, [], [], 'fam1', 1 ).
test( 't67', 564, [], [], 'fam1', 1 ).
test( 't68', 590, [], [], 'fam1', 1 ).
test( 't69', 452, [], [], 'fam1', 1 ).
test( 't70', 546, [], [], 'fam1', 1 ).
test( 't71', 576, [], [], 'fam1', 1 ).
test( 't72', 720, [], [], 'fam1', 1 ).
test( 't73', 153, [], [], 'fam1', 1 ).
test( 't74', 114, [], [], 'fam1', 1 ).
test( 't75', 355, [], [], 'fam1', 1 ).
test( 't76', 233, [], ['r4','r1'], 'fam1', 1 ).
test( 't77', 341, [], [], 'fam1', 1 ).
test( 't78', 24, [], ['r1','r2','r4','r3'], 'fam1', 1 ).
test( 't79', 582, [], [], 'fam1', 1 ).
test( 't80', 121, [], [], 'fam1', 1 ).
test( 't81', 720, [], [], 'fam1', 1 ).
test( 't82', 474, ['m26','m19','m33','m25','m23','m8','m48','m39','m2','m3'], [], 'fam1', 1 ).
test( 't83', 286, ['m29','m30','m21','m38','m48','m28','m12'], [], 'fam1', 1 ).
test( 't84', 408, [], [], 'fam1', 1 ).
test( 't85', 164, [], [], 'fam1', 1 ).
test( 't86', 585, ['m42','m21','m45','m24','m25','m39','m16','m13','m8','m28','m19','m34','m2','m44'], [], 'fam1', 1 ).
test( 't87', 337, [], [], 'fam1', 1 ).
test( 't88', 791, [], [], 'fam1', 1 ).
test( 't89', 728, [], ['r4','r3','r5','r1'], 'fam1', 1 ).
test( 't90', 141, [], [], 'fam1', 1 ).
test( 't91', 661, [], [], 'fam1', 1 ).
test( 't92', 84, ['m1','m40','m13','m43'], ['r5','r2','r3'], 'fam1', 1 ).
test( 't93', 72, [], [], 'fam1', 1 ).
test( 't94', 57, [], ['r4','r2'], 'fam1', 1 ).
test( 't95', 659, [], [], 'fam1', 1 ).
test( 't96', 520, [], [], 'fam1', 1 ).
test( 't97', 689, [], [], 'fam1', 1 ).
test( 't98', 432, [], ['r4','r1','r5','r3','r2'], 'fam1', 1 ).
test( 't99', 755, [], [], 'fam1', 1 ).
test( 't100', 632, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').
embedded_board( 'm21').
embedded_board( 'm22').
embedded_board( 'm23').
embedded_board( 'm24').
embedded_board( 'm25').
embedded_board( 'm26').
embedded_board( 'm27').
embedded_board( 'm28').
embedded_board( 'm29').
embedded_board( 'm30').
embedded_board( 'm31').
embedded_board( 'm32').
embedded_board( 'm33').
embedded_board( 'm34').
embedded_board( 'm35').
embedded_board( 'm36').
embedded_board( 'm37').
embedded_board( 'm38').
embedded_board( 'm39').
embedded_board( 'm40').
embedded_board( 'm41').
embedded_board( 'm42').
embedded_board( 'm43').
embedded_board( 'm44').
embedded_board( 'm45').
embedded_board( 'm46').
embedded_board( 'm47').
embedded_board( 'm48').
embedded_board( 'm49').
embedded_board( 'm50').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
