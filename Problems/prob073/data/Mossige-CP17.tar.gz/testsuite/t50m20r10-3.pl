%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 20
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 213, [], [], 'fam1', 1 ).
test( 't2', 509, ['m1','m19','m8','m4','m11','m7','m2','m10'], [], 'fam1', 1 ).
test( 't3', 687, [], ['r1','r9','r5','r8','r6'], 'fam1', 1 ).
test( 't4', 551, [], [], 'fam1', 1 ).
test( 't5', 402, ['m13','m6'], [], 'fam1', 1 ).
test( 't6', 738, ['m5','m7','m16','m3','m13','m19'], [], 'fam1', 1 ).
test( 't7', 30, [], [], 'fam1', 1 ).
test( 't8', 316, [], ['r1','r3','r4','r6','r8','r2','r10','r7','r5','r9'], 'fam1', 1 ).
test( 't9', 780, [], [], 'fam1', 1 ).
test( 't10', 776, [], ['r10','r2'], 'fam1', 1 ).
test( 't11', 25, [], ['r1','r7','r4','r2','r3','r8'], 'fam1', 1 ).
test( 't12', 605, [], [], 'fam1', 1 ).
test( 't13', 716, [], ['r6','r3','r8','r4','r5','r2','r10','r1','r7'], 'fam1', 1 ).
test( 't14', 693, [], ['r1','r7','r6','r3','r10','r2','r4','r9'], 'fam1', 1 ).
test( 't15', 392, [], ['r4','r7','r3','r6','r9','r5','r8'], 'fam1', 1 ).
test( 't16', 425, [], [], 'fam1', 1 ).
test( 't17', 784, ['m6','m10','m3','m2','m1','m12'], [], 'fam1', 1 ).
test( 't18', 128, ['m20','m13','m7'], [], 'fam1', 1 ).
test( 't19', 437, ['m20','m10','m2','m7','m4','m12'], [], 'fam1', 1 ).
test( 't20', 444, [], [], 'fam1', 1 ).
test( 't21', 440, ['m10','m11','m1','m13','m20','m18'], [], 'fam1', 1 ).
test( 't22', 54, [], [], 'fam1', 1 ).
test( 't23', 146, [], [], 'fam1', 1 ).
test( 't24', 152, [], ['r3','r10','r8','r9','r6','r2','r5','r7','r1','r4'], 'fam1', 1 ).
test( 't25', 305, [], [], 'fam1', 1 ).
test( 't26', 115, [], [], 'fam1', 1 ).
test( 't27', 667, [], [], 'fam1', 1 ).
test( 't28', 313, [], ['r10','r2','r5','r4'], 'fam1', 1 ).
test( 't29', 431, ['m6','m12','m18','m3'], [], 'fam1', 1 ).
test( 't30', 443, ['m14','m10','m17','m12','m19','m7','m6'], ['r10','r6','r7','r5'], 'fam1', 1 ).
test( 't31', 701, [], [], 'fam1', 1 ).
test( 't32', 618, [], [], 'fam1', 1 ).
test( 't33', 534, [], ['r2','r4','r8','r10','r1','r9'], 'fam1', 1 ).
test( 't34', 514, [], [], 'fam1', 1 ).
test( 't35', 464, [], ['r5','r4','r10','r8','r7','r9','r3','r2','r1','r6'], 'fam1', 1 ).
test( 't36', 122, [], [], 'fam1', 1 ).
test( 't37', 231, [], ['r8','r10','r7','r1','r9','r5','r3','r2','r4','r6'], 'fam1', 1 ).
test( 't38', 339, [], [], 'fam1', 1 ).
test( 't39', 348, [], [], 'fam1', 1 ).
test( 't40', 726, [], [], 'fam1', 1 ).
test( 't41', 151, [], [], 'fam1', 1 ).
test( 't42', 719, [], [], 'fam1', 1 ).
test( 't43', 334, [], ['r3','r2','r5','r8','r1','r10','r6','r9','r4'], 'fam1', 1 ).
test( 't44', 168, ['m5','m6','m16','m8','m2','m11','m4','m14'], [], 'fam1', 1 ).
test( 't45', 476, [], [], 'fam1', 1 ).
test( 't46', 724, [], ['r4','r9','r6'], 'fam1', 1 ).
test( 't47', 295, [], [], 'fam1', 1 ).
test( 't48', 558, ['m7','m10','m19','m17'], ['r3','r2','r1','r5','r7','r10','r8','r6'], 'fam1', 1 ).
test( 't49', 783, [], [], 'fam1', 1 ).
test( 't50', 748, [], ['r10','r7'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
