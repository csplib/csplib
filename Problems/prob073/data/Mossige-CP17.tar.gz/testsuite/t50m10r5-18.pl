%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 645, [], [], 'fam1', 1 ).
test( 't2', 549, [], ['r1','r4','r2','r3','r5'], 'fam1', 1 ).
test( 't3', 689, [], [], 'fam1', 1 ).
test( 't4', 34, [], ['r4','r3','r1'], 'fam1', 1 ).
test( 't5', 387, ['m3'], [], 'fam1', 1 ).
test( 't6', 591, [], [], 'fam1', 1 ).
test( 't7', 469, [], [], 'fam1', 1 ).
test( 't8', 431, [], [], 'fam1', 1 ).
test( 't9', 318, ['m2','m6'], [], 'fam1', 1 ).
test( 't10', 382, [], ['r3','r5','r1','r2'], 'fam1', 1 ).
test( 't11', 611, [], ['r3'], 'fam1', 1 ).
test( 't12', 416, [], [], 'fam1', 1 ).
test( 't13', 98, [], [], 'fam1', 1 ).
test( 't14', 645, [], [], 'fam1', 1 ).
test( 't15', 99, [], [], 'fam1', 1 ).
test( 't16', 353, [], [], 'fam1', 1 ).
test( 't17', 381, ['m9','m7','m6'], ['r1','r3','r2','r4'], 'fam1', 1 ).
test( 't18', 520, ['m3'], [], 'fam1', 1 ).
test( 't19', 654, [], [], 'fam1', 1 ).
test( 't20', 615, [], ['r5','r1'], 'fam1', 1 ).
test( 't21', 729, ['m8','m2','m6','m1'], [], 'fam1', 1 ).
test( 't22', 363, [], [], 'fam1', 1 ).
test( 't23', 357, [], ['r4','r3','r1'], 'fam1', 1 ).
test( 't24', 32, [], [], 'fam1', 1 ).
test( 't25', 234, [], [], 'fam1', 1 ).
test( 't26', 34, [], ['r4'], 'fam1', 1 ).
test( 't27', 568, [], [], 'fam1', 1 ).
test( 't28', 283, [], ['r3','r2'], 'fam1', 1 ).
test( 't29', 606, ['m5'], [], 'fam1', 1 ).
test( 't30', 724, [], [], 'fam1', 1 ).
test( 't31', 197, ['m9','m6','m4'], ['r3'], 'fam1', 1 ).
test( 't32', 386, [], [], 'fam1', 1 ).
test( 't33', 120, ['m8','m1','m9','m2'], ['r5','r2','r3','r4','r1'], 'fam1', 1 ).
test( 't34', 524, [], [], 'fam1', 1 ).
test( 't35', 463, [], [], 'fam1', 1 ).
test( 't36', 18, [], [], 'fam1', 1 ).
test( 't37', 167, ['m3','m2','m1'], [], 'fam1', 1 ).
test( 't38', 628, [], [], 'fam1', 1 ).
test( 't39', 645, [], ['r1','r2','r4','r3','r5'], 'fam1', 1 ).
test( 't40', 28, [], [], 'fam1', 1 ).
test( 't41', 465, [], ['r4','r2','r1','r5'], 'fam1', 1 ).
test( 't42', 291, [], ['r1','r5','r2','r3','r4'], 'fam1', 1 ).
test( 't43', 273, [], [], 'fam1', 1 ).
test( 't44', 469, [], ['r4','r1'], 'fam1', 1 ).
test( 't45', 87, [], [], 'fam1', 1 ).
test( 't46', 791, [], ['r4','r1','r3','r2','r5'], 'fam1', 1 ).
test( 't47', 204, [], ['r1'], 'fam1', 1 ).
test( 't48', 732, [], ['r4','r5'], 'fam1', 1 ).
test( 't49', 404, ['m2'], [], 'fam1', 1 ).
test( 't50', 416, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
