%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 257, [], [], 'fam1', 1 ).
test( 't2', 246, [], ['r2','r4','r3','r5'], 'fam1', 1 ).
test( 't3', 369, [], [], 'fam1', 1 ).
test( 't4', 31, [], ['r1','r4','r5','r3'], 'fam1', 1 ).
test( 't5', 241, ['m4'], [], 'fam1', 1 ).
test( 't6', 190, [], ['r3','r2','r4','r5','r1'], 'fam1', 1 ).
test( 't7', 641, [], [], 'fam1', 1 ).
test( 't8', 170, [], [], 'fam1', 1 ).
test( 't9', 279, [], [], 'fam1', 1 ).
test( 't10', 608, [], [], 'fam1', 1 ).
test( 't11', 583, [], [], 'fam1', 1 ).
test( 't12', 785, [], ['r1','r3','r5'], 'fam1', 1 ).
test( 't13', 319, ['m9','m10','m1'], ['r1'], 'fam1', 1 ).
test( 't14', 32, [], ['r5','r4'], 'fam1', 1 ).
test( 't15', 474, [], [], 'fam1', 1 ).
test( 't16', 152, [], [], 'fam1', 1 ).
test( 't17', 323, [], [], 'fam1', 1 ).
test( 't18', 508, [], [], 'fam1', 1 ).
test( 't19', 9, ['m4','m3','m8','m5'], ['r3','r4','r1'], 'fam1', 1 ).
test( 't20', 324, [], [], 'fam1', 1 ).
test( 't21', 263, [], [], 'fam1', 1 ).
test( 't22', 52, [], ['r5','r2','r1','r3','r4'], 'fam1', 1 ).
test( 't23', 141, [], [], 'fam1', 1 ).
test( 't24', 472, ['m4','m9'], [], 'fam1', 1 ).
test( 't25', 219, ['m1','m8'], [], 'fam1', 1 ).
test( 't26', 476, [], ['r5'], 'fam1', 1 ).
test( 't27', 89, [], [], 'fam1', 1 ).
test( 't28', 172, [], [], 'fam1', 1 ).
test( 't29', 37, ['m2','m8'], [], 'fam1', 1 ).
test( 't30', 788, [], [], 'fam1', 1 ).
test( 't31', 472, [], [], 'fam1', 1 ).
test( 't32', 523, [], [], 'fam1', 1 ).
test( 't33', 748, ['m5'], [], 'fam1', 1 ).
test( 't34', 300, [], [], 'fam1', 1 ).
test( 't35', 666, [], [], 'fam1', 1 ).
test( 't36', 184, ['m2','m1','m5'], ['r2','r5'], 'fam1', 1 ).
test( 't37', 502, [], [], 'fam1', 1 ).
test( 't38', 309, [], ['r1','r5','r4','r2'], 'fam1', 1 ).
test( 't39', 734, [], [], 'fam1', 1 ).
test( 't40', 46, [], [], 'fam1', 1 ).
test( 't41', 601, [], ['r2'], 'fam1', 1 ).
test( 't42', 30, ['m10'], [], 'fam1', 1 ).
test( 't43', 161, ['m8'], [], 'fam1', 1 ).
test( 't44', 201, [], ['r4','r2','r3','r1','r5'], 'fam1', 1 ).
test( 't45', 752, ['m6'], [], 'fam1', 1 ).
test( 't46', 694, [], [], 'fam1', 1 ).
test( 't47', 329, ['m6','m8'], [], 'fam1', 1 ).
test( 't48', 537, [], ['r2','r1','r4'], 'fam1', 1 ).
test( 't49', 547, ['m6'], ['r5','r3','r2'], 'fam1', 1 ).
test( 't50', 160, [], ['r2','r1','r3','r4','r5'], 'fam1', 1 ).
test( 't51', 172, ['m8','m5','m7','m9'], ['r4','r5','r3','r2','r1'], 'fam1', 1 ).
test( 't52', 452, [], [], 'fam1', 1 ).
test( 't53', 331, [], [], 'fam1', 1 ).
test( 't54', 678, [], ['r2','r1','r4'], 'fam1', 1 ).
test( 't55', 110, ['m7','m6'], [], 'fam1', 1 ).
test( 't56', 391, [], ['r5','r2','r1'], 'fam1', 1 ).
test( 't57', 275, [], [], 'fam1', 1 ).
test( 't58', 797, [], [], 'fam1', 1 ).
test( 't59', 384, ['m5','m9','m4'], ['r5','r1','r3','r2','r4'], 'fam1', 1 ).
test( 't60', 573, [], [], 'fam1', 1 ).
test( 't61', 655, [], [], 'fam1', 1 ).
test( 't62', 296, [], [], 'fam1', 1 ).
test( 't63', 705, [], ['r5','r4','r2','r3','r1'], 'fam1', 1 ).
test( 't64', 497, [], [], 'fam1', 1 ).
test( 't65', 511, [], ['r2'], 'fam1', 1 ).
test( 't66', 43, ['m9','m5'], [], 'fam1', 1 ).
test( 't67', 671, [], [], 'fam1', 1 ).
test( 't68', 15, [], [], 'fam1', 1 ).
test( 't69', 391, [], [], 'fam1', 1 ).
test( 't70', 520, [], [], 'fam1', 1 ).
test( 't71', 399, [], [], 'fam1', 1 ).
test( 't72', 231, [], [], 'fam1', 1 ).
test( 't73', 447, ['m8','m4','m7'], ['r4','r5'], 'fam1', 1 ).
test( 't74', 633, [], [], 'fam1', 1 ).
test( 't75', 265, [], [], 'fam1', 1 ).
test( 't76', 593, ['m4','m10'], [], 'fam1', 1 ).
test( 't77', 397, [], [], 'fam1', 1 ).
test( 't78', 119, [], [], 'fam1', 1 ).
test( 't79', 357, [], ['r1','r4','r3','r2','r5'], 'fam1', 1 ).
test( 't80', 208, [], [], 'fam1', 1 ).
test( 't81', 697, [], [], 'fam1', 1 ).
test( 't82', 616, [], [], 'fam1', 1 ).
test( 't83', 303, [], [], 'fam1', 1 ).
test( 't84', 292, [], [], 'fam1', 1 ).
test( 't85', 179, ['m4','m7','m1','m10'], ['r1','r2','r3'], 'fam1', 1 ).
test( 't86', 456, ['m9','m5'], [], 'fam1', 1 ).
test( 't87', 281, ['m9','m6','m8'], [], 'fam1', 1 ).
test( 't88', 315, [], ['r4','r2','r5'], 'fam1', 1 ).
test( 't89', 318, ['m2','m3'], ['r2','r1','r5','r3'], 'fam1', 1 ).
test( 't90', 58, [], [], 'fam1', 1 ).
test( 't91', 432, [], [], 'fam1', 1 ).
test( 't92', 295, [], [], 'fam1', 1 ).
test( 't93', 543, [], [], 'fam1', 1 ).
test( 't94', 699, ['m5'], [], 'fam1', 1 ).
test( 't95', 308, [], [], 'fam1', 1 ).
test( 't96', 277, [], [], 'fam1', 1 ).
test( 't97', 788, ['m2','m7','m8'], [], 'fam1', 1 ).
test( 't98', 263, [], ['r4','r2','r5','r1'], 'fam1', 1 ).
test( 't99', 303, [], [], 'fam1', 1 ).
test( 't100', 794, ['m5','m4','m1','m7'], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
