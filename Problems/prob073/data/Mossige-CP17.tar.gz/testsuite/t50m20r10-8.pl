%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 20
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 738, [], [], 'fam1', 1 ).
test( 't2', 203, [], ['r9'], 'fam1', 1 ).
test( 't3', 231, [], [], 'fam1', 1 ).
test( 't4', 553, [], ['r1'], 'fam1', 1 ).
test( 't5', 64, [], ['r10','r7','r8','r9','r1','r5','r2','r4'], 'fam1', 1 ).
test( 't6', 151, ['m11','m5','m4','m20','m13'], [], 'fam1', 1 ).
test( 't7', 44, ['m16','m12','m11','m6','m1'], ['r10','r6','r8'], 'fam1', 1 ).
test( 't8', 405, ['m15','m19','m9','m20','m2'], ['r3'], 'fam1', 1 ).
test( 't9', 297, [], ['r10','r9','r6','r4','r2','r5','r8','r1','r7'], 'fam1', 1 ).
test( 't10', 157, [], ['r1','r6','r8','r10','r7'], 'fam1', 1 ).
test( 't11', 383, [], [], 'fam1', 1 ).
test( 't12', 103, [], ['r5','r2','r4','r8'], 'fam1', 1 ).
test( 't13', 89, [], [], 'fam1', 1 ).
test( 't14', 261, ['m9'], [], 'fam1', 1 ).
test( 't15', 50, [], ['r6','r5'], 'fam1', 1 ).
test( 't16', 105, [], ['r2','r7','r1','r4'], 'fam1', 1 ).
test( 't17', 635, [], [], 'fam1', 1 ).
test( 't18', 480, [], [], 'fam1', 1 ).
test( 't19', 358, [], [], 'fam1', 1 ).
test( 't20', 491, [], ['r4','r3','r7','r10','r6','r8','r9','r1','r5'], 'fam1', 1 ).
test( 't21', 156, ['m5','m12','m17'], ['r6','r7','r2','r10','r3','r8','r4'], 'fam1', 1 ).
test( 't22', 233, [], ['r1','r4','r3','r5','r6','r8','r2'], 'fam1', 1 ).
test( 't23', 569, [], ['r5','r9','r2','r6','r8'], 'fam1', 1 ).
test( 't24', 730, [], [], 'fam1', 1 ).
test( 't25', 386, ['m9','m13','m12','m5','m20','m6','m11'], [], 'fam1', 1 ).
test( 't26', 107, [], ['r10','r2','r7','r6','r9','r8'], 'fam1', 1 ).
test( 't27', 387, [], [], 'fam1', 1 ).
test( 't28', 675, [], ['r2','r7','r5','r10','r9','r8'], 'fam1', 1 ).
test( 't29', 22, [], ['r10','r9','r6','r8','r2','r1','r5','r7'], 'fam1', 1 ).
test( 't30', 605, [], ['r4'], 'fam1', 1 ).
test( 't31', 565, ['m5'], [], 'fam1', 1 ).
test( 't32', 61, [], ['r1','r2','r3','r8','r7','r5','r9','r10','r4'], 'fam1', 1 ).
test( 't33', 330, [], [], 'fam1', 1 ).
test( 't34', 347, [], [], 'fam1', 1 ).
test( 't35', 257, ['m10','m4','m12','m11'], [], 'fam1', 1 ).
test( 't36', 792, [], ['r8','r9','r5','r7','r1'], 'fam1', 1 ).
test( 't37', 798, [], ['r1','r3','r10','r6','r8'], 'fam1', 1 ).
test( 't38', 331, [], [], 'fam1', 1 ).
test( 't39', 556, [], [], 'fam1', 1 ).
test( 't40', 647, [], [], 'fam1', 1 ).
test( 't41', 297, [], [], 'fam1', 1 ).
test( 't42', 457, [], [], 'fam1', 1 ).
test( 't43', 783, [], [], 'fam1', 1 ).
test( 't44', 753, [], [], 'fam1', 1 ).
test( 't45', 537, [], [], 'fam1', 1 ).
test( 't46', 236, [], [], 'fam1', 1 ).
test( 't47', 727, [], [], 'fam1', 1 ).
test( 't48', 341, [], [], 'fam1', 1 ).
test( 't49', 51, [], [], 'fam1', 1 ).
test( 't50', 640, ['m7','m20','m12','m4','m2','m17','m8'], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
