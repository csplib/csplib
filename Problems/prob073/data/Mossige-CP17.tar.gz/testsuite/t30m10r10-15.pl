%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 10
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 634, [], [], 'fam1', 1 ).
test( 't2', 338, ['m1','m2'], ['r9','r10','r3','r4','r8','r5','r1','r6','r7'], 'fam1', 1 ).
test( 't3', 635, [], [], 'fam1', 1 ).
test( 't4', 587, [], ['r1','r7','r8','r10','r3','r9','r4','r6','r2','r5'], 'fam1', 1 ).
test( 't5', 417, [], [], 'fam1', 1 ).
test( 't6', 735, [], [], 'fam1', 1 ).
test( 't7', 108, [], [], 'fam1', 1 ).
test( 't8', 492, [], [], 'fam1', 1 ).
test( 't9', 129, [], ['r6','r7','r3','r1','r4','r9','r5','r10','r2','r8'], 'fam1', 1 ).
test( 't10', 664, [], [], 'fam1', 1 ).
test( 't11', 392, [], ['r10','r7','r4','r1'], 'fam1', 1 ).
test( 't12', 117, [], [], 'fam1', 1 ).
test( 't13', 253, [], [], 'fam1', 1 ).
test( 't14', 226, [], [], 'fam1', 1 ).
test( 't15', 349, [], [], 'fam1', 1 ).
test( 't16', 257, ['m1'], [], 'fam1', 1 ).
test( 't17', 107, [], [], 'fam1', 1 ).
test( 't18', 227, ['m9'], [], 'fam1', 1 ).
test( 't19', 502, [], [], 'fam1', 1 ).
test( 't20', 710, [], [], 'fam1', 1 ).
test( 't21', 496, [], [], 'fam1', 1 ).
test( 't22', 647, [], ['r8','r6','r9','r5'], 'fam1', 1 ).
test( 't23', 276, [], [], 'fam1', 1 ).
test( 't24', 574, [], [], 'fam1', 1 ).
test( 't25', 476, [], [], 'fam1', 1 ).
test( 't26', 508, ['m3','m2','m6','m1'], [], 'fam1', 1 ).
test( 't27', 539, [], [], 'fam1', 1 ).
test( 't28', 667, [], ['r6','r7','r1','r9','r2'], 'fam1', 1 ).
test( 't29', 54, ['m7'], [], 'fam1', 1 ).
test( 't30', 20, [], ['r10','r1','r3','r2','r6','r4','r5','r8','r9'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
