%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 10
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 527, [], ['r4','r8'], 'fam1', 1 ).
test( 't2', 418, [], ['r9','r10','r3','r7','r2','r8'], 'fam1', 1 ).
test( 't3', 676, ['m9','m4','m2','m8'], [], 'fam1', 1 ).
test( 't4', 8, [], [], 'fam1', 1 ).
test( 't5', 563, [], [], 'fam1', 1 ).
test( 't6', 751, [], [], 'fam1', 1 ).
test( 't7', 362, [], [], 'fam1', 1 ).
test( 't8', 369, [], ['r7','r3','r1','r8'], 'fam1', 1 ).
test( 't9', 259, [], [], 'fam1', 1 ).
test( 't10', 57, [], [], 'fam1', 1 ).
test( 't11', 486, [], [], 'fam1', 1 ).
test( 't12', 242, [], ['r5','r6','r3','r2','r4','r1'], 'fam1', 1 ).
test( 't13', 468, [], [], 'fam1', 1 ).
test( 't14', 517, [], [], 'fam1', 1 ).
test( 't15', 633, [], [], 'fam1', 1 ).
test( 't16', 61, [], [], 'fam1', 1 ).
test( 't17', 601, [], [], 'fam1', 1 ).
test( 't18', 93, [], [], 'fam1', 1 ).
test( 't19', 714, ['m10','m6'], [], 'fam1', 1 ).
test( 't20', 481, [], ['r6','r8','r2','r3'], 'fam1', 1 ).
test( 't21', 561, [], [], 'fam1', 1 ).
test( 't22', 696, [], [], 'fam1', 1 ).
test( 't23', 566, [], [], 'fam1', 1 ).
test( 't24', 51, [], ['r1','r4','r10','r7','r8','r5','r6','r9'], 'fam1', 1 ).
test( 't25', 536, [], [], 'fam1', 1 ).
test( 't26', 347, [], [], 'fam1', 1 ).
test( 't27', 339, [], [], 'fam1', 1 ).
test( 't28', 444, [], ['r2'], 'fam1', 1 ).
test( 't29', 244, [], [], 'fam1', 1 ).
test( 't30', 670, [], [], 'fam1', 1 ).
test( 't31', 182, [], [], 'fam1', 1 ).
test( 't32', 271, [], [], 'fam1', 1 ).
test( 't33', 675, [], [], 'fam1', 1 ).
test( 't34', 287, ['m3'], [], 'fam1', 1 ).
test( 't35', 40, [], ['r10','r5'], 'fam1', 1 ).
test( 't36', 147, [], [], 'fam1', 1 ).
test( 't37', 375, [], [], 'fam1', 1 ).
test( 't38', 546, [], [], 'fam1', 1 ).
test( 't39', 589, [], [], 'fam1', 1 ).
test( 't40', 211, [], [], 'fam1', 1 ).
test( 't41', 201, [], [], 'fam1', 1 ).
test( 't42', 220, [], ['r6','r8'], 'fam1', 1 ).
test( 't43', 559, [], ['r1','r6','r2'], 'fam1', 1 ).
test( 't44', 724, ['m5','m7'], [], 'fam1', 1 ).
test( 't45', 637, [], [], 'fam1', 1 ).
test( 't46', 29, [], [], 'fam1', 1 ).
test( 't47', 113, [], ['r1','r4','r8','r2','r9','r3','r5','r10'], 'fam1', 1 ).
test( 't48', 411, [], [], 'fam1', 1 ).
test( 't49', 445, ['m3','m1','m7'], ['r7','r8'], 'fam1', 1 ).
test( 't50', 546, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
