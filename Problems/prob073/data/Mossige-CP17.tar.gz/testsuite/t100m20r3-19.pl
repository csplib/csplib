%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 20
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 407, [], [], 'fam1', 1 ).
test( 't2', 375, [], ['r3','r2'], 'fam1', 1 ).
test( 't3', 200, [], [], 'fam1', 1 ).
test( 't4', 514, ['m4','m15','m19','m6','m20','m9'], [], 'fam1', 1 ).
test( 't5', 765, [], [], 'fam1', 1 ).
test( 't6', 587, [], [], 'fam1', 1 ).
test( 't7', 575, [], [], 'fam1', 1 ).
test( 't8', 257, [], [], 'fam1', 1 ).
test( 't9', 409, ['m18','m8','m5','m6','m1','m17','m7'], [], 'fam1', 1 ).
test( 't10', 186, [], ['r2','r3'], 'fam1', 1 ).
test( 't11', 558, [], [], 'fam1', 1 ).
test( 't12', 497, [], [], 'fam1', 1 ).
test( 't13', 153, [], [], 'fam1', 1 ).
test( 't14', 461, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't15', 752, [], [], 'fam1', 1 ).
test( 't16', 593, [], [], 'fam1', 1 ).
test( 't17', 624, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't18', 513, [], [], 'fam1', 1 ).
test( 't19', 169, ['m7','m18','m8','m11'], [], 'fam1', 1 ).
test( 't20', 222, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't21', 721, [], [], 'fam1', 1 ).
test( 't22', 624, [], [], 'fam1', 1 ).
test( 't23', 419, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't24', 172, [], ['r3'], 'fam1', 1 ).
test( 't25', 214, [], [], 'fam1', 1 ).
test( 't26', 443, [], [], 'fam1', 1 ).
test( 't27', 540, [], [], 'fam1', 1 ).
test( 't28', 255, [], [], 'fam1', 1 ).
test( 't29', 511, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't30', 162, [], [], 'fam1', 1 ).
test( 't31', 587, ['m3','m20','m15','m9','m5','m16','m18'], [], 'fam1', 1 ).
test( 't32', 798, [], [], 'fam1', 1 ).
test( 't33', 341, [], [], 'fam1', 1 ).
test( 't34', 588, [], [], 'fam1', 1 ).
test( 't35', 792, [], ['r3','r2'], 'fam1', 1 ).
test( 't36', 729, [], [], 'fam1', 1 ).
test( 't37', 50, [], ['r2','r3'], 'fam1', 1 ).
test( 't38', 575, [], [], 'fam1', 1 ).
test( 't39', 701, [], ['r1','r2'], 'fam1', 1 ).
test( 't40', 122, [], ['r2','r1'], 'fam1', 1 ).
test( 't41', 73, [], [], 'fam1', 1 ).
test( 't42', 790, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't43', 158, [], [], 'fam1', 1 ).
test( 't44', 72, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't45', 99, [], [], 'fam1', 1 ).
test( 't46', 770, ['m6','m4','m1','m18','m3','m11','m12'], ['r1'], 'fam1', 1 ).
test( 't47', 342, [], ['r2','r3'], 'fam1', 1 ).
test( 't48', 183, [], [], 'fam1', 1 ).
test( 't49', 44, ['m16','m20','m8','m19'], [], 'fam1', 1 ).
test( 't50', 452, [], [], 'fam1', 1 ).
test( 't51', 646, [], [], 'fam1', 1 ).
test( 't52', 40, [], ['r2'], 'fam1', 1 ).
test( 't53', 729, [], [], 'fam1', 1 ).
test( 't54', 635, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't55', 481, [], [], 'fam1', 1 ).
test( 't56', 129, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't57', 602, [], ['r1'], 'fam1', 1 ).
test( 't58', 417, [], [], 'fam1', 1 ).
test( 't59', 684, [], [], 'fam1', 1 ).
test( 't60', 498, [], [], 'fam1', 1 ).
test( 't61', 768, ['m2','m14','m13','m19'], [], 'fam1', 1 ).
test( 't62', 234, [], [], 'fam1', 1 ).
test( 't63', 568, [], [], 'fam1', 1 ).
test( 't64', 642, [], [], 'fam1', 1 ).
test( 't65', 279, [], [], 'fam1', 1 ).
test( 't66', 693, [], ['r1'], 'fam1', 1 ).
test( 't67', 91, ['m5'], [], 'fam1', 1 ).
test( 't68', 199, [], [], 'fam1', 1 ).
test( 't69', 2, [], [], 'fam1', 1 ).
test( 't70', 104, [], [], 'fam1', 1 ).
test( 't71', 615, ['m10','m7','m15','m4','m2','m16'], [], 'fam1', 1 ).
test( 't72', 420, [], ['r3','r1'], 'fam1', 1 ).
test( 't73', 310, ['m7','m8','m11','m12','m18'], ['r3','r2','r1'], 'fam1', 1 ).
test( 't74', 504, [], [], 'fam1', 1 ).
test( 't75', 159, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't76', 183, [], [], 'fam1', 1 ).
test( 't77', 428, ['m11','m4'], [], 'fam1', 1 ).
test( 't78', 147, [], [], 'fam1', 1 ).
test( 't79', 623, [], [], 'fam1', 1 ).
test( 't80', 417, ['m17','m16','m15','m20'], [], 'fam1', 1 ).
test( 't81', 503, [], ['r1','r3'], 'fam1', 1 ).
test( 't82', 63, [], [], 'fam1', 1 ).
test( 't83', 636, ['m16','m19','m14','m20','m8','m17','m4'], [], 'fam1', 1 ).
test( 't84', 78, [], ['r3','r2'], 'fam1', 1 ).
test( 't85', 57, [], [], 'fam1', 1 ).
test( 't86', 371, [], [], 'fam1', 1 ).
test( 't87', 498, [], [], 'fam1', 1 ).
test( 't88', 682, [], [], 'fam1', 1 ).
test( 't89', 207, [], ['r2','r1'], 'fam1', 1 ).
test( 't90', 543, [], [], 'fam1', 1 ).
test( 't91', 314, [], [], 'fam1', 1 ).
test( 't92', 369, [], [], 'fam1', 1 ).
test( 't93', 372, [], [], 'fam1', 1 ).
test( 't94', 291, [], ['r3','r2'], 'fam1', 1 ).
test( 't95', 701, [], [], 'fam1', 1 ).
test( 't96', 61, [], [], 'fam1', 1 ).
test( 't97', 241, [], [], 'fam1', 1 ).
test( 't98', 517, [], [], 'fam1', 1 ).
test( 't99', 510, [], ['r3','r1'], 'fam1', 1 ).
test( 't100', 781, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
