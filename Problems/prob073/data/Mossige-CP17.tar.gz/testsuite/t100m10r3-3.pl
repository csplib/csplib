%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 757, [], [], 'fam1', 1 ).
test( 't2', 800, ['m4','m5'], ['r2'], 'fam1', 1 ).
test( 't3', 295, [], [], 'fam1', 1 ).
test( 't4', 529, [], [], 'fam1', 1 ).
test( 't5', 648, ['m7','m10','m4'], ['r2'], 'fam1', 1 ).
test( 't6', 579, [], [], 'fam1', 1 ).
test( 't7', 5, [], [], 'fam1', 1 ).
test( 't8', 449, ['m5','m9'], ['r1'], 'fam1', 1 ).
test( 't9', 690, [], [], 'fam1', 1 ).
test( 't10', 535, [], [], 'fam1', 1 ).
test( 't11', 251, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't12', 413, [], ['r1','r3'], 'fam1', 1 ).
test( 't13', 782, [], [], 'fam1', 1 ).
test( 't14', 433, ['m4','m5','m2'], ['r3'], 'fam1', 1 ).
test( 't15', 489, [], [], 'fam1', 1 ).
test( 't16', 1, ['m2'], [], 'fam1', 1 ).
test( 't17', 422, [], [], 'fam1', 1 ).
test( 't18', 226, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't19', 280, [], [], 'fam1', 1 ).
test( 't20', 150, ['m7','m1','m6'], [], 'fam1', 1 ).
test( 't21', 368, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't22', 741, [], [], 'fam1', 1 ).
test( 't23', 690, [], [], 'fam1', 1 ).
test( 't24', 484, ['m8','m4','m6','m7'], [], 'fam1', 1 ).
test( 't25', 345, [], [], 'fam1', 1 ).
test( 't26', 466, [], [], 'fam1', 1 ).
test( 't27', 79, [], [], 'fam1', 1 ).
test( 't28', 676, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't29', 423, ['m3','m6','m7','m8'], [], 'fam1', 1 ).
test( 't30', 169, [], [], 'fam1', 1 ).
test( 't31', 474, [], [], 'fam1', 1 ).
test( 't32', 346, [], ['r1','r3'], 'fam1', 1 ).
test( 't33', 303, [], [], 'fam1', 1 ).
test( 't34', 267, [], [], 'fam1', 1 ).
test( 't35', 636, ['m8','m2','m5'], ['r1','r2'], 'fam1', 1 ).
test( 't36', 588, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't37', 77, ['m7'], [], 'fam1', 1 ).
test( 't38', 748, [], [], 'fam1', 1 ).
test( 't39', 380, [], [], 'fam1', 1 ).
test( 't40', 460, [], [], 'fam1', 1 ).
test( 't41', 333, ['m9','m10','m7','m1'], [], 'fam1', 1 ).
test( 't42', 752, [], [], 'fam1', 1 ).
test( 't43', 646, [], [], 'fam1', 1 ).
test( 't44', 413, [], ['r3'], 'fam1', 1 ).
test( 't45', 282, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't46', 159, [], ['r3','r1'], 'fam1', 1 ).
test( 't47', 744, [], [], 'fam1', 1 ).
test( 't48', 781, [], ['r2'], 'fam1', 1 ).
test( 't49', 593, [], [], 'fam1', 1 ).
test( 't50', 391, [], [], 'fam1', 1 ).
test( 't51', 209, [], [], 'fam1', 1 ).
test( 't52', 338, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't53', 712, [], [], 'fam1', 1 ).
test( 't54', 638, [], [], 'fam1', 1 ).
test( 't55', 330, [], [], 'fam1', 1 ).
test( 't56', 697, ['m10','m8'], [], 'fam1', 1 ).
test( 't57', 479, [], ['r1','r2'], 'fam1', 1 ).
test( 't58', 437, [], [], 'fam1', 1 ).
test( 't59', 556, [], [], 'fam1', 1 ).
test( 't60', 384, [], ['r1','r2'], 'fam1', 1 ).
test( 't61', 276, ['m4','m8','m2'], ['r2','r3'], 'fam1', 1 ).
test( 't62', 158, [], [], 'fam1', 1 ).
test( 't63', 583, [], [], 'fam1', 1 ).
test( 't64', 636, [], [], 'fam1', 1 ).
test( 't65', 625, [], [], 'fam1', 1 ).
test( 't66', 304, [], [], 'fam1', 1 ).
test( 't67', 744, [], ['r1'], 'fam1', 1 ).
test( 't68', 86, ['m6'], [], 'fam1', 1 ).
test( 't69', 68, [], [], 'fam1', 1 ).
test( 't70', 96, [], [], 'fam1', 1 ).
test( 't71', 406, [], [], 'fam1', 1 ).
test( 't72', 635, ['m5'], [], 'fam1', 1 ).
test( 't73', 189, [], ['r2','r1'], 'fam1', 1 ).
test( 't74', 556, [], ['r1','r2'], 'fam1', 1 ).
test( 't75', 165, [], [], 'fam1', 1 ).
test( 't76', 22, [], [], 'fam1', 1 ).
test( 't77', 78, [], [], 'fam1', 1 ).
test( 't78', 146, ['m8','m2','m9'], [], 'fam1', 1 ).
test( 't79', 320, [], [], 'fam1', 1 ).
test( 't80', 40, ['m6','m8','m9','m1'], [], 'fam1', 1 ).
test( 't81', 334, [], [], 'fam1', 1 ).
test( 't82', 176, ['m9','m6','m1'], ['r2','r3'], 'fam1', 1 ).
test( 't83', 780, [], [], 'fam1', 1 ).
test( 't84', 545, [], [], 'fam1', 1 ).
test( 't85', 730, [], [], 'fam1', 1 ).
test( 't86', 256, [], ['r2'], 'fam1', 1 ).
test( 't87', 470, [], [], 'fam1', 1 ).
test( 't88', 673, [], [], 'fam1', 1 ).
test( 't89', 161, [], [], 'fam1', 1 ).
test( 't90', 278, [], ['r3'], 'fam1', 1 ).
test( 't91', 121, [], [], 'fam1', 1 ).
test( 't92', 321, [], [], 'fam1', 1 ).
test( 't93', 304, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't94', 440, [], [], 'fam1', 1 ).
test( 't95', 781, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't96', 288, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't97', 771, [], ['r2','r3'], 'fam1', 1 ).
test( 't98', 553, [], [], 'fam1', 1 ).
test( 't99', 341, [], [], 'fam1', 1 ).
test( 't100', 497, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
