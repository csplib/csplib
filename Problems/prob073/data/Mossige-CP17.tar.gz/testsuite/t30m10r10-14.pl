%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 10
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 6, ['m9','m2','m7'], [], 'fam1', 1 ).
test( 't2', 622, [], [], 'fam1', 1 ).
test( 't3', 229, [], ['r7','r3','r8','r10','r6','r1'], 'fam1', 1 ).
test( 't4', 265, [], [], 'fam1', 1 ).
test( 't5', 706, [], [], 'fam1', 1 ).
test( 't6', 274, [], [], 'fam1', 1 ).
test( 't7', 225, [], ['r10','r7'], 'fam1', 1 ).
test( 't8', 711, ['m1','m8','m2','m5'], ['r7','r6','r10','r4'], 'fam1', 1 ).
test( 't9', 152, [], [], 'fam1', 1 ).
test( 't10', 467, [], [], 'fam1', 1 ).
test( 't11', 724, [], [], 'fam1', 1 ).
test( 't12', 584, [], [], 'fam1', 1 ).
test( 't13', 6, [], ['r5','r1','r6','r7','r2','r8','r9','r3'], 'fam1', 1 ).
test( 't14', 682, [], [], 'fam1', 1 ).
test( 't15', 406, [], [], 'fam1', 1 ).
test( 't16', 55, [], [], 'fam1', 1 ).
test( 't17', 543, [], [], 'fam1', 1 ).
test( 't18', 451, [], [], 'fam1', 1 ).
test( 't19', 143, [], [], 'fam1', 1 ).
test( 't20', 333, [], ['r10','r2','r7','r9','r3','r6','r4','r8','r5'], 'fam1', 1 ).
test( 't21', 3, [], ['r6','r4','r5','r1'], 'fam1', 1 ).
test( 't22', 179, [], [], 'fam1', 1 ).
test( 't23', 209, [], ['r5','r3','r4','r8','r9','r2','r10','r1'], 'fam1', 1 ).
test( 't24', 384, [], [], 'fam1', 1 ).
test( 't25', 234, [], ['r2','r10','r1','r5','r8','r7'], 'fam1', 1 ).
test( 't26', 743, [], [], 'fam1', 1 ).
test( 't27', 81, [], [], 'fam1', 1 ).
test( 't28', 794, [], ['r10','r8','r9','r7','r1','r2','r5'], 'fam1', 1 ).
test( 't29', 100, ['m5'], [], 'fam1', 1 ).
test( 't30', 748, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
