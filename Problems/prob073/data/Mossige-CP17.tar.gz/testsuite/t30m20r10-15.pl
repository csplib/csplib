%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 20
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 297, [], ['r7','r8','r4','r1','r5','r10','r2'], 'fam1', 1 ).
test( 't2', 52, [], ['r4'], 'fam1', 1 ).
test( 't3', 751, [], [], 'fam1', 1 ).
test( 't4', 371, [], ['r4','r9','r5','r2','r1','r3','r7'], 'fam1', 1 ).
test( 't5', 339, [], [], 'fam1', 1 ).
test( 't6', 302, [], ['r7','r8','r1'], 'fam1', 1 ).
test( 't7', 587, [], [], 'fam1', 1 ).
test( 't8', 333, [], ['r8','r3','r10','r6','r9','r7','r4','r2'], 'fam1', 1 ).
test( 't9', 326, ['m2'], ['r8','r10','r1','r3','r9','r5','r7','r4'], 'fam1', 1 ).
test( 't10', 783, [], ['r10','r3','r2'], 'fam1', 1 ).
test( 't11', 266, [], ['r7','r4','r2','r8','r9','r1','r5'], 'fam1', 1 ).
test( 't12', 465, [], [], 'fam1', 1 ).
test( 't13', 531, [], [], 'fam1', 1 ).
test( 't14', 541, ['m18','m16','m17'], [], 'fam1', 1 ).
test( 't15', 93, [], ['r7','r9','r2','r6','r10','r4','r1','r5','r8','r3'], 'fam1', 1 ).
test( 't16', 404, ['m11','m8','m2','m9','m6','m14'], ['r4','r9','r5'], 'fam1', 1 ).
test( 't17', 684, [], [], 'fam1', 1 ).
test( 't18', 778, [], ['r6'], 'fam1', 1 ).
test( 't19', 464, [], ['r10','r4','r1'], 'fam1', 1 ).
test( 't20', 89, [], [], 'fam1', 1 ).
test( 't21', 161, ['m13','m6'], [], 'fam1', 1 ).
test( 't22', 172, [], [], 'fam1', 1 ).
test( 't23', 703, [], [], 'fam1', 1 ).
test( 't24', 691, [], [], 'fam1', 1 ).
test( 't25', 538, [], ['r8','r3','r1'], 'fam1', 1 ).
test( 't26', 792, [], [], 'fam1', 1 ).
test( 't27', 314, [], [], 'fam1', 1 ).
test( 't28', 339, [], ['r2','r3','r7','r8','r9','r5','r4','r6','r10'], 'fam1', 1 ).
test( 't29', 512, [], ['r6','r1','r3','r9','r7','r4'], 'fam1', 1 ).
test( 't30', 695, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
