%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 20
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 782, [], [], 'fam1', 1 ).
test( 't2', 752, ['m8','m2','m9','m16','m13','m4','m11','m6'], [], 'fam1', 1 ).
test( 't3', 783, [], ['r4','r1','r2','r3','r5'], 'fam1', 1 ).
test( 't4', 296, [], [], 'fam1', 1 ).
test( 't5', 138, [], [], 'fam1', 1 ).
test( 't6', 99, [], [], 'fam1', 1 ).
test( 't7', 461, [], ['r1','r2'], 'fam1', 1 ).
test( 't8', 318, [], ['r5','r1'], 'fam1', 1 ).
test( 't9', 21, [], [], 'fam1', 1 ).
test( 't10', 612, [], [], 'fam1', 1 ).
test( 't11', 195, [], [], 'fam1', 1 ).
test( 't12', 426, [], ['r4','r5','r3'], 'fam1', 1 ).
test( 't13', 553, [], [], 'fam1', 1 ).
test( 't14', 380, ['m3'], ['r3'], 'fam1', 1 ).
test( 't15', 786, [], [], 'fam1', 1 ).
test( 't16', 150, [], ['r4','r5'], 'fam1', 1 ).
test( 't17', 779, ['m2','m3','m11','m10','m15','m5'], [], 'fam1', 1 ).
test( 't18', 450, [], [], 'fam1', 1 ).
test( 't19', 801, [], ['r3'], 'fam1', 1 ).
test( 't20', 582, [], [], 'fam1', 1 ).
test( 't21', 292, [], [], 'fam1', 1 ).
test( 't22', 496, [], ['r1','r5','r3','r4'], 'fam1', 1 ).
test( 't23', 71, [], ['r3'], 'fam1', 1 ).
test( 't24', 5, [], [], 'fam1', 1 ).
test( 't25', 121, [], [], 'fam1', 1 ).
test( 't26', 105, [], [], 'fam1', 1 ).
test( 't27', 99, [], [], 'fam1', 1 ).
test( 't28', 660, [], [], 'fam1', 1 ).
test( 't29', 780, [], ['r5','r4','r3'], 'fam1', 1 ).
test( 't30', 740, [], [], 'fam1', 1 ).
test( 't31', 325, [], [], 'fam1', 1 ).
test( 't32', 801, ['m18','m5','m1','m3','m6'], ['r3','r5','r1','r4'], 'fam1', 1 ).
test( 't33', 59, ['m3','m15','m20','m19'], ['r4','r2','r5','r3','r1'], 'fam1', 1 ).
test( 't34', 655, [], [], 'fam1', 1 ).
test( 't35', 124, [], [], 'fam1', 1 ).
test( 't36', 269, [], ['r3','r1'], 'fam1', 1 ).
test( 't37', 263, [], [], 'fam1', 1 ).
test( 't38', 638, [], [], 'fam1', 1 ).
test( 't39', 616, ['m13','m10','m19','m14','m5'], [], 'fam1', 1 ).
test( 't40', 344, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
