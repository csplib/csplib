%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 50
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 787, [], [], 'fam1', 1 ).
test( 't2', 666, [], [], 'fam1', 1 ).
test( 't3', 402, [], [], 'fam1', 1 ).
test( 't4', 494, ['m47','m42','m30','m41','m40','m35','m20','m9','m21','m26','m24','m14','m17','m16','m5','m29','m32','m22'], ['r1','r3'], 'fam1', 1 ).
test( 't5', 302, [], [], 'fam1', 1 ).
test( 't6', 792, [], [], 'fam1', 1 ).
test( 't7', 498, [], [], 'fam1', 1 ).
test( 't8', 695, [], [], 'fam1', 1 ).
test( 't9', 377, ['m28','m43','m13','m25','m22','m1','m34','m48','m2','m35','m19','m44','m40','m3','m31','m20'], [], 'fam1', 1 ).
test( 't10', 507, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't11', 633, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't12', 720, [], [], 'fam1', 1 ).
test( 't13', 60, ['m29','m44','m4','m47','m23'], [], 'fam1', 1 ).
test( 't14', 118, [], [], 'fam1', 1 ).
test( 't15', 223, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't16', 354, ['m6','m43','m49','m38','m2','m1','m30','m35'], ['r2','r3','r1'], 'fam1', 1 ).
test( 't17', 44, [], [], 'fam1', 1 ).
test( 't18', 695, [], [], 'fam1', 1 ).
test( 't19', 355, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't20', 501, [], ['r3'], 'fam1', 1 ).
test( 't21', 249, [], [], 'fam1', 1 ).
test( 't22', 108, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't23', 547, ['m20','m49','m40','m8','m33'], ['r1','r2','r3'], 'fam1', 1 ).
test( 't24', 243, [], [], 'fam1', 1 ).
test( 't25', 42, [], ['r2'], 'fam1', 1 ).
test( 't26', 473, ['m24','m27','m36','m10','m22','m38','m21','m8'], [], 'fam1', 1 ).
test( 't27', 42, [], [], 'fam1', 1 ).
test( 't28', 579, [], ['r2'], 'fam1', 1 ).
test( 't29', 517, [], [], 'fam1', 1 ).
test( 't30', 85, [], [], 'fam1', 1 ).
test( 't31', 287, [], [], 'fam1', 1 ).
test( 't32', 406, [], [], 'fam1', 1 ).
test( 't33', 749, [], [], 'fam1', 1 ).
test( 't34', 659, [], [], 'fam1', 1 ).
test( 't35', 728, ['m3','m1','m39','m26','m47','m6','m18','m9','m45','m8','m32','m49','m13','m5','m50','m19','m16','m15','m40','m34'], [], 'fam1', 1 ).
test( 't36', 761, [], [], 'fam1', 1 ).
test( 't37', 496, [], [], 'fam1', 1 ).
test( 't38', 609, [], [], 'fam1', 1 ).
test( 't39', 336, ['m41','m17','m15','m32','m11','m16','m7','m45','m36','m34','m12','m28','m24','m4','m39','m40','m42','m5','m19'], ['r2'], 'fam1', 1 ).
test( 't40', 122, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't41', 1, [], ['r2','r1'], 'fam1', 1 ).
test( 't42', 67, [], [], 'fam1', 1 ).
test( 't43', 472, [], [], 'fam1', 1 ).
test( 't44', 573, [], [], 'fam1', 1 ).
test( 't45', 540, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't46', 628, [], [], 'fam1', 1 ).
test( 't47', 717, [], [], 'fam1', 1 ).
test( 't48', 71, [], [], 'fam1', 1 ).
test( 't49', 309, ['m38','m21','m41','m15'], [], 'fam1', 1 ).
test( 't50', 603, [], [], 'fam1', 1 ).
test( 't51', 83, ['m16','m2','m14','m30','m46','m39','m29','m28'], [], 'fam1', 1 ).
test( 't52', 520, [], [], 'fam1', 1 ).
test( 't53', 553, [], [], 'fam1', 1 ).
test( 't54', 441, ['m29','m16','m36','m8','m31','m34','m9','m43','m48','m24','m11'], ['r3','r2','r1'], 'fam1', 1 ).
test( 't55', 19, [], [], 'fam1', 1 ).
test( 't56', 100, [], [], 'fam1', 1 ).
test( 't57', 45, [], ['r1'], 'fam1', 1 ).
test( 't58', 246, [], ['r1','r3'], 'fam1', 1 ).
test( 't59', 96, [], [], 'fam1', 1 ).
test( 't60', 579, ['m38','m29','m50','m17','m4','m35','m11','m2','m15','m40','m49','m20','m39','m8','m26','m30','m32','m42'], ['r1'], 'fam1', 1 ).
test( 't61', 381, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't62', 651, [], [], 'fam1', 1 ).
test( 't63', 16, [], [], 'fam1', 1 ).
test( 't64', 71, [], [], 'fam1', 1 ).
test( 't65', 740, [], [], 'fam1', 1 ).
test( 't66', 779, [], [], 'fam1', 1 ).
test( 't67', 408, [], [], 'fam1', 1 ).
test( 't68', 543, [], ['r1','r2'], 'fam1', 1 ).
test( 't69', 540, [], [], 'fam1', 1 ).
test( 't70', 703, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't71', 415, [], [], 'fam1', 1 ).
test( 't72', 708, [], [], 'fam1', 1 ).
test( 't73', 601, [], [], 'fam1', 1 ).
test( 't74', 281, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't75', 298, [], [], 'fam1', 1 ).
test( 't76', 388, ['m13','m24'], [], 'fam1', 1 ).
test( 't77', 200, ['m2'], [], 'fam1', 1 ).
test( 't78', 618, [], [], 'fam1', 1 ).
test( 't79', 796, [], [], 'fam1', 1 ).
test( 't80', 645, [], [], 'fam1', 1 ).
test( 't81', 249, [], [], 'fam1', 1 ).
test( 't82', 260, [], [], 'fam1', 1 ).
test( 't83', 167, [], [], 'fam1', 1 ).
test( 't84', 493, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't85', 75, ['m21','m9','m30','m46','m18'], [], 'fam1', 1 ).
test( 't86', 85, [], [], 'fam1', 1 ).
test( 't87', 801, [], [], 'fam1', 1 ).
test( 't88', 551, [], [], 'fam1', 1 ).
test( 't89', 292, ['m20','m21','m25','m32','m30','m23','m17','m3','m27','m11','m14'], [], 'fam1', 1 ).
test( 't90', 16, [], [], 'fam1', 1 ).
test( 't91', 363, [], [], 'fam1', 1 ).
test( 't92', 158, [], ['r2'], 'fam1', 1 ).
test( 't93', 390, [], [], 'fam1', 1 ).
test( 't94', 38, [], [], 'fam1', 1 ).
test( 't95', 567, [], [], 'fam1', 1 ).
test( 't96', 544, ['m20','m16','m35','m31','m42','m45','m30','m24','m47','m14','m36','m34','m25','m21','m29','m8','m23','m27','m33'], ['r2'], 'fam1', 1 ).
test( 't97', 542, [], [], 'fam1', 1 ).
test( 't98', 121, [], [], 'fam1', 1 ).
test( 't99', 705, [], [], 'fam1', 1 ).
test( 't100', 262, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').
embedded_board( 'm21').
embedded_board( 'm22').
embedded_board( 'm23').
embedded_board( 'm24').
embedded_board( 'm25').
embedded_board( 'm26').
embedded_board( 'm27').
embedded_board( 'm28').
embedded_board( 'm29').
embedded_board( 'm30').
embedded_board( 'm31').
embedded_board( 'm32').
embedded_board( 'm33').
embedded_board( 'm34').
embedded_board( 'm35').
embedded_board( 'm36').
embedded_board( 'm37').
embedded_board( 'm38').
embedded_board( 'm39').
embedded_board( 'm40').
embedded_board( 'm41').
embedded_board( 'm42').
embedded_board( 'm43').
embedded_board( 'm44').
embedded_board( 'm45').
embedded_board( 'm46').
embedded_board( 'm47').
embedded_board( 'm48').
embedded_board( 'm49').
embedded_board( 'm50').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
