%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 20
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 24, [], ['r1','r5','r2'], 'fam1', 1 ).
test( 't2', 489, [], ['r1','r5','r2','r4','r3'], 'fam1', 1 ).
test( 't3', 243, [], ['r2','r3','r5'], 'fam1', 1 ).
test( 't4', 477, [], [], 'fam1', 1 ).
test( 't5', 642, [], [], 'fam1', 1 ).
test( 't6', 633, ['m8','m17','m6','m3'], [], 'fam1', 1 ).
test( 't7', 185, [], [], 'fam1', 1 ).
test( 't8', 72, ['m3','m4'], ['r1','r2','r3','r4','r5'], 'fam1', 1 ).
test( 't9', 498, [], [], 'fam1', 1 ).
test( 't10', 507, [], ['r1','r5','r2','r3'], 'fam1', 1 ).
test( 't11', 375, ['m2','m12','m20','m9','m4','m19','m15'], [], 'fam1', 1 ).
test( 't12', 633, [], [], 'fam1', 1 ).
test( 't13', 17, [], ['r4','r5'], 'fam1', 1 ).
test( 't14', 783, ['m11','m17','m10','m16','m8','m2'], [], 'fam1', 1 ).
test( 't15', 701, [], [], 'fam1', 1 ).
test( 't16', 209, ['m8','m19','m5','m6','m18','m12','m16','m11'], [], 'fam1', 1 ).
test( 't17', 413, [], [], 'fam1', 1 ).
test( 't18', 628, [], [], 'fam1', 1 ).
test( 't19', 76, ['m10','m8'], [], 'fam1', 1 ).
test( 't20', 403, [], [], 'fam1', 1 ).
test( 't21', 558, [], [], 'fam1', 1 ).
test( 't22', 591, [], [], 'fam1', 1 ).
test( 't23', 126, [], ['r1'], 'fam1', 1 ).
test( 't24', 197, [], ['r4','r1'], 'fam1', 1 ).
test( 't25', 514, [], ['r5'], 'fam1', 1 ).
test( 't26', 123, [], [], 'fam1', 1 ).
test( 't27', 224, [], [], 'fam1', 1 ).
test( 't28', 314, [], [], 'fam1', 1 ).
test( 't29', 265, ['m17','m7','m4','m6','m10'], ['r2','r5','r4'], 'fam1', 1 ).
test( 't30', 305, [], [], 'fam1', 1 ).
test( 't31', 383, [], [], 'fam1', 1 ).
test( 't32', 354, [], ['r5','r2','r1','r3'], 'fam1', 1 ).
test( 't33', 192, [], ['r5','r1'], 'fam1', 1 ).
test( 't34', 751, ['m7','m15'], [], 'fam1', 1 ).
test( 't35', 271, [], [], 'fam1', 1 ).
test( 't36', 175, [], [], 'fam1', 1 ).
test( 't37', 801, [], [], 'fam1', 1 ).
test( 't38', 60, [], ['r2','r3','r1','r4'], 'fam1', 1 ).
test( 't39', 606, [], [], 'fam1', 1 ).
test( 't40', 517, [], [], 'fam1', 1 ).
test( 't41', 540, [], ['r2'], 'fam1', 1 ).
test( 't42', 46, [], [], 'fam1', 1 ).
test( 't43', 398, ['m11','m3','m16','m1','m13','m15','m20','m8'], [], 'fam1', 1 ).
test( 't44', 438, [], [], 'fam1', 1 ).
test( 't45', 115, ['m11','m8','m2','m18'], [], 'fam1', 1 ).
test( 't46', 785, [], ['r3','r2','r1','r5'], 'fam1', 1 ).
test( 't47', 398, ['m16','m8','m20','m2','m14','m1','m4'], [], 'fam1', 1 ).
test( 't48', 522, [], [], 'fam1', 1 ).
test( 't49', 560, [], ['r5','r2','r4'], 'fam1', 1 ).
test( 't50', 519, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
