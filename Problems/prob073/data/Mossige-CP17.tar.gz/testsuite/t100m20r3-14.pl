%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 20
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 475, [], [], 'fam1', 1 ).
test( 't2', 715, [], [], 'fam1', 1 ).
test( 't3', 628, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't4', 216, [], [], 'fam1', 1 ).
test( 't5', 484, ['m2','m19','m9','m11','m14','m1','m10','m17'], ['r3','r2','r1'], 'fam1', 1 ).
test( 't6', 718, [], [], 'fam1', 1 ).
test( 't7', 468, [], [], 'fam1', 1 ).
test( 't8', 656, [], ['r3','r2'], 'fam1', 1 ).
test( 't9', 662, [], ['r1'], 'fam1', 1 ).
test( 't10', 535, [], [], 'fam1', 1 ).
test( 't11', 472, ['m13','m10','m1','m9'], [], 'fam1', 1 ).
test( 't12', 603, [], [], 'fam1', 1 ).
test( 't13', 226, ['m2','m3','m18','m6','m12'], [], 'fam1', 1 ).
test( 't14', 760, [], [], 'fam1', 1 ).
test( 't15', 474, [], ['r3','r1'], 'fam1', 1 ).
test( 't16', 150, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't17', 113, [], [], 'fam1', 1 ).
test( 't18', 223, ['m1'], [], 'fam1', 1 ).
test( 't19', 602, ['m12','m20','m14','m2','m19','m10','m18','m17'], [], 'fam1', 1 ).
test( 't20', 341, [], [], 'fam1', 1 ).
test( 't21', 502, [], [], 'fam1', 1 ).
test( 't22', 662, [], [], 'fam1', 1 ).
test( 't23', 17, [], [], 'fam1', 1 ).
test( 't24', 423, [], [], 'fam1', 1 ).
test( 't25', 616, [], [], 'fam1', 1 ).
test( 't26', 198, [], [], 'fam1', 1 ).
test( 't27', 751, [], [], 'fam1', 1 ).
test( 't28', 38, [], [], 'fam1', 1 ).
test( 't29', 191, [], [], 'fam1', 1 ).
test( 't30', 201, [], [], 'fam1', 1 ).
test( 't31', 529, ['m16','m8'], ['r2'], 'fam1', 1 ).
test( 't32', 267, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't33', 481, [], [], 'fam1', 1 ).
test( 't34', 650, [], [], 'fam1', 1 ).
test( 't35', 148, ['m5','m7','m14','m15','m8','m19'], [], 'fam1', 1 ).
test( 't36', 779, [], ['r1','r2'], 'fam1', 1 ).
test( 't37', 386, [], [], 'fam1', 1 ).
test( 't38', 27, ['m15'], [], 'fam1', 1 ).
test( 't39', 662, [], ['r2'], 'fam1', 1 ).
test( 't40', 612, ['m3','m8','m2','m20','m4','m9','m16','m15'], [], 'fam1', 1 ).
test( 't41', 278, [], [], 'fam1', 1 ).
test( 't42', 590, [], [], 'fam1', 1 ).
test( 't43', 41, [], [], 'fam1', 1 ).
test( 't44', 200, ['m20','m6','m15','m12','m4'], [], 'fam1', 1 ).
test( 't45', 249, ['m17','m12','m20','m9','m2'], [], 'fam1', 1 ).
test( 't46', 793, ['m9'], ['r2','r1','r3'], 'fam1', 1 ).
test( 't47', 254, [], [], 'fam1', 1 ).
test( 't48', 218, [], [], 'fam1', 1 ).
test( 't49', 633, [], [], 'fam1', 1 ).
test( 't50', 85, [], [], 'fam1', 1 ).
test( 't51', 696, [], [], 'fam1', 1 ).
test( 't52', 55, ['m16','m17','m2','m9','m13','m18','m11','m5'], [], 'fam1', 1 ).
test( 't53', 606, [], [], 'fam1', 1 ).
test( 't54', 9, [], ['r2'], 'fam1', 1 ).
test( 't55', 110, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't56', 781, [], [], 'fam1', 1 ).
test( 't57', 333, [], [], 'fam1', 1 ).
test( 't58', 709, [], [], 'fam1', 1 ).
test( 't59', 476, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't60', 662, [], [], 'fam1', 1 ).
test( 't61', 541, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't62', 152, [], [], 'fam1', 1 ).
test( 't63', 112, [], [], 'fam1', 1 ).
test( 't64', 429, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't65', 800, ['m20','m12','m15','m10','m4','m3'], [], 'fam1', 1 ).
test( 't66', 123, [], ['r2','r1'], 'fam1', 1 ).
test( 't67', 355, [], [], 'fam1', 1 ).
test( 't68', 46, [], [], 'fam1', 1 ).
test( 't69', 357, ['m13','m19','m11','m7','m17'], ['r2'], 'fam1', 1 ).
test( 't70', 218, [], [], 'fam1', 1 ).
test( 't71', 572, [], [], 'fam1', 1 ).
test( 't72', 548, [], [], 'fam1', 1 ).
test( 't73', 640, [], [], 'fam1', 1 ).
test( 't74', 384, [], ['r2'], 'fam1', 1 ).
test( 't75', 351, [], [], 'fam1', 1 ).
test( 't76', 56, [], ['r1','r3'], 'fam1', 1 ).
test( 't77', 14, [], ['r3','r1'], 'fam1', 1 ).
test( 't78', 181, [], ['r3'], 'fam1', 1 ).
test( 't79', 544, ['m2','m1','m16','m17'], [], 'fam1', 1 ).
test( 't80', 467, [], ['r2','r3'], 'fam1', 1 ).
test( 't81', 614, [], ['r1','r2'], 'fam1', 1 ).
test( 't82', 559, [], [], 'fam1', 1 ).
test( 't83', 51, [], [], 'fam1', 1 ).
test( 't84', 463, [], ['r3'], 'fam1', 1 ).
test( 't85', 225, [], [], 'fam1', 1 ).
test( 't86', 207, [], [], 'fam1', 1 ).
test( 't87', 481, ['m20','m6','m9','m3','m10','m16','m11','m5'], [], 'fam1', 1 ).
test( 't88', 228, [], [], 'fam1', 1 ).
test( 't89', 294, ['m14','m6','m3'], [], 'fam1', 1 ).
test( 't90', 565, [], [], 'fam1', 1 ).
test( 't91', 724, [], ['r1'], 'fam1', 1 ).
test( 't92', 525, [], [], 'fam1', 1 ).
test( 't93', 750, ['m2','m12','m13','m9'], ['r3','r1'], 'fam1', 1 ).
test( 't94', 541, [], [], 'fam1', 1 ).
test( 't95', 44, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't96', 476, [], [], 'fam1', 1 ).
test( 't97', 310, [], ['r1'], 'fam1', 1 ).
test( 't98', 308, [], [], 'fam1', 1 ).
test( 't99', 262, [], [], 'fam1', 1 ).
test( 't100', 284, ['m3','m5','m6'], ['r1','r3','r2'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
