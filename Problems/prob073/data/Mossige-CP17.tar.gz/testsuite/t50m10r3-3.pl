%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 107, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't2', 774, [], [], 'fam1', 1 ).
test( 't3', 207, [], [], 'fam1', 1 ).
test( 't4', 412, ['m9'], [], 'fam1', 1 ).
test( 't5', 445, [], ['r1'], 'fam1', 1 ).
test( 't6', 183, [], [], 'fam1', 1 ).
test( 't7', 579, [], [], 'fam1', 1 ).
test( 't8', 187, [], [], 'fam1', 1 ).
test( 't9', 137, [], [], 'fam1', 1 ).
test( 't10', 235, [], ['r2'], 'fam1', 1 ).
test( 't11', 27, ['m3'], [], 'fam1', 1 ).
test( 't12', 129, [], [], 'fam1', 1 ).
test( 't13', 426, ['m2','m4','m8'], [], 'fam1', 1 ).
test( 't14', 330, [], [], 'fam1', 1 ).
test( 't15', 463, [], [], 'fam1', 1 ).
test( 't16', 128, [], [], 'fam1', 1 ).
test( 't17', 448, [], ['r1'], 'fam1', 1 ).
test( 't18', 795, [], [], 'fam1', 1 ).
test( 't19', 388, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't20', 313, [], [], 'fam1', 1 ).
test( 't21', 773, ['m5','m1','m10','m4'], ['r2','r3','r1'], 'fam1', 1 ).
test( 't22', 478, [], [], 'fam1', 1 ).
test( 't23', 450, [], [], 'fam1', 1 ).
test( 't24', 132, [], [], 'fam1', 1 ).
test( 't25', 587, [], ['r3'], 'fam1', 1 ).
test( 't26', 447, [], ['r2'], 'fam1', 1 ).
test( 't27', 280, [], [], 'fam1', 1 ).
test( 't28', 73, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't29', 535, [], [], 'fam1', 1 ).
test( 't30', 395, ['m6','m7'], [], 'fam1', 1 ).
test( 't31', 786, ['m9','m4','m1'], ['r2'], 'fam1', 1 ).
test( 't32', 483, ['m6','m5','m3'], ['r2','r1','r3'], 'fam1', 1 ).
test( 't33', 204, [], [], 'fam1', 1 ).
test( 't34', 95, [], [], 'fam1', 1 ).
test( 't35', 31, [], [], 'fam1', 1 ).
test( 't36', 305, ['m5','m4','m3','m8'], [], 'fam1', 1 ).
test( 't37', 590, ['m4'], [], 'fam1', 1 ).
test( 't38', 743, [], [], 'fam1', 1 ).
test( 't39', 460, [], ['r1','r2'], 'fam1', 1 ).
test( 't40', 635, [], [], 'fam1', 1 ).
test( 't41', 250, [], [], 'fam1', 1 ).
test( 't42', 492, [], [], 'fam1', 1 ).
test( 't43', 209, [], [], 'fam1', 1 ).
test( 't44', 255, [], [], 'fam1', 1 ).
test( 't45', 546, [], ['r1'], 'fam1', 1 ).
test( 't46', 499, [], [], 'fam1', 1 ).
test( 't47', 510, ['m6','m9','m10','m5'], [], 'fam1', 1 ).
test( 't48', 347, ['m6','m5'], [], 'fam1', 1 ).
test( 't49', 219, [], [], 'fam1', 1 ).
test( 't50', 398, ['m9','m5','m4','m8'], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
