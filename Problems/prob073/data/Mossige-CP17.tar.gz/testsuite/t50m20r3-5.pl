%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 20
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 449, [], [], 'fam1', 1 ).
test( 't2', 155, [], ['r1'], 'fam1', 1 ).
test( 't3', 438, [], [], 'fam1', 1 ).
test( 't4', 714, [], [], 'fam1', 1 ).
test( 't5', 480, ['m3','m9','m12','m10'], [], 'fam1', 1 ).
test( 't6', 23, ['m16','m17','m19','m13','m15','m5','m2'], [], 'fam1', 1 ).
test( 't7', 513, ['m9','m2','m3','m18','m13','m1','m10','m17'], [], 'fam1', 1 ).
test( 't8', 801, [], [], 'fam1', 1 ).
test( 't9', 572, [], [], 'fam1', 1 ).
test( 't10', 593, [], [], 'fam1', 1 ).
test( 't11', 418, [], [], 'fam1', 1 ).
test( 't12', 38, [], [], 'fam1', 1 ).
test( 't13', 788, [], [], 'fam1', 1 ).
test( 't14', 89, [], [], 'fam1', 1 ).
test( 't15', 666, ['m12','m9','m18'], [], 'fam1', 1 ).
test( 't16', 507, ['m3','m7','m15','m6','m10'], [], 'fam1', 1 ).
test( 't17', 65, [], [], 'fam1', 1 ).
test( 't18', 58, ['m10'], [], 'fam1', 1 ).
test( 't19', 508, [], [], 'fam1', 1 ).
test( 't20', 124, [], ['r1'], 'fam1', 1 ).
test( 't21', 139, [], ['r1'], 'fam1', 1 ).
test( 't22', 17, [], [], 'fam1', 1 ).
test( 't23', 192, [], [], 'fam1', 1 ).
test( 't24', 329, [], [], 'fam1', 1 ).
test( 't25', 494, ['m1'], [], 'fam1', 1 ).
test( 't26', 530, [], ['r3','r1'], 'fam1', 1 ).
test( 't27', 474, [], [], 'fam1', 1 ).
test( 't28', 242, [], [], 'fam1', 1 ).
test( 't29', 482, [], ['r1','r2'], 'fam1', 1 ).
test( 't30', 270, [], [], 'fam1', 1 ).
test( 't31', 536, ['m3','m6','m15','m19','m16','m14','m9','m5'], [], 'fam1', 1 ).
test( 't32', 568, [], [], 'fam1', 1 ).
test( 't33', 544, [], [], 'fam1', 1 ).
test( 't34', 188, [], [], 'fam1', 1 ).
test( 't35', 80, ['m7','m17'], ['r1','r3','r2'], 'fam1', 1 ).
test( 't36', 284, [], [], 'fam1', 1 ).
test( 't37', 280, [], [], 'fam1', 1 ).
test( 't38', 749, [], [], 'fam1', 1 ).
test( 't39', 111, [], [], 'fam1', 1 ).
test( 't40', 405, ['m3','m19','m11','m15','m13','m9','m5'], [], 'fam1', 1 ).
test( 't41', 437, [], [], 'fam1', 1 ).
test( 't42', 309, [], [], 'fam1', 1 ).
test( 't43', 629, [], ['r2'], 'fam1', 1 ).
test( 't44', 435, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't45', 672, [], [], 'fam1', 1 ).
test( 't46', 439, ['m15','m17','m1','m16','m19','m11'], [], 'fam1', 1 ).
test( 't47', 86, [], [], 'fam1', 1 ).
test( 't48', 137, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't49', 433, [], [], 'fam1', 1 ).
test( 't50', 465, [], ['r2'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
