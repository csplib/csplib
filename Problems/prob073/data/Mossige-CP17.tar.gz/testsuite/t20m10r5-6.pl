%% ****  Testsuite  ****
% Number of tests                  : 20
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 157, [], [], 'fam1', 1 ).
test( 't2', 610, [], [], 'fam1', 1 ).
test( 't3', 201, [], [], 'fam1', 1 ).
test( 't4', 670, [], [], 'fam1', 1 ).
test( 't5', 414, [], [], 'fam1', 1 ).
test( 't6', 386, [], [], 'fam1', 1 ).
test( 't7', 625, [], [], 'fam1', 1 ).
test( 't8', 769, [], [], 'fam1', 1 ).
test( 't9', 708, [], ['r1','r4','r3'], 'fam1', 1 ).
test( 't10', 608, ['m5','m7','m10','m3'], [], 'fam1', 1 ).
test( 't11', 211, [], [], 'fam1', 1 ).
test( 't12', 702, [], ['r3','r4','r5'], 'fam1', 1 ).
test( 't13', 44, [], [], 'fam1', 1 ).
test( 't14', 130, [], [], 'fam1', 1 ).
test( 't15', 151, [], ['r2','r5','r1','r4','r3'], 'fam1', 1 ).
test( 't16', 547, [], [], 'fam1', 1 ).
test( 't17', 696, [], [], 'fam1', 1 ).
test( 't18', 393, [], [], 'fam1', 1 ).
test( 't19', 247, [], ['r3','r4'], 'fam1', 1 ).
test( 't20', 590, [], ['r2','r4','r5','r1','r3'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
