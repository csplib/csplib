%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 20
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 483, [], ['r2','r1'], 'fam1', 1 ).
test( 't2', 737, [], ['r3'], 'fam1', 1 ).
test( 't3', 748, [], [], 'fam1', 1 ).
test( 't4', 43, ['m11','m10','m16'], [], 'fam1', 1 ).
test( 't5', 146, [], [], 'fam1', 1 ).
test( 't6', 706, [], [], 'fam1', 1 ).
test( 't7', 799, [], ['r3','r2'], 'fam1', 1 ).
test( 't8', 490, ['m12','m7','m10','m16','m17','m3','m18','m20'], [], 'fam1', 1 ).
test( 't9', 161, [], ['r2'], 'fam1', 1 ).
test( 't10', 542, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't11', 440, [], [], 'fam1', 1 ).
test( 't12', 31, ['m6','m1','m7'], [], 'fam1', 1 ).
test( 't13', 590, [], [], 'fam1', 1 ).
test( 't14', 491, ['m4','m2'], [], 'fam1', 1 ).
test( 't15', 164, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't16', 59, [], [], 'fam1', 1 ).
test( 't17', 73, [], ['r2'], 'fam1', 1 ).
test( 't18', 118, ['m16','m10','m12','m1','m2','m8'], [], 'fam1', 1 ).
test( 't19', 94, [], [], 'fam1', 1 ).
test( 't20', 192, [], ['r2','r1'], 'fam1', 1 ).
test( 't21', 5, [], [], 'fam1', 1 ).
test( 't22', 523, [], [], 'fam1', 1 ).
test( 't23', 481, [], [], 'fam1', 1 ).
test( 't24', 272, ['m8','m7','m18','m4','m6'], [], 'fam1', 1 ).
test( 't25', 85, [], [], 'fam1', 1 ).
test( 't26', 445, ['m13','m12','m4','m16','m7','m10'], [], 'fam1', 1 ).
test( 't27', 722, [], ['r2','r1'], 'fam1', 1 ).
test( 't28', 674, [], ['r2'], 'fam1', 1 ).
test( 't29', 180, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't30', 777, [], [], 'fam1', 1 ).
test( 't31', 498, [], [], 'fam1', 1 ).
test( 't32', 411, [], [], 'fam1', 1 ).
test( 't33', 757, [], [], 'fam1', 1 ).
test( 't34', 248, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't35', 661, [], [], 'fam1', 1 ).
test( 't36', 72, [], [], 'fam1', 1 ).
test( 't37', 109, [], [], 'fam1', 1 ).
test( 't38', 529, [], [], 'fam1', 1 ).
test( 't39', 161, [], [], 'fam1', 1 ).
test( 't40', 263, [], [], 'fam1', 1 ).
test( 't41', 746, [], ['r1','r2'], 'fam1', 1 ).
test( 't42', 671, ['m16','m3','m2','m13','m6','m8','m4'], [], 'fam1', 1 ).
test( 't43', 659, [], ['r3','r2'], 'fam1', 1 ).
test( 't44', 259, [], [], 'fam1', 1 ).
test( 't45', 191, ['m18','m19','m4','m6','m12','m9','m7'], [], 'fam1', 1 ).
test( 't46', 38, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't47', 79, ['m1','m5','m20','m11'], [], 'fam1', 1 ).
test( 't48', 320, [], [], 'fam1', 1 ).
test( 't49', 364, ['m5','m10'], [], 'fam1', 1 ).
test( 't50', 617, [], [], 'fam1', 1 ).
test( 't51', 445, ['m11','m20','m8','m15','m1','m18','m3'], ['r3','r2','r1'], 'fam1', 1 ).
test( 't52', 161, [], [], 'fam1', 1 ).
test( 't53', 84, ['m11','m7','m12','m3','m18','m20','m10'], ['r1','r2'], 'fam1', 1 ).
test( 't54', 361, [], ['r3'], 'fam1', 1 ).
test( 't55', 280, ['m8','m11','m2'], ['r3','r2'], 'fam1', 1 ).
test( 't56', 309, ['m16','m2','m19','m18','m3'], [], 'fam1', 1 ).
test( 't57', 497, ['m19','m5','m14'], [], 'fam1', 1 ).
test( 't58', 785, [], ['r2'], 'fam1', 1 ).
test( 't59', 263, ['m15','m11','m7','m16','m19','m17'], [], 'fam1', 1 ).
test( 't60', 565, ['m11'], [], 'fam1', 1 ).
test( 't61', 386, [], ['r2'], 'fam1', 1 ).
test( 't62', 146, ['m20','m2','m10','m3','m17','m7'], [], 'fam1', 1 ).
test( 't63', 594, [], [], 'fam1', 1 ).
test( 't64', 299, [], [], 'fam1', 1 ).
test( 't65', 592, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't66', 740, [], [], 'fam1', 1 ).
test( 't67', 723, ['m15','m19','m17','m5','m14','m1','m13'], ['r3','r1'], 'fam1', 1 ).
test( 't68', 714, [], [], 'fam1', 1 ).
test( 't69', 653, [], [], 'fam1', 1 ).
test( 't70', 289, ['m4','m12','m2','m8','m11'], [], 'fam1', 1 ).
test( 't71', 362, [], [], 'fam1', 1 ).
test( 't72', 718, ['m6','m9','m19','m2','m1'], [], 'fam1', 1 ).
test( 't73', 592, [], [], 'fam1', 1 ).
test( 't74', 511, [], [], 'fam1', 1 ).
test( 't75', 263, [], [], 'fam1', 1 ).
test( 't76', 254, [], ['r2'], 'fam1', 1 ).
test( 't77', 754, [], [], 'fam1', 1 ).
test( 't78', 286, [], [], 'fam1', 1 ).
test( 't79', 630, [], [], 'fam1', 1 ).
test( 't80', 768, [], [], 'fam1', 1 ).
test( 't81', 3, ['m9','m3','m10'], [], 'fam1', 1 ).
test( 't82', 729, [], [], 'fam1', 1 ).
test( 't83', 74, ['m8','m11','m9','m6','m18'], [], 'fam1', 1 ).
test( 't84', 519, [], [], 'fam1', 1 ).
test( 't85', 446, [], [], 'fam1', 1 ).
test( 't86', 411, [], [], 'fam1', 1 ).
test( 't87', 644, ['m4','m1','m18','m16','m3'], [], 'fam1', 1 ).
test( 't88', 656, [], ['r1'], 'fam1', 1 ).
test( 't89', 156, [], [], 'fam1', 1 ).
test( 't90', 98, [], ['r1'], 'fam1', 1 ).
test( 't91', 800, ['m12','m11','m20'], [], 'fam1', 1 ).
test( 't92', 195, ['m6','m14','m1','m18'], ['r1'], 'fam1', 1 ).
test( 't93', 273, ['m18'], [], 'fam1', 1 ).
test( 't94', 753, [], [], 'fam1', 1 ).
test( 't95', 447, [], [], 'fam1', 1 ).
test( 't96', 24, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't97', 662, [], [], 'fam1', 1 ).
test( 't98', 542, [], [], 'fam1', 1 ).
test( 't99', 192, [], [], 'fam1', 1 ).
test( 't100', 591, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
