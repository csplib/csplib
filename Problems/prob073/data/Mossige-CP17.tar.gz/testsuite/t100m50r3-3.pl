%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 50
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 540, [], [], 'fam1', 1 ).
test( 't2', 596, [], [], 'fam1', 1 ).
test( 't3', 777, ['m5','m47','m4','m8','m29','m34','m14'], [], 'fam1', 1 ).
test( 't4', 772, [], [], 'fam1', 1 ).
test( 't5', 496, [], [], 'fam1', 1 ).
test( 't6', 728, [], [], 'fam1', 1 ).
test( 't7', 656, [], [], 'fam1', 1 ).
test( 't8', 464, [], [], 'fam1', 1 ).
test( 't9', 261, [], [], 'fam1', 1 ).
test( 't10', 206, [], [], 'fam1', 1 ).
test( 't11', 757, [], [], 'fam1', 1 ).
test( 't12', 70, [], [], 'fam1', 1 ).
test( 't13', 88, [], [], 'fam1', 1 ).
test( 't14', 531, ['m30'], [], 'fam1', 1 ).
test( 't15', 354, [], [], 'fam1', 1 ).
test( 't16', 272, [], [], 'fam1', 1 ).
test( 't17', 444, [], [], 'fam1', 1 ).
test( 't18', 430, [], [], 'fam1', 1 ).
test( 't19', 363, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't20', 542, [], [], 'fam1', 1 ).
test( 't21', 46, [], [], 'fam1', 1 ).
test( 't22', 789, [], [], 'fam1', 1 ).
test( 't23', 499, ['m50','m40','m6','m29','m18'], ['r1','r2','r3'], 'fam1', 1 ).
test( 't24', 25, ['m50','m39','m34','m19','m27','m10','m49'], [], 'fam1', 1 ).
test( 't25', 580, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't26', 591, [], [], 'fam1', 1 ).
test( 't27', 308, ['m44','m10','m39','m40','m49','m47','m36','m37','m2','m38','m18'], [], 'fam1', 1 ).
test( 't28', 341, [], [], 'fam1', 1 ).
test( 't29', 269, [], [], 'fam1', 1 ).
test( 't30', 402, [], [], 'fam1', 1 ).
test( 't31', 648, [], [], 'fam1', 1 ).
test( 't32', 420, [], [], 'fam1', 1 ).
test( 't33', 30, ['m16','m29','m45','m9','m21','m14'], ['r3','r2'], 'fam1', 1 ).
test( 't34', 518, ['m32','m43','m11','m46','m31','m15','m41','m23','m14'], ['r2','r3','r1'], 'fam1', 1 ).
test( 't35', 203, [], [], 'fam1', 1 ).
test( 't36', 564, ['m30'], [], 'fam1', 1 ).
test( 't37', 539, [], [], 'fam1', 1 ).
test( 't38', 685, ['m11','m12','m13','m6','m20','m39','m33','m45','m42','m40','m24','m18','m46','m38','m5','m25'], [], 'fam1', 1 ).
test( 't39', 323, [], ['r2','r3'], 'fam1', 1 ).
test( 't40', 379, [], [], 'fam1', 1 ).
test( 't41', 506, ['m14','m8','m10','m21','m42','m29','m23','m6','m2','m19','m43','m1'], [], 'fam1', 1 ).
test( 't42', 248, [], [], 'fam1', 1 ).
test( 't43', 238, ['m49','m4','m19','m35','m31','m40','m2','m18','m26','m14','m7'], ['r1','r3','r2'], 'fam1', 1 ).
test( 't44', 21, ['m28','m15','m42','m21','m8','m39','m44'], ['r1','r2'], 'fam1', 1 ).
test( 't45', 397, ['m18','m1','m4','m46','m17','m19','m14','m10','m15','m5','m24','m33'], [], 'fam1', 1 ).
test( 't46', 131, [], [], 'fam1', 1 ).
test( 't47', 431, [], [], 'fam1', 1 ).
test( 't48', 87, ['m28','m18','m8','m24','m41','m10','m27','m29'], [], 'fam1', 1 ).
test( 't49', 391, [], [], 'fam1', 1 ).
test( 't50', 599, ['m41','m29','m20','m42','m24','m18','m34','m13','m14','m37','m39','m2','m46'], [], 'fam1', 1 ).
test( 't51', 278, [], [], 'fam1', 1 ).
test( 't52', 460, ['m23','m13','m22','m33','m36','m34','m50','m43','m26','m38','m37','m10','m15','m47','m20','m35'], ['r2','r3','r1'], 'fam1', 1 ).
test( 't53', 340, [], [], 'fam1', 1 ).
test( 't54', 511, [], [], 'fam1', 1 ).
test( 't55', 90, [], [], 'fam1', 1 ).
test( 't56', 525, [], [], 'fam1', 1 ).
test( 't57', 658, [], [], 'fam1', 1 ).
test( 't58', 30, [], [], 'fam1', 1 ).
test( 't59', 365, [], ['r1'], 'fam1', 1 ).
test( 't60', 518, [], [], 'fam1', 1 ).
test( 't61', 120, [], [], 'fam1', 1 ).
test( 't62', 473, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't63', 199, [], [], 'fam1', 1 ).
test( 't64', 525, [], [], 'fam1', 1 ).
test( 't65', 559, [], ['r3','r1'], 'fam1', 1 ).
test( 't66', 612, [], [], 'fam1', 1 ).
test( 't67', 42, [], [], 'fam1', 1 ).
test( 't68', 126, [], [], 'fam1', 1 ).
test( 't69', 262, [], [], 'fam1', 1 ).
test( 't70', 496, [], [], 'fam1', 1 ).
test( 't71', 653, [], [], 'fam1', 1 ).
test( 't72', 458, ['m50'], [], 'fam1', 1 ).
test( 't73', 342, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't74', 232, [], [], 'fam1', 1 ).
test( 't75', 671, [], [], 'fam1', 1 ).
test( 't76', 718, [], [], 'fam1', 1 ).
test( 't77', 717, [], [], 'fam1', 1 ).
test( 't78', 608, [], [], 'fam1', 1 ).
test( 't79', 160, [], [], 'fam1', 1 ).
test( 't80', 564, [], ['r3'], 'fam1', 1 ).
test( 't81', 117, [], [], 'fam1', 1 ).
test( 't82', 102, [], [], 'fam1', 1 ).
test( 't83', 355, [], [], 'fam1', 1 ).
test( 't84', 275, [], [], 'fam1', 1 ).
test( 't85', 701, ['m9','m49','m30','m24','m34','m13','m42','m23','m41','m16'], [], 'fam1', 1 ).
test( 't86', 101, ['m10','m6','m30','m11','m21','m17','m41','m40','m18','m16'], [], 'fam1', 1 ).
test( 't87', 285, [], [], 'fam1', 1 ).
test( 't88', 618, [], [], 'fam1', 1 ).
test( 't89', 429, [], ['r2','r1'], 'fam1', 1 ).
test( 't90', 627, [], [], 'fam1', 1 ).
test( 't91', 589, [], [], 'fam1', 1 ).
test( 't92', 213, [], [], 'fam1', 1 ).
test( 't93', 501, [], ['r1'], 'fam1', 1 ).
test( 't94', 459, [], [], 'fam1', 1 ).
test( 't95', 79, [], [], 'fam1', 1 ).
test( 't96', 349, [], [], 'fam1', 1 ).
test( 't97', 637, [], [], 'fam1', 1 ).
test( 't98', 642, [], [], 'fam1', 1 ).
test( 't99', 170, [], [], 'fam1', 1 ).
test( 't100', 386, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').
embedded_board( 'm21').
embedded_board( 'm22').
embedded_board( 'm23').
embedded_board( 'm24').
embedded_board( 'm25').
embedded_board( 'm26').
embedded_board( 'm27').
embedded_board( 'm28').
embedded_board( 'm29').
embedded_board( 'm30').
embedded_board( 'm31').
embedded_board( 'm32').
embedded_board( 'm33').
embedded_board( 'm34').
embedded_board( 'm35').
embedded_board( 'm36').
embedded_board( 'm37').
embedded_board( 'm38').
embedded_board( 'm39').
embedded_board( 'm40').
embedded_board( 'm41').
embedded_board( 'm42').
embedded_board( 'm43').
embedded_board( 'm44').
embedded_board( 'm45').
embedded_board( 'm46').
embedded_board( 'm47').
embedded_board( 'm48').
embedded_board( 'm49').
embedded_board( 'm50').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
