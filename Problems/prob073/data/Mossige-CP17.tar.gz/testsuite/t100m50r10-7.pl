%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 50
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 13, ['m32','m8','m17','m39','m13','m37','m33','m28'], [], 'fam1', 1 ).
test( 't2', 703, [], ['r8','r6','r1','r3','r7','r10'], 'fam1', 1 ).
test( 't3', 655, [], [], 'fam1', 1 ).
test( 't4', 243, [], ['r8','r5','r10','r7','r3'], 'fam1', 1 ).
test( 't5', 611, [], ['r8','r9','r2','r4','r7','r5'], 'fam1', 1 ).
test( 't6', 388, ['m8','m33','m5','m4','m45','m2','m44','m31','m42','m40','m14','m20','m46','m47'], [], 'fam1', 1 ).
test( 't7', 321, [], ['r8','r1','r7','r3','r9','r2','r10','r4','r6','r5'], 'fam1', 1 ).
test( 't8', 799, [], [], 'fam1', 1 ).
test( 't9', 445, [], [], 'fam1', 1 ).
test( 't10', 158, [], ['r3','r5','r7','r2','r6','r10','r8'], 'fam1', 1 ).
test( 't11', 126, [], [], 'fam1', 1 ).
test( 't12', 227, ['m25','m30','m27','m49','m18','m8','m22','m20','m10','m50','m16','m21','m23','m33','m7','m5','m32','m43'], [], 'fam1', 1 ).
test( 't13', 237, [], [], 'fam1', 1 ).
test( 't14', 528, [], [], 'fam1', 1 ).
test( 't15', 427, [], [], 'fam1', 1 ).
test( 't16', 634, [], [], 'fam1', 1 ).
test( 't17', 525, [], [], 'fam1', 1 ).
test( 't18', 81, [], [], 'fam1', 1 ).
test( 't19', 508, ['m25','m29','m8','m20','m9','m44','m17','m48','m37','m18','m12','m45'], [], 'fam1', 1 ).
test( 't20', 4, ['m24','m37','m19','m4','m50','m27','m39','m17','m49','m6','m33','m40'], ['r7','r9','r4','r6'], 'fam1', 1 ).
test( 't21', 337, [], [], 'fam1', 1 ).
test( 't22', 375, [], ['r4','r3','r1','r5'], 'fam1', 1 ).
test( 't23', 715, [], [], 'fam1', 1 ).
test( 't24', 526, [], ['r3','r6'], 'fam1', 1 ).
test( 't25', 274, [], [], 'fam1', 1 ).
test( 't26', 66, [], ['r3','r8','r1','r2','r9'], 'fam1', 1 ).
test( 't27', 24, [], [], 'fam1', 1 ).
test( 't28', 239, [], [], 'fam1', 1 ).
test( 't29', 729, [], [], 'fam1', 1 ).
test( 't30', 244, ['m43','m26','m1','m10','m16','m3','m4','m42','m35','m32','m23','m25','m8','m11'], [], 'fam1', 1 ).
test( 't31', 801, [], [], 'fam1', 1 ).
test( 't32', 544, ['m45','m8','m50','m42','m39','m10','m18','m34','m33','m3','m6','m31','m37','m11','m30','m1','m15'], [], 'fam1', 1 ).
test( 't33', 509, [], ['r4','r7','r5','r1','r10','r6','r9','r2','r3'], 'fam1', 1 ).
test( 't34', 576, [], ['r3','r1','r5','r10','r4'], 'fam1', 1 ).
test( 't35', 109, ['m9'], [], 'fam1', 1 ).
test( 't36', 393, [], ['r4'], 'fam1', 1 ).
test( 't37', 130, [], ['r2','r5','r1'], 'fam1', 1 ).
test( 't38', 133, [], [], 'fam1', 1 ).
test( 't39', 282, [], [], 'fam1', 1 ).
test( 't40', 559, ['m1','m22','m12','m6'], [], 'fam1', 1 ).
test( 't41', 392, [], [], 'fam1', 1 ).
test( 't42', 704, [], [], 'fam1', 1 ).
test( 't43', 222, [], [], 'fam1', 1 ).
test( 't44', 673, ['m25','m6','m23','m36','m41','m44','m16','m11','m21','m27','m33','m10','m15','m30','m49','m37','m39'], [], 'fam1', 1 ).
test( 't45', 312, [], [], 'fam1', 1 ).
test( 't46', 466, ['m44','m41','m40','m3','m10','m25','m22','m5','m34','m46','m37','m15','m29','m12','m50','m28','m27','m47'], [], 'fam1', 1 ).
test( 't47', 132, [], [], 'fam1', 1 ).
test( 't48', 373, [], ['r3'], 'fam1', 1 ).
test( 't49', 748, [], [], 'fam1', 1 ).
test( 't50', 201, [], [], 'fam1', 1 ).
test( 't51', 41, [], ['r1','r10','r8','r2','r6','r3','r4'], 'fam1', 1 ).
test( 't52', 114, [], [], 'fam1', 1 ).
test( 't53', 413, ['m18','m8','m46','m34','m1','m25','m38','m15','m14','m17','m20','m36','m23','m29','m40','m49'], [], 'fam1', 1 ).
test( 't54', 702, [], ['r6','r4','r3','r9','r8','r2','r5','r10'], 'fam1', 1 ).
test( 't55', 677, ['m5','m38','m19','m11','m12','m49'], ['r3','r7','r9','r4','r5'], 'fam1', 1 ).
test( 't56', 659, [], [], 'fam1', 1 ).
test( 't57', 711, [], [], 'fam1', 1 ).
test( 't58', 663, [], ['r8','r3','r6','r4','r9','r1','r10','r2','r7'], 'fam1', 1 ).
test( 't59', 38, [], [], 'fam1', 1 ).
test( 't60', 621, [], ['r10','r9','r5','r6','r8','r4','r1','r2'], 'fam1', 1 ).
test( 't61', 761, [], ['r3'], 'fam1', 1 ).
test( 't62', 52, ['m17','m21','m35','m26','m2','m46','m36','m32','m41','m24','m20','m43','m40','m9','m3','m29','m50'], ['r3','r2'], 'fam1', 1 ).
test( 't63', 410, [], [], 'fam1', 1 ).
test( 't64', 540, ['m44','m31','m11','m39','m9','m25','m10','m5','m13','m36','m21'], ['r5','r6','r1','r3','r8','r9'], 'fam1', 1 ).
test( 't65', 707, ['m19','m33','m29','m6','m11','m20','m41','m49','m25','m27','m34','m26','m17','m37','m50','m30','m12','m8','m42','m32'], [], 'fam1', 1 ).
test( 't66', 286, [], [], 'fam1', 1 ).
test( 't67', 788, [], [], 'fam1', 1 ).
test( 't68', 702, [], [], 'fam1', 1 ).
test( 't69', 200, [], [], 'fam1', 1 ).
test( 't70', 448, [], ['r1','r2','r7'], 'fam1', 1 ).
test( 't71', 75, [], [], 'fam1', 1 ).
test( 't72', 788, [], [], 'fam1', 1 ).
test( 't73', 486, [], [], 'fam1', 1 ).
test( 't74', 257, [], [], 'fam1', 1 ).
test( 't75', 482, ['m36','m8','m39','m25','m24','m5','m18','m41','m27','m26','m29'], ['r2','r9','r3','r5','r4','r7','r1','r10','r8'], 'fam1', 1 ).
test( 't76', 352, [], [], 'fam1', 1 ).
test( 't77', 314, [], [], 'fam1', 1 ).
test( 't78', 236, [], [], 'fam1', 1 ).
test( 't79', 291, [], ['r7'], 'fam1', 1 ).
test( 't80', 656, [], [], 'fam1', 1 ).
test( 't81', 387, [], [], 'fam1', 1 ).
test( 't82', 387, [], [], 'fam1', 1 ).
test( 't83', 27, ['m34','m7','m23','m16','m28','m50','m12','m15','m5'], [], 'fam1', 1 ).
test( 't84', 700, [], [], 'fam1', 1 ).
test( 't85', 240, [], ['r3','r1','r10','r7','r8'], 'fam1', 1 ).
test( 't86', 12, [], [], 'fam1', 1 ).
test( 't87', 363, ['m6','m1','m47','m15','m20','m21','m9','m27','m29','m18','m48','m3'], ['r3','r5'], 'fam1', 1 ).
test( 't88', 389, [], [], 'fam1', 1 ).
test( 't89', 766, [], [], 'fam1', 1 ).
test( 't90', 444, [], [], 'fam1', 1 ).
test( 't91', 209, [], [], 'fam1', 1 ).
test( 't92', 684, [], ['r3','r5'], 'fam1', 1 ).
test( 't93', 653, [], [], 'fam1', 1 ).
test( 't94', 710, [], [], 'fam1', 1 ).
test( 't95', 539, [], [], 'fam1', 1 ).
test( 't96', 99, [], ['r7','r10','r5','r4','r1'], 'fam1', 1 ).
test( 't97', 515, ['m6','m23','m21','m3','m37','m50','m5','m18','m29','m15','m1','m7','m8','m17','m22'], ['r4','r7','r10','r9','r8'], 'fam1', 1 ).
test( 't98', 503, [], [], 'fam1', 1 ).
test( 't99', 487, ['m10','m46','m36','m27','m48','m49','m5','m32','m4','m6','m19','m28','m43'], ['r7','r5','r3','r1'], 'fam1', 1 ).
test( 't100', 718, ['m5','m1','m9','m38','m47','m45','m32','m29','m21','m7','m33','m42','m24','m49','m34','m22','m25','m46','m13','m8'], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').
embedded_board( 'm21').
embedded_board( 'm22').
embedded_board( 'm23').
embedded_board( 'm24').
embedded_board( 'm25').
embedded_board( 'm26').
embedded_board( 'm27').
embedded_board( 'm28').
embedded_board( 'm29').
embedded_board( 'm30').
embedded_board( 'm31').
embedded_board( 'm32').
embedded_board( 'm33').
embedded_board( 'm34').
embedded_board( 'm35').
embedded_board( 'm36').
embedded_board( 'm37').
embedded_board( 'm38').
embedded_board( 'm39').
embedded_board( 'm40').
embedded_board( 'm41').
embedded_board( 'm42').
embedded_board( 'm43').
embedded_board( 'm44').
embedded_board( 'm45').
embedded_board( 'm46').
embedded_board( 'm47').
embedded_board( 'm48').
embedded_board( 'm49').
embedded_board( 'm50').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
