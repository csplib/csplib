%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 50
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 583, [], ['r2'], 'fam1', 1 ).
test( 't2', 410, [], [], 'fam1', 1 ).
test( 't3', 3, [], [], 'fam1', 1 ).
test( 't4', 263, [], [], 'fam1', 1 ).
test( 't5', 503, [], ['r5','r6','r9','r3','r10','r7'], 'fam1', 1 ).
test( 't6', 533, ['m19','m12','m20','m31','m27','m43'], [], 'fam1', 1 ).
test( 't7', 564, [], ['r3','r6','r5','r7','r4','r2','r10','r1','r9','r8'], 'fam1', 1 ).
test( 't8', 791, ['m23','m28'], [], 'fam1', 1 ).
test( 't9', 176, [], [], 'fam1', 1 ).
test( 't10', 96, [], [], 'fam1', 1 ).
test( 't11', 490, [], [], 'fam1', 1 ).
test( 't12', 92, ['m11','m38','m45','m29','m42','m5','m43','m48','m15','m47','m23','m2','m50','m27','m6','m17','m37'], [], 'fam1', 1 ).
test( 't13', 302, ['m8','m30','m29','m27','m45','m21'], [], 'fam1', 1 ).
test( 't14', 494, ['m22','m32','m15','m29','m8','m46','m30','m3','m41','m49','m23','m47','m4','m24','m13','m37','m39','m33'], [], 'fam1', 1 ).
test( 't15', 198, [], [], 'fam1', 1 ).
test( 't16', 645, ['m22','m36','m9','m31','m7','m50'], [], 'fam1', 1 ).
test( 't17', 651, [], ['r8','r4','r1','r7','r2','r10'], 'fam1', 1 ).
test( 't18', 375, [], [], 'fam1', 1 ).
test( 't19', 779, [], [], 'fam1', 1 ).
test( 't20', 246, ['m44','m14','m43','m47','m10','m21','m34','m4','m45','m16','m6','m46','m23','m29','m36','m5','m41','m3'], [], 'fam1', 1 ).
test( 't21', 164, ['m41','m40','m45','m9','m6','m12'], ['r6','r7'], 'fam1', 1 ).
test( 't22', 121, [], ['r10','r7','r2','r4','r9','r5','r6','r1','r3','r8'], 'fam1', 1 ).
test( 't23', 191, [], [], 'fam1', 1 ).
test( 't24', 778, [], [], 'fam1', 1 ).
test( 't25', 95, [], [], 'fam1', 1 ).
test( 't26', 63, [], [], 'fam1', 1 ).
test( 't27', 476, [], ['r1','r7','r5','r8','r4','r10','r2','r3','r9','r6'], 'fam1', 1 ).
test( 't28', 342, [], [], 'fam1', 1 ).
test( 't29', 723, [], [], 'fam1', 1 ).
test( 't30', 532, [], ['r1','r5','r3','r2','r6','r7','r4','r8'], 'fam1', 1 ).
test( 't31', 327, [], ['r1','r2'], 'fam1', 1 ).
test( 't32', 759, [], [], 'fam1', 1 ).
test( 't33', 673, [], [], 'fam1', 1 ).
test( 't34', 736, [], ['r1','r8','r10','r6'], 'fam1', 1 ).
test( 't35', 334, ['m45','m21','m19','m31','m41','m9','m28','m35','m2','m6','m26','m44'], [], 'fam1', 1 ).
test( 't36', 739, ['m6','m27','m28'], [], 'fam1', 1 ).
test( 't37', 182, [], [], 'fam1', 1 ).
test( 't38', 750, [], [], 'fam1', 1 ).
test( 't39', 747, [], [], 'fam1', 1 ).
test( 't40', 640, [], [], 'fam1', 1 ).
test( 't41', 395, ['m47','m37','m38','m18','m4','m34','m17'], [], 'fam1', 1 ).
test( 't42', 621, [], ['r6','r9','r3','r10','r4','r2','r7','r8','r5'], 'fam1', 1 ).
test( 't43', 18, ['m43','m2','m24','m18','m35','m41','m14','m4','m1','m10','m46'], ['r8','r2','r4'], 'fam1', 1 ).
test( 't44', 389, [], [], 'fam1', 1 ).
test( 't45', 649, [], [], 'fam1', 1 ).
test( 't46', 57, [], [], 'fam1', 1 ).
test( 't47', 233, [], [], 'fam1', 1 ).
test( 't48', 610, [], [], 'fam1', 1 ).
test( 't49', 423, [], [], 'fam1', 1 ).
test( 't50', 530, [], [], 'fam1', 1 ).
test( 't51', 79, [], [], 'fam1', 1 ).
test( 't52', 477, ['m5','m21','m24','m6','m48','m26','m2','m9','m14','m15','m16','m20','m11','m29','m25','m43'], ['r3','r8','r1','r5','r6'], 'fam1', 1 ).
test( 't53', 407, [], ['r6','r2','r10','r4','r8','r1','r3','r7','r9','r5'], 'fam1', 1 ).
test( 't54', 400, [], [], 'fam1', 1 ).
test( 't55', 58, [], [], 'fam1', 1 ).
test( 't56', 160, [], ['r4','r9','r8'], 'fam1', 1 ).
test( 't57', 164, [], ['r4','r6','r1'], 'fam1', 1 ).
test( 't58', 685, ['m32','m44','m19','m47','m16','m6','m5','m14','m30','m41'], [], 'fam1', 1 ).
test( 't59', 446, ['m8','m34','m36','m32','m16','m22','m30','m39'], ['r4','r3','r7','r8'], 'fam1', 1 ).
test( 't60', 194, [], [], 'fam1', 1 ).
test( 't61', 380, [], ['r8','r5','r9','r2','r3','r10'], 'fam1', 1 ).
test( 't62', 277, [], ['r1','r5','r9'], 'fam1', 1 ).
test( 't63', 234, [], ['r5','r1','r10','r9','r2','r4'], 'fam1', 1 ).
test( 't64', 197, [], ['r5'], 'fam1', 1 ).
test( 't65', 151, [], ['r9','r2','r6','r10','r1','r3','r8','r7','r4'], 'fam1', 1 ).
test( 't66', 671, [], ['r10','r4','r2','r5','r9','r1','r7','r8'], 'fam1', 1 ).
test( 't67', 36, [], [], 'fam1', 1 ).
test( 't68', 293, [], [], 'fam1', 1 ).
test( 't69', 256, ['m25','m5','m7','m12','m30','m15','m35','m40'], [], 'fam1', 1 ).
test( 't70', 794, [], [], 'fam1', 1 ).
test( 't71', 105, [], ['r8','r9','r10','r3','r1'], 'fam1', 1 ).
test( 't72', 422, [], ['r7','r4','r2'], 'fam1', 1 ).
test( 't73', 32, [], [], 'fam1', 1 ).
test( 't74', 404, [], [], 'fam1', 1 ).
test( 't75', 459, [], [], 'fam1', 1 ).
test( 't76', 651, [], [], 'fam1', 1 ).
test( 't77', 135, ['m20','m33','m21','m22','m19'], [], 'fam1', 1 ).
test( 't78', 437, [], [], 'fam1', 1 ).
test( 't79', 659, [], ['r10','r5','r9','r7','r4','r3','r1','r6'], 'fam1', 1 ).
test( 't80', 374, ['m41','m50','m9'], ['r1','r7','r2','r9','r10','r4','r5','r6','r3'], 'fam1', 1 ).
test( 't81', 194, [], [], 'fam1', 1 ).
test( 't82', 77, [], [], 'fam1', 1 ).
test( 't83', 599, [], [], 'fam1', 1 ).
test( 't84', 7, [], [], 'fam1', 1 ).
test( 't85', 54, [], [], 'fam1', 1 ).
test( 't86', 533, [], ['r3','r4','r10','r6','r9','r8','r7','r5','r2','r1'], 'fam1', 1 ).
test( 't87', 33, [], [], 'fam1', 1 ).
test( 't88', 747, [], ['r3','r7','r5','r6','r8','r10','r2'], 'fam1', 1 ).
test( 't89', 37, [], ['r1','r5','r6','r2','r3','r8','r9','r10'], 'fam1', 1 ).
test( 't90', 103, [], [], 'fam1', 1 ).
test( 't91', 721, [], [], 'fam1', 1 ).
test( 't92', 458, [], ['r6'], 'fam1', 1 ).
test( 't93', 330, [], ['r2'], 'fam1', 1 ).
test( 't94', 690, ['m44','m20','m39'], ['r5','r4','r2','r1','r7','r6','r3'], 'fam1', 1 ).
test( 't95', 263, [], [], 'fam1', 1 ).
test( 't96', 686, [], [], 'fam1', 1 ).
test( 't97', 444, [], ['r3','r9','r7','r5','r4','r1'], 'fam1', 1 ).
test( 't98', 44, [], [], 'fam1', 1 ).
test( 't99', 789, [], [], 'fam1', 1 ).
test( 't100', 88, [], ['r1','r4'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').
embedded_board( 'm21').
embedded_board( 'm22').
embedded_board( 'm23').
embedded_board( 'm24').
embedded_board( 'm25').
embedded_board( 'm26').
embedded_board( 'm27').
embedded_board( 'm28').
embedded_board( 'm29').
embedded_board( 'm30').
embedded_board( 'm31').
embedded_board( 'm32').
embedded_board( 'm33').
embedded_board( 'm34').
embedded_board( 'm35').
embedded_board( 'm36').
embedded_board( 'm37').
embedded_board( 'm38').
embedded_board( 'm39').
embedded_board( 'm40').
embedded_board( 'm41').
embedded_board( 'm42').
embedded_board( 'm43').
embedded_board( 'm44').
embedded_board( 'm45').
embedded_board( 'm46').
embedded_board( 'm47').
embedded_board( 'm48').
embedded_board( 'm49').
embedded_board( 'm50').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
