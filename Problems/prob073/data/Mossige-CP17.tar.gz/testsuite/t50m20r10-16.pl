%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 20
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 132, [], ['r8','r5','r7','r3','r10','r6','r9'], 'fam1', 1 ).
test( 't2', 577, [], [], 'fam1', 1 ).
test( 't3', 720, [], [], 'fam1', 1 ).
test( 't4', 244, [], [], 'fam1', 1 ).
test( 't5', 149, [], [], 'fam1', 1 ).
test( 't6', 5, [], ['r1','r4','r5','r6','r8','r10','r3','r9','r7','r2'], 'fam1', 1 ).
test( 't7', 467, [], [], 'fam1', 1 ).
test( 't8', 630, [], [], 'fam1', 1 ).
test( 't9', 378, [], [], 'fam1', 1 ).
test( 't10', 565, ['m13','m19','m7','m8','m12','m16','m14','m11'], [], 'fam1', 1 ).
test( 't11', 696, [], [], 'fam1', 1 ).
test( 't12', 55, [], [], 'fam1', 1 ).
test( 't13', 446, [], ['r1'], 'fam1', 1 ).
test( 't14', 348, [], ['r6','r1','r8','r3'], 'fam1', 1 ).
test( 't15', 454, [], ['r7','r8'], 'fam1', 1 ).
test( 't16', 707, [], [], 'fam1', 1 ).
test( 't17', 593, [], [], 'fam1', 1 ).
test( 't18', 288, [], [], 'fam1', 1 ).
test( 't19', 185, [], [], 'fam1', 1 ).
test( 't20', 679, [], ['r7'], 'fam1', 1 ).
test( 't21', 486, [], ['r6','r10','r4','r8','r9','r1','r7','r3','r2','r5'], 'fam1', 1 ).
test( 't22', 103, [], [], 'fam1', 1 ).
test( 't23', 590, [], ['r5','r1','r7','r8'], 'fam1', 1 ).
test( 't24', 469, [], [], 'fam1', 1 ).
test( 't25', 536, [], ['r1','r5'], 'fam1', 1 ).
test( 't26', 246, [], ['r10','r7'], 'fam1', 1 ).
test( 't27', 35, [], [], 'fam1', 1 ).
test( 't28', 653, [], [], 'fam1', 1 ).
test( 't29', 659, ['m10','m15','m19'], [], 'fam1', 1 ).
test( 't30', 440, [], ['r10','r8','r9'], 'fam1', 1 ).
test( 't31', 47, ['m15','m13','m6','m7','m1','m8'], [], 'fam1', 1 ).
test( 't32', 54, [], ['r10','r4','r7','r1'], 'fam1', 1 ).
test( 't33', 631, ['m17'], ['r3'], 'fam1', 1 ).
test( 't34', 712, ['m2','m12','m15'], [], 'fam1', 1 ).
test( 't35', 78, [], ['r1','r6','r2','r5','r3'], 'fam1', 1 ).
test( 't36', 451, [], [], 'fam1', 1 ).
test( 't37', 215, ['m11','m16','m3','m13','m20','m2'], [], 'fam1', 1 ).
test( 't38', 549, ['m19','m17','m8','m7','m1','m16','m6'], ['r3','r5','r7','r4','r2','r9'], 'fam1', 1 ).
test( 't39', 92, [], [], 'fam1', 1 ).
test( 't40', 467, [], [], 'fam1', 1 ).
test( 't41', 495, [], ['r7','r9','r5'], 'fam1', 1 ).
test( 't42', 28, [], [], 'fam1', 1 ).
test( 't43', 232, [], [], 'fam1', 1 ).
test( 't44', 18, [], [], 'fam1', 1 ).
test( 't45', 279, [], [], 'fam1', 1 ).
test( 't46', 606, ['m2'], [], 'fam1', 1 ).
test( 't47', 601, [], ['r2','r6','r8','r1','r10','r9','r7','r3','r5'], 'fam1', 1 ).
test( 't48', 683, [], [], 'fam1', 1 ).
test( 't49', 741, [], ['r2','r4','r7','r3','r10'], 'fam1', 1 ).
test( 't50', 214, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
