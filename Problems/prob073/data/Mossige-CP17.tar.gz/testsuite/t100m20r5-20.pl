%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 20
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 453, [], [], 'fam1', 1 ).
test( 't2', 63, [], [], 'fam1', 1 ).
test( 't3', 735, [], [], 'fam1', 1 ).
test( 't4', 403, [], [], 'fam1', 1 ).
test( 't5', 114, [], [], 'fam1', 1 ).
test( 't6', 192, ['m15','m17','m4','m3','m5','m9'], ['r3','r4','r5'], 'fam1', 1 ).
test( 't7', 478, [], ['r5','r3'], 'fam1', 1 ).
test( 't8', 389, [], [], 'fam1', 1 ).
test( 't9', 3, [], [], 'fam1', 1 ).
test( 't10', 708, ['m16','m19','m9','m1','m2','m14','m4','m6'], ['r5','r3','r1'], 'fam1', 1 ).
test( 't11', 146, [], [], 'fam1', 1 ).
test( 't12', 742, ['m8','m20','m17','m13','m16'], [], 'fam1', 1 ).
test( 't13', 520, [], ['r2','r4','r3'], 'fam1', 1 ).
test( 't14', 495, [], ['r3','r5','r4','r1','r2'], 'fam1', 1 ).
test( 't15', 642, [], [], 'fam1', 1 ).
test( 't16', 282, [], [], 'fam1', 1 ).
test( 't17', 469, [], ['r3','r4','r2','r5'], 'fam1', 1 ).
test( 't18', 146, [], ['r1','r5','r3','r2'], 'fam1', 1 ).
test( 't19', 650, [], [], 'fam1', 1 ).
test( 't20', 668, [], ['r4','r2','r5','r1','r3'], 'fam1', 1 ).
test( 't21', 768, [], [], 'fam1', 1 ).
test( 't22', 344, ['m10','m8'], ['r5','r2','r3','r1'], 'fam1', 1 ).
test( 't23', 18, ['m19'], ['r3','r5','r2','r4'], 'fam1', 1 ).
test( 't24', 161, ['m11','m14'], ['r5','r2','r1','r4','r3'], 'fam1', 1 ).
test( 't25', 7, [], [], 'fam1', 1 ).
test( 't26', 636, [], [], 'fam1', 1 ).
test( 't27', 721, [], [], 'fam1', 1 ).
test( 't28', 498, ['m10','m8','m6','m12','m14','m18','m4'], [], 'fam1', 1 ).
test( 't29', 598, [], [], 'fam1', 1 ).
test( 't30', 584, [], ['r1','r5','r4'], 'fam1', 1 ).
test( 't31', 279, [], [], 'fam1', 1 ).
test( 't32', 284, [], [], 'fam1', 1 ).
test( 't33', 672, [], [], 'fam1', 1 ).
test( 't34', 214, [], [], 'fam1', 1 ).
test( 't35', 360, [], [], 'fam1', 1 ).
test( 't36', 4, [], [], 'fam1', 1 ).
test( 't37', 596, [], [], 'fam1', 1 ).
test( 't38', 135, [], ['r2','r4','r5','r3'], 'fam1', 1 ).
test( 't39', 373, [], [], 'fam1', 1 ).
test( 't40', 671, ['m18','m10','m20','m8','m2','m16','m5','m12'], ['r3','r1','r2','r5','r4'], 'fam1', 1 ).
test( 't41', 258, ['m3'], ['r4','r2','r1','r5','r3'], 'fam1', 1 ).
test( 't42', 155, [], ['r4','r3'], 'fam1', 1 ).
test( 't43', 305, ['m9'], [], 'fam1', 1 ).
test( 't44', 304, [], [], 'fam1', 1 ).
test( 't45', 669, ['m20','m1'], ['r3','r2','r5','r1','r4'], 'fam1', 1 ).
test( 't46', 438, [], [], 'fam1', 1 ).
test( 't47', 571, [], [], 'fam1', 1 ).
test( 't48', 353, [], [], 'fam1', 1 ).
test( 't49', 659, ['m7'], [], 'fam1', 1 ).
test( 't50', 609, ['m2','m8','m13'], ['r5','r2','r1','r4'], 'fam1', 1 ).
test( 't51', 434, [], [], 'fam1', 1 ).
test( 't52', 24, [], [], 'fam1', 1 ).
test( 't53', 183, [], [], 'fam1', 1 ).
test( 't54', 286, ['m18'], ['r2','r3','r4','r5','r1'], 'fam1', 1 ).
test( 't55', 32, [], [], 'fam1', 1 ).
test( 't56', 586, [], ['r1','r4','r3','r5'], 'fam1', 1 ).
test( 't57', 673, [], [], 'fam1', 1 ).
test( 't58', 434, [], ['r5','r3','r4','r2'], 'fam1', 1 ).
test( 't59', 529, ['m13','m14','m19'], ['r2','r3','r4'], 'fam1', 1 ).
test( 't60', 372, [], [], 'fam1', 1 ).
test( 't61', 319, [], [], 'fam1', 1 ).
test( 't62', 236, [], [], 'fam1', 1 ).
test( 't63', 59, [], [], 'fam1', 1 ).
test( 't64', 163, ['m20'], [], 'fam1', 1 ).
test( 't65', 149, [], [], 'fam1', 1 ).
test( 't66', 393, [], [], 'fam1', 1 ).
test( 't67', 584, ['m12','m15','m11','m4','m20','m16','m2'], [], 'fam1', 1 ).
test( 't68', 192, [], ['r1','r2','r4'], 'fam1', 1 ).
test( 't69', 719, ['m4','m18','m19','m6','m15'], ['r4','r2','r5'], 'fam1', 1 ).
test( 't70', 723, [], [], 'fam1', 1 ).
test( 't71', 375, [], ['r5','r4','r1'], 'fam1', 1 ).
test( 't72', 460, [], [], 'fam1', 1 ).
test( 't73', 288, [], ['r4'], 'fam1', 1 ).
test( 't74', 288, ['m8','m1','m6','m15','m20','m2'], [], 'fam1', 1 ).
test( 't75', 145, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't76', 652, [], [], 'fam1', 1 ).
test( 't77', 136, [], [], 'fam1', 1 ).
test( 't78', 89, [], [], 'fam1', 1 ).
test( 't79', 5, [], [], 'fam1', 1 ).
test( 't80', 497, ['m7','m3','m8','m15','m5','m17','m10','m16'], ['r3','r2','r1','r4'], 'fam1', 1 ).
test( 't81', 457, [], ['r2','r3'], 'fam1', 1 ).
test( 't82', 344, [], ['r1','r5','r2','r4'], 'fam1', 1 ).
test( 't83', 636, [], [], 'fam1', 1 ).
test( 't84', 460, [], [], 'fam1', 1 ).
test( 't85', 719, [], [], 'fam1', 1 ).
test( 't86', 778, [], [], 'fam1', 1 ).
test( 't87', 374, [], ['r2','r1','r4','r5'], 'fam1', 1 ).
test( 't88', 390, ['m7','m20'], [], 'fam1', 1 ).
test( 't89', 611, [], [], 'fam1', 1 ).
test( 't90', 419, [], [], 'fam1', 1 ).
test( 't91', 577, [], [], 'fam1', 1 ).
test( 't92', 697, [], [], 'fam1', 1 ).
test( 't93', 180, [], ['r1'], 'fam1', 1 ).
test( 't94', 72, [], [], 'fam1', 1 ).
test( 't95', 100, [], [], 'fam1', 1 ).
test( 't96', 106, [], [], 'fam1', 1 ).
test( 't97', 190, [], [], 'fam1', 1 ).
test( 't98', 217, [], [], 'fam1', 1 ).
test( 't99', 521, [], [], 'fam1', 1 ).
test( 't100', 570, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
