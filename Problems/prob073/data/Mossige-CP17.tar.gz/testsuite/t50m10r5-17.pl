%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 523, [], [], 'fam1', 1 ).
test( 't2', 596, [], [], 'fam1', 1 ).
test( 't3', 606, ['m2','m4','m3'], [], 'fam1', 1 ).
test( 't4', 708, [], ['r3','r4','r1'], 'fam1', 1 ).
test( 't5', 105, [], [], 'fam1', 1 ).
test( 't6', 693, [], ['r2'], 'fam1', 1 ).
test( 't7', 552, [], ['r5','r1','r2','r3'], 'fam1', 1 ).
test( 't8', 532, [], [], 'fam1', 1 ).
test( 't9', 354, [], ['r5','r3','r4','r2'], 'fam1', 1 ).
test( 't10', 522, [], [], 'fam1', 1 ).
test( 't11', 746, ['m4','m10','m2','m7'], ['r4','r5','r3','r2','r1'], 'fam1', 1 ).
test( 't12', 722, [], [], 'fam1', 1 ).
test( 't13', 539, [], ['r5'], 'fam1', 1 ).
test( 't14', 56, [], ['r4','r1'], 'fam1', 1 ).
test( 't15', 418, [], [], 'fam1', 1 ).
test( 't16', 614, [], [], 'fam1', 1 ).
test( 't17', 311, [], [], 'fam1', 1 ).
test( 't18', 289, [], ['r3','r2','r5'], 'fam1', 1 ).
test( 't19', 350, [], [], 'fam1', 1 ).
test( 't20', 660, [], [], 'fam1', 1 ).
test( 't21', 224, [], ['r4','r3','r2'], 'fam1', 1 ).
test( 't22', 95, [], [], 'fam1', 1 ).
test( 't23', 49, ['m8'], ['r5','r3','r2','r1'], 'fam1', 1 ).
test( 't24', 593, ['m1','m10','m2'], [], 'fam1', 1 ).
test( 't25', 707, [], ['r2','r5','r4','r3'], 'fam1', 1 ).
test( 't26', 439, ['m10'], ['r1'], 'fam1', 1 ).
test( 't27', 130, [], [], 'fam1', 1 ).
test( 't28', 577, [], ['r4','r3','r1','r2','r5'], 'fam1', 1 ).
test( 't29', 324, [], ['r3','r5','r1'], 'fam1', 1 ).
test( 't30', 56, [], [], 'fam1', 1 ).
test( 't31', 307, [], [], 'fam1', 1 ).
test( 't32', 441, [], [], 'fam1', 1 ).
test( 't33', 137, [], [], 'fam1', 1 ).
test( 't34', 446, ['m7','m8','m6','m10'], [], 'fam1', 1 ).
test( 't35', 268, [], [], 'fam1', 1 ).
test( 't36', 386, [], [], 'fam1', 1 ).
test( 't37', 12, ['m10'], [], 'fam1', 1 ).
test( 't38', 461, [], [], 'fam1', 1 ).
test( 't39', 123, [], [], 'fam1', 1 ).
test( 't40', 197, [], [], 'fam1', 1 ).
test( 't41', 102, [], [], 'fam1', 1 ).
test( 't42', 440, [], [], 'fam1', 1 ).
test( 't43', 553, [], [], 'fam1', 1 ).
test( 't44', 599, [], ['r4','r1','r2','r5','r3'], 'fam1', 1 ).
test( 't45', 82, ['m2','m4','m6'], [], 'fam1', 1 ).
test( 't46', 444, ['m2','m8','m4'], [], 'fam1', 1 ).
test( 't47', 354, [], ['r4'], 'fam1', 1 ).
test( 't48', 383, [], [], 'fam1', 1 ).
test( 't49', 12, [], ['r2'], 'fam1', 1 ).
test( 't50', 386, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
