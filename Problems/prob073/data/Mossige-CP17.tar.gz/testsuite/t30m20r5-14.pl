%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 20
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 552, [], [], 'fam1', 1 ).
test( 't2', 315, [], [], 'fam1', 1 ).
test( 't3', 63, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't4', 107, [], ['r4'], 'fam1', 1 ).
test( 't5', 635, [], [], 'fam1', 1 ).
test( 't6', 465, ['m9','m5','m6','m19','m13'], [], 'fam1', 1 ).
test( 't7', 473, ['m19','m17'], ['r4','r5','r1'], 'fam1', 1 ).
test( 't8', 725, ['m3','m14','m20'], ['r5','r4','r1','r3'], 'fam1', 1 ).
test( 't9', 246, [], ['r3'], 'fam1', 1 ).
test( 't10', 91, [], [], 'fam1', 1 ).
test( 't11', 450, [], [], 'fam1', 1 ).
test( 't12', 613, [], ['r1','r3','r4','r2'], 'fam1', 1 ).
test( 't13', 570, [], [], 'fam1', 1 ).
test( 't14', 399, [], ['r2','r4','r5'], 'fam1', 1 ).
test( 't15', 292, [], [], 'fam1', 1 ).
test( 't16', 330, [], ['r4','r5','r1','r2'], 'fam1', 1 ).
test( 't17', 706, [], ['r5','r1','r2','r3'], 'fam1', 1 ).
test( 't18', 102, [], ['r5'], 'fam1', 1 ).
test( 't19', 43, [], ['r1','r5','r2','r4'], 'fam1', 1 ).
test( 't20', 666, [], [], 'fam1', 1 ).
test( 't21', 337, [], [], 'fam1', 1 ).
test( 't22', 795, [], [], 'fam1', 1 ).
test( 't23', 112, [], [], 'fam1', 1 ).
test( 't24', 74, [], ['r3'], 'fam1', 1 ).
test( 't25', 54, ['m6','m11','m2'], [], 'fam1', 1 ).
test( 't26', 253, [], ['r2','r1','r3','r5','r4'], 'fam1', 1 ).
test( 't27', 655, ['m4','m20','m19'], ['r1'], 'fam1', 1 ).
test( 't28', 553, ['m3','m8'], [], 'fam1', 1 ).
test( 't29', 189, ['m4','m5','m14','m1','m9'], [], 'fam1', 1 ).
test( 't30', 107, ['m4','m7','m8','m17','m10','m13'], ['r5','r2','r4'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
