%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 20
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 10, [], [], 'fam1', 1 ).
test( 't2', 567, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't3', 537, ['m12','m15','m2','m20','m17','m8','m7'], [], 'fam1', 1 ).
test( 't4', 66, ['m6','m20','m13','m11'], [], 'fam1', 1 ).
test( 't5', 700, [], ['r3','r2'], 'fam1', 1 ).
test( 't6', 649, [], [], 'fam1', 1 ).
test( 't7', 613, [], [], 'fam1', 1 ).
test( 't8', 722, [], ['r1','r2'], 'fam1', 1 ).
test( 't9', 546, [], ['r1','r3'], 'fam1', 1 ).
test( 't10', 288, [], [], 'fam1', 1 ).
test( 't11', 419, [], [], 'fam1', 1 ).
test( 't12', 282, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't13', 443, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't14', 585, [], [], 'fam1', 1 ).
test( 't15', 648, [], [], 'fam1', 1 ).
test( 't16', 566, [], [], 'fam1', 1 ).
test( 't17', 619, ['m7'], [], 'fam1', 1 ).
test( 't18', 569, [], [], 'fam1', 1 ).
test( 't19', 295, [], [], 'fam1', 1 ).
test( 't20', 32, [], [], 'fam1', 1 ).
test( 't21', 299, [], [], 'fam1', 1 ).
test( 't22', 607, [], [], 'fam1', 1 ).
test( 't23', 592, [], [], 'fam1', 1 ).
test( 't24', 752, [], [], 'fam1', 1 ).
test( 't25', 251, ['m1','m14','m5','m2','m7','m18','m13','m16'], ['r1'], 'fam1', 1 ).
test( 't26', 621, [], ['r1','r3'], 'fam1', 1 ).
test( 't27', 632, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't28', 478, [], ['r1'], 'fam1', 1 ).
test( 't29', 651, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't30', 78, ['m9','m13','m10','m6','m3','m18','m1','m12'], [], 'fam1', 1 ).
test( 't31', 550, ['m6','m14','m10','m7','m15','m1'], [], 'fam1', 1 ).
test( 't32', 568, ['m16','m13','m3','m2'], ['r2','r1','r3'], 'fam1', 1 ).
test( 't33', 204, [], ['r1'], 'fam1', 1 ).
test( 't34', 693, [], [], 'fam1', 1 ).
test( 't35', 765, [], ['r3','r1'], 'fam1', 1 ).
test( 't36', 369, ['m13','m8','m1'], [], 'fam1', 1 ).
test( 't37', 234, [], [], 'fam1', 1 ).
test( 't38', 355, [], [], 'fam1', 1 ).
test( 't39', 211, [], [], 'fam1', 1 ).
test( 't40', 732, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
