%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 326, [], [], 'fam1', 1 ).
test( 't2', 600, ['m6','m10','m1'], ['r3','r1','r2'], 'fam1', 1 ).
test( 't3', 31, [], [], 'fam1', 1 ).
test( 't4', 356, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't5', 156, [], [], 'fam1', 1 ).
test( 't6', 39, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't7', 685, [], [], 'fam1', 1 ).
test( 't8', 534, ['m9','m6','m8','m4'], ['r3'], 'fam1', 1 ).
test( 't9', 111, ['m10','m4'], [], 'fam1', 1 ).
test( 't10', 554, ['m3','m6'], ['r1','r2'], 'fam1', 1 ).
test( 't11', 123, [], ['r1'], 'fam1', 1 ).
test( 't12', 420, [], [], 'fam1', 1 ).
test( 't13', 760, ['m2'], [], 'fam1', 1 ).
test( 't14', 587, [], [], 'fam1', 1 ).
test( 't15', 716, [], [], 'fam1', 1 ).
test( 't16', 266, [], ['r2','r1'], 'fam1', 1 ).
test( 't17', 140, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't18', 698, ['m10','m2'], ['r2','r1'], 'fam1', 1 ).
test( 't19', 110, [], ['r3'], 'fam1', 1 ).
test( 't20', 221, [], [], 'fam1', 1 ).
test( 't21', 663, [], ['r3','r1'], 'fam1', 1 ).
test( 't22', 799, [], [], 'fam1', 1 ).
test( 't23', 742, [], [], 'fam1', 1 ).
test( 't24', 674, [], [], 'fam1', 1 ).
test( 't25', 712, ['m2'], ['r3','r1'], 'fam1', 1 ).
test( 't26', 692, [], [], 'fam1', 1 ).
test( 't27', 763, [], [], 'fam1', 1 ).
test( 't28', 602, [], [], 'fam1', 1 ).
test( 't29', 456, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't30', 507, [], [], 'fam1', 1 ).
test( 't31', 169, [], [], 'fam1', 1 ).
test( 't32', 198, [], [], 'fam1', 1 ).
test( 't33', 91, [], [], 'fam1', 1 ).
test( 't34', 349, ['m5','m10','m3'], [], 'fam1', 1 ).
test( 't35', 481, ['m8','m7'], [], 'fam1', 1 ).
test( 't36', 173, [], [], 'fam1', 1 ).
test( 't37', 544, [], [], 'fam1', 1 ).
test( 't38', 38, [], [], 'fam1', 1 ).
test( 't39', 438, [], [], 'fam1', 1 ).
test( 't40', 139, [], [], 'fam1', 1 ).
test( 't41', 189, ['m1','m7'], [], 'fam1', 1 ).
test( 't42', 572, [], ['r3','r1'], 'fam1', 1 ).
test( 't43', 388, [], [], 'fam1', 1 ).
test( 't44', 352, [], [], 'fam1', 1 ).
test( 't45', 679, ['m9','m2','m1'], [], 'fam1', 1 ).
test( 't46', 678, [], ['r3'], 'fam1', 1 ).
test( 't47', 158, [], [], 'fam1', 1 ).
test( 't48', 373, ['m2','m1'], ['r3','r2'], 'fam1', 1 ).
test( 't49', 567, [], [], 'fam1', 1 ).
test( 't50', 727, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
