%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 10
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 728, [], ['r9','r5','r1','r10','r6','r3','r4'], 'fam1', 1 ).
test( 't2', 423, [], [], 'fam1', 1 ).
test( 't3', 128, [], [], 'fam1', 1 ).
test( 't4', 377, ['m4','m9','m2','m7'], ['r2','r6','r1','r4','r10','r8','r5'], 'fam1', 1 ).
test( 't5', 409, [], [], 'fam1', 1 ).
test( 't6', 493, [], ['r7','r4','r2','r5','r10'], 'fam1', 1 ).
test( 't7', 788, [], [], 'fam1', 1 ).
test( 't8', 703, [], [], 'fam1', 1 ).
test( 't9', 54, ['m10','m4'], [], 'fam1', 1 ).
test( 't10', 419, [], [], 'fam1', 1 ).
test( 't11', 462, [], [], 'fam1', 1 ).
test( 't12', 45, [], ['r5','r10','r8','r3','r2','r1','r7','r9'], 'fam1', 1 ).
test( 't13', 446, [], [], 'fam1', 1 ).
test( 't14', 229, ['m1','m2'], [], 'fam1', 1 ).
test( 't15', 399, [], ['r9','r3','r8','r2','r5','r10','r4'], 'fam1', 1 ).
test( 't16', 795, ['m6','m9','m3','m8'], ['r8','r7','r3','r9'], 'fam1', 1 ).
test( 't17', 512, [], ['r7','r9','r10','r1','r5'], 'fam1', 1 ).
test( 't18', 725, [], [], 'fam1', 1 ).
test( 't19', 194, [], [], 'fam1', 1 ).
test( 't20', 439, [], ['r10','r6','r4','r3','r1'], 'fam1', 1 ).
test( 't21', 1, ['m8','m5','m10','m4'], ['r4','r9','r6'], 'fam1', 1 ).
test( 't22', 486, ['m2','m5','m7','m10'], [], 'fam1', 1 ).
test( 't23', 337, [], [], 'fam1', 1 ).
test( 't24', 134, ['m8','m7'], [], 'fam1', 1 ).
test( 't25', 415, [], [], 'fam1', 1 ).
test( 't26', 655, [], [], 'fam1', 1 ).
test( 't27', 522, ['m3','m10'], [], 'fam1', 1 ).
test( 't28', 642, [], [], 'fam1', 1 ).
test( 't29', 273, [], [], 'fam1', 1 ).
test( 't30', 538, ['m6','m4','m5'], [], 'fam1', 1 ).
test( 't31', 723, [], [], 'fam1', 1 ).
test( 't32', 186, [], [], 'fam1', 1 ).
test( 't33', 764, ['m3','m4'], ['r1','r5','r8','r4','r6'], 'fam1', 1 ).
test( 't34', 517, [], [], 'fam1', 1 ).
test( 't35', 307, ['m4','m2','m7'], ['r1'], 'fam1', 1 ).
test( 't36', 757, ['m9','m7','m2','m5'], [], 'fam1', 1 ).
test( 't37', 767, [], [], 'fam1', 1 ).
test( 't38', 203, [], [], 'fam1', 1 ).
test( 't39', 657, ['m2','m7'], [], 'fam1', 1 ).
test( 't40', 113, [], ['r6','r1','r8','r10','r9','r5','r4','r2'], 'fam1', 1 ).
test( 't41', 37, [], [], 'fam1', 1 ).
test( 't42', 167, ['m6'], [], 'fam1', 1 ).
test( 't43', 326, [], ['r2','r8'], 'fam1', 1 ).
test( 't44', 533, [], [], 'fam1', 1 ).
test( 't45', 3, [], [], 'fam1', 1 ).
test( 't46', 757, [], [], 'fam1', 1 ).
test( 't47', 660, [], [], 'fam1', 1 ).
test( 't48', 433, [], ['r7','r9','r2'], 'fam1', 1 ).
test( 't49', 681, [], [], 'fam1', 1 ).
test( 't50', 369, ['m8','m2','m9','m5'], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
