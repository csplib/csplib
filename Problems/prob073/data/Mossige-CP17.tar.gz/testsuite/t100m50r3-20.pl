%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 50
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 99, [], [], 'fam1', 1 ).
test( 't2', 109, [], [], 'fam1', 1 ).
test( 't3', 190, [], [], 'fam1', 1 ).
test( 't4', 391, ['m20','m33','m39','m24'], [], 'fam1', 1 ).
test( 't5', 182, [], [], 'fam1', 1 ).
test( 't6', 563, [], ['r1','r3'], 'fam1', 1 ).
test( 't7', 414, [], ['r2'], 'fam1', 1 ).
test( 't8', 477, [], ['r1','r2'], 'fam1', 1 ).
test( 't9', 611, [], [], 'fam1', 1 ).
test( 't10', 398, [], [], 'fam1', 1 ).
test( 't11', 697, [], [], 'fam1', 1 ).
test( 't12', 168, [], ['r1','r2'], 'fam1', 1 ).
test( 't13', 754, ['m19','m1','m27','m34','m50','m9','m13','m21','m37','m10'], ['r1','r2','r3'], 'fam1', 1 ).
test( 't14', 440, [], [], 'fam1', 1 ).
test( 't15', 472, [], [], 'fam1', 1 ).
test( 't16', 266, [], [], 'fam1', 1 ).
test( 't17', 582, ['m31','m30','m38','m17','m43','m18','m40','m16','m26'], ['r3'], 'fam1', 1 ).
test( 't18', 680, [], [], 'fam1', 1 ).
test( 't19', 324, [], [], 'fam1', 1 ).
test( 't20', 323, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't21', 341, ['m8','m4'], [], 'fam1', 1 ).
test( 't22', 433, [], ['r1'], 'fam1', 1 ).
test( 't23', 255, ['m23','m34','m13','m18','m27','m44','m24','m4','m15','m49','m31','m36','m1'], [], 'fam1', 1 ).
test( 't24', 203, [], [], 'fam1', 1 ).
test( 't25', 157, ['m37','m16','m1','m43','m14'], [], 'fam1', 1 ).
test( 't26', 370, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't27', 730, [], [], 'fam1', 1 ).
test( 't28', 535, [], [], 'fam1', 1 ).
test( 't29', 71, [], [], 'fam1', 1 ).
test( 't30', 285, ['m11','m2','m16','m34','m9','m20','m30','m50','m1','m36','m8','m33','m19','m3','m6','m31','m4'], [], 'fam1', 1 ).
test( 't31', 615, ['m28','m46','m38','m26'], [], 'fam1', 1 ).
test( 't32', 758, ['m27'], ['r1','r2'], 'fam1', 1 ).
test( 't33', 162, [], [], 'fam1', 1 ).
test( 't34', 211, [], ['r3'], 'fam1', 1 ).
test( 't35', 683, [], [], 'fam1', 1 ).
test( 't36', 259, [], [], 'fam1', 1 ).
test( 't37', 513, [], ['r3','r1'], 'fam1', 1 ).
test( 't38', 110, [], [], 'fam1', 1 ).
test( 't39', 673, [], [], 'fam1', 1 ).
test( 't40', 258, [], [], 'fam1', 1 ).
test( 't41', 423, ['m20','m1','m36','m15','m30','m18','m35','m34','m49','m12'], [], 'fam1', 1 ).
test( 't42', 486, [], ['r3'], 'fam1', 1 ).
test( 't43', 392, [], [], 'fam1', 1 ).
test( 't44', 569, [], ['r1'], 'fam1', 1 ).
test( 't45', 197, [], ['r2'], 'fam1', 1 ).
test( 't46', 518, ['m22','m20','m19','m35','m2','m14','m12','m17','m25','m49','m47','m28'], ['r2'], 'fam1', 1 ).
test( 't47', 743, [], [], 'fam1', 1 ).
test( 't48', 783, ['m13','m50','m31','m7','m6','m44','m46','m40','m22'], [], 'fam1', 1 ).
test( 't49', 276, [], [], 'fam1', 1 ).
test( 't50', 471, [], [], 'fam1', 1 ).
test( 't51', 60, [], ['r1','r3'], 'fam1', 1 ).
test( 't52', 121, ['m17','m48'], [], 'fam1', 1 ).
test( 't53', 635, [], [], 'fam1', 1 ).
test( 't54', 509, [], [], 'fam1', 1 ).
test( 't55', 675, [], [], 'fam1', 1 ).
test( 't56', 519, [], [], 'fam1', 1 ).
test( 't57', 622, [], [], 'fam1', 1 ).
test( 't58', 411, [], [], 'fam1', 1 ).
test( 't59', 460, [], [], 'fam1', 1 ).
test( 't60', 135, [], [], 'fam1', 1 ).
test( 't61', 252, [], [], 'fam1', 1 ).
test( 't62', 515, [], [], 'fam1', 1 ).
test( 't63', 311, [], ['r1','r3'], 'fam1', 1 ).
test( 't64', 777, [], [], 'fam1', 1 ).
test( 't65', 786, [], [], 'fam1', 1 ).
test( 't66', 736, [], [], 'fam1', 1 ).
test( 't67', 361, ['m4','m21'], [], 'fam1', 1 ).
test( 't68', 242, [], ['r1'], 'fam1', 1 ).
test( 't69', 51, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't70', 499, [], [], 'fam1', 1 ).
test( 't71', 776, [], [], 'fam1', 1 ).
test( 't72', 249, [], [], 'fam1', 1 ).
test( 't73', 268, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't74', 152, [], [], 'fam1', 1 ).
test( 't75', 762, [], [], 'fam1', 1 ).
test( 't76', 597, [], ['r1','r2'], 'fam1', 1 ).
test( 't77', 243, ['m40','m26'], [], 'fam1', 1 ).
test( 't78', 303, ['m6','m34','m46','m39','m8','m20','m9'], ['r1','r2','r3'], 'fam1', 1 ).
test( 't79', 199, [], [], 'fam1', 1 ).
test( 't80', 477, [], [], 'fam1', 1 ).
test( 't81', 622, [], [], 'fam1', 1 ).
test( 't82', 658, ['m7','m13','m22','m36'], [], 'fam1', 1 ).
test( 't83', 153, [], [], 'fam1', 1 ).
test( 't84', 200, [], [], 'fam1', 1 ).
test( 't85', 265, [], [], 'fam1', 1 ).
test( 't86', 491, ['m50'], [], 'fam1', 1 ).
test( 't87', 12, [], [], 'fam1', 1 ).
test( 't88', 523, [], [], 'fam1', 1 ).
test( 't89', 13, [], [], 'fam1', 1 ).
test( 't90', 82, [], [], 'fam1', 1 ).
test( 't91', 669, [], [], 'fam1', 1 ).
test( 't92', 801, [], [], 'fam1', 1 ).
test( 't93', 214, [], [], 'fam1', 1 ).
test( 't94', 291, [], [], 'fam1', 1 ).
test( 't95', 4, [], [], 'fam1', 1 ).
test( 't96', 219, [], [], 'fam1', 1 ).
test( 't97', 275, [], [], 'fam1', 1 ).
test( 't98', 467, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't99', 290, ['m19','m6','m4','m34','m11','m9','m49','m47','m20','m21','m8','m15','m10','m16','m43','m38'], [], 'fam1', 1 ).
test( 't100', 435, [], ['r1'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').
embedded_board( 'm21').
embedded_board( 'm22').
embedded_board( 'm23').
embedded_board( 'm24').
embedded_board( 'm25').
embedded_board( 'm26').
embedded_board( 'm27').
embedded_board( 'm28').
embedded_board( 'm29').
embedded_board( 'm30').
embedded_board( 'm31').
embedded_board( 'm32').
embedded_board( 'm33').
embedded_board( 'm34').
embedded_board( 'm35').
embedded_board( 'm36').
embedded_board( 'm37').
embedded_board( 'm38').
embedded_board( 'm39').
embedded_board( 'm40').
embedded_board( 'm41').
embedded_board( 'm42').
embedded_board( 'm43').
embedded_board( 'm44').
embedded_board( 'm45').
embedded_board( 'm46').
embedded_board( 'm47').
embedded_board( 'm48').
embedded_board( 'm49').
embedded_board( 'm50').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
