%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 20
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 462, [], [], 'fam1', 1 ).
test( 't2', 242, [], [], 'fam1', 1 ).
test( 't3', 426, [], [], 'fam1', 1 ).
test( 't4', 141, [], [], 'fam1', 1 ).
test( 't5', 626, [], [], 'fam1', 1 ).
test( 't6', 434, ['m7','m9','m10','m1'], ['r6'], 'fam1', 1 ).
test( 't7', 591, [], ['r4','r2','r10','r7','r6','r1'], 'fam1', 1 ).
test( 't8', 800, [], [], 'fam1', 1 ).
test( 't9', 259, [], [], 'fam1', 1 ).
test( 't10', 738, ['m19','m10','m11','m6','m16','m14','m4'], ['r5','r7','r3','r1','r9','r4','r8','r2'], 'fam1', 1 ).
test( 't11', 537, ['m9','m5','m4','m12','m14','m15','m20'], ['r9','r4','r1'], 'fam1', 1 ).
test( 't12', 80, [], [], 'fam1', 1 ).
test( 't13', 537, [], [], 'fam1', 1 ).
test( 't14', 174, [], [], 'fam1', 1 ).
test( 't15', 585, ['m11','m9','m17','m12','m7','m14'], [], 'fam1', 1 ).
test( 't16', 5, [], [], 'fam1', 1 ).
test( 't17', 654, [], ['r1','r9','r8'], 'fam1', 1 ).
test( 't18', 64, ['m18','m9','m1','m19','m11'], [], 'fam1', 1 ).
test( 't19', 574, [], [], 'fam1', 1 ).
test( 't20', 174, ['m11','m7','m15','m8','m10'], [], 'fam1', 1 ).
test( 't21', 771, [], [], 'fam1', 1 ).
test( 't22', 380, [], [], 'fam1', 1 ).
test( 't23', 566, [], [], 'fam1', 1 ).
test( 't24', 209, [], [], 'fam1', 1 ).
test( 't25', 312, [], [], 'fam1', 1 ).
test( 't26', 516, [], [], 'fam1', 1 ).
test( 't27', 323, [], [], 'fam1', 1 ).
test( 't28', 374, ['m15','m6','m19','m13','m20','m9'], [], 'fam1', 1 ).
test( 't29', 146, [], [], 'fam1', 1 ).
test( 't30', 365, [], [], 'fam1', 1 ).
test( 't31', 733, [], ['r2','r6'], 'fam1', 1 ).
test( 't32', 66, [], [], 'fam1', 1 ).
test( 't33', 85, [], [], 'fam1', 1 ).
test( 't34', 741, [], [], 'fam1', 1 ).
test( 't35', 219, [], [], 'fam1', 1 ).
test( 't36', 750, [], [], 'fam1', 1 ).
test( 't37', 488, [], [], 'fam1', 1 ).
test( 't38', 732, [], ['r6','r5','r10','r7'], 'fam1', 1 ).
test( 't39', 496, ['m1','m6','m8','m20','m19','m17'], [], 'fam1', 1 ).
test( 't40', 176, [], [], 'fam1', 1 ).
test( 't41', 363, [], ['r9','r2','r4','r7','r5','r1'], 'fam1', 1 ).
test( 't42', 160, [], [], 'fam1', 1 ).
test( 't43', 337, [], ['r4','r6','r5','r7','r9','r2','r8'], 'fam1', 1 ).
test( 't44', 12, [], ['r3','r2','r8','r5','r7','r9','r6','r10'], 'fam1', 1 ).
test( 't45', 641, [], ['r5','r9','r2','r6'], 'fam1', 1 ).
test( 't46', 331, [], ['r9','r6','r1'], 'fam1', 1 ).
test( 't47', 210, [], [], 'fam1', 1 ).
test( 't48', 153, [], [], 'fam1', 1 ).
test( 't49', 324, [], ['r2','r7','r10','r3','r9','r4','r5','r6'], 'fam1', 1 ).
test( 't50', 682, [], [], 'fam1', 1 ).
test( 't51', 694, [], [], 'fam1', 1 ).
test( 't52', 220, [], ['r4','r1','r7','r10','r2','r3','r6','r8','r9'], 'fam1', 1 ).
test( 't53', 105, [], [], 'fam1', 1 ).
test( 't54', 450, [], [], 'fam1', 1 ).
test( 't55', 6, [], [], 'fam1', 1 ).
test( 't56', 726, ['m19','m11','m17','m12'], [], 'fam1', 1 ).
test( 't57', 724, [], [], 'fam1', 1 ).
test( 't58', 59, [], [], 'fam1', 1 ).
test( 't59', 494, [], [], 'fam1', 1 ).
test( 't60', 706, [], [], 'fam1', 1 ).
test( 't61', 50, [], [], 'fam1', 1 ).
test( 't62', 205, [], ['r5','r7','r10','r2','r4','r6'], 'fam1', 1 ).
test( 't63', 83, [], ['r7','r2','r8','r10'], 'fam1', 1 ).
test( 't64', 223, [], [], 'fam1', 1 ).
test( 't65', 777, [], [], 'fam1', 1 ).
test( 't66', 519, [], [], 'fam1', 1 ).
test( 't67', 702, ['m17','m16','m3','m9','m15','m19'], ['r8','r2','r1','r3','r10','r9','r5','r7','r6'], 'fam1', 1 ).
test( 't68', 330, [], [], 'fam1', 1 ).
test( 't69', 547, [], ['r8','r9','r3','r7'], 'fam1', 1 ).
test( 't70', 594, [], ['r10','r6','r3','r5','r1','r7','r9','r4','r2'], 'fam1', 1 ).
test( 't71', 684, ['m19','m12','m6','m1','m9','m20','m10','m16'], [], 'fam1', 1 ).
test( 't72', 655, ['m9','m4','m10','m1','m8','m2','m14','m18'], [], 'fam1', 1 ).
test( 't73', 418, [], ['r9','r4'], 'fam1', 1 ).
test( 't74', 115, [], [], 'fam1', 1 ).
test( 't75', 232, [], ['r4','r3'], 'fam1', 1 ).
test( 't76', 664, ['m15','m12','m5','m3','m2'], [], 'fam1', 1 ).
test( 't77', 583, [], [], 'fam1', 1 ).
test( 't78', 467, [], ['r2','r4','r5'], 'fam1', 1 ).
test( 't79', 54, ['m7','m6','m17','m18','m8','m3','m19','m11'], ['r7','r1','r4','r6','r8'], 'fam1', 1 ).
test( 't80', 759, [], [], 'fam1', 1 ).
test( 't81', 162, [], [], 'fam1', 1 ).
test( 't82', 674, [], [], 'fam1', 1 ).
test( 't83', 562, [], ['r3','r4','r10','r1','r8','r7'], 'fam1', 1 ).
test( 't84', 482, ['m16','m1','m4','m13','m2','m20','m19'], [], 'fam1', 1 ).
test( 't85', 380, [], ['r9','r2','r4','r7','r8','r1','r5','r10','r6','r3'], 'fam1', 1 ).
test( 't86', 686, [], [], 'fam1', 1 ).
test( 't87', 437, [], ['r5','r6','r3','r10','r8','r1','r2'], 'fam1', 1 ).
test( 't88', 793, [], [], 'fam1', 1 ).
test( 't89', 765, ['m6','m7','m15'], [], 'fam1', 1 ).
test( 't90', 211, [], [], 'fam1', 1 ).
test( 't91', 697, [], ['r5','r1','r3'], 'fam1', 1 ).
test( 't92', 373, [], [], 'fam1', 1 ).
test( 't93', 452, [], ['r10','r1','r6','r8','r7','r3','r4','r9','r5'], 'fam1', 1 ).
test( 't94', 335, [], [], 'fam1', 1 ).
test( 't95', 739, ['m8','m4','m20','m15','m3'], [], 'fam1', 1 ).
test( 't96', 424, [], [], 'fam1', 1 ).
test( 't97', 498, [], [], 'fam1', 1 ).
test( 't98', 170, [], ['r6'], 'fam1', 1 ).
test( 't99', 36, [], [], 'fam1', 1 ).
test( 't100', 554, [], ['r3','r2'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
