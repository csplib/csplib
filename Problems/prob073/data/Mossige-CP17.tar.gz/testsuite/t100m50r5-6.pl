%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 50
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 785, ['m17','m12','m45'], [], 'fam1', 1 ).
test( 't2', 788, [], ['r2','r5','r1'], 'fam1', 1 ).
test( 't3', 161, ['m32','m10','m17','m11','m21','m9','m7','m30','m13','m46','m14','m38'], ['r4','r2','r3','r1'], 'fam1', 1 ).
test( 't4', 106, [], ['r1','r4','r2'], 'fam1', 1 ).
test( 't5', 612, [], [], 'fam1', 1 ).
test( 't6', 681, [], ['r5'], 'fam1', 1 ).
test( 't7', 406, [], ['r3','r5','r1','r4','r2'], 'fam1', 1 ).
test( 't8', 109, [], [], 'fam1', 1 ).
test( 't9', 155, ['m8','m40','m9'], [], 'fam1', 1 ).
test( 't10', 306, ['m26'], [], 'fam1', 1 ).
test( 't11', 30, [], [], 'fam1', 1 ).
test( 't12', 641, [], [], 'fam1', 1 ).
test( 't13', 767, [], [], 'fam1', 1 ).
test( 't14', 4, ['m46','m18','m20','m3','m45','m1','m17','m19','m5','m25'], ['r1','r4','r2','r5'], 'fam1', 1 ).
test( 't15', 393, [], [], 'fam1', 1 ).
test( 't16', 361, [], [], 'fam1', 1 ).
test( 't17', 264, ['m20','m41','m2','m43','m23','m6','m12','m15','m39','m37','m29'], ['r2','r4'], 'fam1', 1 ).
test( 't18', 551, [], [], 'fam1', 1 ).
test( 't19', 170, [], [], 'fam1', 1 ).
test( 't20', 150, [], [], 'fam1', 1 ).
test( 't21', 684, ['m32','m35','m28','m47','m31','m44','m16','m14','m27','m5','m37','m48','m41','m29','m23','m19','m8','m9','m36','m2'], [], 'fam1', 1 ).
test( 't22', 439, ['m13','m40','m24','m15','m47','m37','m34','m44','m1','m10','m25','m45'], [], 'fam1', 1 ).
test( 't23', 602, ['m43','m25','m9','m33','m32'], ['r3','r1'], 'fam1', 1 ).
test( 't24', 545, [], [], 'fam1', 1 ).
test( 't25', 322, [], [], 'fam1', 1 ).
test( 't26', 334, [], [], 'fam1', 1 ).
test( 't27', 451, [], [], 'fam1', 1 ).
test( 't28', 72, [], [], 'fam1', 1 ).
test( 't29', 492, [], [], 'fam1', 1 ).
test( 't30', 784, [], [], 'fam1', 1 ).
test( 't31', 166, [], ['r5','r1'], 'fam1', 1 ).
test( 't32', 543, [], ['r3'], 'fam1', 1 ).
test( 't33', 98, ['m16','m43','m44','m45','m20','m9','m37','m25','m21','m7','m6','m24','m13','m39','m29','m4','m15','m47'], [], 'fam1', 1 ).
test( 't34', 268, [], [], 'fam1', 1 ).
test( 't35', 645, [], [], 'fam1', 1 ).
test( 't36', 755, ['m22','m43','m36','m38','m7','m12','m49','m29','m32','m40','m8','m27','m46','m31','m13'], ['r5','r4','r2','r3','r1'], 'fam1', 1 ).
test( 't37', 127, [], [], 'fam1', 1 ).
test( 't38', 301, [], [], 'fam1', 1 ).
test( 't39', 517, [], ['r5','r1'], 'fam1', 1 ).
test( 't40', 401, [], [], 'fam1', 1 ).
test( 't41', 632, [], ['r1'], 'fam1', 1 ).
test( 't42', 198, [], ['r4','r3'], 'fam1', 1 ).
test( 't43', 405, ['m24'], [], 'fam1', 1 ).
test( 't44', 474, [], [], 'fam1', 1 ).
test( 't45', 639, [], [], 'fam1', 1 ).
test( 't46', 195, ['m43','m35','m10','m33','m13','m2','m14','m3','m12','m18','m44','m8','m42','m47','m34','m36'], [], 'fam1', 1 ).
test( 't47', 633, ['m43','m35','m20','m24','m44'], [], 'fam1', 1 ).
test( 't48', 67, [], [], 'fam1', 1 ).
test( 't49', 447, [], [], 'fam1', 1 ).
test( 't50', 410, [], [], 'fam1', 1 ).
test( 't51', 225, [], [], 'fam1', 1 ).
test( 't52', 378, [], ['r4','r3'], 'fam1', 1 ).
test( 't53', 792, [], [], 'fam1', 1 ).
test( 't54', 418, [], ['r2','r3','r4','r5','r1'], 'fam1', 1 ).
test( 't55', 248, ['m19','m26','m16','m2','m42','m47','m25','m44','m37'], [], 'fam1', 1 ).
test( 't56', 390, ['m7','m14','m44','m24','m25','m22','m46','m30','m35','m10','m13','m4','m9','m1','m34'], [], 'fam1', 1 ).
test( 't57', 161, ['m47','m14','m22','m1','m20','m16','m48','m17'], [], 'fam1', 1 ).
test( 't58', 230, [], [], 'fam1', 1 ).
test( 't59', 667, [], [], 'fam1', 1 ).
test( 't60', 679, [], [], 'fam1', 1 ).
test( 't61', 246, [], ['r3','r1','r4'], 'fam1', 1 ).
test( 't62', 14, [], [], 'fam1', 1 ).
test( 't63', 599, ['m35','m20','m24','m49','m30','m13','m25','m18','m38','m47','m11','m10','m17','m41','m22','m4','m48'], [], 'fam1', 1 ).
test( 't64', 453, ['m33','m1','m17','m11'], ['r4','r1'], 'fam1', 1 ).
test( 't65', 168, ['m25','m37','m47','m10','m12','m28','m22','m1','m27','m7','m46','m39','m3','m16','m15','m31','m38','m21','m23','m44'], ['r5'], 'fam1', 1 ).
test( 't66', 580, ['m29','m7','m20','m18','m28','m25','m30','m15','m12','m6','m49'], [], 'fam1', 1 ).
test( 't67', 259, ['m30','m13','m33','m39','m28','m37','m29','m15','m44'], [], 'fam1', 1 ).
test( 't68', 518, [], ['r2','r1'], 'fam1', 1 ).
test( 't69', 343, [], ['r3','r4','r1','r2'], 'fam1', 1 ).
test( 't70', 570, [], ['r1','r3','r4'], 'fam1', 1 ).
test( 't71', 26, [], [], 'fam1', 1 ).
test( 't72', 195, [], [], 'fam1', 1 ).
test( 't73', 117, [], [], 'fam1', 1 ).
test( 't74', 727, [], ['r3','r5','r4'], 'fam1', 1 ).
test( 't75', 98, ['m26','m44','m12','m21','m17','m35','m41','m39','m49','m16','m1','m38','m23','m7'], [], 'fam1', 1 ).
test( 't76', 693, [], [], 'fam1', 1 ).
test( 't77', 200, [], [], 'fam1', 1 ).
test( 't78', 382, [], ['r1'], 'fam1', 1 ).
test( 't79', 406, [], [], 'fam1', 1 ).
test( 't80', 107, [], [], 'fam1', 1 ).
test( 't81', 315, [], ['r5','r1','r4'], 'fam1', 1 ).
test( 't82', 145, [], [], 'fam1', 1 ).
test( 't83', 537, [], [], 'fam1', 1 ).
test( 't84', 395, ['m8','m42','m23','m46','m2','m5','m36','m49','m6','m35','m15','m22','m25','m26','m28'], [], 'fam1', 1 ).
test( 't85', 659, [], ['r5'], 'fam1', 1 ).
test( 't86', 185, [], [], 'fam1', 1 ).
test( 't87', 482, [], [], 'fam1', 1 ).
test( 't88', 550, [], [], 'fam1', 1 ).
test( 't89', 58, ['m12','m36','m20'], ['r2'], 'fam1', 1 ).
test( 't90', 429, [], [], 'fam1', 1 ).
test( 't91', 290, [], ['r5','r1','r4','r3'], 'fam1', 1 ).
test( 't92', 765, [], [], 'fam1', 1 ).
test( 't93', 20, [], ['r4','r1','r2','r3','r5'], 'fam1', 1 ).
test( 't94', 626, [], [], 'fam1', 1 ).
test( 't95', 209, ['m9','m46','m10'], [], 'fam1', 1 ).
test( 't96', 256, [], [], 'fam1', 1 ).
test( 't97', 9, [], ['r4','r1','r5','r3','r2'], 'fam1', 1 ).
test( 't98', 3, [], [], 'fam1', 1 ).
test( 't99', 539, [], ['r2','r1','r5','r3','r4'], 'fam1', 1 ).
test( 't100', 443, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').
embedded_board( 'm21').
embedded_board( 'm22').
embedded_board( 'm23').
embedded_board( 'm24').
embedded_board( 'm25').
embedded_board( 'm26').
embedded_board( 'm27').
embedded_board( 'm28').
embedded_board( 'm29').
embedded_board( 'm30').
embedded_board( 'm31').
embedded_board( 'm32').
embedded_board( 'm33').
embedded_board( 'm34').
embedded_board( 'm35').
embedded_board( 'm36').
embedded_board( 'm37').
embedded_board( 'm38').
embedded_board( 'm39').
embedded_board( 'm40').
embedded_board( 'm41').
embedded_board( 'm42').
embedded_board( 'm43').
embedded_board( 'm44').
embedded_board( 'm45').
embedded_board( 'm46').
embedded_board( 'm47').
embedded_board( 'm48').
embedded_board( 'm49').
embedded_board( 'm50').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
