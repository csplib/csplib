%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 10
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 491, [], [], 'fam1', 1 ).
test( 't2', 705, [], ['r6','r2','r4','r1','r3','r8','r5','r7','r9','r10'], 'fam1', 1 ).
test( 't3', 124, [], ['r10'], 'fam1', 1 ).
test( 't4', 54, [], ['r5','r8','r10','r7','r4','r1'], 'fam1', 1 ).
test( 't5', 538, [], [], 'fam1', 1 ).
test( 't6', 122, [], ['r5','r6','r2','r10','r1','r7','r3','r8','r9','r4'], 'fam1', 1 ).
test( 't7', 512, [], [], 'fam1', 1 ).
test( 't8', 770, [], [], 'fam1', 1 ).
test( 't9', 424, [], [], 'fam1', 1 ).
test( 't10', 281, [], ['r7','r8','r5','r1','r2','r3','r4'], 'fam1', 1 ).
test( 't11', 480, [], [], 'fam1', 1 ).
test( 't12', 18, [], ['r5','r6','r9','r1','r4','r3','r10','r8','r7'], 'fam1', 1 ).
test( 't13', 546, [], ['r4','r3','r2','r5','r8','r7','r1','r6','r10'], 'fam1', 1 ).
test( 't14', 391, [], [], 'fam1', 1 ).
test( 't15', 388, [], [], 'fam1', 1 ).
test( 't16', 526, [], ['r1','r9','r5','r6'], 'fam1', 1 ).
test( 't17', 661, [], [], 'fam1', 1 ).
test( 't18', 594, [], ['r10'], 'fam1', 1 ).
test( 't19', 112, [], ['r8','r1','r9','r10','r3','r4','r6','r2','r7','r5'], 'fam1', 1 ).
test( 't20', 235, [], ['r4','r2','r9','r5'], 'fam1', 1 ).
test( 't21', 534, [], [], 'fam1', 1 ).
test( 't22', 106, [], [], 'fam1', 1 ).
test( 't23', 248, [], ['r3','r4','r9','r7','r1','r8','r5','r2','r10','r6'], 'fam1', 1 ).
test( 't24', 7, [], ['r3','r7','r10','r2'], 'fam1', 1 ).
test( 't25', 39, [], [], 'fam1', 1 ).
test( 't26', 417, [], [], 'fam1', 1 ).
test( 't27', 78, [], ['r8','r5','r3'], 'fam1', 1 ).
test( 't28', 690, [], [], 'fam1', 1 ).
test( 't29', 701, [], [], 'fam1', 1 ).
test( 't30', 747, [], ['r5','r3'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
