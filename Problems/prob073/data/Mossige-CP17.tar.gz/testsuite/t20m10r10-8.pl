%% ****  Testsuite  ****
% Number of tests                  : 20
% Number of machines               : 10
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 111, [], [], 'fam1', 1 ).
test( 't2', 223, ['m7'], ['r3','r7'], 'fam1', 1 ).
test( 't3', 477, ['m4','m6','m3','m2'], [], 'fam1', 1 ).
test( 't4', 464, [], ['r5','r9','r6'], 'fam1', 1 ).
test( 't5', 429, ['m10','m8','m2'], [], 'fam1', 1 ).
test( 't6', 145, [], [], 'fam1', 1 ).
test( 't7', 506, ['m2','m7'], [], 'fam1', 1 ).
test( 't8', 374, [], [], 'fam1', 1 ).
test( 't9', 533, [], ['r1','r5','r3','r6','r7','r9','r4','r8'], 'fam1', 1 ).
test( 't10', 172, [], [], 'fam1', 1 ).
test( 't11', 648, [], [], 'fam1', 1 ).
test( 't12', 332, [], ['r9','r4','r8','r10','r2','r6','r5'], 'fam1', 1 ).
test( 't13', 256, [], [], 'fam1', 1 ).
test( 't14', 39, [], [], 'fam1', 1 ).
test( 't15', 434, [], [], 'fam1', 1 ).
test( 't16', 715, [], [], 'fam1', 1 ).
test( 't17', 421, [], [], 'fam1', 1 ).
test( 't18', 358, [], [], 'fam1', 1 ).
test( 't19', 150, [], [], 'fam1', 1 ).
test( 't20', 678, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
