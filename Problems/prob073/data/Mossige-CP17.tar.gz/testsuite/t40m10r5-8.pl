%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 703, ['m6'], [], 'fam1', 1 ).
test( 't2', 288, [], [], 'fam1', 1 ).
test( 't3', 357, [], [], 'fam1', 1 ).
test( 't4', 46, [], ['r5','r2','r4','r1'], 'fam1', 1 ).
test( 't5', 795, [], ['r2','r1','r4'], 'fam1', 1 ).
test( 't6', 272, [], [], 'fam1', 1 ).
test( 't7', 277, [], [], 'fam1', 1 ).
test( 't8', 493, [], [], 'fam1', 1 ).
test( 't9', 496, [], [], 'fam1', 1 ).
test( 't10', 383, [], [], 'fam1', 1 ).
test( 't11', 496, [], ['r2','r5','r1'], 'fam1', 1 ).
test( 't12', 140, [], [], 'fam1', 1 ).
test( 't13', 200, [], ['r4'], 'fam1', 1 ).
test( 't14', 34, [], [], 'fam1', 1 ).
test( 't15', 133, [], [], 'fam1', 1 ).
test( 't16', 15, [], ['r3','r1'], 'fam1', 1 ).
test( 't17', 132, [], [], 'fam1', 1 ).
test( 't18', 66, [], [], 'fam1', 1 ).
test( 't19', 795, [], [], 'fam1', 1 ).
test( 't20', 48, [], ['r4'], 'fam1', 1 ).
test( 't21', 511, [], [], 'fam1', 1 ).
test( 't22', 428, [], [], 'fam1', 1 ).
test( 't23', 407, [], [], 'fam1', 1 ).
test( 't24', 304, [], ['r5','r1','r3','r4'], 'fam1', 1 ).
test( 't25', 460, [], [], 'fam1', 1 ).
test( 't26', 270, [], [], 'fam1', 1 ).
test( 't27', 370, [], ['r5','r3','r4'], 'fam1', 1 ).
test( 't28', 163, [], [], 'fam1', 1 ).
test( 't29', 551, [], ['r4','r5','r1'], 'fam1', 1 ).
test( 't30', 376, [], [], 'fam1', 1 ).
test( 't31', 318, [], [], 'fam1', 1 ).
test( 't32', 411, [], ['r5','r1','r3','r2','r4'], 'fam1', 1 ).
test( 't33', 533, [], ['r3'], 'fam1', 1 ).
test( 't34', 656, [], [], 'fam1', 1 ).
test( 't35', 120, [], ['r4','r3','r2','r1'], 'fam1', 1 ).
test( 't36', 489, [], [], 'fam1', 1 ).
test( 't37', 263, [], ['r3','r5','r4','r2','r1'], 'fam1', 1 ).
test( 't38', 539, [], [], 'fam1', 1 ).
test( 't39', 408, [], [], 'fam1', 1 ).
test( 't40', 188, [], ['r5','r1'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
