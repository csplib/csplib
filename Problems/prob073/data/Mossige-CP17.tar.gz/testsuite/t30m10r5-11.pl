%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 624, [], [], 'fam1', 1 ).
test( 't2', 659, [], ['r2','r5','r4','r3'], 'fam1', 1 ).
test( 't3', 744, [], [], 'fam1', 1 ).
test( 't4', 443, [], [], 'fam1', 1 ).
test( 't5', 79, [], [], 'fam1', 1 ).
test( 't6', 174, [], [], 'fam1', 1 ).
test( 't7', 613, [], [], 'fam1', 1 ).
test( 't8', 377, ['m8'], [], 'fam1', 1 ).
test( 't9', 654, [], [], 'fam1', 1 ).
test( 't10', 637, [], [], 'fam1', 1 ).
test( 't11', 17, [], ['r2','r1','r3','r5'], 'fam1', 1 ).
test( 't12', 138, [], [], 'fam1', 1 ).
test( 't13', 533, [], ['r4','r1','r5'], 'fam1', 1 ).
test( 't14', 558, [], ['r1','r5','r3','r2'], 'fam1', 1 ).
test( 't15', 32, [], [], 'fam1', 1 ).
test( 't16', 223, ['m8','m10'], ['r2'], 'fam1', 1 ).
test( 't17', 753, [], [], 'fam1', 1 ).
test( 't18', 592, ['m1','m5'], [], 'fam1', 1 ).
test( 't19', 366, [], [], 'fam1', 1 ).
test( 't20', 395, [], [], 'fam1', 1 ).
test( 't21', 256, [], ['r5','r2'], 'fam1', 1 ).
test( 't22', 497, [], [], 'fam1', 1 ).
test( 't23', 452, ['m9','m10'], [], 'fam1', 1 ).
test( 't24', 115, [], ['r3','r2','r1','r5'], 'fam1', 1 ).
test( 't25', 435, ['m8','m7'], [], 'fam1', 1 ).
test( 't26', 550, [], [], 'fam1', 1 ).
test( 't27', 151, [], [], 'fam1', 1 ).
test( 't28', 270, [], [], 'fam1', 1 ).
test( 't29', 485, [], [], 'fam1', 1 ).
test( 't30', 146, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
