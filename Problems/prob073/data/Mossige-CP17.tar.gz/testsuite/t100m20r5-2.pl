%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 20
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 317, [], ['r2','r4','r5','r1','r3'], 'fam1', 1 ).
test( 't2', 198, [], ['r4','r2','r3'], 'fam1', 1 ).
test( 't3', 434, [], ['r2'], 'fam1', 1 ).
test( 't4', 129, [], [], 'fam1', 1 ).
test( 't5', 722, [], [], 'fam1', 1 ).
test( 't6', 226, [], ['r5','r3'], 'fam1', 1 ).
test( 't7', 226, [], [], 'fam1', 1 ).
test( 't8', 766, [], [], 'fam1', 1 ).
test( 't9', 402, [], [], 'fam1', 1 ).
test( 't10', 378, [], [], 'fam1', 1 ).
test( 't11', 591, [], [], 'fam1', 1 ).
test( 't12', 184, [], [], 'fam1', 1 ).
test( 't13', 150, [], [], 'fam1', 1 ).
test( 't14', 220, [], [], 'fam1', 1 ).
test( 't15', 72, [], ['r2','r3'], 'fam1', 1 ).
test( 't16', 458, ['m20','m11'], ['r2','r4','r5','r3','r1'], 'fam1', 1 ).
test( 't17', 354, [], ['r5','r3','r1','r4','r2'], 'fam1', 1 ).
test( 't18', 416, [], [], 'fam1', 1 ).
test( 't19', 54, [], [], 'fam1', 1 ).
test( 't20', 209, [], ['r3','r4','r2','r1','r5'], 'fam1', 1 ).
test( 't21', 604, ['m13','m19','m10','m1','m6'], ['r1','r3','r5','r4','r2'], 'fam1', 1 ).
test( 't22', 479, [], [], 'fam1', 1 ).
test( 't23', 576, ['m18','m16','m1','m19','m4'], [], 'fam1', 1 ).
test( 't24', 59, [], ['r1','r4'], 'fam1', 1 ).
test( 't25', 360, [], ['r5','r4','r3'], 'fam1', 1 ).
test( 't26', 320, [], [], 'fam1', 1 ).
test( 't27', 798, [], [], 'fam1', 1 ).
test( 't28', 315, [], [], 'fam1', 1 ).
test( 't29', 780, [], [], 'fam1', 1 ).
test( 't30', 69, ['m2','m18','m1','m16','m10','m4','m17'], [], 'fam1', 1 ).
test( 't31', 649, [], ['r1'], 'fam1', 1 ).
test( 't32', 20, [], [], 'fam1', 1 ).
test( 't33', 605, [], ['r3'], 'fam1', 1 ).
test( 't34', 47, [], [], 'fam1', 1 ).
test( 't35', 581, ['m9','m12','m14','m15','m5','m16'], ['r3'], 'fam1', 1 ).
test( 't36', 391, [], [], 'fam1', 1 ).
test( 't37', 770, [], [], 'fam1', 1 ).
test( 't38', 797, ['m5','m9','m3','m10','m14','m1'], [], 'fam1', 1 ).
test( 't39', 44, [], [], 'fam1', 1 ).
test( 't40', 436, [], [], 'fam1', 1 ).
test( 't41', 132, [], [], 'fam1', 1 ).
test( 't42', 226, [], ['r4','r2','r3','r1'], 'fam1', 1 ).
test( 't43', 668, [], [], 'fam1', 1 ).
test( 't44', 287, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't45', 727, [], ['r4'], 'fam1', 1 ).
test( 't46', 471, [], ['r2','r4'], 'fam1', 1 ).
test( 't47', 367, [], [], 'fam1', 1 ).
test( 't48', 28, [], [], 'fam1', 1 ).
test( 't49', 460, [], [], 'fam1', 1 ).
test( 't50', 434, [], ['r3','r4','r1','r5','r2'], 'fam1', 1 ).
test( 't51', 192, [], [], 'fam1', 1 ).
test( 't52', 1, [], [], 'fam1', 1 ).
test( 't53', 364, [], ['r3','r5','r2','r4'], 'fam1', 1 ).
test( 't54', 353, ['m16','m7','m12','m5','m10','m14','m4','m3'], [], 'fam1', 1 ).
test( 't55', 586, [], [], 'fam1', 1 ).
test( 't56', 286, [], [], 'fam1', 1 ).
test( 't57', 801, [], [], 'fam1', 1 ).
test( 't58', 675, [], [], 'fam1', 1 ).
test( 't59', 321, [], [], 'fam1', 1 ).
test( 't60', 129, [], ['r3','r1','r4'], 'fam1', 1 ).
test( 't61', 86, [], [], 'fam1', 1 ).
test( 't62', 707, [], ['r3'], 'fam1', 1 ).
test( 't63', 268, ['m18','m3'], ['r1','r2','r5','r4'], 'fam1', 1 ).
test( 't64', 35, [], ['r2','r4','r3'], 'fam1', 1 ).
test( 't65', 410, ['m19'], [], 'fam1', 1 ).
test( 't66', 198, [], [], 'fam1', 1 ).
test( 't67', 248, ['m16'], [], 'fam1', 1 ).
test( 't68', 296, [], ['r2'], 'fam1', 1 ).
test( 't69', 35, [], [], 'fam1', 1 ).
test( 't70', 741, [], ['r5','r1','r2','r3'], 'fam1', 1 ).
test( 't71', 391, [], [], 'fam1', 1 ).
test( 't72', 538, ['m19','m4'], [], 'fam1', 1 ).
test( 't73', 389, ['m17','m12','m19','m11','m5','m6'], ['r1','r4','r3'], 'fam1', 1 ).
test( 't74', 148, [], ['r5','r4','r2','r1'], 'fam1', 1 ).
test( 't75', 427, [], ['r3','r1','r5'], 'fam1', 1 ).
test( 't76', 475, [], [], 'fam1', 1 ).
test( 't77', 799, ['m19','m11','m16','m17','m10','m15','m8'], ['r1','r3'], 'fam1', 1 ).
test( 't78', 36, [], ['r3','r4'], 'fam1', 1 ).
test( 't79', 645, [], [], 'fam1', 1 ).
test( 't80', 661, [], [], 'fam1', 1 ).
test( 't81', 519, [], [], 'fam1', 1 ).
test( 't82', 498, [], [], 'fam1', 1 ).
test( 't83', 587, [], [], 'fam1', 1 ).
test( 't84', 80, [], [], 'fam1', 1 ).
test( 't85', 254, [], ['r3','r4'], 'fam1', 1 ).
test( 't86', 424, [], [], 'fam1', 1 ).
test( 't87', 784, [], [], 'fam1', 1 ).
test( 't88', 485, [], ['r4','r1'], 'fam1', 1 ).
test( 't89', 429, ['m8','m13','m2','m1'], [], 'fam1', 1 ).
test( 't90', 426, [], [], 'fam1', 1 ).
test( 't91', 766, ['m6','m12','m5','m19','m2'], [], 'fam1', 1 ).
test( 't92', 679, [], [], 'fam1', 1 ).
test( 't93', 105, [], [], 'fam1', 1 ).
test( 't94', 754, [], ['r4','r2','r3','r1','r5'], 'fam1', 1 ).
test( 't95', 355, [], [], 'fam1', 1 ).
test( 't96', 512, [], [], 'fam1', 1 ).
test( 't97', 481, ['m4','m18','m5','m8'], [], 'fam1', 1 ).
test( 't98', 132, [], ['r2'], 'fam1', 1 ).
test( 't99', 30, [], [], 'fam1', 1 ).
test( 't100', 573, ['m4','m11','m6','m13','m18','m19','m12','m14'], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
