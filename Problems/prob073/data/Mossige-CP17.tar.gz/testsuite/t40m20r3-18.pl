%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 20
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 710, ['m11','m4','m12','m19','m10','m20','m18'], [], 'fam1', 1 ).
test( 't2', 278, [], [], 'fam1', 1 ).
test( 't3', 402, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't4', 602, ['m3'], ['r3','r2'], 'fam1', 1 ).
test( 't5', 715, [], [], 'fam1', 1 ).
test( 't6', 558, [], ['r2','r3'], 'fam1', 1 ).
test( 't7', 113, [], [], 'fam1', 1 ).
test( 't8', 669, [], [], 'fam1', 1 ).
test( 't9', 292, ['m17','m1','m19','m11','m15','m3'], ['r1'], 'fam1', 1 ).
test( 't10', 793, [], [], 'fam1', 1 ).
test( 't11', 699, [], [], 'fam1', 1 ).
test( 't12', 207, [], [], 'fam1', 1 ).
test( 't13', 127, [], [], 'fam1', 1 ).
test( 't14', 125, [], ['r2'], 'fam1', 1 ).
test( 't15', 476, [], [], 'fam1', 1 ).
test( 't16', 378, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't17', 767, [], [], 'fam1', 1 ).
test( 't18', 335, [], ['r1','r3'], 'fam1', 1 ).
test( 't19', 130, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't20', 496, ['m4'], [], 'fam1', 1 ).
test( 't21', 719, [], [], 'fam1', 1 ).
test( 't22', 349, [], [], 'fam1', 1 ).
test( 't23', 83, [], ['r1','r2'], 'fam1', 1 ).
test( 't24', 349, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't25', 72, [], ['r1','r3'], 'fam1', 1 ).
test( 't26', 733, [], [], 'fam1', 1 ).
test( 't27', 679, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't28', 600, [], ['r2','r1'], 'fam1', 1 ).
test( 't29', 238, ['m12','m3','m6','m14','m2','m4','m20'], [], 'fam1', 1 ).
test( 't30', 627, ['m3'], ['r2'], 'fam1', 1 ).
test( 't31', 340, [], [], 'fam1', 1 ).
test( 't32', 800, [], [], 'fam1', 1 ).
test( 't33', 286, [], [], 'fam1', 1 ).
test( 't34', 584, [], [], 'fam1', 1 ).
test( 't35', 536, [], [], 'fam1', 1 ).
test( 't36', 147, ['m8','m11','m5'], [], 'fam1', 1 ).
test( 't37', 88, [], [], 'fam1', 1 ).
test( 't38', 449, [], ['r2','r3'], 'fam1', 1 ).
test( 't39', 751, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't40', 85, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
