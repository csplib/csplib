%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 20
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 488, [], [], 'fam1', 1 ).
test( 't2', 587, [], [], 'fam1', 1 ).
test( 't3', 328, [], [], 'fam1', 1 ).
test( 't4', 454, [], ['r5','r2','r1'], 'fam1', 1 ).
test( 't5', 192, [], [], 'fam1', 1 ).
test( 't6', 202, ['m12','m6','m15','m13','m9','m1','m7','m17'], ['r3','r5'], 'fam1', 1 ).
test( 't7', 530, [], [], 'fam1', 1 ).
test( 't8', 244, [], [], 'fam1', 1 ).
test( 't9', 292, ['m5','m6','m7','m14','m20'], [], 'fam1', 1 ).
test( 't10', 470, [], [], 'fam1', 1 ).
test( 't11', 754, ['m1'], [], 'fam1', 1 ).
test( 't12', 538, [], [], 'fam1', 1 ).
test( 't13', 171, [], ['r5','r1'], 'fam1', 1 ).
test( 't14', 420, ['m1','m3','m11','m18','m19','m8','m20','m6'], [], 'fam1', 1 ).
test( 't15', 173, [], [], 'fam1', 1 ).
test( 't16', 536, [], [], 'fam1', 1 ).
test( 't17', 465, [], [], 'fam1', 1 ).
test( 't18', 309, [], [], 'fam1', 1 ).
test( 't19', 21, ['m4','m17','m19','m3','m2','m20','m5'], ['r2','r5','r1'], 'fam1', 1 ).
test( 't20', 606, [], ['r4','r5','r2'], 'fam1', 1 ).
test( 't21', 257, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't22', 665, [], [], 'fam1', 1 ).
test( 't23', 514, ['m9','m12'], [], 'fam1', 1 ).
test( 't24', 382, [], [], 'fam1', 1 ).
test( 't25', 554, ['m4'], ['r2','r3','r1'], 'fam1', 1 ).
test( 't26', 631, [], [], 'fam1', 1 ).
test( 't27', 649, [], [], 'fam1', 1 ).
test( 't28', 604, [], ['r5','r3','r4','r1'], 'fam1', 1 ).
test( 't29', 761, [], ['r4'], 'fam1', 1 ).
test( 't30', 469, ['m10','m6','m9','m20'], ['r1','r4','r2','r3'], 'fam1', 1 ).
test( 't31', 406, ['m14','m17','m20','m18','m5','m8'], ['r2','r3'], 'fam1', 1 ).
test( 't32', 307, [], [], 'fam1', 1 ).
test( 't33', 63, ['m9','m6'], [], 'fam1', 1 ).
test( 't34', 591, [], ['r5','r3'], 'fam1', 1 ).
test( 't35', 10, ['m14','m10','m5'], ['r3','r2'], 'fam1', 1 ).
test( 't36', 93, ['m19','m9'], [], 'fam1', 1 ).
test( 't37', 7, [], [], 'fam1', 1 ).
test( 't38', 744, [], [], 'fam1', 1 ).
test( 't39', 95, [], [], 'fam1', 1 ).
test( 't40', 451, [], ['r2','r5','r1'], 'fam1', 1 ).
test( 't41', 474, [], ['r5','r1'], 'fam1', 1 ).
test( 't42', 615, [], ['r5','r4','r1','r2'], 'fam1', 1 ).
test( 't43', 665, [], [], 'fam1', 1 ).
test( 't44', 308, [], ['r5','r2','r3','r4'], 'fam1', 1 ).
test( 't45', 421, [], ['r1'], 'fam1', 1 ).
test( 't46', 62, [], ['r5','r1','r3','r2','r4'], 'fam1', 1 ).
test( 't47', 124, [], [], 'fam1', 1 ).
test( 't48', 800, ['m10','m12'], ['r5','r2','r1','r4','r3'], 'fam1', 1 ).
test( 't49', 13, ['m20','m14','m4','m9','m13','m18','m12','m2'], [], 'fam1', 1 ).
test( 't50', 572, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
