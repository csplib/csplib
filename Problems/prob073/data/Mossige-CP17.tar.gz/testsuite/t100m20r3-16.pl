%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 20
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 124, [], [], 'fam1', 1 ).
test( 't2', 137, [], ['r2','r1'], 'fam1', 1 ).
test( 't3', 582, [], ['r3','r2'], 'fam1', 1 ).
test( 't4', 373, [], ['r1','r3'], 'fam1', 1 ).
test( 't5', 239, ['m20','m15','m12','m6'], ['r1','r2'], 'fam1', 1 ).
test( 't6', 595, [], [], 'fam1', 1 ).
test( 't7', 673, ['m15','m6','m18'], [], 'fam1', 1 ).
test( 't8', 682, [], [], 'fam1', 1 ).
test( 't9', 615, [], [], 'fam1', 1 ).
test( 't10', 772, [], [], 'fam1', 1 ).
test( 't11', 124, [], [], 'fam1', 1 ).
test( 't12', 772, ['m16'], [], 'fam1', 1 ).
test( 't13', 113, [], [], 'fam1', 1 ).
test( 't14', 39, [], [], 'fam1', 1 ).
test( 't15', 360, ['m19','m14','m13','m2','m10','m4','m7'], ['r1','r3'], 'fam1', 1 ).
test( 't16', 135, [], ['r3'], 'fam1', 1 ).
test( 't17', 563, [], [], 'fam1', 1 ).
test( 't18', 404, [], [], 'fam1', 1 ).
test( 't19', 86, [], ['r3'], 'fam1', 1 ).
test( 't20', 277, [], [], 'fam1', 1 ).
test( 't21', 413, [], ['r1'], 'fam1', 1 ).
test( 't22', 240, [], ['r3'], 'fam1', 1 ).
test( 't23', 684, [], [], 'fam1', 1 ).
test( 't24', 800, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't25', 418, [], [], 'fam1', 1 ).
test( 't26', 738, [], [], 'fam1', 1 ).
test( 't27', 179, [], [], 'fam1', 1 ).
test( 't28', 680, ['m1','m18'], [], 'fam1', 1 ).
test( 't29', 328, [], ['r1'], 'fam1', 1 ).
test( 't30', 335, [], [], 'fam1', 1 ).
test( 't31', 743, [], [], 'fam1', 1 ).
test( 't32', 681, [], ['r1'], 'fam1', 1 ).
test( 't33', 705, [], [], 'fam1', 1 ).
test( 't34', 286, [], [], 'fam1', 1 ).
test( 't35', 525, ['m16','m18','m19','m20','m14','m8','m6'], ['r1','r3','r2'], 'fam1', 1 ).
test( 't36', 189, [], ['r3','r2'], 'fam1', 1 ).
test( 't37', 766, [], [], 'fam1', 1 ).
test( 't38', 517, [], [], 'fam1', 1 ).
test( 't39', 90, [], ['r2','r1'], 'fam1', 1 ).
test( 't40', 26, [], [], 'fam1', 1 ).
test( 't41', 300, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't42', 538, ['m20','m15','m8','m4','m13'], [], 'fam1', 1 ).
test( 't43', 615, [], ['r3','r1'], 'fam1', 1 ).
test( 't44', 136, [], [], 'fam1', 1 ).
test( 't45', 92, [], [], 'fam1', 1 ).
test( 't46', 413, ['m19','m15','m4','m7','m10'], [], 'fam1', 1 ).
test( 't47', 282, [], [], 'fam1', 1 ).
test( 't48', 252, [], [], 'fam1', 1 ).
test( 't49', 749, [], ['r3'], 'fam1', 1 ).
test( 't50', 97, [], [], 'fam1', 1 ).
test( 't51', 267, [], [], 'fam1', 1 ).
test( 't52', 663, [], [], 'fam1', 1 ).
test( 't53', 700, [], [], 'fam1', 1 ).
test( 't54', 373, ['m5','m13'], [], 'fam1', 1 ).
test( 't55', 619, [], [], 'fam1', 1 ).
test( 't56', 649, ['m12'], [], 'fam1', 1 ).
test( 't57', 167, [], ['r2'], 'fam1', 1 ).
test( 't58', 451, ['m7','m5','m17','m6','m12'], ['r3','r1','r2'], 'fam1', 1 ).
test( 't59', 114, ['m8','m20','m4','m19'], [], 'fam1', 1 ).
test( 't60', 625, [], ['r1'], 'fam1', 1 ).
test( 't61', 397, [], [], 'fam1', 1 ).
test( 't62', 311, [], [], 'fam1', 1 ).
test( 't63', 300, [], [], 'fam1', 1 ).
test( 't64', 36, ['m6','m10','m12','m5','m17'], ['r3','r2'], 'fam1', 1 ).
test( 't65', 765, ['m8'], [], 'fam1', 1 ).
test( 't66', 400, [], [], 'fam1', 1 ).
test( 't67', 611, [], [], 'fam1', 1 ).
test( 't68', 412, ['m8','m18','m20','m4'], [], 'fam1', 1 ).
test( 't69', 761, ['m3','m16','m19','m9'], ['r3','r2','r1'], 'fam1', 1 ).
test( 't70', 24, [], ['r3','r2'], 'fam1', 1 ).
test( 't71', 765, [], [], 'fam1', 1 ).
test( 't72', 127, [], [], 'fam1', 1 ).
test( 't73', 674, ['m5','m1','m8','m16','m13','m6','m14'], [], 'fam1', 1 ).
test( 't74', 539, [], ['r1','r3'], 'fam1', 1 ).
test( 't75', 520, [], [], 'fam1', 1 ).
test( 't76', 138, [], [], 'fam1', 1 ).
test( 't77', 268, ['m15','m2','m16','m7','m17'], ['r1'], 'fam1', 1 ).
test( 't78', 403, [], [], 'fam1', 1 ).
test( 't79', 193, [], [], 'fam1', 1 ).
test( 't80', 793, [], [], 'fam1', 1 ).
test( 't81', 757, [], [], 'fam1', 1 ).
test( 't82', 279, [], [], 'fam1', 1 ).
test( 't83', 73, [], [], 'fam1', 1 ).
test( 't84', 482, ['m2','m18','m4','m12','m20','m5','m17'], [], 'fam1', 1 ).
test( 't85', 177, [], [], 'fam1', 1 ).
test( 't86', 751, [], [], 'fam1', 1 ).
test( 't87', 264, [], [], 'fam1', 1 ).
test( 't88', 240, [], [], 'fam1', 1 ).
test( 't89', 646, [], [], 'fam1', 1 ).
test( 't90', 25, [], [], 'fam1', 1 ).
test( 't91', 584, [], [], 'fam1', 1 ).
test( 't92', 728, [], [], 'fam1', 1 ).
test( 't93', 160, [], [], 'fam1', 1 ).
test( 't94', 695, [], [], 'fam1', 1 ).
test( 't95', 492, [], ['r1'], 'fam1', 1 ).
test( 't96', 196, [], ['r1'], 'fam1', 1 ).
test( 't97', 450, [], ['r3'], 'fam1', 1 ).
test( 't98', 663, [], ['r1'], 'fam1', 1 ).
test( 't99', 599, [], [], 'fam1', 1 ).
test( 't100', 354, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
