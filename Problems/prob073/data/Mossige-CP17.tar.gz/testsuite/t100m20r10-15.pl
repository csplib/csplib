%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 20
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 785, ['m13','m18','m14'], [], 'fam1', 1 ).
test( 't2', 719, [], ['r8','r10','r2','r9'], 'fam1', 1 ).
test( 't3', 691, [], [], 'fam1', 1 ).
test( 't4', 499, [], [], 'fam1', 1 ).
test( 't5', 83, [], ['r1','r2','r9','r5','r7','r4','r10'], 'fam1', 1 ).
test( 't6', 76, [], ['r6','r8','r1','r5','r9','r10','r2','r3','r4'], 'fam1', 1 ).
test( 't7', 141, [], [], 'fam1', 1 ).
test( 't8', 366, [], [], 'fam1', 1 ).
test( 't9', 544, [], [], 'fam1', 1 ).
test( 't10', 370, [], [], 'fam1', 1 ).
test( 't11', 131, [], [], 'fam1', 1 ).
test( 't12', 163, ['m16','m13','m18','m2','m7','m15'], [], 'fam1', 1 ).
test( 't13', 773, [], ['r8','r2','r10','r9'], 'fam1', 1 ).
test( 't14', 489, [], [], 'fam1', 1 ).
test( 't15', 161, [], ['r3','r4','r9','r10'], 'fam1', 1 ).
test( 't16', 682, ['m19','m5'], [], 'fam1', 1 ).
test( 't17', 765, ['m12','m16','m1','m3','m11','m18'], [], 'fam1', 1 ).
test( 't18', 297, [], ['r1'], 'fam1', 1 ).
test( 't19', 490, [], [], 'fam1', 1 ).
test( 't20', 447, [], ['r9','r2'], 'fam1', 1 ).
test( 't21', 629, ['m11','m4','m3','m18'], [], 'fam1', 1 ).
test( 't22', 91, [], ['r6','r3'], 'fam1', 1 ).
test( 't23', 756, ['m7','m14','m12'], [], 'fam1', 1 ).
test( 't24', 518, ['m12','m18','m1','m4','m10','m7','m5','m13'], ['r4','r8'], 'fam1', 1 ).
test( 't25', 422, [], ['r8','r9','r5','r6'], 'fam1', 1 ).
test( 't26', 24, [], ['r10','r5','r3','r7','r1'], 'fam1', 1 ).
test( 't27', 118, [], [], 'fam1', 1 ).
test( 't28', 463, ['m7','m8','m15','m13','m10','m18','m17'], [], 'fam1', 1 ).
test( 't29', 604, [], [], 'fam1', 1 ).
test( 't30', 630, [], [], 'fam1', 1 ).
test( 't31', 394, [], [], 'fam1', 1 ).
test( 't32', 175, [], [], 'fam1', 1 ).
test( 't33', 794, [], ['r5','r2','r1','r3','r6','r10','r9'], 'fam1', 1 ).
test( 't34', 469, [], [], 'fam1', 1 ).
test( 't35', 101, [], [], 'fam1', 1 ).
test( 't36', 357, ['m13','m16','m11','m18','m5','m15','m10'], [], 'fam1', 1 ).
test( 't37', 505, [], [], 'fam1', 1 ).
test( 't38', 136, [], [], 'fam1', 1 ).
test( 't39', 671, ['m12'], [], 'fam1', 1 ).
test( 't40', 216, [], [], 'fam1', 1 ).
test( 't41', 725, [], [], 'fam1', 1 ).
test( 't42', 663, [], [], 'fam1', 1 ).
test( 't43', 176, ['m10','m2','m7','m15','m13'], [], 'fam1', 1 ).
test( 't44', 557, [], [], 'fam1', 1 ).
test( 't45', 166, [], [], 'fam1', 1 ).
test( 't46', 595, ['m5','m20','m6','m15','m3','m9','m11','m13'], [], 'fam1', 1 ).
test( 't47', 551, [], ['r7','r6','r2','r4','r8','r3','r5','r9','r10'], 'fam1', 1 ).
test( 't48', 578, [], [], 'fam1', 1 ).
test( 't49', 538, [], [], 'fam1', 1 ).
test( 't50', 308, [], [], 'fam1', 1 ).
test( 't51', 340, [], [], 'fam1', 1 ).
test( 't52', 719, [], [], 'fam1', 1 ).
test( 't53', 353, [], [], 'fam1', 1 ).
test( 't54', 677, [], [], 'fam1', 1 ).
test( 't55', 591, [], [], 'fam1', 1 ).
test( 't56', 598, [], [], 'fam1', 1 ).
test( 't57', 419, [], [], 'fam1', 1 ).
test( 't58', 95, [], [], 'fam1', 1 ).
test( 't59', 281, [], [], 'fam1', 1 ).
test( 't60', 599, ['m6','m1','m13','m3','m17'], ['r9','r8','r4'], 'fam1', 1 ).
test( 't61', 489, [], [], 'fam1', 1 ).
test( 't62', 762, [], [], 'fam1', 1 ).
test( 't63', 112, [], [], 'fam1', 1 ).
test( 't64', 426, [], [], 'fam1', 1 ).
test( 't65', 105, [], [], 'fam1', 1 ).
test( 't66', 470, [], [], 'fam1', 1 ).
test( 't67', 214, [], [], 'fam1', 1 ).
test( 't68', 309, [], [], 'fam1', 1 ).
test( 't69', 591, [], [], 'fam1', 1 ).
test( 't70', 222, [], ['r2','r4','r8','r1'], 'fam1', 1 ).
test( 't71', 159, [], ['r9','r1','r8','r5','r6','r4','r7','r2','r10','r3'], 'fam1', 1 ).
test( 't72', 551, [], [], 'fam1', 1 ).
test( 't73', 353, ['m12','m13','m1','m9','m6'], ['r10','r6','r1','r7','r3','r4'], 'fam1', 1 ).
test( 't74', 135, ['m5','m13','m18','m14','m10','m9'], ['r6'], 'fam1', 1 ).
test( 't75', 332, [], [], 'fam1', 1 ).
test( 't76', 345, [], [], 'fam1', 1 ).
test( 't77', 541, [], [], 'fam1', 1 ).
test( 't78', 412, [], ['r1','r10','r4','r3','r6','r2'], 'fam1', 1 ).
test( 't79', 235, [], [], 'fam1', 1 ).
test( 't80', 254, ['m20','m12','m7','m11','m1','m8'], ['r6','r1','r3','r5','r9','r7','r10','r8','r2','r4'], 'fam1', 1 ).
test( 't81', 501, ['m11','m18','m6','m19'], [], 'fam1', 1 ).
test( 't82', 682, [], ['r2','r5','r6','r7','r3','r1','r4','r8'], 'fam1', 1 ).
test( 't83', 377, [], [], 'fam1', 1 ).
test( 't84', 669, [], ['r6','r4','r5'], 'fam1', 1 ).
test( 't85', 609, [], [], 'fam1', 1 ).
test( 't86', 190, ['m4','m18','m15','m9','m10','m16','m2'], ['r3','r9','r7','r10','r2'], 'fam1', 1 ).
test( 't87', 498, [], [], 'fam1', 1 ).
test( 't88', 377, [], [], 'fam1', 1 ).
test( 't89', 650, [], [], 'fam1', 1 ).
test( 't90', 736, ['m15','m12','m4'], [], 'fam1', 1 ).
test( 't91', 153, [], [], 'fam1', 1 ).
test( 't92', 771, ['m8','m10','m18','m20','m19','m7'], [], 'fam1', 1 ).
test( 't93', 529, ['m19','m4','m16','m8','m12','m3','m2'], [], 'fam1', 1 ).
test( 't94', 298, [], [], 'fam1', 1 ).
test( 't95', 626, [], [], 'fam1', 1 ).
test( 't96', 151, [], [], 'fam1', 1 ).
test( 't97', 497, ['m18','m3','m12','m7','m2','m14','m10','m13'], [], 'fam1', 1 ).
test( 't98', 413, [], [], 'fam1', 1 ).
test( 't99', 241, ['m7','m14','m9','m5','m15','m13'], [], 'fam1', 1 ).
test( 't100', 125, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
