%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 10
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 474, [], [], 'fam1', 1 ).
test( 't2', 100, [], [], 'fam1', 1 ).
test( 't3', 376, ['m10'], ['r1','r7','r2','r3'], 'fam1', 1 ).
test( 't4', 740, [], [], 'fam1', 1 ).
test( 't5', 544, [], [], 'fam1', 1 ).
test( 't6', 276, [], [], 'fam1', 1 ).
test( 't7', 301, [], [], 'fam1', 1 ).
test( 't8', 193, [], [], 'fam1', 1 ).
test( 't9', 193, ['m8','m4','m3','m7'], [], 'fam1', 1 ).
test( 't10', 303, [], [], 'fam1', 1 ).
test( 't11', 45, [], [], 'fam1', 1 ).
test( 't12', 660, [], [], 'fam1', 1 ).
test( 't13', 190, [], [], 'fam1', 1 ).
test( 't14', 225, [], [], 'fam1', 1 ).
test( 't15', 159, ['m2','m5','m6','m7'], [], 'fam1', 1 ).
test( 't16', 194, [], [], 'fam1', 1 ).
test( 't17', 541, [], ['r2','r9','r3'], 'fam1', 1 ).
test( 't18', 540, ['m1'], ['r6','r8','r5','r4'], 'fam1', 1 ).
test( 't19', 368, ['m2','m3'], [], 'fam1', 1 ).
test( 't20', 72, ['m5','m10','m2'], [], 'fam1', 1 ).
test( 't21', 571, [], [], 'fam1', 1 ).
test( 't22', 44, [], [], 'fam1', 1 ).
test( 't23', 671, ['m8','m2','m10'], ['r6','r9','r10','r2','r4','r3','r1','r7'], 'fam1', 1 ).
test( 't24', 197, [], [], 'fam1', 1 ).
test( 't25', 290, [], [], 'fam1', 1 ).
test( 't26', 791, [], ['r9','r7','r2','r4','r10','r1','r6','r8'], 'fam1', 1 ).
test( 't27', 270, [], ['r6','r10','r2'], 'fam1', 1 ).
test( 't28', 437, [], [], 'fam1', 1 ).
test( 't29', 572, [], [], 'fam1', 1 ).
test( 't30', 189, [], ['r10'], 'fam1', 1 ).
test( 't31', 690, [], [], 'fam1', 1 ).
test( 't32', 287, [], [], 'fam1', 1 ).
test( 't33', 605, ['m1','m10','m4'], [], 'fam1', 1 ).
test( 't34', 182, ['m5','m3'], ['r3','r8','r7','r5','r4','r2','r6','r10','r1','r9'], 'fam1', 1 ).
test( 't35', 465, [], ['r6','r5','r7','r1','r9','r10','r4'], 'fam1', 1 ).
test( 't36', 167, ['m6'], ['r3','r8','r1','r9','r10','r2','r5'], 'fam1', 1 ).
test( 't37', 451, ['m3','m5'], [], 'fam1', 1 ).
test( 't38', 148, ['m7','m5','m1'], [], 'fam1', 1 ).
test( 't39', 438, [], [], 'fam1', 1 ).
test( 't40', 487, [], [], 'fam1', 1 ).
test( 't41', 17, ['m10'], [], 'fam1', 1 ).
test( 't42', 13, [], [], 'fam1', 1 ).
test( 't43', 15, [], ['r10'], 'fam1', 1 ).
test( 't44', 451, [], [], 'fam1', 1 ).
test( 't45', 296, [], ['r6','r7','r3'], 'fam1', 1 ).
test( 't46', 771, [], [], 'fam1', 1 ).
test( 't47', 622, [], [], 'fam1', 1 ).
test( 't48', 500, ['m1','m4'], ['r7','r1','r5','r9','r3','r2','r4','r8','r6','r10'], 'fam1', 1 ).
test( 't49', 82, [], [], 'fam1', 1 ).
test( 't50', 550, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
