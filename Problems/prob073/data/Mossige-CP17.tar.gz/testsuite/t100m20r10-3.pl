%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 20
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 615, [], [], 'fam1', 1 ).
test( 't2', 178, [], ['r5','r3'], 'fam1', 1 ).
test( 't3', 535, [], [], 'fam1', 1 ).
test( 't4', 297, ['m7','m8','m17','m20','m19','m10','m15','m12'], [], 'fam1', 1 ).
test( 't5', 514, [], [], 'fam1', 1 ).
test( 't6', 83, [], [], 'fam1', 1 ).
test( 't7', 449, ['m15','m12','m6','m20','m5','m14','m19'], [], 'fam1', 1 ).
test( 't8', 623, [], [], 'fam1', 1 ).
test( 't9', 800, [], [], 'fam1', 1 ).
test( 't10', 210, [], [], 'fam1', 1 ).
test( 't11', 268, [], [], 'fam1', 1 ).
test( 't12', 670, ['m16'], [], 'fam1', 1 ).
test( 't13', 665, [], [], 'fam1', 1 ).
test( 't14', 142, ['m15','m5','m3','m19'], [], 'fam1', 1 ).
test( 't15', 273, [], ['r5','r2','r3','r7'], 'fam1', 1 ).
test( 't16', 534, [], [], 'fam1', 1 ).
test( 't17', 102, [], [], 'fam1', 1 ).
test( 't18', 399, [], [], 'fam1', 1 ).
test( 't19', 203, ['m12','m2','m13','m4'], ['r9','r5','r3','r8','r7','r6','r1','r4','r2','r10'], 'fam1', 1 ).
test( 't20', 358, ['m10','m11','m4','m15','m16','m6','m1','m18'], [], 'fam1', 1 ).
test( 't21', 174, [], ['r3','r1','r6','r10','r7'], 'fam1', 1 ).
test( 't22', 152, [], [], 'fam1', 1 ).
test( 't23', 696, [], [], 'fam1', 1 ).
test( 't24', 18, ['m9','m16'], ['r5','r3','r1','r6','r9','r2','r10','r8','r4'], 'fam1', 1 ).
test( 't25', 528, ['m13','m17'], [], 'fam1', 1 ).
test( 't26', 278, [], [], 'fam1', 1 ).
test( 't27', 360, [], [], 'fam1', 1 ).
test( 't28', 688, [], ['r10','r7'], 'fam1', 1 ).
test( 't29', 312, ['m13','m17'], [], 'fam1', 1 ).
test( 't30', 402, [], [], 'fam1', 1 ).
test( 't31', 703, [], [], 'fam1', 1 ).
test( 't32', 89, [], [], 'fam1', 1 ).
test( 't33', 738, [], [], 'fam1', 1 ).
test( 't34', 759, [], [], 'fam1', 1 ).
test( 't35', 577, [], ['r10','r7','r1','r3','r5','r4'], 'fam1', 1 ).
test( 't36', 167, [], [], 'fam1', 1 ).
test( 't37', 387, [], ['r2','r1','r7','r9','r4'], 'fam1', 1 ).
test( 't38', 218, [], [], 'fam1', 1 ).
test( 't39', 268, ['m14','m20','m18','m11','m7','m17','m13','m12'], ['r7','r9','r5','r6','r1','r10'], 'fam1', 1 ).
test( 't40', 483, [], [], 'fam1', 1 ).
test( 't41', 641, [], [], 'fam1', 1 ).
test( 't42', 407, [], [], 'fam1', 1 ).
test( 't43', 357, ['m15','m1'], [], 'fam1', 1 ).
test( 't44', 759, ['m12','m15','m9'], [], 'fam1', 1 ).
test( 't45', 668, ['m3','m11','m9'], [], 'fam1', 1 ).
test( 't46', 775, ['m20','m5','m1','m12','m11'], [], 'fam1', 1 ).
test( 't47', 554, ['m3','m20','m16','m19','m18','m10','m6','m8'], ['r2','r5','r3','r6'], 'fam1', 1 ).
test( 't48', 505, ['m7'], [], 'fam1', 1 ).
test( 't49', 788, [], [], 'fam1', 1 ).
test( 't50', 304, [], [], 'fam1', 1 ).
test( 't51', 275, [], ['r1','r4'], 'fam1', 1 ).
test( 't52', 735, [], [], 'fam1', 1 ).
test( 't53', 168, [], [], 'fam1', 1 ).
test( 't54', 391, ['m11','m2'], [], 'fam1', 1 ).
test( 't55', 200, ['m12','m10'], [], 'fam1', 1 ).
test( 't56', 504, [], [], 'fam1', 1 ).
test( 't57', 729, [], ['r3','r7'], 'fam1', 1 ).
test( 't58', 51, [], [], 'fam1', 1 ).
test( 't59', 541, [], [], 'fam1', 1 ).
test( 't60', 25, [], ['r8','r4','r6','r7','r1','r3','r2','r9','r5','r10'], 'fam1', 1 ).
test( 't61', 83, [], [], 'fam1', 1 ).
test( 't62', 4, ['m2','m18','m6','m9','m17','m12'], [], 'fam1', 1 ).
test( 't63', 124, [], ['r10','r4','r2','r7','r8','r9','r1'], 'fam1', 1 ).
test( 't64', 386, [], [], 'fam1', 1 ).
test( 't65', 317, [], [], 'fam1', 1 ).
test( 't66', 51, [], ['r3','r1'], 'fam1', 1 ).
test( 't67', 200, ['m5','m12','m19','m14','m9','m15','m18'], [], 'fam1', 1 ).
test( 't68', 513, [], [], 'fam1', 1 ).
test( 't69', 657, [], [], 'fam1', 1 ).
test( 't70', 423, [], [], 'fam1', 1 ).
test( 't71', 777, [], ['r3','r2','r10'], 'fam1', 1 ).
test( 't72', 777, ['m12','m2','m14','m9','m3'], [], 'fam1', 1 ).
test( 't73', 338, ['m6'], [], 'fam1', 1 ).
test( 't74', 684, [], [], 'fam1', 1 ).
test( 't75', 412, [], ['r6','r4','r8'], 'fam1', 1 ).
test( 't76', 10, [], ['r10','r5','r6','r9'], 'fam1', 1 ).
test( 't77', 187, [], [], 'fam1', 1 ).
test( 't78', 339, [], [], 'fam1', 1 ).
test( 't79', 567, ['m20','m17','m6'], [], 'fam1', 1 ).
test( 't80', 77, [], [], 'fam1', 1 ).
test( 't81', 542, ['m8','m10','m7','m11'], [], 'fam1', 1 ).
test( 't82', 218, [], ['r8','r7','r4','r3','r9','r6','r5','r10'], 'fam1', 1 ).
test( 't83', 513, [], ['r10','r1','r8','r6'], 'fam1', 1 ).
test( 't84', 682, [], ['r1','r6','r9','r5','r7','r10','r3','r2'], 'fam1', 1 ).
test( 't85', 81, [], [], 'fam1', 1 ).
test( 't86', 785, [], [], 'fam1', 1 ).
test( 't87', 68, [], [], 'fam1', 1 ).
test( 't88', 676, ['m7','m10','m1','m11','m3','m19','m4','m9'], ['r1','r9','r6','r8','r10'], 'fam1', 1 ).
test( 't89', 79, [], ['r9','r4','r10','r8','r7','r6'], 'fam1', 1 ).
test( 't90', 622, [], [], 'fam1', 1 ).
test( 't91', 162, [], ['r4','r7','r5','r10'], 'fam1', 1 ).
test( 't92', 469, [], ['r9','r8','r6','r3','r4','r1','r10','r7','r5','r2'], 'fam1', 1 ).
test( 't93', 774, [], [], 'fam1', 1 ).
test( 't94', 513, [], [], 'fam1', 1 ).
test( 't95', 392, [], [], 'fam1', 1 ).
test( 't96', 218, ['m4','m12'], [], 'fam1', 1 ).
test( 't97', 678, [], [], 'fam1', 1 ).
test( 't98', 632, [], ['r3','r1','r4','r6','r2','r10','r5','r8','r7','r9'], 'fam1', 1 ).
test( 't99', 102, [], [], 'fam1', 1 ).
test( 't100', 451, [], ['r3','r5','r4','r7','r6','r8','r1'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
