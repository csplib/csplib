%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 20
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 288, ['m6'], [], 'fam1', 1 ).
test( 't2', 664, [], [], 'fam1', 1 ).
test( 't3', 725, [], [], 'fam1', 1 ).
test( 't4', 666, [], ['r8','r6','r3','r1','r2','r10','r9'], 'fam1', 1 ).
test( 't5', 71, [], [], 'fam1', 1 ).
test( 't6', 110, [], [], 'fam1', 1 ).
test( 't7', 702, [], ['r5','r6','r3','r10'], 'fam1', 1 ).
test( 't8', 341, ['m8','m14','m2'], [], 'fam1', 1 ).
test( 't9', 255, [], ['r8','r10','r2','r1'], 'fam1', 1 ).
test( 't10', 139, [], [], 'fam1', 1 ).
test( 't11', 123, [], [], 'fam1', 1 ).
test( 't12', 771, [], [], 'fam1', 1 ).
test( 't13', 515, [], [], 'fam1', 1 ).
test( 't14', 133, [], [], 'fam1', 1 ).
test( 't15', 146, ['m18','m1','m7','m9','m2'], ['r10','r6','r9','r7','r1','r5','r4','r8'], 'fam1', 1 ).
test( 't16', 253, [], [], 'fam1', 1 ).
test( 't17', 61, [], [], 'fam1', 1 ).
test( 't18', 481, [], [], 'fam1', 1 ).
test( 't19', 423, [], [], 'fam1', 1 ).
test( 't20', 148, [], ['r2','r9','r5'], 'fam1', 1 ).
test( 't21', 326, ['m14','m7'], ['r9','r2','r7','r1','r4','r8','r3','r6','r5'], 'fam1', 1 ).
test( 't22', 57, [], [], 'fam1', 1 ).
test( 't23', 692, [], [], 'fam1', 1 ).
test( 't24', 101, ['m20','m7','m11','m10'], [], 'fam1', 1 ).
test( 't25', 130, [], [], 'fam1', 1 ).
test( 't26', 351, [], [], 'fam1', 1 ).
test( 't27', 31, [], ['r9','r10','r6','r3','r7'], 'fam1', 1 ).
test( 't28', 728, [], [], 'fam1', 1 ).
test( 't29', 706, [], [], 'fam1', 1 ).
test( 't30', 31, ['m1','m9','m2','m5','m13','m17','m19','m12'], ['r7','r2','r10','r6','r9','r8','r5'], 'fam1', 1 ).
test( 't31', 396, ['m5','m1','m20','m6','m17','m12','m10'], ['r3','r9','r6','r10','r2','r4','r7','r8'], 'fam1', 1 ).
test( 't32', 377, [], [], 'fam1', 1 ).
test( 't33', 83, [], ['r6','r9','r4'], 'fam1', 1 ).
test( 't34', 59, ['m7','m17','m1','m5','m15'], [], 'fam1', 1 ).
test( 't35', 714, [], [], 'fam1', 1 ).
test( 't36', 83, [], [], 'fam1', 1 ).
test( 't37', 280, [], [], 'fam1', 1 ).
test( 't38', 678, ['m13','m7','m20','m5','m19'], [], 'fam1', 1 ).
test( 't39', 409, [], [], 'fam1', 1 ).
test( 't40', 698, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
