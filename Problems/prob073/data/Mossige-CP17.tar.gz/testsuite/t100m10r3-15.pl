%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 543, ['m8','m9','m7'], ['r1','r3','r2'], 'fam1', 1 ).
test( 't2', 457, [], [], 'fam1', 1 ).
test( 't3', 737, ['m2'], [], 'fam1', 1 ).
test( 't4', 257, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't5', 503, [], [], 'fam1', 1 ).
test( 't6', 288, ['m6','m7','m3'], ['r3'], 'fam1', 1 ).
test( 't7', 599, [], [], 'fam1', 1 ).
test( 't8', 135, [], [], 'fam1', 1 ).
test( 't9', 190, [], [], 'fam1', 1 ).
test( 't10', 468, [], [], 'fam1', 1 ).
test( 't11', 679, [], ['r1','r3'], 'fam1', 1 ).
test( 't12', 122, ['m1'], [], 'fam1', 1 ).
test( 't13', 118, [], [], 'fam1', 1 ).
test( 't14', 445, [], [], 'fam1', 1 ).
test( 't15', 2, [], [], 'fam1', 1 ).
test( 't16', 48, [], [], 'fam1', 1 ).
test( 't17', 714, ['m3','m8','m7'], [], 'fam1', 1 ).
test( 't18', 275, ['m9'], [], 'fam1', 1 ).
test( 't19', 691, [], [], 'fam1', 1 ).
test( 't20', 52, [], [], 'fam1', 1 ).
test( 't21', 487, [], ['r1'], 'fam1', 1 ).
test( 't22', 412, [], [], 'fam1', 1 ).
test( 't23', 462, [], [], 'fam1', 1 ).
test( 't24', 398, [], [], 'fam1', 1 ).
test( 't25', 765, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't26', 157, ['m2','m10','m8','m3'], ['r2'], 'fam1', 1 ).
test( 't27', 196, [], [], 'fam1', 1 ).
test( 't28', 100, [], [], 'fam1', 1 ).
test( 't29', 434, [], [], 'fam1', 1 ).
test( 't30', 504, [], [], 'fam1', 1 ).
test( 't31', 720, [], [], 'fam1', 1 ).
test( 't32', 351, [], ['r2'], 'fam1', 1 ).
test( 't33', 758, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't34', 427, [], [], 'fam1', 1 ).
test( 't35', 640, [], [], 'fam1', 1 ).
test( 't36', 582, [], [], 'fam1', 1 ).
test( 't37', 565, [], ['r3'], 'fam1', 1 ).
test( 't38', 662, [], ['r1','r3'], 'fam1', 1 ).
test( 't39', 186, [], [], 'fam1', 1 ).
test( 't40', 748, [], [], 'fam1', 1 ).
test( 't41', 362, ['m6','m3','m1'], [], 'fam1', 1 ).
test( 't42', 598, [], [], 'fam1', 1 ).
test( 't43', 249, [], ['r1'], 'fam1', 1 ).
test( 't44', 644, [], [], 'fam1', 1 ).
test( 't45', 669, ['m10'], [], 'fam1', 1 ).
test( 't46', 499, [], [], 'fam1', 1 ).
test( 't47', 466, [], [], 'fam1', 1 ).
test( 't48', 246, ['m10'], ['r3'], 'fam1', 1 ).
test( 't49', 517, [], [], 'fam1', 1 ).
test( 't50', 496, [], [], 'fam1', 1 ).
test( 't51', 407, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't52', 277, [], [], 'fam1', 1 ).
test( 't53', 398, [], ['r3'], 'fam1', 1 ).
test( 't54', 363, [], [], 'fam1', 1 ).
test( 't55', 49, [], [], 'fam1', 1 ).
test( 't56', 336, ['m4','m7'], [], 'fam1', 1 ).
test( 't57', 75, [], [], 'fam1', 1 ).
test( 't58', 271, [], [], 'fam1', 1 ).
test( 't59', 72, [], ['r3'], 'fam1', 1 ).
test( 't60', 273, [], [], 'fam1', 1 ).
test( 't61', 328, [], ['r2','r1'], 'fam1', 1 ).
test( 't62', 703, [], [], 'fam1', 1 ).
test( 't63', 779, [], [], 'fam1', 1 ).
test( 't64', 704, ['m8','m4','m9','m5'], [], 'fam1', 1 ).
test( 't65', 681, ['m1'], [], 'fam1', 1 ).
test( 't66', 344, [], ['r3'], 'fam1', 1 ).
test( 't67', 507, [], [], 'fam1', 1 ).
test( 't68', 513, [], ['r3','r1'], 'fam1', 1 ).
test( 't69', 259, [], [], 'fam1', 1 ).
test( 't70', 486, [], [], 'fam1', 1 ).
test( 't71', 628, [], [], 'fam1', 1 ).
test( 't72', 722, [], [], 'fam1', 1 ).
test( 't73', 136, [], [], 'fam1', 1 ).
test( 't74', 635, [], ['r2'], 'fam1', 1 ).
test( 't75', 715, [], [], 'fam1', 1 ).
test( 't76', 481, [], [], 'fam1', 1 ).
test( 't77', 84, ['m10'], ['r3','r1','r2'], 'fam1', 1 ).
test( 't78', 36, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't79', 587, ['m7'], ['r2','r3','r1'], 'fam1', 1 ).
test( 't80', 324, ['m3','m9','m1','m5'], [], 'fam1', 1 ).
test( 't81', 190, [], [], 'fam1', 1 ).
test( 't82', 24, [], [], 'fam1', 1 ).
test( 't83', 448, [], [], 'fam1', 1 ).
test( 't84', 418, [], [], 'fam1', 1 ).
test( 't85', 284, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't86', 261, [], [], 'fam1', 1 ).
test( 't87', 666, [], ['r1','r3'], 'fam1', 1 ).
test( 't88', 161, [], ['r1'], 'fam1', 1 ).
test( 't89', 712, [], [], 'fam1', 1 ).
test( 't90', 216, [], [], 'fam1', 1 ).
test( 't91', 76, [], [], 'fam1', 1 ).
test( 't92', 656, ['m6','m2','m9'], ['r3','r2'], 'fam1', 1 ).
test( 't93', 658, [], [], 'fam1', 1 ).
test( 't94', 17, [], [], 'fam1', 1 ).
test( 't95', 470, ['m8'], [], 'fam1', 1 ).
test( 't96', 467, [], [], 'fam1', 1 ).
test( 't97', 224, [], [], 'fam1', 1 ).
test( 't98', 75, [], [], 'fam1', 1 ).
test( 't99', 536, [], [], 'fam1', 1 ).
test( 't100', 108, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
