%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 622, ['m2'], ['r2','r1','r3'], 'fam1', 1 ).
test( 't2', 585, [], [], 'fam1', 1 ).
test( 't3', 585, [], [], 'fam1', 1 ).
test( 't4', 76, [], [], 'fam1', 1 ).
test( 't5', 621, [], [], 'fam1', 1 ).
test( 't6', 154, [], [], 'fam1', 1 ).
test( 't7', 266, [], ['r2','r1'], 'fam1', 1 ).
test( 't8', 110, [], [], 'fam1', 1 ).
test( 't9', 654, ['m7'], [], 'fam1', 1 ).
test( 't10', 467, [], [], 'fam1', 1 ).
test( 't11', 197, [], [], 'fam1', 1 ).
test( 't12', 712, [], ['r1','r3'], 'fam1', 1 ).
test( 't13', 327, [], [], 'fam1', 1 ).
test( 't14', 45, [], [], 'fam1', 1 ).
test( 't15', 258, [], [], 'fam1', 1 ).
test( 't16', 784, ['m2','m4'], [], 'fam1', 1 ).
test( 't17', 423, [], [], 'fam1', 1 ).
test( 't18', 565, [], [], 'fam1', 1 ).
test( 't19', 319, [], [], 'fam1', 1 ).
test( 't20', 60, [], [], 'fam1', 1 ).
test( 't21', 116, [], [], 'fam1', 1 ).
test( 't22', 757, [], [], 'fam1', 1 ).
test( 't23', 749, [], [], 'fam1', 1 ).
test( 't24', 619, [], [], 'fam1', 1 ).
test( 't25', 304, [], [], 'fam1', 1 ).
test( 't26', 362, ['m1','m6'], [], 'fam1', 1 ).
test( 't27', 630, ['m6','m10'], ['r3','r1','r2'], 'fam1', 1 ).
test( 't28', 508, ['m5','m2','m8','m4'], ['r3','r1'], 'fam1', 1 ).
test( 't29', 702, [], ['r2','r1'], 'fam1', 1 ).
test( 't30', 448, [], [], 'fam1', 1 ).
test( 't31', 330, [], [], 'fam1', 1 ).
test( 't32', 725, ['m4','m1','m7'], [], 'fam1', 1 ).
test( 't33', 115, ['m5','m2','m8'], [], 'fam1', 1 ).
test( 't34', 172, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't35', 801, ['m5','m10','m7'], [], 'fam1', 1 ).
test( 't36', 655, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't37', 488, [], ['r1'], 'fam1', 1 ).
test( 't38', 510, [], ['r2'], 'fam1', 1 ).
test( 't39', 766, [], [], 'fam1', 1 ).
test( 't40', 131, [], [], 'fam1', 1 ).
test( 't41', 229, [], ['r1'], 'fam1', 1 ).
test( 't42', 170, ['m2','m7','m4'], [], 'fam1', 1 ).
test( 't43', 483, [], [], 'fam1', 1 ).
test( 't44', 513, [], [], 'fam1', 1 ).
test( 't45', 589, [], [], 'fam1', 1 ).
test( 't46', 236, [], [], 'fam1', 1 ).
test( 't47', 427, [], [], 'fam1', 1 ).
test( 't48', 699, [], [], 'fam1', 1 ).
test( 't49', 384, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't50', 605, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
