%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 50
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 259, [], [], 'fam1', 1 ).
test( 't2', 439, ['m37'], [], 'fam1', 1 ).
test( 't3', 368, [], [], 'fam1', 1 ).
test( 't4', 229, [], [], 'fam1', 1 ).
test( 't5', 48, [], [], 'fam1', 1 ).
test( 't6', 652, [], [], 'fam1', 1 ).
test( 't7', 100, [], [], 'fam1', 1 ).
test( 't8', 539, ['m20','m43','m12','m45','m14','m5','m47','m9','m23','m13','m41','m22','m46','m18','m10','m36','m26','m21'], [], 'fam1', 1 ).
test( 't9', 695, [], [], 'fam1', 1 ).
test( 't10', 773, [], [], 'fam1', 1 ).
test( 't11', 229, [], [], 'fam1', 1 ).
test( 't12', 714, ['m49','m40','m23','m28'], [], 'fam1', 1 ).
test( 't13', 390, [], ['r1'], 'fam1', 1 ).
test( 't14', 590, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't15', 228, [], [], 'fam1', 1 ).
test( 't16', 646, [], [], 'fam1', 1 ).
test( 't17', 389, ['m2','m32','m1','m30','m7','m23','m34','m13','m18','m8','m6'], [], 'fam1', 1 ).
test( 't18', 487, [], [], 'fam1', 1 ).
test( 't19', 584, [], [], 'fam1', 1 ).
test( 't20', 131, [], [], 'fam1', 1 ).
test( 't21', 727, [], [], 'fam1', 1 ).
test( 't22', 367, [], [], 'fam1', 1 ).
test( 't23', 612, [], [], 'fam1', 1 ).
test( 't24', 19, [], [], 'fam1', 1 ).
test( 't25', 20, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't26', 17, [], ['r1'], 'fam1', 1 ).
test( 't27', 575, [], [], 'fam1', 1 ).
test( 't28', 559, [], [], 'fam1', 1 ).
test( 't29', 190, ['m29','m45','m39','m37','m33','m41','m15','m20','m42','m28'], [], 'fam1', 1 ).
test( 't30', 179, [], ['r1'], 'fam1', 1 ).
test( 't31', 580, ['m29','m2','m36','m22','m20','m47','m31','m32','m38','m23','m18','m21','m39','m37','m24','m7','m13','m42','m19'], [], 'fam1', 1 ).
test( 't32', 111, [], [], 'fam1', 1 ).
test( 't33', 17, [], [], 'fam1', 1 ).
test( 't34', 709, [], [], 'fam1', 1 ).
test( 't35', 372, [], [], 'fam1', 1 ).
test( 't36', 337, ['m38','m40','m21','m37','m1','m43','m22','m45','m50','m35','m36','m29','m19','m28','m24'], [], 'fam1', 1 ).
test( 't37', 291, [], [], 'fam1', 1 ).
test( 't38', 634, [], ['r2'], 'fam1', 1 ).
test( 't39', 12, [], [], 'fam1', 1 ).
test( 't40', 297, [], [], 'fam1', 1 ).
test( 't41', 583, [], [], 'fam1', 1 ).
test( 't42', 164, [], [], 'fam1', 1 ).
test( 't43', 750, [], [], 'fam1', 1 ).
test( 't44', 50, [], [], 'fam1', 1 ).
test( 't45', 310, [], [], 'fam1', 1 ).
test( 't46', 16, [], ['r3','r1'], 'fam1', 1 ).
test( 't47', 235, [], [], 'fam1', 1 ).
test( 't48', 31, [], [], 'fam1', 1 ).
test( 't49', 684, ['m13'], [], 'fam1', 1 ).
test( 't50', 136, [], [], 'fam1', 1 ).
test( 't51', 93, [], [], 'fam1', 1 ).
test( 't52', 579, [], [], 'fam1', 1 ).
test( 't53', 245, ['m42','m19','m22','m50','m33','m16','m20','m32','m3'], [], 'fam1', 1 ).
test( 't54', 785, ['m46','m4','m11','m13'], [], 'fam1', 1 ).
test( 't55', 726, [], [], 'fam1', 1 ).
test( 't56', 174, [], ['r2'], 'fam1', 1 ).
test( 't57', 495, [], [], 'fam1', 1 ).
test( 't58', 649, ['m42','m47','m10','m23','m4','m26'], [], 'fam1', 1 ).
test( 't59', 628, [], ['r1'], 'fam1', 1 ).
test( 't60', 284, [], ['r1','r3'], 'fam1', 1 ).
test( 't61', 188, ['m31','m15','m34','m49','m26','m7'], [], 'fam1', 1 ).
test( 't62', 768, [], [], 'fam1', 1 ).
test( 't63', 385, [], [], 'fam1', 1 ).
test( 't64', 102, [], [], 'fam1', 1 ).
test( 't65', 490, [], ['r1','r2'], 'fam1', 1 ).
test( 't66', 295, ['m42','m37','m19','m47','m46','m27','m31','m34','m18','m39','m45','m49','m3','m15','m30','m24','m38','m33'], [], 'fam1', 1 ).
test( 't67', 159, [], [], 'fam1', 1 ).
test( 't68', 132, [], ['r3','r1'], 'fam1', 1 ).
test( 't69', 456, [], [], 'fam1', 1 ).
test( 't70', 310, [], [], 'fam1', 1 ).
test( 't71', 98, [], [], 'fam1', 1 ).
test( 't72', 615, [], ['r2'], 'fam1', 1 ).
test( 't73', 228, [], [], 'fam1', 1 ).
test( 't74', 640, [], ['r3','r1'], 'fam1', 1 ).
test( 't75', 700, ['m8','m41','m50','m4','m29','m48','m30','m22','m33','m5','m6','m7','m19','m21'], ['r1','r2','r3'], 'fam1', 1 ).
test( 't76', 176, ['m16','m34','m18','m38','m13','m41','m1','m50','m7','m15','m8','m31','m47','m4','m39','m19','m12'], [], 'fam1', 1 ).
test( 't77', 746, [], [], 'fam1', 1 ).
test( 't78', 223, [], [], 'fam1', 1 ).
test( 't79', 281, [], [], 'fam1', 1 ).
test( 't80', 227, [], [], 'fam1', 1 ).
test( 't81', 653, [], ['r2'], 'fam1', 1 ).
test( 't82', 640, [], [], 'fam1', 1 ).
test( 't83', 793, [], ['r1','r2'], 'fam1', 1 ).
test( 't84', 262, [], ['r1'], 'fam1', 1 ).
test( 't85', 300, ['m50','m41','m13','m36','m28'], [], 'fam1', 1 ).
test( 't86', 102, ['m39','m14','m45','m20','m33'], [], 'fam1', 1 ).
test( 't87', 149, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't88', 317, [], [], 'fam1', 1 ).
test( 't89', 286, ['m30','m10','m32','m34','m31','m33','m37','m5','m25','m43','m40','m18','m50'], [], 'fam1', 1 ).
test( 't90', 1, [], [], 'fam1', 1 ).
test( 't91', 725, [], [], 'fam1', 1 ).
test( 't92', 263, ['m10'], ['r2','r1'], 'fam1', 1 ).
test( 't93', 98, ['m30','m16','m45','m11','m4','m36','m5','m21','m35','m17','m13','m9','m22','m18','m6','m47','m50'], [], 'fam1', 1 ).
test( 't94', 593, [], [], 'fam1', 1 ).
test( 't95', 500, [], [], 'fam1', 1 ).
test( 't96', 465, ['m2','m4','m1','m46','m12','m48','m13','m37'], ['r3','r1','r2'], 'fam1', 1 ).
test( 't97', 798, [], ['r3'], 'fam1', 1 ).
test( 't98', 557, ['m44','m46','m45','m1','m48','m18','m8','m10','m47','m28','m25','m4','m11'], [], 'fam1', 1 ).
test( 't99', 380, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't100', 75, [], ['r1'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').
embedded_board( 'm21').
embedded_board( 'm22').
embedded_board( 'm23').
embedded_board( 'm24').
embedded_board( 'm25').
embedded_board( 'm26').
embedded_board( 'm27').
embedded_board( 'm28').
embedded_board( 'm29').
embedded_board( 'm30').
embedded_board( 'm31').
embedded_board( 'm32').
embedded_board( 'm33').
embedded_board( 'm34').
embedded_board( 'm35').
embedded_board( 'm36').
embedded_board( 'm37').
embedded_board( 'm38').
embedded_board( 'm39').
embedded_board( 'm40').
embedded_board( 'm41').
embedded_board( 'm42').
embedded_board( 'm43').
embedded_board( 'm44').
embedded_board( 'm45').
embedded_board( 'm46').
embedded_board( 'm47').
embedded_board( 'm48').
embedded_board( 'm49').
embedded_board( 'm50').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
