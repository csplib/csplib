%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 20
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 639, [], [], 'fam1', 1 ).
test( 't2', 158, [], ['r4','r1','r5','r2','r3'], 'fam1', 1 ).
test( 't3', 89, [], ['r2','r3','r1','r5','r4'], 'fam1', 1 ).
test( 't4', 266, [], [], 'fam1', 1 ).
test( 't5', 5, [], ['r1','r5','r2','r4'], 'fam1', 1 ).
test( 't6', 202, [], [], 'fam1', 1 ).
test( 't7', 20, ['m7','m6','m1','m20','m9','m5','m14','m11'], [], 'fam1', 1 ).
test( 't8', 100, [], [], 'fam1', 1 ).
test( 't9', 749, ['m2'], [], 'fam1', 1 ).
test( 't10', 576, [], ['r4','r1','r5','r3'], 'fam1', 1 ).
test( 't11', 229, [], ['r1','r2'], 'fam1', 1 ).
test( 't12', 267, ['m6','m7','m9'], [], 'fam1', 1 ).
test( 't13', 271, [], ['r2','r4','r5','r1','r3'], 'fam1', 1 ).
test( 't14', 797, ['m10','m20','m18','m19','m8'], [], 'fam1', 1 ).
test( 't15', 615, [], ['r4','r5','r3','r1'], 'fam1', 1 ).
test( 't16', 229, [], ['r5','r4','r3','r2','r1'], 'fam1', 1 ).
test( 't17', 40, [], [], 'fam1', 1 ).
test( 't18', 20, [], ['r2','r1','r4','r5','r3'], 'fam1', 1 ).
test( 't19', 176, ['m20','m4','m10','m19','m2'], [], 'fam1', 1 ).
test( 't20', 55, [], [], 'fam1', 1 ).
test( 't21', 607, [], ['r5'], 'fam1', 1 ).
test( 't22', 17, [], ['r1','r4'], 'fam1', 1 ).
test( 't23', 721, [], [], 'fam1', 1 ).
test( 't24', 174, [], [], 'fam1', 1 ).
test( 't25', 647, [], ['r4','r2','r1'], 'fam1', 1 ).
test( 't26', 582, [], [], 'fam1', 1 ).
test( 't27', 734, [], [], 'fam1', 1 ).
test( 't28', 593, [], [], 'fam1', 1 ).
test( 't29', 71, [], [], 'fam1', 1 ).
test( 't30', 617, [], ['r3','r1','r2','r5'], 'fam1', 1 ).
test( 't31', 340, [], ['r2'], 'fam1', 1 ).
test( 't32', 256, ['m9','m10','m7','m1'], [], 'fam1', 1 ).
test( 't33', 199, ['m10','m16','m20'], ['r2'], 'fam1', 1 ).
test( 't34', 330, [], [], 'fam1', 1 ).
test( 't35', 672, [], [], 'fam1', 1 ).
test( 't36', 692, [], [], 'fam1', 1 ).
test( 't37', 483, [], [], 'fam1', 1 ).
test( 't38', 586, [], ['r1','r5','r2','r4','r3'], 'fam1', 1 ).
test( 't39', 262, [], [], 'fam1', 1 ).
test( 't40', 23, [], [], 'fam1', 1 ).
test( 't41', 439, [], [], 'fam1', 1 ).
test( 't42', 687, [], [], 'fam1', 1 ).
test( 't43', 300, [], [], 'fam1', 1 ).
test( 't44', 155, [], ['r3'], 'fam1', 1 ).
test( 't45', 578, [], [], 'fam1', 1 ).
test( 't46', 101, [], [], 'fam1', 1 ).
test( 't47', 4, [], [], 'fam1', 1 ).
test( 't48', 41, [], [], 'fam1', 1 ).
test( 't49', 735, [], [], 'fam1', 1 ).
test( 't50', 631, ['m8','m7','m14','m12','m2'], [], 'fam1', 1 ).
test( 't51', 649, [], ['r3','r4'], 'fam1', 1 ).
test( 't52', 74, [], ['r3','r4'], 'fam1', 1 ).
test( 't53', 40, ['m19','m8','m3'], [], 'fam1', 1 ).
test( 't54', 476, [], [], 'fam1', 1 ).
test( 't55', 561, [], [], 'fam1', 1 ).
test( 't56', 76, [], [], 'fam1', 1 ).
test( 't57', 717, [], [], 'fam1', 1 ).
test( 't58', 353, [], ['r5'], 'fam1', 1 ).
test( 't59', 700, [], [], 'fam1', 1 ).
test( 't60', 171, [], [], 'fam1', 1 ).
test( 't61', 666, [], [], 'fam1', 1 ).
test( 't62', 611, [], [], 'fam1', 1 ).
test( 't63', 421, [], [], 'fam1', 1 ).
test( 't64', 672, [], [], 'fam1', 1 ).
test( 't65', 414, [], ['r3','r2'], 'fam1', 1 ).
test( 't66', 6, [], [], 'fam1', 1 ).
test( 't67', 477, [], [], 'fam1', 1 ).
test( 't68', 645, [], [], 'fam1', 1 ).
test( 't69', 89, ['m16','m4','m5'], [], 'fam1', 1 ).
test( 't70', 770, ['m17','m13','m12'], [], 'fam1', 1 ).
test( 't71', 610, [], [], 'fam1', 1 ).
test( 't72', 16, [], [], 'fam1', 1 ).
test( 't73', 36, ['m16'], [], 'fam1', 1 ).
test( 't74', 143, [], [], 'fam1', 1 ).
test( 't75', 208, ['m8','m19','m18','m13','m4','m9','m11'], [], 'fam1', 1 ).
test( 't76', 102, [], [], 'fam1', 1 ).
test( 't77', 473, [], [], 'fam1', 1 ).
test( 't78', 582, ['m1'], [], 'fam1', 1 ).
test( 't79', 392, [], [], 'fam1', 1 ).
test( 't80', 783, [], [], 'fam1', 1 ).
test( 't81', 250, [], ['r3'], 'fam1', 1 ).
test( 't82', 458, [], ['r2'], 'fam1', 1 ).
test( 't83', 408, [], [], 'fam1', 1 ).
test( 't84', 697, [], ['r2','r4','r3','r1','r5'], 'fam1', 1 ).
test( 't85', 801, [], [], 'fam1', 1 ).
test( 't86', 237, [], [], 'fam1', 1 ).
test( 't87', 184, [], ['r3'], 'fam1', 1 ).
test( 't88', 171, [], ['r4','r1','r3'], 'fam1', 1 ).
test( 't89', 784, [], ['r4','r3','r5'], 'fam1', 1 ).
test( 't90', 580, ['m19','m16','m18','m4','m20','m3','m10','m2'], [], 'fam1', 1 ).
test( 't91', 565, [], [], 'fam1', 1 ).
test( 't92', 219, [], [], 'fam1', 1 ).
test( 't93', 688, ['m5','m4','m12','m2'], ['r1','r2','r3','r4','r5'], 'fam1', 1 ).
test( 't94', 565, ['m20','m18','m13','m7'], [], 'fam1', 1 ).
test( 't95', 535, [], [], 'fam1', 1 ).
test( 't96', 606, [], [], 'fam1', 1 ).
test( 't97', 380, [], ['r3'], 'fam1', 1 ).
test( 't98', 358, [], [], 'fam1', 1 ).
test( 't99', 623, [], ['r2','r3','r4','r1'], 'fam1', 1 ).
test( 't100', 650, [], ['r4','r3'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
