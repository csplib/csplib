%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 10
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 2, [], ['r2','r7','r4','r6','r1','r9'], 'fam1', 1 ).
test( 't2', 239, [], [], 'fam1', 1 ).
test( 't3', 610, [], [], 'fam1', 1 ).
test( 't4', 738, [], [], 'fam1', 1 ).
test( 't5', 119, [], [], 'fam1', 1 ).
test( 't6', 557, [], ['r5','r9','r4','r10','r1','r2','r7'], 'fam1', 1 ).
test( 't7', 608, ['m1','m9','m5','m8'], [], 'fam1', 1 ).
test( 't8', 789, ['m6','m5'], ['r1','r2','r8','r10','r3','r5','r6'], 'fam1', 1 ).
test( 't9', 112, [], ['r8','r5','r2','r9','r6','r10','r1','r7'], 'fam1', 1 ).
test( 't10', 57, [], [], 'fam1', 1 ).
test( 't11', 293, [], ['r4','r6','r3','r1','r9','r5','r2'], 'fam1', 1 ).
test( 't12', 686, [], ['r2','r7','r10','r4','r9'], 'fam1', 1 ).
test( 't13', 323, [], [], 'fam1', 1 ).
test( 't14', 208, [], [], 'fam1', 1 ).
test( 't15', 441, [], [], 'fam1', 1 ).
test( 't16', 766, [], [], 'fam1', 1 ).
test( 't17', 97, [], ['r5','r8'], 'fam1', 1 ).
test( 't18', 303, [], ['r10','r6'], 'fam1', 1 ).
test( 't19', 444, [], [], 'fam1', 1 ).
test( 't20', 591, [], [], 'fam1', 1 ).
test( 't21', 742, [], ['r1','r10','r8','r5'], 'fam1', 1 ).
test( 't22', 668, [], [], 'fam1', 1 ).
test( 't23', 471, [], [], 'fam1', 1 ).
test( 't24', 170, [], [], 'fam1', 1 ).
test( 't25', 133, ['m8','m3','m6','m7'], ['r6','r4','r10','r8','r5','r2','r7','r9','r1','r3'], 'fam1', 1 ).
test( 't26', 269, [], ['r2','r5','r1','r10','r7','r4','r6','r9','r3'], 'fam1', 1 ).
test( 't27', 721, [], [], 'fam1', 1 ).
test( 't28', 5, [], ['r10','r9','r2','r6','r4'], 'fam1', 1 ).
test( 't29', 791, [], [], 'fam1', 1 ).
test( 't30', 488, [], [], 'fam1', 1 ).
test( 't31', 194, [], [], 'fam1', 1 ).
test( 't32', 605, [], [], 'fam1', 1 ).
test( 't33', 198, ['m3'], [], 'fam1', 1 ).
test( 't34', 151, ['m3'], ['r2','r5','r1','r3','r10'], 'fam1', 1 ).
test( 't35', 483, [], [], 'fam1', 1 ).
test( 't36', 686, [], [], 'fam1', 1 ).
test( 't37', 39, [], ['r2','r4','r1','r9','r5','r10','r7','r8','r6'], 'fam1', 1 ).
test( 't38', 175, [], ['r10','r8','r9','r1','r6','r5'], 'fam1', 1 ).
test( 't39', 535, [], ['r4','r8','r1','r9','r5','r6','r3','r7','r10'], 'fam1', 1 ).
test( 't40', 538, [], [], 'fam1', 1 ).
test( 't41', 713, [], ['r4','r5','r9','r1','r3','r8','r7','r10','r2','r6'], 'fam1', 1 ).
test( 't42', 731, [], [], 'fam1', 1 ).
test( 't43', 49, ['m4','m8','m10','m1'], [], 'fam1', 1 ).
test( 't44', 463, [], [], 'fam1', 1 ).
test( 't45', 428, [], [], 'fam1', 1 ).
test( 't46', 352, [], [], 'fam1', 1 ).
test( 't47', 131, [], [], 'fam1', 1 ).
test( 't48', 100, [], [], 'fam1', 1 ).
test( 't49', 658, [], [], 'fam1', 1 ).
test( 't50', 248, [], ['r6','r4','r10','r8','r7','r9','r3','r1','r2'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
