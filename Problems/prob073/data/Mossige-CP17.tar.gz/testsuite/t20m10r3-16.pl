%% ****  Testsuite  ****
% Number of tests                  : 20
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 598, [], [], 'fam1', 1 ).
test( 't2', 95, [], ['r2'], 'fam1', 1 ).
test( 't3', 6, [], [], 'fam1', 1 ).
test( 't4', 203, [], [], 'fam1', 1 ).
test( 't5', 367, [], [], 'fam1', 1 ).
test( 't6', 660, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't7', 205, ['m10','m1','m2','m9'], [], 'fam1', 1 ).
test( 't8', 325, [], [], 'fam1', 1 ).
test( 't9', 394, ['m4','m2'], [], 'fam1', 1 ).
test( 't10', 486, ['m10'], [], 'fam1', 1 ).
test( 't11', 148, [], [], 'fam1', 1 ).
test( 't12', 612, [], ['r3'], 'fam1', 1 ).
test( 't13', 265, [], [], 'fam1', 1 ).
test( 't14', 378, [], ['r2','r1'], 'fam1', 1 ).
test( 't15', 431, [], ['r2','r1'], 'fam1', 1 ).
test( 't16', 569, [], [], 'fam1', 1 ).
test( 't17', 424, [], [], 'fam1', 1 ).
test( 't18', 303, [], [], 'fam1', 1 ).
test( 't19', 416, [], [], 'fam1', 1 ).
test( 't20', 153, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
