%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 592, [], ['r5','r4','r3'], 'fam1', 1 ).
test( 't2', 535, ['m10','m4','m7'], [], 'fam1', 1 ).
test( 't3', 328, ['m1','m7','m4','m5'], [], 'fam1', 1 ).
test( 't4', 179, [], [], 'fam1', 1 ).
test( 't5', 526, [], [], 'fam1', 1 ).
test( 't6', 657, [], [], 'fam1', 1 ).
test( 't7', 682, [], ['r4','r5','r2','r3','r1'], 'fam1', 1 ).
test( 't8', 459, [], [], 'fam1', 1 ).
test( 't9', 82, [], ['r1'], 'fam1', 1 ).
test( 't10', 157, [], [], 'fam1', 1 ).
test( 't11', 168, ['m9'], ['r2','r4','r1','r5'], 'fam1', 1 ).
test( 't12', 343, [], [], 'fam1', 1 ).
test( 't13', 178, [], ['r3'], 'fam1', 1 ).
test( 't14', 567, [], [], 'fam1', 1 ).
test( 't15', 465, [], [], 'fam1', 1 ).
test( 't16', 258, [], ['r5','r3','r1','r2'], 'fam1', 1 ).
test( 't17', 434, ['m4','m8'], ['r1','r4','r2'], 'fam1', 1 ).
test( 't18', 456, [], [], 'fam1', 1 ).
test( 't19', 136, ['m1','m3','m4'], [], 'fam1', 1 ).
test( 't20', 782, [], [], 'fam1', 1 ).
test( 't21', 708, ['m10','m5','m8','m2'], [], 'fam1', 1 ).
test( 't22', 158, ['m8','m7','m4'], [], 'fam1', 1 ).
test( 't23', 449, ['m2','m5','m9','m3'], [], 'fam1', 1 ).
test( 't24', 481, [], [], 'fam1', 1 ).
test( 't25', 207, [], [], 'fam1', 1 ).
test( 't26', 272, [], [], 'fam1', 1 ).
test( 't27', 526, ['m8','m9','m5'], [], 'fam1', 1 ).
test( 't28', 117, ['m1'], [], 'fam1', 1 ).
test( 't29', 532, [], ['r3'], 'fam1', 1 ).
test( 't30', 598, [], [], 'fam1', 1 ).
test( 't31', 1, [], [], 'fam1', 1 ).
test( 't32', 244, [], [], 'fam1', 1 ).
test( 't33', 387, [], [], 'fam1', 1 ).
test( 't34', 86, [], [], 'fam1', 1 ).
test( 't35', 65, [], ['r4','r3'], 'fam1', 1 ).
test( 't36', 361, [], ['r4'], 'fam1', 1 ).
test( 't37', 230, [], [], 'fam1', 1 ).
test( 't38', 260, [], [], 'fam1', 1 ).
test( 't39', 369, [], [], 'fam1', 1 ).
test( 't40', 130, [], [], 'fam1', 1 ).
test( 't41', 616, [], [], 'fam1', 1 ).
test( 't42', 201, [], ['r1','r5','r4'], 'fam1', 1 ).
test( 't43', 667, [], [], 'fam1', 1 ).
test( 't44', 253, [], ['r1'], 'fam1', 1 ).
test( 't45', 13, [], [], 'fam1', 1 ).
test( 't46', 212, ['m9','m5'], [], 'fam1', 1 ).
test( 't47', 444, [], [], 'fam1', 1 ).
test( 't48', 684, [], [], 'fam1', 1 ).
test( 't49', 656, [], [], 'fam1', 1 ).
test( 't50', 491, ['m8','m2'], [], 'fam1', 1 ).
test( 't51', 4, [], [], 'fam1', 1 ).
test( 't52', 271, [], ['r4','r2','r5','r1'], 'fam1', 1 ).
test( 't53', 348, [], [], 'fam1', 1 ).
test( 't54', 502, [], ['r4','r5','r1'], 'fam1', 1 ).
test( 't55', 224, [], [], 'fam1', 1 ).
test( 't56', 713, ['m1','m2','m3','m6'], [], 'fam1', 1 ).
test( 't57', 752, ['m10','m9'], [], 'fam1', 1 ).
test( 't58', 472, [], ['r5'], 'fam1', 1 ).
test( 't59', 790, [], [], 'fam1', 1 ).
test( 't60', 605, [], ['r2','r3','r4'], 'fam1', 1 ).
test( 't61', 225, ['m10','m7'], [], 'fam1', 1 ).
test( 't62', 545, [], ['r3','r1','r5','r4'], 'fam1', 1 ).
test( 't63', 702, [], [], 'fam1', 1 ).
test( 't64', 404, [], [], 'fam1', 1 ).
test( 't65', 211, [], [], 'fam1', 1 ).
test( 't66', 158, ['m10','m7','m1'], [], 'fam1', 1 ).
test( 't67', 572, [], [], 'fam1', 1 ).
test( 't68', 145, [], [], 'fam1', 1 ).
test( 't69', 533, [], [], 'fam1', 1 ).
test( 't70', 497, [], [], 'fam1', 1 ).
test( 't71', 343, [], [], 'fam1', 1 ).
test( 't72', 125, [], [], 'fam1', 1 ).
test( 't73', 164, [], ['r1','r3','r5'], 'fam1', 1 ).
test( 't74', 156, [], [], 'fam1', 1 ).
test( 't75', 166, ['m8','m3','m6','m10'], [], 'fam1', 1 ).
test( 't76', 76, [], [], 'fam1', 1 ).
test( 't77', 94, ['m7','m4'], [], 'fam1', 1 ).
test( 't78', 274, [], [], 'fam1', 1 ).
test( 't79', 138, ['m2','m10'], [], 'fam1', 1 ).
test( 't80', 350, [], ['r3'], 'fam1', 1 ).
test( 't81', 184, [], [], 'fam1', 1 ).
test( 't82', 784, ['m6','m7','m9','m1'], [], 'fam1', 1 ).
test( 't83', 348, [], [], 'fam1', 1 ).
test( 't84', 633, [], [], 'fam1', 1 ).
test( 't85', 772, [], ['r3'], 'fam1', 1 ).
test( 't86', 180, [], [], 'fam1', 1 ).
test( 't87', 573, [], [], 'fam1', 1 ).
test( 't88', 112, [], [], 'fam1', 1 ).
test( 't89', 695, [], ['r5'], 'fam1', 1 ).
test( 't90', 651, [], [], 'fam1', 1 ).
test( 't91', 361, ['m10','m8','m3'], ['r2','r5','r4'], 'fam1', 1 ).
test( 't92', 433, [], [], 'fam1', 1 ).
test( 't93', 335, [], [], 'fam1', 1 ).
test( 't94', 609, [], [], 'fam1', 1 ).
test( 't95', 705, [], ['r1','r3','r5'], 'fam1', 1 ).
test( 't96', 92, [], [], 'fam1', 1 ).
test( 't97', 136, [], [], 'fam1', 1 ).
test( 't98', 446, [], ['r5','r3'], 'fam1', 1 ).
test( 't99', 619, [], ['r2','r3','r4'], 'fam1', 1 ).
test( 't100', 459, [], ['r5','r4','r3','r1','r2'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
