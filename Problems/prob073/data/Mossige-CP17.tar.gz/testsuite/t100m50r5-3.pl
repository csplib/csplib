%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 50
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 644, [], [], 'fam1', 1 ).
test( 't2', 642, [], ['r5','r4'], 'fam1', 1 ).
test( 't3', 324, [], [], 'fam1', 1 ).
test( 't4', 782, [], ['r4','r3','r2','r5','r1'], 'fam1', 1 ).
test( 't5', 764, [], [], 'fam1', 1 ).
test( 't6', 230, [], [], 'fam1', 1 ).
test( 't7', 50, [], ['r5','r3','r1'], 'fam1', 1 ).
test( 't8', 707, [], [], 'fam1', 1 ).
test( 't9', 62, ['m16','m47','m10','m35','m15','m28','m18','m30','m34','m27','m39','m38','m46','m7'], [], 'fam1', 1 ).
test( 't10', 539, [], ['r2','r1','r3','r4','r5'], 'fam1', 1 ).
test( 't11', 299, ['m7','m42','m27','m22','m40','m8','m12','m3','m31','m43'], [], 'fam1', 1 ).
test( 't12', 346, ['m10','m2','m28','m17','m6','m3','m11','m5','m41','m1','m34','m26','m20','m22','m49','m30'], [], 'fam1', 1 ).
test( 't13', 292, [], [], 'fam1', 1 ).
test( 't14', 732, [], ['r3','r4','r1','r5','r2'], 'fam1', 1 ).
test( 't15', 349, [], ['r3','r5','r1'], 'fam1', 1 ).
test( 't16', 243, [], [], 'fam1', 1 ).
test( 't17', 476, [], ['r2'], 'fam1', 1 ).
test( 't18', 759, ['m33','m38','m18','m43','m19','m15','m8','m2','m20','m41','m6','m14','m4','m48'], [], 'fam1', 1 ).
test( 't19', 429, [], [], 'fam1', 1 ).
test( 't20', 31, [], [], 'fam1', 1 ).
test( 't21', 372, ['m41','m21'], [], 'fam1', 1 ).
test( 't22', 697, ['m8'], ['r2','r1'], 'fam1', 1 ).
test( 't23', 400, ['m12','m35','m3','m8','m20','m46'], ['r5'], 'fam1', 1 ).
test( 't24', 306, [], ['r3','r1','r2','r5','r4'], 'fam1', 1 ).
test( 't25', 588, [], [], 'fam1', 1 ).
test( 't26', 311, [], ['r5'], 'fam1', 1 ).
test( 't27', 229, [], [], 'fam1', 1 ).
test( 't28', 733, [], [], 'fam1', 1 ).
test( 't29', 22, [], [], 'fam1', 1 ).
test( 't30', 733, [], ['r3','r2'], 'fam1', 1 ).
test( 't31', 141, [], [], 'fam1', 1 ).
test( 't32', 237, [], [], 'fam1', 1 ).
test( 't33', 563, [], [], 'fam1', 1 ).
test( 't34', 558, [], [], 'fam1', 1 ).
test( 't35', 122, [], [], 'fam1', 1 ).
test( 't36', 780, [], [], 'fam1', 1 ).
test( 't37', 461, [], [], 'fam1', 1 ).
test( 't38', 788, [], [], 'fam1', 1 ).
test( 't39', 597, [], [], 'fam1', 1 ).
test( 't40', 772, [], ['r1','r2'], 'fam1', 1 ).
test( 't41', 728, ['m20','m24','m21','m19','m25','m28','m50','m40','m38','m18','m6','m17','m33'], [], 'fam1', 1 ).
test( 't42', 60, [], [], 'fam1', 1 ).
test( 't43', 17, [], [], 'fam1', 1 ).
test( 't44', 260, [], ['r4','r5','r3','r2'], 'fam1', 1 ).
test( 't45', 552, [], [], 'fam1', 1 ).
test( 't46', 37, ['m36','m8','m14','m28','m24'], ['r4','r1','r3'], 'fam1', 1 ).
test( 't47', 732, [], [], 'fam1', 1 ).
test( 't48', 265, [], [], 'fam1', 1 ).
test( 't49', 16, [], [], 'fam1', 1 ).
test( 't50', 279, [], ['r5','r3','r1','r4'], 'fam1', 1 ).
test( 't51', 331, ['m36','m13','m16','m43','m7','m31','m41','m49','m18','m12'], [], 'fam1', 1 ).
test( 't52', 170, [], [], 'fam1', 1 ).
test( 't53', 61, [], [], 'fam1', 1 ).
test( 't54', 40, [], ['r2','r4','r3','r5','r1'], 'fam1', 1 ).
test( 't55', 346, [], [], 'fam1', 1 ).
test( 't56', 10, [], [], 'fam1', 1 ).
test( 't57', 450, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't58', 747, [], [], 'fam1', 1 ).
test( 't59', 221, ['m20','m17','m7','m12','m19','m13','m36','m3','m15','m46','m45','m9','m25','m44','m43','m50','m27','m41','m10','m22'], ['r1','r3'], 'fam1', 1 ).
test( 't60', 208, [], [], 'fam1', 1 ).
test( 't61', 196, [], [], 'fam1', 1 ).
test( 't62', 245, [], [], 'fam1', 1 ).
test( 't63', 525, [], [], 'fam1', 1 ).
test( 't64', 800, [], [], 'fam1', 1 ).
test( 't65', 685, [], ['r4','r3'], 'fam1', 1 ).
test( 't66', 380, [], [], 'fam1', 1 ).
test( 't67', 90, ['m32','m46','m38','m2','m33'], ['r1'], 'fam1', 1 ).
test( 't68', 306, [], [], 'fam1', 1 ).
test( 't69', 661, ['m19','m4','m50','m10','m38','m7','m15','m33','m35','m21','m42'], [], 'fam1', 1 ).
test( 't70', 572, [], [], 'fam1', 1 ).
test( 't71', 293, [], [], 'fam1', 1 ).
test( 't72', 553, [], ['r4','r3'], 'fam1', 1 ).
test( 't73', 547, [], [], 'fam1', 1 ).
test( 't74', 764, ['m32','m31','m25','m36','m48','m14','m37','m1','m24','m45','m17','m28','m44','m41','m33','m29','m49','m34','m16','m38'], ['r1'], 'fam1', 1 ).
test( 't75', 795, [], [], 'fam1', 1 ).
test( 't76', 284, [], [], 'fam1', 1 ).
test( 't77', 524, [], [], 'fam1', 1 ).
test( 't78', 518, [], [], 'fam1', 1 ).
test( 't79', 684, [], [], 'fam1', 1 ).
test( 't80', 423, [], [], 'fam1', 1 ).
test( 't81', 144, [], ['r3','r4','r5'], 'fam1', 1 ).
test( 't82', 786, [], ['r3','r5','r1','r2','r4'], 'fam1', 1 ).
test( 't83', 552, [], [], 'fam1', 1 ).
test( 't84', 399, ['m14','m16','m34','m31'], [], 'fam1', 1 ).
test( 't85', 701, [], ['r2'], 'fam1', 1 ).
test( 't86', 28, [], [], 'fam1', 1 ).
test( 't87', 255, [], ['r4','r2','r5','r3','r1'], 'fam1', 1 ).
test( 't88', 66, [], ['r4','r3','r1'], 'fam1', 1 ).
test( 't89', 506, [], ['r5'], 'fam1', 1 ).
test( 't90', 192, [], [], 'fam1', 1 ).
test( 't91', 433, ['m21'], [], 'fam1', 1 ).
test( 't92', 590, [], ['r1','r3','r5'], 'fam1', 1 ).
test( 't93', 314, [], [], 'fam1', 1 ).
test( 't94', 19, [], [], 'fam1', 1 ).
test( 't95', 152, [], [], 'fam1', 1 ).
test( 't96', 271, [], [], 'fam1', 1 ).
test( 't97', 367, [], [], 'fam1', 1 ).
test( 't98', 292, [], [], 'fam1', 1 ).
test( 't99', 395, [], [], 'fam1', 1 ).
test( 't100', 56, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').
embedded_board( 'm21').
embedded_board( 'm22').
embedded_board( 'm23').
embedded_board( 'm24').
embedded_board( 'm25').
embedded_board( 'm26').
embedded_board( 'm27').
embedded_board( 'm28').
embedded_board( 'm29').
embedded_board( 'm30').
embedded_board( 'm31').
embedded_board( 'm32').
embedded_board( 'm33').
embedded_board( 'm34').
embedded_board( 'm35').
embedded_board( 'm36').
embedded_board( 'm37').
embedded_board( 'm38').
embedded_board( 'm39').
embedded_board( 'm40').
embedded_board( 'm41').
embedded_board( 'm42').
embedded_board( 'm43').
embedded_board( 'm44').
embedded_board( 'm45').
embedded_board( 'm46').
embedded_board( 'm47').
embedded_board( 'm48').
embedded_board( 'm49').
embedded_board( 'm50').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
