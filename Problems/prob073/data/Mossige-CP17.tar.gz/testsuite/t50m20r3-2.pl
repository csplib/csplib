%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 20
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 418, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't2', 386, [], [], 'fam1', 1 ).
test( 't3', 307, [], [], 'fam1', 1 ).
test( 't4', 306, ['m11','m17','m7'], [], 'fam1', 1 ).
test( 't5', 569, [], ['r2'], 'fam1', 1 ).
test( 't6', 520, [], ['r2','r1'], 'fam1', 1 ).
test( 't7', 97, ['m16','m13'], ['r3','r1','r2'], 'fam1', 1 ).
test( 't8', 89, [], [], 'fam1', 1 ).
test( 't9', 668, [], [], 'fam1', 1 ).
test( 't10', 265, [], [], 'fam1', 1 ).
test( 't11', 459, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't12', 674, [], [], 'fam1', 1 ).
test( 't13', 462, [], ['r2'], 'fam1', 1 ).
test( 't14', 531, [], [], 'fam1', 1 ).
test( 't15', 601, ['m16','m3','m19','m17','m15'], [], 'fam1', 1 ).
test( 't16', 555, [], [], 'fam1', 1 ).
test( 't17', 93, ['m16'], ['r2'], 'fam1', 1 ).
test( 't18', 443, [], [], 'fam1', 1 ).
test( 't19', 155, [], [], 'fam1', 1 ).
test( 't20', 196, [], ['r2'], 'fam1', 1 ).
test( 't21', 692, ['m16','m19','m12','m10'], [], 'fam1', 1 ).
test( 't22', 510, [], [], 'fam1', 1 ).
test( 't23', 583, ['m8','m20','m15'], [], 'fam1', 1 ).
test( 't24', 411, [], [], 'fam1', 1 ).
test( 't25', 660, [], [], 'fam1', 1 ).
test( 't26', 254, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't27', 204, [], [], 'fam1', 1 ).
test( 't28', 105, ['m2','m9','m20'], ['r3'], 'fam1', 1 ).
test( 't29', 198, ['m8','m1','m9'], [], 'fam1', 1 ).
test( 't30', 751, [], ['r3','r1'], 'fam1', 1 ).
test( 't31', 599, [], ['r3'], 'fam1', 1 ).
test( 't32', 497, ['m11','m15','m2','m8','m6','m5','m9','m4'], [], 'fam1', 1 ).
test( 't33', 462, ['m17','m14','m5'], ['r2'], 'fam1', 1 ).
test( 't34', 426, [], [], 'fam1', 1 ).
test( 't35', 126, [], [], 'fam1', 1 ).
test( 't36', 482, [], [], 'fam1', 1 ).
test( 't37', 241, [], [], 'fam1', 1 ).
test( 't38', 375, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't39', 70, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't40', 59, [], [], 'fam1', 1 ).
test( 't41', 366, [], [], 'fam1', 1 ).
test( 't42', 679, [], [], 'fam1', 1 ).
test( 't43', 658, [], [], 'fam1', 1 ).
test( 't44', 275, [], ['r1'], 'fam1', 1 ).
test( 't45', 790, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't46', 76, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't47', 282, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't48', 779, [], [], 'fam1', 1 ).
test( 't49', 447, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't50', 507, ['m13','m5','m3','m1','m4','m10'], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
