%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 506, ['m6','m7','m2'], ['r3'], 'fam1', 1 ).
test( 't2', 128, [], [], 'fam1', 1 ).
test( 't3', 603, [], [], 'fam1', 1 ).
test( 't4', 639, [], ['r1','r5','r3','r4'], 'fam1', 1 ).
test( 't5', 700, [], [], 'fam1', 1 ).
test( 't6', 599, [], [], 'fam1', 1 ).
test( 't7', 301, [], [], 'fam1', 1 ).
test( 't8', 663, [], [], 'fam1', 1 ).
test( 't9', 472, [], [], 'fam1', 1 ).
test( 't10', 159, ['m2','m1'], [], 'fam1', 1 ).
test( 't11', 23, ['m4','m8'], ['r5','r2'], 'fam1', 1 ).
test( 't12', 394, [], [], 'fam1', 1 ).
test( 't13', 284, [], ['r2','r3'], 'fam1', 1 ).
test( 't14', 328, ['m1','m8','m3'], [], 'fam1', 1 ).
test( 't15', 712, [], [], 'fam1', 1 ).
test( 't16', 565, [], ['r3','r5','r4'], 'fam1', 1 ).
test( 't17', 636, [], [], 'fam1', 1 ).
test( 't18', 795, [], ['r4','r3','r2','r1','r5'], 'fam1', 1 ).
test( 't19', 443, [], [], 'fam1', 1 ).
test( 't20', 317, [], [], 'fam1', 1 ).
test( 't21', 576, [], [], 'fam1', 1 ).
test( 't22', 483, [], [], 'fam1', 1 ).
test( 't23', 616, [], ['r3','r4'], 'fam1', 1 ).
test( 't24', 548, [], [], 'fam1', 1 ).
test( 't25', 624, [], [], 'fam1', 1 ).
test( 't26', 69, ['m10','m4','m7'], [], 'fam1', 1 ).
test( 't27', 79, ['m1','m5'], [], 'fam1', 1 ).
test( 't28', 31, [], [], 'fam1', 1 ).
test( 't29', 80, [], [], 'fam1', 1 ).
test( 't30', 596, ['m7','m2','m1'], ['r4','r1','r5'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
