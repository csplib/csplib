%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 20
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 37, [], [], 'fam1', 1 ).
test( 't2', 589, [], [], 'fam1', 1 ).
test( 't3', 748, [], [], 'fam1', 1 ).
test( 't4', 172, [], [], 'fam1', 1 ).
test( 't5', 9, [], [], 'fam1', 1 ).
test( 't6', 578, [], [], 'fam1', 1 ).
test( 't7', 407, [], ['r2','r1'], 'fam1', 1 ).
test( 't8', 389, [], [], 'fam1', 1 ).
test( 't9', 14, [], [], 'fam1', 1 ).
test( 't10', 782, [], ['r4','r5'], 'fam1', 1 ).
test( 't11', 610, [], [], 'fam1', 1 ).
test( 't12', 536, [], ['r5','r1','r4','r3'], 'fam1', 1 ).
test( 't13', 229, ['m8','m16','m1'], ['r5','r1','r2'], 'fam1', 1 ).
test( 't14', 611, [], ['r5'], 'fam1', 1 ).
test( 't15', 665, [], [], 'fam1', 1 ).
test( 't16', 618, [], ['r2','r5','r1','r3'], 'fam1', 1 ).
test( 't17', 27, [], ['r1','r2'], 'fam1', 1 ).
test( 't18', 737, [], [], 'fam1', 1 ).
test( 't19', 304, ['m2','m17','m9','m6'], [], 'fam1', 1 ).
test( 't20', 634, [], [], 'fam1', 1 ).
test( 't21', 685, ['m16','m20','m12','m4','m5'], [], 'fam1', 1 ).
test( 't22', 179, [], [], 'fam1', 1 ).
test( 't23', 661, ['m2','m1','m9','m14'], [], 'fam1', 1 ).
test( 't24', 230, [], [], 'fam1', 1 ).
test( 't25', 262, [], [], 'fam1', 1 ).
test( 't26', 365, [], [], 'fam1', 1 ).
test( 't27', 517, ['m9','m6','m17'], [], 'fam1', 1 ).
test( 't28', 348, [], [], 'fam1', 1 ).
test( 't29', 62, [], ['r2','r5'], 'fam1', 1 ).
test( 't30', 452, [], [], 'fam1', 1 ).
test( 't31', 753, [], [], 'fam1', 1 ).
test( 't32', 724, [], [], 'fam1', 1 ).
test( 't33', 278, [], ['r2','r4','r5','r3'], 'fam1', 1 ).
test( 't34', 469, [], [], 'fam1', 1 ).
test( 't35', 748, [], [], 'fam1', 1 ).
test( 't36', 524, [], [], 'fam1', 1 ).
test( 't37', 586, ['m12'], ['r3','r4'], 'fam1', 1 ).
test( 't38', 535, [], [], 'fam1', 1 ).
test( 't39', 356, [], ['r3','r5'], 'fam1', 1 ).
test( 't40', 716, [], [], 'fam1', 1 ).
test( 't41', 700, [], [], 'fam1', 1 ).
test( 't42', 158, [], ['r4'], 'fam1', 1 ).
test( 't43', 665, ['m1','m16'], ['r2'], 'fam1', 1 ).
test( 't44', 621, [], [], 'fam1', 1 ).
test( 't45', 620, ['m5','m20','m17','m18','m1','m3','m6','m14'], ['r1'], 'fam1', 1 ).
test( 't46', 703, [], [], 'fam1', 1 ).
test( 't47', 757, [], [], 'fam1', 1 ).
test( 't48', 656, [], ['r2'], 'fam1', 1 ).
test( 't49', 582, ['m18','m12','m15'], [], 'fam1', 1 ).
test( 't50', 434, [], ['r1'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
