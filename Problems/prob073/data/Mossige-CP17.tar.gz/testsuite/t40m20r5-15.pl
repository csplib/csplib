%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 20
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 183, ['m6'], [], 'fam1', 1 ).
test( 't2', 402, ['m2','m19'], ['r1','r3'], 'fam1', 1 ).
test( 't3', 47, [], ['r1','r5','r4'], 'fam1', 1 ).
test( 't4', 528, [], [], 'fam1', 1 ).
test( 't5', 80, [], [], 'fam1', 1 ).
test( 't6', 632, [], [], 'fam1', 1 ).
test( 't7', 68, [], [], 'fam1', 1 ).
test( 't8', 10, [], ['r3','r5'], 'fam1', 1 ).
test( 't9', 401, ['m16','m5'], [], 'fam1', 1 ).
test( 't10', 163, [], ['r3'], 'fam1', 1 ).
test( 't11', 456, [], [], 'fam1', 1 ).
test( 't12', 235, [], ['r4','r5'], 'fam1', 1 ).
test( 't13', 179, [], ['r5'], 'fam1', 1 ).
test( 't14', 37, ['m17','m7','m6','m3','m12','m11','m4'], [], 'fam1', 1 ).
test( 't15', 116, [], [], 'fam1', 1 ).
test( 't16', 303, [], ['r1','r4','r2'], 'fam1', 1 ).
test( 't17', 760, [], [], 'fam1', 1 ).
test( 't18', 245, [], [], 'fam1', 1 ).
test( 't19', 8, [], ['r1'], 'fam1', 1 ).
test( 't20', 400, [], ['r5','r4','r3','r2'], 'fam1', 1 ).
test( 't21', 626, [], [], 'fam1', 1 ).
test( 't22', 164, [], [], 'fam1', 1 ).
test( 't23', 793, [], ['r3','r5','r1','r4','r2'], 'fam1', 1 ).
test( 't24', 282, [], [], 'fam1', 1 ).
test( 't25', 573, [], [], 'fam1', 1 ).
test( 't26', 2, [], ['r5'], 'fam1', 1 ).
test( 't27', 338, ['m19','m9','m17','m7','m4','m12'], [], 'fam1', 1 ).
test( 't28', 741, ['m2','m4','m13','m11','m19','m20'], [], 'fam1', 1 ).
test( 't29', 622, [], ['r3','r2','r4','r5'], 'fam1', 1 ).
test( 't30', 686, [], ['r4','r5','r1'], 'fam1', 1 ).
test( 't31', 235, [], ['r3','r5','r1','r2','r4'], 'fam1', 1 ).
test( 't32', 381, [], ['r5','r3','r1'], 'fam1', 1 ).
test( 't33', 711, ['m20','m6','m5','m12','m19'], [], 'fam1', 1 ).
test( 't34', 348, [], [], 'fam1', 1 ).
test( 't35', 731, [], [], 'fam1', 1 ).
test( 't36', 304, ['m20','m3','m10','m2','m11','m15'], [], 'fam1', 1 ).
test( 't37', 684, [], [], 'fam1', 1 ).
test( 't38', 169, [], [], 'fam1', 1 ).
test( 't39', 648, [], [], 'fam1', 1 ).
test( 't40', 180, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
