%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 20
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 556, [], ['r8','r5','r3','r4','r2','r9'], 'fam1', 1 ).
test( 't2', 642, [], [], 'fam1', 1 ).
test( 't3', 560, [], ['r10','r2','r9','r8','r3','r7'], 'fam1', 1 ).
test( 't4', 17, ['m13','m20'], [], 'fam1', 1 ).
test( 't5', 60, [], ['r6','r4','r3','r9','r10'], 'fam1', 1 ).
test( 't6', 736, [], ['r9','r7','r1'], 'fam1', 1 ).
test( 't7', 285, [], [], 'fam1', 1 ).
test( 't8', 113, ['m14','m17','m3','m10'], ['r3'], 'fam1', 1 ).
test( 't9', 278, [], [], 'fam1', 1 ).
test( 't10', 380, [], ['r7','r1','r10','r3','r2','r8','r5','r6','r9','r4'], 'fam1', 1 ).
test( 't11', 375, [], ['r1','r8','r10'], 'fam1', 1 ).
test( 't12', 119, [], [], 'fam1', 1 ).
test( 't13', 511, ['m10','m9'], ['r9','r4','r1','r3','r8','r10','r7'], 'fam1', 1 ).
test( 't14', 396, ['m15','m7'], [], 'fam1', 1 ).
test( 't15', 542, [], [], 'fam1', 1 ).
test( 't16', 368, [], [], 'fam1', 1 ).
test( 't17', 464, ['m6'], [], 'fam1', 1 ).
test( 't18', 767, [], [], 'fam1', 1 ).
test( 't19', 365, [], [], 'fam1', 1 ).
test( 't20', 570, [], [], 'fam1', 1 ).
test( 't21', 251, [], [], 'fam1', 1 ).
test( 't22', 414, [], ['r8','r10','r7','r9','r3'], 'fam1', 1 ).
test( 't23', 329, [], ['r1'], 'fam1', 1 ).
test( 't24', 67, [], [], 'fam1', 1 ).
test( 't25', 48, [], [], 'fam1', 1 ).
test( 't26', 526, [], [], 'fam1', 1 ).
test( 't27', 160, [], [], 'fam1', 1 ).
test( 't28', 21, [], [], 'fam1', 1 ).
test( 't29', 448, [], ['r6','r4','r10','r5','r7'], 'fam1', 1 ).
test( 't30', 163, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
