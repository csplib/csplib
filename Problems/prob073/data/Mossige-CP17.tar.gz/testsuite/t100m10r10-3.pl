%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 10
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 195, ['m2','m6','m10','m1'], ['r10','r6','r3'], 'fam1', 1 ).
test( 't2', 783, [], [], 'fam1', 1 ).
test( 't3', 19, [], [], 'fam1', 1 ).
test( 't4', 732, [], ['r3','r6','r10','r7','r8','r1'], 'fam1', 1 ).
test( 't5', 365, [], [], 'fam1', 1 ).
test( 't6', 64, [], [], 'fam1', 1 ).
test( 't7', 71, [], [], 'fam1', 1 ).
test( 't8', 423, ['m4','m8'], [], 'fam1', 1 ).
test( 't9', 769, [], ['r9','r4','r8','r2','r3','r1','r10','r6','r5','r7'], 'fam1', 1 ).
test( 't10', 513, [], ['r10','r2','r3','r1'], 'fam1', 1 ).
test( 't11', 766, [], [], 'fam1', 1 ).
test( 't12', 352, [], [], 'fam1', 1 ).
test( 't13', 29, ['m2','m7','m10','m9'], [], 'fam1', 1 ).
test( 't14', 17, ['m1'], [], 'fam1', 1 ).
test( 't15', 393, [], [], 'fam1', 1 ).
test( 't16', 39, [], ['r9'], 'fam1', 1 ).
test( 't17', 616, ['m5'], [], 'fam1', 1 ).
test( 't18', 772, [], [], 'fam1', 1 ).
test( 't19', 349, [], [], 'fam1', 1 ).
test( 't20', 704, [], [], 'fam1', 1 ).
test( 't21', 744, [], [], 'fam1', 1 ).
test( 't22', 298, ['m3','m1','m6'], [], 'fam1', 1 ).
test( 't23', 629, [], [], 'fam1', 1 ).
test( 't24', 197, [], [], 'fam1', 1 ).
test( 't25', 681, [], [], 'fam1', 1 ).
test( 't26', 319, ['m10'], [], 'fam1', 1 ).
test( 't27', 346, [], [], 'fam1', 1 ).
test( 't28', 330, [], ['r10','r3','r9'], 'fam1', 1 ).
test( 't29', 598, [], [], 'fam1', 1 ).
test( 't30', 307, [], ['r4','r2','r1','r5','r9','r10','r8'], 'fam1', 1 ).
test( 't31', 262, [], [], 'fam1', 1 ).
test( 't32', 696, [], ['r6','r3','r2','r9','r7','r10','r4'], 'fam1', 1 ).
test( 't33', 384, ['m9','m4'], [], 'fam1', 1 ).
test( 't34', 384, [], [], 'fam1', 1 ).
test( 't35', 687, [], [], 'fam1', 1 ).
test( 't36', 582, [], ['r8','r1'], 'fam1', 1 ).
test( 't37', 526, [], [], 'fam1', 1 ).
test( 't38', 669, [], [], 'fam1', 1 ).
test( 't39', 791, ['m9'], ['r2','r8'], 'fam1', 1 ).
test( 't40', 439, [], [], 'fam1', 1 ).
test( 't41', 532, [], ['r10','r3','r7','r6','r9','r5','r8','r2'], 'fam1', 1 ).
test( 't42', 692, [], [], 'fam1', 1 ).
test( 't43', 765, [], [], 'fam1', 1 ).
test( 't44', 17, [], [], 'fam1', 1 ).
test( 't45', 727, [], [], 'fam1', 1 ).
test( 't46', 517, ['m6','m7','m5'], ['r5','r9','r2','r7','r10'], 'fam1', 1 ).
test( 't47', 344, [], [], 'fam1', 1 ).
test( 't48', 386, [], [], 'fam1', 1 ).
test( 't49', 678, [], ['r7','r6','r9','r1','r8','r2','r4','r3'], 'fam1', 1 ).
test( 't50', 588, [], [], 'fam1', 1 ).
test( 't51', 513, [], [], 'fam1', 1 ).
test( 't52', 650, [], [], 'fam1', 1 ).
test( 't53', 484, [], [], 'fam1', 1 ).
test( 't54', 80, [], [], 'fam1', 1 ).
test( 't55', 203, [], [], 'fam1', 1 ).
test( 't56', 101, [], [], 'fam1', 1 ).
test( 't57', 175, ['m4'], [], 'fam1', 1 ).
test( 't58', 34, [], [], 'fam1', 1 ).
test( 't59', 315, [], ['r1','r8','r5','r3','r7','r6','r2','r10','r9'], 'fam1', 1 ).
test( 't60', 326, ['m1','m4'], [], 'fam1', 1 ).
test( 't61', 671, [], [], 'fam1', 1 ).
test( 't62', 203, ['m7','m4','m5','m10'], [], 'fam1', 1 ).
test( 't63', 326, [], [], 'fam1', 1 ).
test( 't64', 142, [], ['r10','r1','r8','r3','r5'], 'fam1', 1 ).
test( 't65', 547, [], ['r10','r9'], 'fam1', 1 ).
test( 't66', 261, ['m6'], [], 'fam1', 1 ).
test( 't67', 52, [], [], 'fam1', 1 ).
test( 't68', 89, [], ['r7'], 'fam1', 1 ).
test( 't69', 752, [], [], 'fam1', 1 ).
test( 't70', 19, [], [], 'fam1', 1 ).
test( 't71', 608, [], [], 'fam1', 1 ).
test( 't72', 536, [], ['r2','r1','r7'], 'fam1', 1 ).
test( 't73', 685, [], ['r3'], 'fam1', 1 ).
test( 't74', 63, [], [], 'fam1', 1 ).
test( 't75', 655, [], [], 'fam1', 1 ).
test( 't76', 19, [], ['r8','r9','r10','r6','r2','r4','r7','r3'], 'fam1', 1 ).
test( 't77', 442, ['m10'], ['r6','r10','r3','r5','r9'], 'fam1', 1 ).
test( 't78', 73, [], [], 'fam1', 1 ).
test( 't79', 259, ['m8','m7','m2','m1'], [], 'fam1', 1 ).
test( 't80', 331, [], ['r3','r1','r8','r2'], 'fam1', 1 ).
test( 't81', 321, [], [], 'fam1', 1 ).
test( 't82', 440, [], [], 'fam1', 1 ).
test( 't83', 520, [], [], 'fam1', 1 ).
test( 't84', 278, [], [], 'fam1', 1 ).
test( 't85', 240, [], [], 'fam1', 1 ).
test( 't86', 97, [], [], 'fam1', 1 ).
test( 't87', 135, [], [], 'fam1', 1 ).
test( 't88', 615, [], [], 'fam1', 1 ).
test( 't89', 628, [], [], 'fam1', 1 ).
test( 't90', 352, ['m1','m9','m8'], [], 'fam1', 1 ).
test( 't91', 139, [], [], 'fam1', 1 ).
test( 't92', 704, [], [], 'fam1', 1 ).
test( 't93', 139, [], [], 'fam1', 1 ).
test( 't94', 514, [], [], 'fam1', 1 ).
test( 't95', 638, [], [], 'fam1', 1 ).
test( 't96', 23, ['m7','m9','m2','m5'], [], 'fam1', 1 ).
test( 't97', 151, [], [], 'fam1', 1 ).
test( 't98', 192, [], [], 'fam1', 1 ).
test( 't99', 689, [], [], 'fam1', 1 ).
test( 't100', 567, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
