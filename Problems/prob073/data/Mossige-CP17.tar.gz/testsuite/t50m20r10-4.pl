%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 20
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 794, [], [], 'fam1', 1 ).
test( 't2', 6, [], ['r4','r7','r8','r1','r10'], 'fam1', 1 ).
test( 't3', 416, [], ['r2','r7','r4'], 'fam1', 1 ).
test( 't4', 462, [], ['r8','r5'], 'fam1', 1 ).
test( 't5', 269, ['m19','m3','m15'], [], 'fam1', 1 ).
test( 't6', 455, ['m2','m17','m20'], [], 'fam1', 1 ).
test( 't7', 684, [], ['r5','r8'], 'fam1', 1 ).
test( 't8', 87, [], ['r1'], 'fam1', 1 ).
test( 't9', 170, [], [], 'fam1', 1 ).
test( 't10', 584, [], [], 'fam1', 1 ).
test( 't11', 441, [], [], 'fam1', 1 ).
test( 't12', 312, [], [], 'fam1', 1 ).
test( 't13', 272, [], ['r3','r5','r7','r2'], 'fam1', 1 ).
test( 't14', 788, [], [], 'fam1', 1 ).
test( 't15', 291, [], [], 'fam1', 1 ).
test( 't16', 144, [], [], 'fam1', 1 ).
test( 't17', 120, ['m14','m6','m19','m15','m17','m11','m2'], [], 'fam1', 1 ).
test( 't18', 595, [], [], 'fam1', 1 ).
test( 't19', 274, [], ['r1','r10','r4','r2','r6','r5','r8'], 'fam1', 1 ).
test( 't20', 295, ['m16','m20'], ['r10','r9','r5','r2','r8','r1','r3'], 'fam1', 1 ).
test( 't21', 159, [], ['r3','r5','r7','r1','r10','r4','r9','r6'], 'fam1', 1 ).
test( 't22', 226, [], [], 'fam1', 1 ).
test( 't23', 775, [], [], 'fam1', 1 ).
test( 't24', 174, [], ['r7','r5','r1','r6','r9','r4','r10','r2','r8','r3'], 'fam1', 1 ).
test( 't25', 680, [], [], 'fam1', 1 ).
test( 't26', 261, [], [], 'fam1', 1 ).
test( 't27', 373, ['m20','m17','m10'], [], 'fam1', 1 ).
test( 't28', 377, [], [], 'fam1', 1 ).
test( 't29', 732, [], [], 'fam1', 1 ).
test( 't30', 550, [], [], 'fam1', 1 ).
test( 't31', 744, [], ['r5','r2','r9','r1','r10'], 'fam1', 1 ).
test( 't32', 762, [], ['r7','r3','r5','r6','r8','r9','r2','r1','r10','r4'], 'fam1', 1 ).
test( 't33', 646, [], ['r3','r8','r2','r6'], 'fam1', 1 ).
test( 't34', 514, [], [], 'fam1', 1 ).
test( 't35', 759, ['m18','m7','m1'], [], 'fam1', 1 ).
test( 't36', 714, [], [], 'fam1', 1 ).
test( 't37', 648, [], [], 'fam1', 1 ).
test( 't38', 638, [], [], 'fam1', 1 ).
test( 't39', 460, [], ['r10','r7','r3','r1','r2'], 'fam1', 1 ).
test( 't40', 251, [], [], 'fam1', 1 ).
test( 't41', 670, ['m7','m3','m6','m14','m4','m16','m15','m5'], ['r10','r9'], 'fam1', 1 ).
test( 't42', 734, [], [], 'fam1', 1 ).
test( 't43', 613, [], ['r8','r7','r2','r6','r3','r4','r9','r5'], 'fam1', 1 ).
test( 't44', 370, ['m5','m11','m16','m9','m3','m17','m19','m2'], ['r5','r3','r6','r9'], 'fam1', 1 ).
test( 't45', 231, [], ['r9','r3','r8','r10','r7','r6','r4'], 'fam1', 1 ).
test( 't46', 665, [], [], 'fam1', 1 ).
test( 't47', 533, [], [], 'fam1', 1 ).
test( 't48', 369, [], [], 'fam1', 1 ).
test( 't49', 389, [], [], 'fam1', 1 ).
test( 't50', 504, ['m2','m5','m9','m1'], ['r2','r4'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
