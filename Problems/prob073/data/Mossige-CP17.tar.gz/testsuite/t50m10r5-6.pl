%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 535, [], ['r5','r4','r2','r3','r1'], 'fam1', 1 ).
test( 't2', 15, ['m5','m2','m3'], [], 'fam1', 1 ).
test( 't3', 602, [], [], 'fam1', 1 ).
test( 't4', 607, ['m5','m2','m6','m8'], ['r2'], 'fam1', 1 ).
test( 't5', 8, [], [], 'fam1', 1 ).
test( 't6', 797, [], [], 'fam1', 1 ).
test( 't7', 195, [], ['r2','r1','r3','r4'], 'fam1', 1 ).
test( 't8', 374, [], ['r5','r1','r3','r2'], 'fam1', 1 ).
test( 't9', 787, [], [], 'fam1', 1 ).
test( 't10', 798, [], ['r3','r4','r5','r1'], 'fam1', 1 ).
test( 't11', 329, [], [], 'fam1', 1 ).
test( 't12', 460, [], [], 'fam1', 1 ).
test( 't13', 325, ['m2','m7','m5'], [], 'fam1', 1 ).
test( 't14', 116, [], ['r5','r1','r4','r2','r3'], 'fam1', 1 ).
test( 't15', 126, [], ['r5','r1'], 'fam1', 1 ).
test( 't16', 269, [], ['r2','r1','r4','r3'], 'fam1', 1 ).
test( 't17', 397, [], [], 'fam1', 1 ).
test( 't18', 20, ['m3'], [], 'fam1', 1 ).
test( 't19', 789, [], [], 'fam1', 1 ).
test( 't20', 717, ['m7','m3'], [], 'fam1', 1 ).
test( 't21', 588, [], ['r3'], 'fam1', 1 ).
test( 't22', 52, [], [], 'fam1', 1 ).
test( 't23', 25, ['m10'], [], 'fam1', 1 ).
test( 't24', 302, [], ['r1'], 'fam1', 1 ).
test( 't25', 279, ['m5','m4','m6'], [], 'fam1', 1 ).
test( 't26', 422, [], ['r5','r1','r2'], 'fam1', 1 ).
test( 't27', 63, [], ['r3','r5','r2'], 'fam1', 1 ).
test( 't28', 469, [], [], 'fam1', 1 ).
test( 't29', 510, [], [], 'fam1', 1 ).
test( 't30', 30, [], ['r1','r2','r3','r5'], 'fam1', 1 ).
test( 't31', 642, [], [], 'fam1', 1 ).
test( 't32', 424, [], ['r1','r5','r3','r4'], 'fam1', 1 ).
test( 't33', 30, [], [], 'fam1', 1 ).
test( 't34', 612, [], [], 'fam1', 1 ).
test( 't35', 208, [], [], 'fam1', 1 ).
test( 't36', 442, [], [], 'fam1', 1 ).
test( 't37', 61, [], [], 'fam1', 1 ).
test( 't38', 679, [], [], 'fam1', 1 ).
test( 't39', 190, [], ['r1','r4','r2','r5'], 'fam1', 1 ).
test( 't40', 63, [], [], 'fam1', 1 ).
test( 't41', 277, ['m3','m1','m2'], [], 'fam1', 1 ).
test( 't42', 754, [], [], 'fam1', 1 ).
test( 't43', 631, [], ['r4'], 'fam1', 1 ).
test( 't44', 574, [], [], 'fam1', 1 ).
test( 't45', 736, [], [], 'fam1', 1 ).
test( 't46', 133, [], ['r2','r4'], 'fam1', 1 ).
test( 't47', 160, ['m5','m2','m8'], [], 'fam1', 1 ).
test( 't48', 292, ['m8'], [], 'fam1', 1 ).
test( 't49', 404, [], [], 'fam1', 1 ).
test( 't50', 502, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
