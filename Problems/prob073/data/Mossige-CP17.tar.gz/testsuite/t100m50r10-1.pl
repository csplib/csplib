%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 50
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 718, [], [], 'fam1', 1 ).
test( 't2', 131, [], [], 'fam1', 1 ).
test( 't3', 569, [], ['r6','r5','r8'], 'fam1', 1 ).
test( 't4', 754, [], [], 'fam1', 1 ).
test( 't5', 208, ['m22','m46','m11','m2','m41','m16','m48','m36','m13','m17','m4','m28','m20','m3','m31','m38','m10'], [], 'fam1', 1 ).
test( 't6', 734, [], [], 'fam1', 1 ).
test( 't7', 505, [], [], 'fam1', 1 ).
test( 't8', 295, [], [], 'fam1', 1 ).
test( 't9', 713, ['m16','m4','m29','m14','m40','m26','m31','m47','m41','m34'], ['r6','r3','r1','r7','r10','r4','r2','r9'], 'fam1', 1 ).
test( 't10', 177, [], [], 'fam1', 1 ).
test( 't11', 168, ['m13','m38','m39'], [], 'fam1', 1 ).
test( 't12', 745, [], [], 'fam1', 1 ).
test( 't13', 275, [], [], 'fam1', 1 ).
test( 't14', 300, [], [], 'fam1', 1 ).
test( 't15', 611, ['m30','m47','m21','m33','m50','m38','m5','m46','m17','m26','m35','m4','m43','m20'], [], 'fam1', 1 ).
test( 't16', 680, [], [], 'fam1', 1 ).
test( 't17', 330, ['m33','m20'], [], 'fam1', 1 ).
test( 't18', 680, [], [], 'fam1', 1 ).
test( 't19', 533, ['m3','m34','m27','m40','m25','m36','m19'], ['r1','r4','r9','r6','r7','r3','r5','r10','r8','r2'], 'fam1', 1 ).
test( 't20', 396, [], ['r8','r4','r2','r1','r6','r10','r5','r3','r9','r7'], 'fam1', 1 ).
test( 't21', 257, ['m17','m19','m8','m39','m33','m36','m6','m45','m5','m10','m35','m31','m24','m21','m20','m22'], [], 'fam1', 1 ).
test( 't22', 307, [], [], 'fam1', 1 ).
test( 't23', 153, [], [], 'fam1', 1 ).
test( 't24', 216, [], [], 'fam1', 1 ).
test( 't25', 434, [], [], 'fam1', 1 ).
test( 't26', 80, ['m19','m24','m43','m34','m12'], ['r6','r7','r3','r1','r2','r10','r9','r8','r5','r4'], 'fam1', 1 ).
test( 't27', 95, ['m15','m18','m19','m27','m22','m46','m21','m37','m33','m35','m48'], [], 'fam1', 1 ).
test( 't28', 601, [], ['r7','r3','r2','r1'], 'fam1', 1 ).
test( 't29', 402, [], ['r5','r2','r4','r3','r9','r1','r10','r7','r6','r8'], 'fam1', 1 ).
test( 't30', 747, [], [], 'fam1', 1 ).
test( 't31', 72, [], ['r9','r8','r7','r6'], 'fam1', 1 ).
test( 't32', 80, [], ['r9','r5','r6','r4','r2','r8','r3'], 'fam1', 1 ).
test( 't33', 704, [], [], 'fam1', 1 ).
test( 't34', 481, [], [], 'fam1', 1 ).
test( 't35', 198, [], [], 'fam1', 1 ).
test( 't36', 62, ['m6','m21','m24','m4','m43','m15','m47','m33','m31','m49','m42'], [], 'fam1', 1 ).
test( 't37', 161, [], [], 'fam1', 1 ).
test( 't38', 165, ['m38','m15','m5','m14','m13','m8','m50','m24','m23','m39','m37','m43'], ['r5','r9','r10','r4','r8','r2','r1','r3','r7'], 'fam1', 1 ).
test( 't39', 389, [], [], 'fam1', 1 ).
test( 't40', 304, [], [], 'fam1', 1 ).
test( 't41', 439, [], [], 'fam1', 1 ).
test( 't42', 708, [], [], 'fam1', 1 ).
test( 't43', 380, [], ['r3','r7','r9','r10','r8','r2'], 'fam1', 1 ).
test( 't44', 97, [], ['r8','r7','r10','r4','r3','r5'], 'fam1', 1 ).
test( 't45', 250, [], [], 'fam1', 1 ).
test( 't46', 438, [], [], 'fam1', 1 ).
test( 't47', 317, [], [], 'fam1', 1 ).
test( 't48', 750, [], [], 'fam1', 1 ).
test( 't49', 465, [], ['r10','r6','r4','r1','r5','r3','r7','r9','r2'], 'fam1', 1 ).
test( 't50', 762, ['m43','m8','m36'], [], 'fam1', 1 ).
test( 't51', 784, [], [], 'fam1', 1 ).
test( 't52', 287, [], ['r1'], 'fam1', 1 ).
test( 't53', 225, [], [], 'fam1', 1 ).
test( 't54', 648, ['m17','m15','m31','m23','m35','m14','m25','m18','m36','m1','m46','m40','m49'], ['r6','r1','r8','r9','r7','r4','r3'], 'fam1', 1 ).
test( 't55', 700, [], ['r5'], 'fam1', 1 ).
test( 't56', 408, [], ['r5','r8','r1','r3'], 'fam1', 1 ).
test( 't57', 324, [], [], 'fam1', 1 ).
test( 't58', 709, [], [], 'fam1', 1 ).
test( 't59', 163, [], [], 'fam1', 1 ).
test( 't60', 132, [], ['r9','r3','r7','r1','r10','r6'], 'fam1', 1 ).
test( 't61', 591, ['m13','m48','m44','m2'], ['r9'], 'fam1', 1 ).
test( 't62', 325, [], [], 'fam1', 1 ).
test( 't63', 159, ['m17','m45'], [], 'fam1', 1 ).
test( 't64', 153, ['m18','m45','m10','m5','m17','m1','m37','m19','m11','m26','m13','m8','m44','m31','m41'], ['r7','r8'], 'fam1', 1 ).
test( 't65', 182, [], [], 'fam1', 1 ).
test( 't66', 81, ['m20','m22','m41','m50','m32','m47','m16','m43','m36','m34','m8','m45','m42','m26','m35','m5','m15'], [], 'fam1', 1 ).
test( 't67', 249, [], ['r10','r7','r1','r2','r6','r3','r9'], 'fam1', 1 ).
test( 't68', 692, ['m44','m47','m20','m38','m25','m50','m21'], [], 'fam1', 1 ).
test( 't69', 551, ['m16'], ['r8','r4','r5'], 'fam1', 1 ).
test( 't70', 22, ['m28','m42','m16','m1','m13','m25','m6','m18'], [], 'fam1', 1 ).
test( 't71', 77, [], [], 'fam1', 1 ).
test( 't72', 307, [], [], 'fam1', 1 ).
test( 't73', 723, [], [], 'fam1', 1 ).
test( 't74', 724, [], [], 'fam1', 1 ).
test( 't75', 603, [], [], 'fam1', 1 ).
test( 't76', 162, [], ['r4','r3','r1','r8','r6','r2','r9','r10','r7'], 'fam1', 1 ).
test( 't77', 395, [], [], 'fam1', 1 ).
test( 't78', 443, ['m15','m37','m10','m19','m18','m38','m20'], [], 'fam1', 1 ).
test( 't79', 491, ['m41','m15','m46','m14','m19','m6','m21','m38','m31','m9','m20','m36','m1','m16','m45','m40'], ['r1','r2','r9','r7','r10','r4','r3','r5'], 'fam1', 1 ).
test( 't80', 647, ['m28','m14','m2','m22','m40','m12','m34','m49','m43','m18','m5','m31','m47','m7','m38','m24','m39','m48'], [], 'fam1', 1 ).
test( 't81', 42, [], ['r9','r4','r2','r8','r3','r6','r5','r7'], 'fam1', 1 ).
test( 't82', 524, [], [], 'fam1', 1 ).
test( 't83', 637, [], [], 'fam1', 1 ).
test( 't84', 746, [], ['r6','r2','r9','r1','r5','r4','r10','r7','r3'], 'fam1', 1 ).
test( 't85', 9, ['m37','m35','m23','m6','m27','m42','m33','m31','m38','m2','m21','m11','m34'], [], 'fam1', 1 ).
test( 't86', 489, ['m4','m12','m32','m27','m6','m34','m10','m25','m7','m38','m13','m24','m16','m20','m28'], [], 'fam1', 1 ).
test( 't87', 91, [], [], 'fam1', 1 ).
test( 't88', 230, [], ['r7','r6'], 'fam1', 1 ).
test( 't89', 200, [], [], 'fam1', 1 ).
test( 't90', 144, [], [], 'fam1', 1 ).
test( 't91', 100, [], ['r9','r3','r8','r1','r2','r5','r4'], 'fam1', 1 ).
test( 't92', 685, [], [], 'fam1', 1 ).
test( 't93', 264, [], [], 'fam1', 1 ).
test( 't94', 540, [], [], 'fam1', 1 ).
test( 't95', 584, [], [], 'fam1', 1 ).
test( 't96', 688, [], [], 'fam1', 1 ).
test( 't97', 184, [], ['r6','r1','r7','r2'], 'fam1', 1 ).
test( 't98', 624, [], [], 'fam1', 1 ).
test( 't99', 185, [], [], 'fam1', 1 ).
test( 't100', 339, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').
embedded_board( 'm21').
embedded_board( 'm22').
embedded_board( 'm23').
embedded_board( 'm24').
embedded_board( 'm25').
embedded_board( 'm26').
embedded_board( 'm27').
embedded_board( 'm28').
embedded_board( 'm29').
embedded_board( 'm30').
embedded_board( 'm31').
embedded_board( 'm32').
embedded_board( 'm33').
embedded_board( 'm34').
embedded_board( 'm35').
embedded_board( 'm36').
embedded_board( 'm37').
embedded_board( 'm38').
embedded_board( 'm39').
embedded_board( 'm40').
embedded_board( 'm41').
embedded_board( 'm42').
embedded_board( 'm43').
embedded_board( 'm44').
embedded_board( 'm45').
embedded_board( 'm46').
embedded_board( 'm47').
embedded_board( 'm48').
embedded_board( 'm49').
embedded_board( 'm50').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
