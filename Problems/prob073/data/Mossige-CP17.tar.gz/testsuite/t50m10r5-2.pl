%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 676, ['m6','m8'], [], 'fam1', 1 ).
test( 't2', 681, [], [], 'fam1', 1 ).
test( 't3', 128, [], [], 'fam1', 1 ).
test( 't4', 727, [], ['r1','r3','r4','r5','r2'], 'fam1', 1 ).
test( 't5', 63, [], [], 'fam1', 1 ).
test( 't6', 494, [], [], 'fam1', 1 ).
test( 't7', 510, [], [], 'fam1', 1 ).
test( 't8', 749, ['m5','m8','m4'], [], 'fam1', 1 ).
test( 't9', 174, [], [], 'fam1', 1 ).
test( 't10', 110, [], [], 'fam1', 1 ).
test( 't11', 326, ['m1'], [], 'fam1', 1 ).
test( 't12', 643, [], [], 'fam1', 1 ).
test( 't13', 653, ['m1'], [], 'fam1', 1 ).
test( 't14', 287, [], ['r1','r5','r2','r4'], 'fam1', 1 ).
test( 't15', 592, [], ['r5'], 'fam1', 1 ).
test( 't16', 496, [], [], 'fam1', 1 ).
test( 't17', 483, ['m5'], [], 'fam1', 1 ).
test( 't18', 496, [], [], 'fam1', 1 ).
test( 't19', 733, [], [], 'fam1', 1 ).
test( 't20', 210, [], ['r5','r1','r4','r3'], 'fam1', 1 ).
test( 't21', 334, [], ['r3','r1'], 'fam1', 1 ).
test( 't22', 756, ['m2'], [], 'fam1', 1 ).
test( 't23', 346, ['m3','m10','m4'], [], 'fam1', 1 ).
test( 't24', 678, [], [], 'fam1', 1 ).
test( 't25', 248, [], [], 'fam1', 1 ).
test( 't26', 509, ['m7'], [], 'fam1', 1 ).
test( 't27', 141, [], [], 'fam1', 1 ).
test( 't28', 128, ['m4'], [], 'fam1', 1 ).
test( 't29', 793, ['m10','m2','m7'], [], 'fam1', 1 ).
test( 't30', 687, ['m9','m4'], ['r4','r5','r1','r2','r3'], 'fam1', 1 ).
test( 't31', 371, [], ['r4'], 'fam1', 1 ).
test( 't32', 486, [], [], 'fam1', 1 ).
test( 't33', 730, [], ['r5','r1','r4','r3','r2'], 'fam1', 1 ).
test( 't34', 286, [], ['r3','r5'], 'fam1', 1 ).
test( 't35', 464, [], ['r1'], 'fam1', 1 ).
test( 't36', 203, [], [], 'fam1', 1 ).
test( 't37', 371, [], [], 'fam1', 1 ).
test( 't38', 599, [], [], 'fam1', 1 ).
test( 't39', 480, [], ['r5','r4','r3'], 'fam1', 1 ).
test( 't40', 793, ['m2','m3','m7'], [], 'fam1', 1 ).
test( 't41', 367, [], [], 'fam1', 1 ).
test( 't42', 292, [], [], 'fam1', 1 ).
test( 't43', 93, [], [], 'fam1', 1 ).
test( 't44', 243, [], [], 'fam1', 1 ).
test( 't45', 19, [], ['r5'], 'fam1', 1 ).
test( 't46', 649, ['m10'], ['r1','r5','r4','r2'], 'fam1', 1 ).
test( 't47', 468, [], [], 'fam1', 1 ).
test( 't48', 486, ['m8','m5','m4','m10'], ['r2','r5','r3','r1','r4'], 'fam1', 1 ).
test( 't49', 60, ['m10','m7','m2'], [], 'fam1', 1 ).
test( 't50', 611, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
