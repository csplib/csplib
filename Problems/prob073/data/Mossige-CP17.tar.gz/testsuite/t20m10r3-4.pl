%% ****  Testsuite  ****
% Number of tests                  : 20
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 403, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't2', 244, [], [], 'fam1', 1 ).
test( 't3', 29, [], [], 'fam1', 1 ).
test( 't4', 248, ['m2','m5','m6','m4'], ['r2','r3','r1'], 'fam1', 1 ).
test( 't5', 169, [], ['r1','r2'], 'fam1', 1 ).
test( 't6', 35, [], [], 'fam1', 1 ).
test( 't7', 800, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't8', 340, [], [], 'fam1', 1 ).
test( 't9', 583, [], [], 'fam1', 1 ).
test( 't10', 574, [], ['r1','r3'], 'fam1', 1 ).
test( 't11', 61, [], [], 'fam1', 1 ).
test( 't12', 637, [], [], 'fam1', 1 ).
test( 't13', 134, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't14', 168, [], [], 'fam1', 1 ).
test( 't15', 477, [], [], 'fam1', 1 ).
test( 't16', 204, [], [], 'fam1', 1 ).
test( 't17', 4, [], [], 'fam1', 1 ).
test( 't18', 679, [], [], 'fam1', 1 ).
test( 't19', 700, [], [], 'fam1', 1 ).
test( 't20', 379, [], ['r3','r2','r1'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
