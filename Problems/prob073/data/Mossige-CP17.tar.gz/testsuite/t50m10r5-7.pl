%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 353, [], [], 'fam1', 1 ).
test( 't2', 126, [], [], 'fam1', 1 ).
test( 't3', 243, [], ['r2','r1','r4','r5','r3'], 'fam1', 1 ).
test( 't4', 194, [], ['r3','r2','r5','r4','r1'], 'fam1', 1 ).
test( 't5', 402, [], [], 'fam1', 1 ).
test( 't6', 255, [], [], 'fam1', 1 ).
test( 't7', 509, [], [], 'fam1', 1 ).
test( 't8', 1, [], [], 'fam1', 1 ).
test( 't9', 363, [], [], 'fam1', 1 ).
test( 't10', 411, [], [], 'fam1', 1 ).
test( 't11', 689, [], ['r4','r2','r1'], 'fam1', 1 ).
test( 't12', 524, ['m7','m10'], [], 'fam1', 1 ).
test( 't13', 583, ['m10','m8'], ['r4','r3','r5'], 'fam1', 1 ).
test( 't14', 484, [], [], 'fam1', 1 ).
test( 't15', 768, ['m7','m2','m9'], [], 'fam1', 1 ).
test( 't16', 165, [], [], 'fam1', 1 ).
test( 't17', 677, ['m9','m5'], [], 'fam1', 1 ).
test( 't18', 179, [], [], 'fam1', 1 ).
test( 't19', 352, [], [], 'fam1', 1 ).
test( 't20', 334, [], [], 'fam1', 1 ).
test( 't21', 595, ['m10','m2'], [], 'fam1', 1 ).
test( 't22', 705, [], [], 'fam1', 1 ).
test( 't23', 773, ['m1','m7'], ['r4','r1','r2','r3','r5'], 'fam1', 1 ).
test( 't24', 104, [], ['r4','r3'], 'fam1', 1 ).
test( 't25', 726, ['m2'], [], 'fam1', 1 ).
test( 't26', 554, [], [], 'fam1', 1 ).
test( 't27', 780, [], [], 'fam1', 1 ).
test( 't28', 38, ['m5','m3'], [], 'fam1', 1 ).
test( 't29', 22, [], ['r5','r2','r4','r1'], 'fam1', 1 ).
test( 't30', 33, [], [], 'fam1', 1 ).
test( 't31', 441, [], [], 'fam1', 1 ).
test( 't32', 378, [], [], 'fam1', 1 ).
test( 't33', 576, [], [], 'fam1', 1 ).
test( 't34', 682, [], [], 'fam1', 1 ).
test( 't35', 767, [], [], 'fam1', 1 ).
test( 't36', 556, [], ['r4','r5'], 'fam1', 1 ).
test( 't37', 751, [], [], 'fam1', 1 ).
test( 't38', 475, [], [], 'fam1', 1 ).
test( 't39', 82, [], [], 'fam1', 1 ).
test( 't40', 113, [], [], 'fam1', 1 ).
test( 't41', 64, [], [], 'fam1', 1 ).
test( 't42', 693, [], [], 'fam1', 1 ).
test( 't43', 54, [], [], 'fam1', 1 ).
test( 't44', 522, [], [], 'fam1', 1 ).
test( 't45', 431, [], [], 'fam1', 1 ).
test( 't46', 120, [], [], 'fam1', 1 ).
test( 't47', 642, [], [], 'fam1', 1 ).
test( 't48', 159, [], ['r5','r1','r3'], 'fam1', 1 ).
test( 't49', 433, [], [], 'fam1', 1 ).
test( 't50', 785, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
