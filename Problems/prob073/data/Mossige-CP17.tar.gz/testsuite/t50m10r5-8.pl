%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 398, [], [], 'fam1', 1 ).
test( 't2', 592, [], ['r4','r1','r5'], 'fam1', 1 ).
test( 't3', 596, [], [], 'fam1', 1 ).
test( 't4', 78, [], [], 'fam1', 1 ).
test( 't5', 516, [], [], 'fam1', 1 ).
test( 't6', 782, [], [], 'fam1', 1 ).
test( 't7', 738, [], ['r3','r4','r5','r2'], 'fam1', 1 ).
test( 't8', 65, [], [], 'fam1', 1 ).
test( 't9', 510, [], ['r1','r2'], 'fam1', 1 ).
test( 't10', 278, [], [], 'fam1', 1 ).
test( 't11', 799, ['m8','m2','m6','m5'], [], 'fam1', 1 ).
test( 't12', 179, ['m9'], ['r5'], 'fam1', 1 ).
test( 't13', 637, [], [], 'fam1', 1 ).
test( 't14', 303, [], [], 'fam1', 1 ).
test( 't15', 6, [], [], 'fam1', 1 ).
test( 't16', 364, [], [], 'fam1', 1 ).
test( 't17', 646, [], [], 'fam1', 1 ).
test( 't18', 580, [], [], 'fam1', 1 ).
test( 't19', 638, ['m5','m9','m2'], ['r4','r5','r2','r3'], 'fam1', 1 ).
test( 't20', 394, ['m3','m8','m1'], ['r1','r5','r4','r2','r3'], 'fam1', 1 ).
test( 't21', 238, [], [], 'fam1', 1 ).
test( 't22', 567, ['m2','m1','m9'], ['r3','r1','r5','r2','r4'], 'fam1', 1 ).
test( 't23', 599, [], ['r3'], 'fam1', 1 ).
test( 't24', 472, ['m3'], [], 'fam1', 1 ).
test( 't25', 646, [], [], 'fam1', 1 ).
test( 't26', 706, ['m4','m8','m7'], [], 'fam1', 1 ).
test( 't27', 297, [], [], 'fam1', 1 ).
test( 't28', 179, ['m6','m4','m9'], ['r4'], 'fam1', 1 ).
test( 't29', 61, [], [], 'fam1', 1 ).
test( 't30', 359, [], [], 'fam1', 1 ).
test( 't31', 45, [], [], 'fam1', 1 ).
test( 't32', 655, [], [], 'fam1', 1 ).
test( 't33', 313, [], [], 'fam1', 1 ).
test( 't34', 183, [], ['r5','r4','r1','r2','r3'], 'fam1', 1 ).
test( 't35', 741, [], [], 'fam1', 1 ).
test( 't36', 213, [], [], 'fam1', 1 ).
test( 't37', 581, [], [], 'fam1', 1 ).
test( 't38', 207, [], [], 'fam1', 1 ).
test( 't39', 282, [], [], 'fam1', 1 ).
test( 't40', 655, [], [], 'fam1', 1 ).
test( 't41', 392, [], ['r1','r5','r4','r2','r3'], 'fam1', 1 ).
test( 't42', 33, [], [], 'fam1', 1 ).
test( 't43', 551, ['m2'], ['r2','r1'], 'fam1', 1 ).
test( 't44', 523, [], [], 'fam1', 1 ).
test( 't45', 254, [], ['r1','r5','r3','r4'], 'fam1', 1 ).
test( 't46', 740, [], ['r3','r5','r2','r1','r4'], 'fam1', 1 ).
test( 't47', 425, ['m5','m10','m6','m2'], [], 'fam1', 1 ).
test( 't48', 309, ['m7','m3'], ['r5'], 'fam1', 1 ).
test( 't49', 33, [], [], 'fam1', 1 ).
test( 't50', 315, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
