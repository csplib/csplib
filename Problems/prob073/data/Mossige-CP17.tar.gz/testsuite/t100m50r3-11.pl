%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 50
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 208, [], [], 'fam1', 1 ).
test( 't2', 266, ['m26','m33','m44','m46','m3','m19','m37','m28','m16','m1','m5'], ['r1','r3'], 'fam1', 1 ).
test( 't3', 323, ['m10','m41','m13','m12','m18','m34','m4','m9','m1','m5','m43','m47','m27','m36','m15','m11','m33','m30'], ['r2','r3','r1'], 'fam1', 1 ).
test( 't4', 199, [], ['r2'], 'fam1', 1 ).
test( 't5', 456, [], [], 'fam1', 1 ).
test( 't6', 426, [], [], 'fam1', 1 ).
test( 't7', 57, [], [], 'fam1', 1 ).
test( 't8', 501, [], [], 'fam1', 1 ).
test( 't9', 409, [], [], 'fam1', 1 ).
test( 't10', 668, ['m9','m44','m49'], [], 'fam1', 1 ).
test( 't11', 228, [], [], 'fam1', 1 ).
test( 't12', 6, ['m8','m30','m41','m33','m39','m5','m7','m40','m20','m36','m35','m43','m18','m44','m22','m23','m10'], [], 'fam1', 1 ).
test( 't13', 712, [], ['r1'], 'fam1', 1 ).
test( 't14', 139, ['m7','m49','m3','m25','m18','m38','m31','m28','m47','m43','m37','m6','m44','m20','m39','m36','m34','m42','m40'], [], 'fam1', 1 ).
test( 't15', 15, [], ['r1'], 'fam1', 1 ).
test( 't16', 148, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't17', 190, [], ['r3'], 'fam1', 1 ).
test( 't18', 691, [], [], 'fam1', 1 ).
test( 't19', 550, [], ['r3','r1'], 'fam1', 1 ).
test( 't20', 34, [], [], 'fam1', 1 ).
test( 't21', 496, [], [], 'fam1', 1 ).
test( 't22', 654, [], [], 'fam1', 1 ).
test( 't23', 218, [], [], 'fam1', 1 ).
test( 't24', 479, [], [], 'fam1', 1 ).
test( 't25', 200, ['m9'], [], 'fam1', 1 ).
test( 't26', 683, [], [], 'fam1', 1 ).
test( 't27', 400, [], ['r1'], 'fam1', 1 ).
test( 't28', 174, [], [], 'fam1', 1 ).
test( 't29', 108, ['m11','m33','m1','m17','m22','m30','m50','m21','m39','m36','m41'], [], 'fam1', 1 ).
test( 't30', 667, [], [], 'fam1', 1 ).
test( 't31', 724, [], [], 'fam1', 1 ).
test( 't32', 651, ['m13','m17','m8','m1','m22','m26','m36','m11','m50','m40','m37','m7','m30'], ['r1'], 'fam1', 1 ).
test( 't33', 670, ['m4','m44','m27','m16'], [], 'fam1', 1 ).
test( 't34', 684, [], [], 'fam1', 1 ).
test( 't35', 6, [], [], 'fam1', 1 ).
test( 't36', 170, [], [], 'fam1', 1 ).
test( 't37', 270, ['m49','m23','m32','m10','m2','m43'], [], 'fam1', 1 ).
test( 't38', 654, ['m49','m42','m44'], [], 'fam1', 1 ).
test( 't39', 623, [], [], 'fam1', 1 ).
test( 't40', 597, [], [], 'fam1', 1 ).
test( 't41', 333, [], ['r2','r1'], 'fam1', 1 ).
test( 't42', 303, [], [], 'fam1', 1 ).
test( 't43', 170, [], ['r3'], 'fam1', 1 ).
test( 't44', 42, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't45', 210, [], [], 'fam1', 1 ).
test( 't46', 151, [], ['r2','r3'], 'fam1', 1 ).
test( 't47', 358, [], ['r1','r3'], 'fam1', 1 ).
test( 't48', 244, [], [], 'fam1', 1 ).
test( 't49', 606, [], [], 'fam1', 1 ).
test( 't50', 670, [], [], 'fam1', 1 ).
test( 't51', 561, ['m4','m32','m13','m19','m5','m26','m28','m33','m8','m12','m30','m9'], [], 'fam1', 1 ).
test( 't52', 638, [], [], 'fam1', 1 ).
test( 't53', 275, [], [], 'fam1', 1 ).
test( 't54', 151, [], [], 'fam1', 1 ).
test( 't55', 557, [], [], 'fam1', 1 ).
test( 't56', 72, ['m49','m10','m38','m4','m9','m7','m18'], [], 'fam1', 1 ).
test( 't57', 710, [], [], 'fam1', 1 ).
test( 't58', 104, [], [], 'fam1', 1 ).
test( 't59', 240, [], [], 'fam1', 1 ).
test( 't60', 461, [], ['r3','r2'], 'fam1', 1 ).
test( 't61', 213, [], [], 'fam1', 1 ).
test( 't62', 251, [], ['r1','r3'], 'fam1', 1 ).
test( 't63', 203, ['m43','m23','m30','m35','m11','m8','m15','m3','m18','m12','m25','m33','m10','m1','m5','m2','m27','m46','m39','m29'], [], 'fam1', 1 ).
test( 't64', 795, [], [], 'fam1', 1 ).
test( 't65', 205, ['m19','m11','m1','m46','m25','m4','m35','m29','m7','m23','m28','m8','m39','m43','m21'], [], 'fam1', 1 ).
test( 't66', 681, ['m39','m48','m44','m30','m31','m21','m26','m1','m32','m3','m41','m8','m7'], [], 'fam1', 1 ).
test( 't67', 91, ['m4','m35','m38','m23','m50','m10','m24','m33','m9','m48','m11','m44','m41','m36','m32','m2'], [], 'fam1', 1 ).
test( 't68', 620, ['m46','m43','m16','m34','m17','m39','m18','m12'], [], 'fam1', 1 ).
test( 't69', 201, [], [], 'fam1', 1 ).
test( 't70', 796, ['m34','m25','m15','m20','m29','m45','m4','m1','m33','m32','m38','m47'], [], 'fam1', 1 ).
test( 't71', 342, [], [], 'fam1', 1 ).
test( 't72', 40, [], ['r2'], 'fam1', 1 ).
test( 't73', 487, ['m4','m33','m26','m44','m19','m3','m16','m30','m47','m7','m14','m32','m8'], [], 'fam1', 1 ).
test( 't74', 158, [], ['r3','r1'], 'fam1', 1 ).
test( 't75', 525, [], [], 'fam1', 1 ).
test( 't76', 610, [], [], 'fam1', 1 ).
test( 't77', 792, [], [], 'fam1', 1 ).
test( 't78', 88, ['m49','m45','m39','m44','m17','m42','m5','m4','m26'], ['r2'], 'fam1', 1 ).
test( 't79', 346, [], ['r1'], 'fam1', 1 ).
test( 't80', 182, [], [], 'fam1', 1 ).
test( 't81', 433, ['m50','m22','m38','m36'], ['r1','r2'], 'fam1', 1 ).
test( 't82', 756, [], [], 'fam1', 1 ).
test( 't83', 710, [], ['r2','r3'], 'fam1', 1 ).
test( 't84', 366, [], ['r2'], 'fam1', 1 ).
test( 't85', 31, ['m37','m35','m28','m45','m43','m2'], [], 'fam1', 1 ).
test( 't86', 393, ['m43','m19','m46','m16','m24','m27'], [], 'fam1', 1 ).
test( 't87', 10, [], [], 'fam1', 1 ).
test( 't88', 196, [], [], 'fam1', 1 ).
test( 't89', 340, [], [], 'fam1', 1 ).
test( 't90', 336, [], [], 'fam1', 1 ).
test( 't91', 23, [], ['r1'], 'fam1', 1 ).
test( 't92', 775, [], ['r2'], 'fam1', 1 ).
test( 't93', 462, [], ['r2','r1'], 'fam1', 1 ).
test( 't94', 300, [], [], 'fam1', 1 ).
test( 't95', 238, [], [], 'fam1', 1 ).
test( 't96', 312, [], [], 'fam1', 1 ).
test( 't97', 570, [], [], 'fam1', 1 ).
test( 't98', 421, [], [], 'fam1', 1 ).
test( 't99', 228, [], [], 'fam1', 1 ).
test( 't100', 670, [], ['r3','r1','r2'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').
embedded_board( 'm21').
embedded_board( 'm22').
embedded_board( 'm23').
embedded_board( 'm24').
embedded_board( 'm25').
embedded_board( 'm26').
embedded_board( 'm27').
embedded_board( 'm28').
embedded_board( 'm29').
embedded_board( 'm30').
embedded_board( 'm31').
embedded_board( 'm32').
embedded_board( 'm33').
embedded_board( 'm34').
embedded_board( 'm35').
embedded_board( 'm36').
embedded_board( 'm37').
embedded_board( 'm38').
embedded_board( 'm39').
embedded_board( 'm40').
embedded_board( 'm41').
embedded_board( 'm42').
embedded_board( 'm43').
embedded_board( 'm44').
embedded_board( 'm45').
embedded_board( 'm46').
embedded_board( 'm47').
embedded_board( 'm48').
embedded_board( 'm49').
embedded_board( 'm50').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
