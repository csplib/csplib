%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 20
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 722, [], [], 'fam1', 1 ).
test( 't2', 337, ['m16','m12','m10','m2','m20','m7'], [], 'fam1', 1 ).
test( 't3', 477, [], [], 'fam1', 1 ).
test( 't4', 418, ['m20','m10','m3','m16','m13','m19','m9','m8'], [], 'fam1', 1 ).
test( 't5', 495, [], [], 'fam1', 1 ).
test( 't6', 237, [], [], 'fam1', 1 ).
test( 't7', 113, [], [], 'fam1', 1 ).
test( 't8', 446, [], [], 'fam1', 1 ).
test( 't9', 333, [], ['r5'], 'fam1', 1 ).
test( 't10', 399, [], [], 'fam1', 1 ).
test( 't11', 4, ['m8','m20','m13','m3'], [], 'fam1', 1 ).
test( 't12', 226, [], [], 'fam1', 1 ).
test( 't13', 420, [], ['r4','r2','r3','r1'], 'fam1', 1 ).
test( 't14', 539, [], [], 'fam1', 1 ).
test( 't15', 612, [], ['r4'], 'fam1', 1 ).
test( 't16', 773, [], [], 'fam1', 1 ).
test( 't17', 238, [], [], 'fam1', 1 ).
test( 't18', 748, ['m17','m14','m7','m16','m10','m19'], [], 'fam1', 1 ).
test( 't19', 211, [], [], 'fam1', 1 ).
test( 't20', 453, ['m7','m19'], [], 'fam1', 1 ).
test( 't21', 697, [], [], 'fam1', 1 ).
test( 't22', 561, [], [], 'fam1', 1 ).
test( 't23', 262, [], [], 'fam1', 1 ).
test( 't24', 627, [], [], 'fam1', 1 ).
test( 't25', 449, [], [], 'fam1', 1 ).
test( 't26', 232, [], [], 'fam1', 1 ).
test( 't27', 778, ['m14','m3','m18','m11'], ['r3'], 'fam1', 1 ).
test( 't28', 388, [], [], 'fam1', 1 ).
test( 't29', 428, [], ['r2','r5','r4','r3','r1'], 'fam1', 1 ).
test( 't30', 505, [], [], 'fam1', 1 ).
test( 't31', 332, ['m16','m8','m3'], [], 'fam1', 1 ).
test( 't32', 556, [], [], 'fam1', 1 ).
test( 't33', 713, [], [], 'fam1', 1 ).
test( 't34', 738, [], [], 'fam1', 1 ).
test( 't35', 276, [], [], 'fam1', 1 ).
test( 't36', 782, [], ['r4'], 'fam1', 1 ).
test( 't37', 587, [], [], 'fam1', 1 ).
test( 't38', 629, [], [], 'fam1', 1 ).
test( 't39', 781, [], [], 'fam1', 1 ).
test( 't40', 252, [], [], 'fam1', 1 ).
test( 't41', 755, [], [], 'fam1', 1 ).
test( 't42', 135, [], [], 'fam1', 1 ).
test( 't43', 371, [], [], 'fam1', 1 ).
test( 't44', 158, [], [], 'fam1', 1 ).
test( 't45', 702, ['m10','m5'], ['r2','r5','r3','r1'], 'fam1', 1 ).
test( 't46', 656, [], [], 'fam1', 1 ).
test( 't47', 782, [], [], 'fam1', 1 ).
test( 't48', 159, [], [], 'fam1', 1 ).
test( 't49', 563, [], [], 'fam1', 1 ).
test( 't50', 32, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
