%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 50
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 673, [], [], 'fam1', 1 ).
test( 't2', 160, [], [], 'fam1', 1 ).
test( 't3', 255, [], [], 'fam1', 1 ).
test( 't4', 177, [], [], 'fam1', 1 ).
test( 't5', 73, ['m42','m27','m32','m13','m29','m14','m45','m7'], [], 'fam1', 1 ).
test( 't6', 182, [], [], 'fam1', 1 ).
test( 't7', 478, [], ['r4'], 'fam1', 1 ).
test( 't8', 167, [], [], 'fam1', 1 ).
test( 't9', 753, [], ['r5','r4','r9'], 'fam1', 1 ).
test( 't10', 92, [], [], 'fam1', 1 ).
test( 't11', 687, [], [], 'fam1', 1 ).
test( 't12', 485, [], [], 'fam1', 1 ).
test( 't13', 727, [], [], 'fam1', 1 ).
test( 't14', 289, [], ['r9','r1','r2','r3','r4','r10','r7'], 'fam1', 1 ).
test( 't15', 118, [], [], 'fam1', 1 ).
test( 't16', 671, [], [], 'fam1', 1 ).
test( 't17', 675, [], [], 'fam1', 1 ).
test( 't18', 370, [], [], 'fam1', 1 ).
test( 't19', 539, ['m37','m30','m24','m10','m6','m34','m3','m23','m11','m49','m42','m44','m2','m5','m32','m22','m7','m38'], [], 'fam1', 1 ).
test( 't20', 300, [], [], 'fam1', 1 ).
test( 't21', 769, [], ['r1','r2','r4'], 'fam1', 1 ).
test( 't22', 515, ['m49','m7','m22','m44','m28','m8','m46','m27','m47','m50','m3','m14','m33','m18','m11','m32','m23'], ['r4','r7','r8','r9','r5','r6','r10'], 'fam1', 1 ).
test( 't23', 536, [], [], 'fam1', 1 ).
test( 't24', 683, [], [], 'fam1', 1 ).
test( 't25', 711, [], ['r6','r9','r4','r3','r7','r10','r1'], 'fam1', 1 ).
test( 't26', 409, ['m36','m26','m23','m44','m18','m29'], ['r6','r7','r5','r3','r4'], 'fam1', 1 ).
test( 't27', 710, [], ['r6'], 'fam1', 1 ).
test( 't28', 385, [], [], 'fam1', 1 ).
test( 't29', 243, [], [], 'fam1', 1 ).
test( 't30', 590, [], [], 'fam1', 1 ).
test( 't31', 359, ['m13','m25','m20','m6','m12','m31','m40','m49','m42','m2','m47','m37','m33','m41','m35','m16','m50'], [], 'fam1', 1 ).
test( 't32', 464, [], [], 'fam1', 1 ).
test( 't33', 319, ['m31','m29','m38','m20','m22'], [], 'fam1', 1 ).
test( 't34', 401, ['m31','m38','m16','m37','m10','m50','m33','m43','m36','m2','m11'], ['r3','r10','r4','r2','r9','r6'], 'fam1', 1 ).
test( 't35', 216, [], [], 'fam1', 1 ).
test( 't36', 714, [], [], 'fam1', 1 ).
test( 't37', 487, [], [], 'fam1', 1 ).
test( 't38', 510, [], ['r5','r4','r10','r1','r2','r3'], 'fam1', 1 ).
test( 't39', 719, ['m50','m19','m5','m20','m2'], [], 'fam1', 1 ).
test( 't40', 672, [], [], 'fam1', 1 ).
test( 't41', 764, [], [], 'fam1', 1 ).
test( 't42', 483, [], [], 'fam1', 1 ).
test( 't43', 62, [], [], 'fam1', 1 ).
test( 't44', 106, [], ['r5','r8','r4','r6','r10','r7','r2','r3','r1','r9'], 'fam1', 1 ).
test( 't45', 501, [], [], 'fam1', 1 ).
test( 't46', 382, ['m47','m37'], [], 'fam1', 1 ).
test( 't47', 791, [], [], 'fam1', 1 ).
test( 't48', 260, [], [], 'fam1', 1 ).
test( 't49', 734, [], [], 'fam1', 1 ).
test( 't50', 588, ['m30','m24','m18','m11','m39','m33','m15','m49','m8'], [], 'fam1', 1 ).
test( 't51', 710, [], [], 'fam1', 1 ).
test( 't52', 718, [], [], 'fam1', 1 ).
test( 't53', 613, ['m34','m33','m14','m41','m5','m3'], [], 'fam1', 1 ).
test( 't54', 648, ['m47'], ['r1','r2','r5','r4','r9'], 'fam1', 1 ).
test( 't55', 158, [], [], 'fam1', 1 ).
test( 't56', 760, [], [], 'fam1', 1 ).
test( 't57', 540, [], [], 'fam1', 1 ).
test( 't58', 248, [], [], 'fam1', 1 ).
test( 't59', 614, ['m9','m12','m50'], ['r7'], 'fam1', 1 ).
test( 't60', 457, [], ['r1'], 'fam1', 1 ).
test( 't61', 688, [], [], 'fam1', 1 ).
test( 't62', 418, [], [], 'fam1', 1 ).
test( 't63', 166, [], [], 'fam1', 1 ).
test( 't64', 299, [], [], 'fam1', 1 ).
test( 't65', 407, [], [], 'fam1', 1 ).
test( 't66', 679, [], [], 'fam1', 1 ).
test( 't67', 582, [], ['r1','r8','r7','r5','r4','r10','r6','r3'], 'fam1', 1 ).
test( 't68', 552, [], [], 'fam1', 1 ).
test( 't69', 497, ['m15','m41','m28','m35'], [], 'fam1', 1 ).
test( 't70', 363, [], [], 'fam1', 1 ).
test( 't71', 505, [], ['r5','r3','r8','r2','r7','r6','r10','r4','r1','r9'], 'fam1', 1 ).
test( 't72', 689, [], [], 'fam1', 1 ).
test( 't73', 476, ['m40','m23','m20','m50','m13','m42','m37','m30','m19','m7','m15','m16','m10','m33','m31','m22','m24'], ['r6','r4','r7','r9','r8','r5','r1','r3'], 'fam1', 1 ).
test( 't74', 115, [], [], 'fam1', 1 ).
test( 't75', 430, [], ['r1','r7','r9','r3','r10'], 'fam1', 1 ).
test( 't76', 144, [], [], 'fam1', 1 ).
test( 't77', 18, ['m2','m16'], ['r9','r4','r3','r7','r8','r2','r10','r6','r5','r1'], 'fam1', 1 ).
test( 't78', 757, ['m17','m47','m34','m28','m40','m12','m27','m9','m48','m31'], [], 'fam1', 1 ).
test( 't79', 284, [], [], 'fam1', 1 ).
test( 't80', 634, [], [], 'fam1', 1 ).
test( 't81', 638, [], [], 'fam1', 1 ).
test( 't82', 36, [], [], 'fam1', 1 ).
test( 't83', 130, [], [], 'fam1', 1 ).
test( 't84', 348, [], ['r5','r1'], 'fam1', 1 ).
test( 't85', 284, [], [], 'fam1', 1 ).
test( 't86', 624, [], [], 'fam1', 1 ).
test( 't87', 435, [], [], 'fam1', 1 ).
test( 't88', 328, [], [], 'fam1', 1 ).
test( 't89', 125, [], ['r2','r1','r7','r10','r8','r9','r5','r3','r4'], 'fam1', 1 ).
test( 't90', 583, [], [], 'fam1', 1 ).
test( 't91', 527, [], [], 'fam1', 1 ).
test( 't92', 501, [], ['r5','r8','r6','r7'], 'fam1', 1 ).
test( 't93', 272, [], [], 'fam1', 1 ).
test( 't94', 548, ['m20','m42','m26','m18','m30','m40','m27','m37','m32','m2','m13','m14','m15','m50','m4'], ['r5','r2','r8','r3','r1'], 'fam1', 1 ).
test( 't95', 655, [], [], 'fam1', 1 ).
test( 't96', 383, [], [], 'fam1', 1 ).
test( 't97', 567, ['m40','m2','m44','m7','m5','m19','m50'], [], 'fam1', 1 ).
test( 't98', 764, [], ['r6','r4','r2','r9','r3','r5'], 'fam1', 1 ).
test( 't99', 270, [], [], 'fam1', 1 ).
test( 't100', 189, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').
embedded_board( 'm21').
embedded_board( 'm22').
embedded_board( 'm23').
embedded_board( 'm24').
embedded_board( 'm25').
embedded_board( 'm26').
embedded_board( 'm27').
embedded_board( 'm28').
embedded_board( 'm29').
embedded_board( 'm30').
embedded_board( 'm31').
embedded_board( 'm32').
embedded_board( 'm33').
embedded_board( 'm34').
embedded_board( 'm35').
embedded_board( 'm36').
embedded_board( 'm37').
embedded_board( 'm38').
embedded_board( 'm39').
embedded_board( 'm40').
embedded_board( 'm41').
embedded_board( 'm42').
embedded_board( 'm43').
embedded_board( 'm44').
embedded_board( 'm45').
embedded_board( 'm46').
embedded_board( 'm47').
embedded_board( 'm48').
embedded_board( 'm49').
embedded_board( 'm50').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
