%% ****  Testsuite  ****
% Number of tests                  : 20
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 277, [], [], 'fam1', 1 ).
test( 't2', 489, [], ['r1','r5','r2'], 'fam1', 1 ).
test( 't3', 216, [], ['r3','r1'], 'fam1', 1 ).
test( 't4', 336, [], [], 'fam1', 1 ).
test( 't5', 175, [], ['r1','r3'], 'fam1', 1 ).
test( 't6', 669, [], [], 'fam1', 1 ).
test( 't7', 674, [], [], 'fam1', 1 ).
test( 't8', 312, [], ['r1'], 'fam1', 1 ).
test( 't9', 464, ['m7','m9'], [], 'fam1', 1 ).
test( 't10', 349, [], [], 'fam1', 1 ).
test( 't11', 146, [], ['r2','r1','r3','r4','r5'], 'fam1', 1 ).
test( 't12', 369, [], [], 'fam1', 1 ).
test( 't13', 343, [], [], 'fam1', 1 ).
test( 't14', 199, [], [], 'fam1', 1 ).
test( 't15', 711, [], [], 'fam1', 1 ).
test( 't16', 321, [], [], 'fam1', 1 ).
test( 't17', 666, [], [], 'fam1', 1 ).
test( 't18', 92, [], ['r1','r4','r2','r5'], 'fam1', 1 ).
test( 't19', 56, [], [], 'fam1', 1 ).
test( 't20', 330, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
