%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 20
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 116, [], [], 'fam1', 1 ).
test( 't2', 550, [], ['r2','r3','r4','r1','r5'], 'fam1', 1 ).
test( 't3', 16, [], [], 'fam1', 1 ).
test( 't4', 222, [], ['r2'], 'fam1', 1 ).
test( 't5', 531, [], [], 'fam1', 1 ).
test( 't6', 682, [], [], 'fam1', 1 ).
test( 't7', 275, [], [], 'fam1', 1 ).
test( 't8', 621, [], ['r3','r5','r4','r1'], 'fam1', 1 ).
test( 't9', 751, [], [], 'fam1', 1 ).
test( 't10', 575, [], [], 'fam1', 1 ).
test( 't11', 275, [], [], 'fam1', 1 ).
test( 't12', 3, [], [], 'fam1', 1 ).
test( 't13', 188, [], [], 'fam1', 1 ).
test( 't14', 651, [], [], 'fam1', 1 ).
test( 't15', 673, ['m3','m20'], ['r4','r5'], 'fam1', 1 ).
test( 't16', 438, [], [], 'fam1', 1 ).
test( 't17', 716, [], ['r5','r2','r4','r1'], 'fam1', 1 ).
test( 't18', 687, [], [], 'fam1', 1 ).
test( 't19', 367, [], ['r1','r4','r5','r2'], 'fam1', 1 ).
test( 't20', 99, [], [], 'fam1', 1 ).
test( 't21', 234, [], [], 'fam1', 1 ).
test( 't22', 282, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't23', 76, [], [], 'fam1', 1 ).
test( 't24', 35, [], ['r3','r4','r5','r2','r1'], 'fam1', 1 ).
test( 't25', 107, [], [], 'fam1', 1 ).
test( 't26', 147, [], [], 'fam1', 1 ).
test( 't27', 300, [], [], 'fam1', 1 ).
test( 't28', 262, [], [], 'fam1', 1 ).
test( 't29', 288, [], [], 'fam1', 1 ).
test( 't30', 623, [], [], 'fam1', 1 ).
test( 't31', 478, [], [], 'fam1', 1 ).
test( 't32', 161, [], [], 'fam1', 1 ).
test( 't33', 134, [], [], 'fam1', 1 ).
test( 't34', 528, [], ['r3','r5','r4','r2'], 'fam1', 1 ).
test( 't35', 253, [], [], 'fam1', 1 ).
test( 't36', 192, [], ['r5','r1','r4','r2','r3'], 'fam1', 1 ).
test( 't37', 297, [], ['r1'], 'fam1', 1 ).
test( 't38', 709, [], ['r3','r5'], 'fam1', 1 ).
test( 't39', 750, [], [], 'fam1', 1 ).
test( 't40', 322, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
