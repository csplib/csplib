%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 20
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 32, [], ['r2','r1'], 'fam1', 1 ).
test( 't2', 671, [], [], 'fam1', 1 ).
test( 't3', 113, [], [], 'fam1', 1 ).
test( 't4', 560, [], [], 'fam1', 1 ).
test( 't5', 693, [], [], 'fam1', 1 ).
test( 't6', 656, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't7', 376, [], [], 'fam1', 1 ).
test( 't8', 154, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't9', 543, [], ['r2'], 'fam1', 1 ).
test( 't10', 285, [], [], 'fam1', 1 ).
test( 't11', 355, [], [], 'fam1', 1 ).
test( 't12', 332, [], [], 'fam1', 1 ).
test( 't13', 221, [], ['r3','r1'], 'fam1', 1 ).
test( 't14', 670, [], [], 'fam1', 1 ).
test( 't15', 80, [], [], 'fam1', 1 ).
test( 't16', 90, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't17', 23, ['m5'], [], 'fam1', 1 ).
test( 't18', 99, ['m17','m16','m14','m10'], [], 'fam1', 1 ).
test( 't19', 307, [], [], 'fam1', 1 ).
test( 't20', 746, ['m1','m12','m6','m20'], ['r3','r1','r2'], 'fam1', 1 ).
test( 't21', 307, [], ['r1','r2'], 'fam1', 1 ).
test( 't22', 365, ['m6','m12','m13'], ['r2','r3','r1'], 'fam1', 1 ).
test( 't23', 54, [], [], 'fam1', 1 ).
test( 't24', 762, [], [], 'fam1', 1 ).
test( 't25', 602, ['m14','m20','m18','m7'], ['r3','r2','r1'], 'fam1', 1 ).
test( 't26', 174, ['m2','m7','m5','m13','m6'], [], 'fam1', 1 ).
test( 't27', 705, [], [], 'fam1', 1 ).
test( 't28', 801, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't29', 355, [], [], 'fam1', 1 ).
test( 't30', 305, [], [], 'fam1', 1 ).
test( 't31', 392, [], [], 'fam1', 1 ).
test( 't32', 742, [], [], 'fam1', 1 ).
test( 't33', 439, [], ['r1'], 'fam1', 1 ).
test( 't34', 281, ['m1'], [], 'fam1', 1 ).
test( 't35', 504, [], ['r2'], 'fam1', 1 ).
test( 't36', 798, [], [], 'fam1', 1 ).
test( 't37', 640, [], [], 'fam1', 1 ).
test( 't38', 372, [], [], 'fam1', 1 ).
test( 't39', 441, ['m18','m16','m11'], [], 'fam1', 1 ).
test( 't40', 18, [], ['r1'], 'fam1', 1 ).
test( 't41', 301, ['m11'], [], 'fam1', 1 ).
test( 't42', 221, [], [], 'fam1', 1 ).
test( 't43', 699, [], [], 'fam1', 1 ).
test( 't44', 16, ['m13','m15'], [], 'fam1', 1 ).
test( 't45', 374, [], [], 'fam1', 1 ).
test( 't46', 208, [], [], 'fam1', 1 ).
test( 't47', 210, [], [], 'fam1', 1 ).
test( 't48', 501, ['m9'], [], 'fam1', 1 ).
test( 't49', 395, [], ['r3'], 'fam1', 1 ).
test( 't50', 133, [], ['r2','r1','r3'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
