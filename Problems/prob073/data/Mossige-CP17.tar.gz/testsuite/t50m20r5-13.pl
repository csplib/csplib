%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 20
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 25, ['m4','m14','m13','m12','m19','m10','m6','m18'], ['r3','r5','r1'], 'fam1', 1 ).
test( 't2', 215, ['m18','m13'], ['r3','r2','r5','r4'], 'fam1', 1 ).
test( 't3', 12, [], [], 'fam1', 1 ).
test( 't4', 532, ['m17','m11','m20','m13','m7','m3'], ['r1'], 'fam1', 1 ).
test( 't5', 706, [], ['r3','r2'], 'fam1', 1 ).
test( 't6', 492, [], ['r2'], 'fam1', 1 ).
test( 't7', 130, ['m10','m13','m6','m18','m5','m15','m14','m3'], ['r1','r5','r4','r3','r2'], 'fam1', 1 ).
test( 't8', 654, [], [], 'fam1', 1 ).
test( 't9', 236, [], [], 'fam1', 1 ).
test( 't10', 65, [], [], 'fam1', 1 ).
test( 't11', 265, [], ['r1','r2','r3','r5'], 'fam1', 1 ).
test( 't12', 480, [], [], 'fam1', 1 ).
test( 't13', 465, [], ['r2','r5','r3'], 'fam1', 1 ).
test( 't14', 609, [], [], 'fam1', 1 ).
test( 't15', 708, ['m4','m12','m13','m19','m9','m5'], [], 'fam1', 1 ).
test( 't16', 558, ['m19'], [], 'fam1', 1 ).
test( 't17', 243, [], ['r5'], 'fam1', 1 ).
test( 't18', 660, [], ['r1','r3','r2','r4','r5'], 'fam1', 1 ).
test( 't19', 645, [], [], 'fam1', 1 ).
test( 't20', 411, ['m4','m6','m3','m16','m19','m5'], [], 'fam1', 1 ).
test( 't21', 315, [], [], 'fam1', 1 ).
test( 't22', 248, [], [], 'fam1', 1 ).
test( 't23', 625, [], ['r3','r2','r4','r1'], 'fam1', 1 ).
test( 't24', 543, [], [], 'fam1', 1 ).
test( 't25', 46, [], ['r1','r4','r3'], 'fam1', 1 ).
test( 't26', 647, [], [], 'fam1', 1 ).
test( 't27', 648, [], ['r3','r2','r4'], 'fam1', 1 ).
test( 't28', 517, [], [], 'fam1', 1 ).
test( 't29', 471, [], [], 'fam1', 1 ).
test( 't30', 516, [], ['r5','r1','r3'], 'fam1', 1 ).
test( 't31', 573, ['m4','m2','m17','m20','m3','m14','m13'], ['r1'], 'fam1', 1 ).
test( 't32', 119, ['m20','m16','m17','m19','m2','m10','m13'], [], 'fam1', 1 ).
test( 't33', 557, [], [], 'fam1', 1 ).
test( 't34', 329, [], [], 'fam1', 1 ).
test( 't35', 798, [], [], 'fam1', 1 ).
test( 't36', 781, [], [], 'fam1', 1 ).
test( 't37', 795, ['m4','m11'], [], 'fam1', 1 ).
test( 't38', 471, [], ['r3','r4','r1','r5','r2'], 'fam1', 1 ).
test( 't39', 725, [], [], 'fam1', 1 ).
test( 't40', 135, [], [], 'fam1', 1 ).
test( 't41', 625, [], [], 'fam1', 1 ).
test( 't42', 90, [], ['r4','r3','r1'], 'fam1', 1 ).
test( 't43', 512, [], [], 'fam1', 1 ).
test( 't44', 613, [], ['r2','r4'], 'fam1', 1 ).
test( 't45', 424, ['m11','m4'], [], 'fam1', 1 ).
test( 't46', 741, [], [], 'fam1', 1 ).
test( 't47', 233, ['m4','m19','m5'], [], 'fam1', 1 ).
test( 't48', 518, ['m12','m9','m14','m6','m13','m17','m1'], ['r3','r4'], 'fam1', 1 ).
test( 't49', 177, [], [], 'fam1', 1 ).
test( 't50', 374, [], ['r1','r3'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
