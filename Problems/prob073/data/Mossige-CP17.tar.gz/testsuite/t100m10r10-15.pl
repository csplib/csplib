%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 10
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 382, [], [], 'fam1', 1 ).
test( 't2', 386, [], [], 'fam1', 1 ).
test( 't3', 771, [], [], 'fam1', 1 ).
test( 't4', 158, [], [], 'fam1', 1 ).
test( 't5', 763, ['m2','m9','m10','m3'], ['r3','r8','r9','r6','r4','r1'], 'fam1', 1 ).
test( 't6', 382, [], ['r6','r3','r7','r10','r8'], 'fam1', 1 ).
test( 't7', 579, [], [], 'fam1', 1 ).
test( 't8', 159, [], [], 'fam1', 1 ).
test( 't9', 399, ['m4','m10','m7','m1'], ['r1','r7'], 'fam1', 1 ).
test( 't10', 259, ['m1','m2'], [], 'fam1', 1 ).
test( 't11', 716, ['m10','m7','m5','m8'], [], 'fam1', 1 ).
test( 't12', 622, [], ['r3','r10','r1','r4','r5'], 'fam1', 1 ).
test( 't13', 153, [], [], 'fam1', 1 ).
test( 't14', 172, [], ['r2','r8'], 'fam1', 1 ).
test( 't15', 27, [], [], 'fam1', 1 ).
test( 't16', 424, [], [], 'fam1', 1 ).
test( 't17', 315, ['m9','m3','m5'], [], 'fam1', 1 ).
test( 't18', 168, ['m7','m1','m4'], [], 'fam1', 1 ).
test( 't19', 636, [], ['r8','r10','r9','r1','r5'], 'fam1', 1 ).
test( 't20', 674, [], [], 'fam1', 1 ).
test( 't21', 607, [], ['r7','r1','r6','r9','r4'], 'fam1', 1 ).
test( 't22', 314, [], [], 'fam1', 1 ).
test( 't23', 758, [], [], 'fam1', 1 ).
test( 't24', 306, [], [], 'fam1', 1 ).
test( 't25', 238, [], ['r9'], 'fam1', 1 ).
test( 't26', 386, [], ['r6','r5','r10','r4','r8','r1','r3','r7','r2'], 'fam1', 1 ).
test( 't27', 384, [], [], 'fam1', 1 ).
test( 't28', 174, [], [], 'fam1', 1 ).
test( 't29', 390, [], [], 'fam1', 1 ).
test( 't30', 583, [], [], 'fam1', 1 ).
test( 't31', 90, [], ['r2','r5','r10','r3','r1','r9','r7','r4'], 'fam1', 1 ).
test( 't32', 594, ['m3','m9','m5','m1'], [], 'fam1', 1 ).
test( 't33', 711, [], ['r1','r8','r5'], 'fam1', 1 ).
test( 't34', 603, [], [], 'fam1', 1 ).
test( 't35', 506, [], [], 'fam1', 1 ).
test( 't36', 499, [], ['r2'], 'fam1', 1 ).
test( 't37', 77, [], [], 'fam1', 1 ).
test( 't38', 327, [], [], 'fam1', 1 ).
test( 't39', 319, [], [], 'fam1', 1 ).
test( 't40', 15, [], ['r8','r7','r1','r3'], 'fam1', 1 ).
test( 't41', 447, [], [], 'fam1', 1 ).
test( 't42', 307, [], [], 'fam1', 1 ).
test( 't43', 645, [], [], 'fam1', 1 ).
test( 't44', 692, [], [], 'fam1', 1 ).
test( 't45', 543, [], [], 'fam1', 1 ).
test( 't46', 84, [], [], 'fam1', 1 ).
test( 't47', 790, [], ['r3'], 'fam1', 1 ).
test( 't48', 275, [], ['r3','r7','r2','r10','r8','r4','r5'], 'fam1', 1 ).
test( 't49', 191, [], [], 'fam1', 1 ).
test( 't50', 106, [], [], 'fam1', 1 ).
test( 't51', 279, [], [], 'fam1', 1 ).
test( 't52', 89, [], [], 'fam1', 1 ).
test( 't53', 623, [], [], 'fam1', 1 ).
test( 't54', 490, ['m1','m9','m8','m2'], [], 'fam1', 1 ).
test( 't55', 134, [], [], 'fam1', 1 ).
test( 't56', 255, [], [], 'fam1', 1 ).
test( 't57', 474, [], [], 'fam1', 1 ).
test( 't58', 287, [], [], 'fam1', 1 ).
test( 't59', 209, [], ['r8','r2','r7','r10','r9','r5','r3','r1','r4','r6'], 'fam1', 1 ).
test( 't60', 574, [], ['r8','r1','r2','r7','r4','r10','r6','r3','r9','r5'], 'fam1', 1 ).
test( 't61', 89, [], [], 'fam1', 1 ).
test( 't62', 400, [], [], 'fam1', 1 ).
test( 't63', 58, [], [], 'fam1', 1 ).
test( 't64', 218, [], [], 'fam1', 1 ).
test( 't65', 265, ['m1','m5','m4','m2'], [], 'fam1', 1 ).
test( 't66', 366, ['m6','m3','m1'], [], 'fam1', 1 ).
test( 't67', 377, [], [], 'fam1', 1 ).
test( 't68', 356, ['m8','m2','m9','m7'], [], 'fam1', 1 ).
test( 't69', 448, [], [], 'fam1', 1 ).
test( 't70', 28, [], ['r10','r7','r8'], 'fam1', 1 ).
test( 't71', 596, [], [], 'fam1', 1 ).
test( 't72', 366, [], [], 'fam1', 1 ).
test( 't73', 741, [], [], 'fam1', 1 ).
test( 't74', 797, [], [], 'fam1', 1 ).
test( 't75', 769, ['m1'], [], 'fam1', 1 ).
test( 't76', 320, [], [], 'fam1', 1 ).
test( 't77', 641, [], [], 'fam1', 1 ).
test( 't78', 19, [], ['r9'], 'fam1', 1 ).
test( 't79', 741, ['m2','m10'], [], 'fam1', 1 ).
test( 't80', 496, ['m8'], [], 'fam1', 1 ).
test( 't81', 34, [], [], 'fam1', 1 ).
test( 't82', 229, [], [], 'fam1', 1 ).
test( 't83', 242, [], [], 'fam1', 1 ).
test( 't84', 408, ['m4','m7','m6','m3'], ['r7','r3','r2','r10','r4','r8'], 'fam1', 1 ).
test( 't85', 62, [], [], 'fam1', 1 ).
test( 't86', 504, [], [], 'fam1', 1 ).
test( 't87', 263, ['m10'], [], 'fam1', 1 ).
test( 't88', 253, [], [], 'fam1', 1 ).
test( 't89', 686, [], [], 'fam1', 1 ).
test( 't90', 436, [], [], 'fam1', 1 ).
test( 't91', 800, [], ['r2','r6'], 'fam1', 1 ).
test( 't92', 769, [], [], 'fam1', 1 ).
test( 't93', 30, [], [], 'fam1', 1 ).
test( 't94', 645, [], [], 'fam1', 1 ).
test( 't95', 695, [], [], 'fam1', 1 ).
test( 't96', 143, ['m7','m1','m4','m5'], ['r2'], 'fam1', 1 ).
test( 't97', 579, [], [], 'fam1', 1 ).
test( 't98', 637, [], ['r7','r9'], 'fam1', 1 ).
test( 't99', 594, ['m1','m7'], [], 'fam1', 1 ).
test( 't100', 637, [], ['r2'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
