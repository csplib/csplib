%% ****  Testsuite  ****
% Number of tests                  : 20
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 506, [], ['r2'], 'fam1', 1 ).
test( 't2', 517, [], [], 'fam1', 1 ).
test( 't3', 132, [], ['r3','r5','r4','r2'], 'fam1', 1 ).
test( 't4', 602, [], ['r2'], 'fam1', 1 ).
test( 't5', 272, [], [], 'fam1', 1 ).
test( 't6', 90, ['m8','m4'], [], 'fam1', 1 ).
test( 't7', 742, ['m8'], ['r5','r1'], 'fam1', 1 ).
test( 't8', 565, [], [], 'fam1', 1 ).
test( 't9', 93, [], [], 'fam1', 1 ).
test( 't10', 522, [], [], 'fam1', 1 ).
test( 't11', 669, [], [], 'fam1', 1 ).
test( 't12', 792, ['m6','m8','m1'], [], 'fam1', 1 ).
test( 't13', 190, [], ['r5','r3'], 'fam1', 1 ).
test( 't14', 680, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't15', 586, [], [], 'fam1', 1 ).
test( 't16', 525, [], [], 'fam1', 1 ).
test( 't17', 340, [], ['r2'], 'fam1', 1 ).
test( 't18', 488, [], [], 'fam1', 1 ).
test( 't19', 131, [], [], 'fam1', 1 ).
test( 't20', 590, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
