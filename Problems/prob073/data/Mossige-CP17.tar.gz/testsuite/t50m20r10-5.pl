%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 20
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 260, [], ['r6'], 'fam1', 1 ).
test( 't2', 27, [], ['r2'], 'fam1', 1 ).
test( 't3', 36, [], [], 'fam1', 1 ).
test( 't4', 99, ['m11','m16','m1','m20','m13','m2','m17'], [], 'fam1', 1 ).
test( 't5', 650, ['m9'], [], 'fam1', 1 ).
test( 't6', 525, [], [], 'fam1', 1 ).
test( 't7', 213, [], ['r10','r8','r6','r2','r5','r1','r3','r9','r4','r7'], 'fam1', 1 ).
test( 't8', 343, [], [], 'fam1', 1 ).
test( 't9', 380, [], [], 'fam1', 1 ).
test( 't10', 376, ['m16','m10','m7','m1','m18'], [], 'fam1', 1 ).
test( 't11', 186, [], [], 'fam1', 1 ).
test( 't12', 173, [], ['r4','r10','r5','r8','r1','r2','r7','r9','r3'], 'fam1', 1 ).
test( 't13', 705, [], [], 'fam1', 1 ).
test( 't14', 116, [], [], 'fam1', 1 ).
test( 't15', 524, [], [], 'fam1', 1 ).
test( 't16', 694, ['m13','m10','m18','m16','m8','m11','m4','m1'], [], 'fam1', 1 ).
test( 't17', 602, [], ['r7'], 'fam1', 1 ).
test( 't18', 737, [], [], 'fam1', 1 ).
test( 't19', 121, [], ['r10','r4','r1','r8','r6','r9','r7','r2','r3','r5'], 'fam1', 1 ).
test( 't20', 255, [], [], 'fam1', 1 ).
test( 't21', 636, [], [], 'fam1', 1 ).
test( 't22', 181, [], [], 'fam1', 1 ).
test( 't23', 631, [], [], 'fam1', 1 ).
test( 't24', 542, [], [], 'fam1', 1 ).
test( 't25', 606, [], [], 'fam1', 1 ).
test( 't26', 679, [], [], 'fam1', 1 ).
test( 't27', 99, [], [], 'fam1', 1 ).
test( 't28', 356, ['m3','m20','m7','m8','m18','m12','m13'], ['r1','r4','r3','r8','r7','r5','r9','r2','r10','r6'], 'fam1', 1 ).
test( 't29', 469, [], [], 'fam1', 1 ).
test( 't30', 446, [], [], 'fam1', 1 ).
test( 't31', 190, [], ['r9','r4','r2','r7','r8','r5','r1'], 'fam1', 1 ).
test( 't32', 659, [], [], 'fam1', 1 ).
test( 't33', 738, ['m8','m3'], [], 'fam1', 1 ).
test( 't34', 380, [], [], 'fam1', 1 ).
test( 't35', 574, [], [], 'fam1', 1 ).
test( 't36', 689, ['m17','m9','m6'], ['r3','r5','r6','r10','r8','r7','r9','r1'], 'fam1', 1 ).
test( 't37', 345, [], [], 'fam1', 1 ).
test( 't38', 729, [], [], 'fam1', 1 ).
test( 't39', 214, ['m12','m18','m3'], [], 'fam1', 1 ).
test( 't40', 4, [], [], 'fam1', 1 ).
test( 't41', 154, [], ['r6','r9','r7','r4'], 'fam1', 1 ).
test( 't42', 377, ['m3','m4','m5','m9','m11'], [], 'fam1', 1 ).
test( 't43', 139, [], [], 'fam1', 1 ).
test( 't44', 379, [], [], 'fam1', 1 ).
test( 't45', 503, [], ['r3','r2','r5','r8','r4','r6','r10','r9','r7','r1'], 'fam1', 1 ).
test( 't46', 691, [], [], 'fam1', 1 ).
test( 't47', 626, [], ['r5','r3'], 'fam1', 1 ).
test( 't48', 662, [], [], 'fam1', 1 ).
test( 't49', 300, [], ['r2','r5','r8','r3','r10','r1','r7','r6','r9'], 'fam1', 1 ).
test( 't50', 638, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
