%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 20
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 500, [], ['r1','r2','r4','r3','r5'], 'fam1', 1 ).
test( 't2', 14, [], ['r3'], 'fam1', 1 ).
test( 't3', 740, [], [], 'fam1', 1 ).
test( 't4', 682, [], [], 'fam1', 1 ).
test( 't5', 537, [], [], 'fam1', 1 ).
test( 't6', 419, [], ['r2','r4','r1','r5','r3'], 'fam1', 1 ).
test( 't7', 301, [], [], 'fam1', 1 ).
test( 't8', 219, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't9', 604, [], [], 'fam1', 1 ).
test( 't10', 563, [], ['r4','r3','r1','r2','r5'], 'fam1', 1 ).
test( 't11', 512, [], ['r5','r4','r3','r1','r2'], 'fam1', 1 ).
test( 't12', 313, [], ['r4','r3','r5','r1'], 'fam1', 1 ).
test( 't13', 201, [], [], 'fam1', 1 ).
test( 't14', 607, [], [], 'fam1', 1 ).
test( 't15', 314, [], [], 'fam1', 1 ).
test( 't16', 398, ['m6','m4','m2','m3','m1','m10'], ['r5','r2','r1','r3','r4'], 'fam1', 1 ).
test( 't17', 683, [], [], 'fam1', 1 ).
test( 't18', 454, [], [], 'fam1', 1 ).
test( 't19', 421, [], ['r2','r4','r5','r1','r3'], 'fam1', 1 ).
test( 't20', 312, ['m10','m14'], [], 'fam1', 1 ).
test( 't21', 731, [], [], 'fam1', 1 ).
test( 't22', 765, [], ['r4','r5','r3','r1','r2'], 'fam1', 1 ).
test( 't23', 494, [], [], 'fam1', 1 ).
test( 't24', 120, [], [], 'fam1', 1 ).
test( 't25', 612, ['m9','m15','m18','m17','m10'], ['r2','r4','r3','r1','r5'], 'fam1', 1 ).
test( 't26', 443, [], [], 'fam1', 1 ).
test( 't27', 105, [], [], 'fam1', 1 ).
test( 't28', 203, ['m10'], [], 'fam1', 1 ).
test( 't29', 594, [], [], 'fam1', 1 ).
test( 't30', 770, [], [], 'fam1', 1 ).
test( 't31', 168, ['m16','m9','m18','m1','m17'], [], 'fam1', 1 ).
test( 't32', 403, [], [], 'fam1', 1 ).
test( 't33', 242, [], [], 'fam1', 1 ).
test( 't34', 801, [], [], 'fam1', 1 ).
test( 't35', 551, ['m10','m4','m8','m12'], [], 'fam1', 1 ).
test( 't36', 88, [], ['r4','r2','r3'], 'fam1', 1 ).
test( 't37', 330, ['m9','m17','m2'], [], 'fam1', 1 ).
test( 't38', 585, [], [], 'fam1', 1 ).
test( 't39', 442, [], ['r2'], 'fam1', 1 ).
test( 't40', 367, [], [], 'fam1', 1 ).
test( 't41', 798, [], [], 'fam1', 1 ).
test( 't42', 634, [], [], 'fam1', 1 ).
test( 't43', 793, [], [], 'fam1', 1 ).
test( 't44', 300, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't45', 626, [], [], 'fam1', 1 ).
test( 't46', 70, ['m12','m16','m1','m15'], [], 'fam1', 1 ).
test( 't47', 522, [], [], 'fam1', 1 ).
test( 't48', 210, [], ['r2','r5','r4','r3'], 'fam1', 1 ).
test( 't49', 205, [], [], 'fam1', 1 ).
test( 't50', 481, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
