%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 20
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 697, [], [], 'fam1', 1 ).
test( 't2', 694, [], [], 'fam1', 1 ).
test( 't3', 284, [], [], 'fam1', 1 ).
test( 't4', 538, [], ['r6'], 'fam1', 1 ).
test( 't5', 662, [], [], 'fam1', 1 ).
test( 't6', 235, ['m20','m10','m13'], ['r2'], 'fam1', 1 ).
test( 't7', 135, [], [], 'fam1', 1 ).
test( 't8', 411, [], ['r1','r3'], 'fam1', 1 ).
test( 't9', 361, [], ['r8'], 'fam1', 1 ).
test( 't10', 281, [], [], 'fam1', 1 ).
test( 't11', 782, ['m9','m3','m12','m2','m20','m1','m4'], ['r6','r7','r10','r1','r8','r2','r4'], 'fam1', 1 ).
test( 't12', 230, [], [], 'fam1', 1 ).
test( 't13', 667, [], [], 'fam1', 1 ).
test( 't14', 31, ['m6'], ['r4','r3','r6','r2','r1','r9'], 'fam1', 1 ).
test( 't15', 189, [], [], 'fam1', 1 ).
test( 't16', 415, [], [], 'fam1', 1 ).
test( 't17', 789, [], ['r4','r2','r7'], 'fam1', 1 ).
test( 't18', 417, ['m15','m7','m13','m16','m14','m10'], [], 'fam1', 1 ).
test( 't19', 640, ['m20','m4','m10','m6','m19'], [], 'fam1', 1 ).
test( 't20', 618, ['m9','m6','m3'], ['r2','r7','r6','r4','r10','r1'], 'fam1', 1 ).
test( 't21', 606, [], ['r7','r6','r5','r1','r3','r8','r2'], 'fam1', 1 ).
test( 't22', 537, [], [], 'fam1', 1 ).
test( 't23', 263, [], ['r3','r9','r1','r6'], 'fam1', 1 ).
test( 't24', 617, ['m4'], [], 'fam1', 1 ).
test( 't25', 399, [], [], 'fam1', 1 ).
test( 't26', 452, [], [], 'fam1', 1 ).
test( 't27', 545, [], [], 'fam1', 1 ).
test( 't28', 522, [], ['r8'], 'fam1', 1 ).
test( 't29', 477, [], [], 'fam1', 1 ).
test( 't30', 340, [], [], 'fam1', 1 ).
test( 't31', 192, ['m3','m8','m5','m2','m19','m7','m12'], [], 'fam1', 1 ).
test( 't32', 590, [], [], 'fam1', 1 ).
test( 't33', 2, [], [], 'fam1', 1 ).
test( 't34', 360, ['m9','m20','m12','m1'], ['r8','r10','r5','r6','r7','r9','r1','r2'], 'fam1', 1 ).
test( 't35', 648, [], [], 'fam1', 1 ).
test( 't36', 708, [], ['r7','r3','r2','r6','r4','r10','r5'], 'fam1', 1 ).
test( 't37', 695, [], [], 'fam1', 1 ).
test( 't38', 38, ['m19','m18','m13','m15','m10','m8','m14'], [], 'fam1', 1 ).
test( 't39', 33, [], [], 'fam1', 1 ).
test( 't40', 169, [], ['r3','r10','r8','r7','r4'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
