%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 552, [], [], 'fam1', 1 ).
test( 't2', 116, [], ['r5','r3','r1'], 'fam1', 1 ).
test( 't3', 729, [], [], 'fam1', 1 ).
test( 't4', 72, ['m7','m4','m6'], [], 'fam1', 1 ).
test( 't5', 286, [], [], 'fam1', 1 ).
test( 't6', 443, [], [], 'fam1', 1 ).
test( 't7', 249, ['m2','m10','m4','m7'], [], 'fam1', 1 ).
test( 't8', 446, [], [], 'fam1', 1 ).
test( 't9', 712, [], [], 'fam1', 1 ).
test( 't10', 514, [], [], 'fam1', 1 ).
test( 't11', 638, [], [], 'fam1', 1 ).
test( 't12', 734, [], [], 'fam1', 1 ).
test( 't13', 800, ['m6','m3'], [], 'fam1', 1 ).
test( 't14', 186, [], ['r4','r2','r1','r5','r3'], 'fam1', 1 ).
test( 't15', 439, ['m1','m10','m2','m9'], [], 'fam1', 1 ).
test( 't16', 690, ['m4','m3','m8'], ['r4'], 'fam1', 1 ).
test( 't17', 693, [], ['r4','r2','r5','r1','r3'], 'fam1', 1 ).
test( 't18', 768, ['m4','m3'], ['r4','r3','r1','r2'], 'fam1', 1 ).
test( 't19', 673, ['m4','m6'], [], 'fam1', 1 ).
test( 't20', 40, [], [], 'fam1', 1 ).
test( 't21', 647, [], ['r2','r4','r1','r3','r5'], 'fam1', 1 ).
test( 't22', 25, [], [], 'fam1', 1 ).
test( 't23', 156, [], ['r3','r5','r1','r2','r4'], 'fam1', 1 ).
test( 't24', 29, ['m3','m10','m9','m8'], [], 'fam1', 1 ).
test( 't25', 757, [], [], 'fam1', 1 ).
test( 't26', 23, [], [], 'fam1', 1 ).
test( 't27', 603, [], ['r1','r4'], 'fam1', 1 ).
test( 't28', 656, ['m7','m3','m10','m2'], ['r1','r3'], 'fam1', 1 ).
test( 't29', 149, [], [], 'fam1', 1 ).
test( 't30', 723, [], ['r5','r1','r4','r2','r3'], 'fam1', 1 ).
test( 't31', 580, ['m4','m8'], ['r2','r1','r5','r4'], 'fam1', 1 ).
test( 't32', 143, [], [], 'fam1', 1 ).
test( 't33', 315, [], [], 'fam1', 1 ).
test( 't34', 285, ['m8','m1','m7','m5'], ['r1','r5','r2','r4'], 'fam1', 1 ).
test( 't35', 379, ['m1'], [], 'fam1', 1 ).
test( 't36', 212, [], [], 'fam1', 1 ).
test( 't37', 779, [], ['r2','r5','r3','r1','r4'], 'fam1', 1 ).
test( 't38', 135, ['m5','m1'], ['r1','r5','r4'], 'fam1', 1 ).
test( 't39', 136, [], ['r3'], 'fam1', 1 ).
test( 't40', 588, [], [], 'fam1', 1 ).
test( 't41', 94, [], ['r4','r2'], 'fam1', 1 ).
test( 't42', 217, [], [], 'fam1', 1 ).
test( 't43', 535, ['m4','m9','m2','m3'], ['r3','r4','r5'], 'fam1', 1 ).
test( 't44', 544, [], [], 'fam1', 1 ).
test( 't45', 345, [], [], 'fam1', 1 ).
test( 't46', 788, [], [], 'fam1', 1 ).
test( 't47', 373, [], ['r2','r4','r5','r1'], 'fam1', 1 ).
test( 't48', 9, [], ['r4','r3','r1'], 'fam1', 1 ).
test( 't49', 355, [], [], 'fam1', 1 ).
test( 't50', 195, [], ['r3','r1','r2','r4','r5'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
