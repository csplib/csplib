%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 334, [], [], 'fam1', 1 ).
test( 't2', 303, ['m4','m3'], ['r1','r2','r5'], 'fam1', 1 ).
test( 't3', 575, [], [], 'fam1', 1 ).
test( 't4', 9, [], [], 'fam1', 1 ).
test( 't5', 66, [], [], 'fam1', 1 ).
test( 't6', 466, [], [], 'fam1', 1 ).
test( 't7', 672, [], ['r1','r3'], 'fam1', 1 ).
test( 't8', 739, [], ['r5','r2'], 'fam1', 1 ).
test( 't9', 506, [], [], 'fam1', 1 ).
test( 't10', 89, [], [], 'fam1', 1 ).
test( 't11', 243, [], ['r2','r3'], 'fam1', 1 ).
test( 't12', 602, [], [], 'fam1', 1 ).
test( 't13', 534, [], ['r1','r5','r3'], 'fam1', 1 ).
test( 't14', 696, ['m1','m3','m9','m10'], [], 'fam1', 1 ).
test( 't15', 495, [], [], 'fam1', 1 ).
test( 't16', 669, [], [], 'fam1', 1 ).
test( 't17', 698, [], [], 'fam1', 1 ).
test( 't18', 587, [], ['r4','r5','r3'], 'fam1', 1 ).
test( 't19', 445, [], [], 'fam1', 1 ).
test( 't20', 799, [], [], 'fam1', 1 ).
test( 't21', 281, [], ['r4','r1'], 'fam1', 1 ).
test( 't22', 198, ['m8'], [], 'fam1', 1 ).
test( 't23', 738, [], ['r1','r4','r5','r3','r2'], 'fam1', 1 ).
test( 't24', 212, ['m9','m4','m8'], [], 'fam1', 1 ).
test( 't25', 352, [], ['r3','r5'], 'fam1', 1 ).
test( 't26', 486, [], [], 'fam1', 1 ).
test( 't27', 638, [], ['r1','r3'], 'fam1', 1 ).
test( 't28', 445, [], [], 'fam1', 1 ).
test( 't29', 87, [], [], 'fam1', 1 ).
test( 't30', 504, ['m4','m9','m8','m2'], [], 'fam1', 1 ).
test( 't31', 624, [], ['r3','r2'], 'fam1', 1 ).
test( 't32', 307, ['m8','m7','m3'], [], 'fam1', 1 ).
test( 't33', 201, [], [], 'fam1', 1 ).
test( 't34', 782, ['m3'], [], 'fam1', 1 ).
test( 't35', 98, [], [], 'fam1', 1 ).
test( 't36', 473, [], [], 'fam1', 1 ).
test( 't37', 704, [], [], 'fam1', 1 ).
test( 't38', 405, ['m8'], [], 'fam1', 1 ).
test( 't39', 781, [], ['r2','r3','r4','r5'], 'fam1', 1 ).
test( 't40', 171, [], ['r5','r4','r2','r1','r3'], 'fam1', 1 ).
test( 't41', 191, [], ['r1','r3'], 'fam1', 1 ).
test( 't42', 355, ['m1','m8'], [], 'fam1', 1 ).
test( 't43', 489, [], [], 'fam1', 1 ).
test( 't44', 665, [], [], 'fam1', 1 ).
test( 't45', 50, [], [], 'fam1', 1 ).
test( 't46', 89, ['m2','m5','m3'], ['r4','r2','r3','r1'], 'fam1', 1 ).
test( 't47', 462, [], ['r2','r5','r4','r1','r3'], 'fam1', 1 ).
test( 't48', 645, [], ['r2','r1'], 'fam1', 1 ).
test( 't49', 112, ['m1','m2'], [], 'fam1', 1 ).
test( 't50', 55, ['m8'], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
