%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 20
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 652, [], [], 'fam1', 1 ).
test( 't2', 106, [], [], 'fam1', 1 ).
test( 't3', 554, [], [], 'fam1', 1 ).
test( 't4', 335, [], [], 'fam1', 1 ).
test( 't5', 12, [], [], 'fam1', 1 ).
test( 't6', 792, [], ['r5','r3','r4','r2','r1'], 'fam1', 1 ).
test( 't7', 583, [], [], 'fam1', 1 ).
test( 't8', 568, [], [], 'fam1', 1 ).
test( 't9', 532, [], [], 'fam1', 1 ).
test( 't10', 554, [], [], 'fam1', 1 ).
test( 't11', 44, [], ['r2','r4','r3','r5','r1'], 'fam1', 1 ).
test( 't12', 93, [], ['r1','r3','r5','r2','r4'], 'fam1', 1 ).
test( 't13', 193, ['m7','m2','m17','m4'], [], 'fam1', 1 ).
test( 't14', 156, [], [], 'fam1', 1 ).
test( 't15', 241, [], [], 'fam1', 1 ).
test( 't16', 664, ['m13','m17','m6','m15','m1','m3','m16'], [], 'fam1', 1 ).
test( 't17', 474, [], ['r4','r3','r5','r1'], 'fam1', 1 ).
test( 't18', 48, [], ['r5'], 'fam1', 1 ).
test( 't19', 346, [], [], 'fam1', 1 ).
test( 't20', 288, ['m2','m13'], [], 'fam1', 1 ).
test( 't21', 385, [], [], 'fam1', 1 ).
test( 't22', 518, [], [], 'fam1', 1 ).
test( 't23', 736, [], [], 'fam1', 1 ).
test( 't24', 589, [], ['r2'], 'fam1', 1 ).
test( 't25', 482, ['m6','m16','m17','m15','m14'], [], 'fam1', 1 ).
test( 't26', 233, [], ['r4','r1','r5','r2','r3'], 'fam1', 1 ).
test( 't27', 179, [], [], 'fam1', 1 ).
test( 't28', 134, [], [], 'fam1', 1 ).
test( 't29', 331, [], [], 'fam1', 1 ).
test( 't30', 567, [], ['r5','r3','r1','r4'], 'fam1', 1 ).
test( 't31', 702, [], [], 'fam1', 1 ).
test( 't32', 624, [], [], 'fam1', 1 ).
test( 't33', 343, [], [], 'fam1', 1 ).
test( 't34', 791, [], [], 'fam1', 1 ).
test( 't35', 349, [], ['r1','r4'], 'fam1', 1 ).
test( 't36', 23, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't37', 620, [], [], 'fam1', 1 ).
test( 't38', 257, [], [], 'fam1', 1 ).
test( 't39', 210, [], ['r2','r1'], 'fam1', 1 ).
test( 't40', 449, [], [], 'fam1', 1 ).
test( 't41', 496, [], [], 'fam1', 1 ).
test( 't42', 113, [], [], 'fam1', 1 ).
test( 't43', 525, [], ['r4','r5','r3','r2'], 'fam1', 1 ).
test( 't44', 801, [], ['r3'], 'fam1', 1 ).
test( 't45', 459, [], [], 'fam1', 1 ).
test( 't46', 53, [], [], 'fam1', 1 ).
test( 't47', 176, [], [], 'fam1', 1 ).
test( 't48', 456, [], [], 'fam1', 1 ).
test( 't49', 321, ['m15'], ['r5'], 'fam1', 1 ).
test( 't50', 53, [], [], 'fam1', 1 ).
test( 't51', 136, [], [], 'fam1', 1 ).
test( 't52', 339, [], [], 'fam1', 1 ).
test( 't53', 126, [], [], 'fam1', 1 ).
test( 't54', 212, [], [], 'fam1', 1 ).
test( 't55', 180, ['m18','m8','m13','m14','m11','m4','m17'], [], 'fam1', 1 ).
test( 't56', 753, ['m2','m11','m15','m7','m18','m14'], [], 'fam1', 1 ).
test( 't57', 781, [], [], 'fam1', 1 ).
test( 't58', 121, [], [], 'fam1', 1 ).
test( 't59', 183, [], [], 'fam1', 1 ).
test( 't60', 219, [], [], 'fam1', 1 ).
test( 't61', 72, [], [], 'fam1', 1 ).
test( 't62', 50, [], [], 'fam1', 1 ).
test( 't63', 546, [], [], 'fam1', 1 ).
test( 't64', 280, [], [], 'fam1', 1 ).
test( 't65', 719, ['m7','m18','m3','m11','m19','m2','m20','m13'], ['r5'], 'fam1', 1 ).
test( 't66', 559, [], ['r1','r3'], 'fam1', 1 ).
test( 't67', 668, [], ['r1','r3'], 'fam1', 1 ).
test( 't68', 274, ['m8','m1'], [], 'fam1', 1 ).
test( 't69', 574, ['m17','m20'], [], 'fam1', 1 ).
test( 't70', 382, [], ['r3','r1'], 'fam1', 1 ).
test( 't71', 752, [], ['r4','r5','r2'], 'fam1', 1 ).
test( 't72', 775, [], [], 'fam1', 1 ).
test( 't73', 666, [], [], 'fam1', 1 ).
test( 't74', 423, [], [], 'fam1', 1 ).
test( 't75', 634, [], ['r3','r5','r2','r4','r1'], 'fam1', 1 ).
test( 't76', 383, ['m11','m10'], [], 'fam1', 1 ).
test( 't77', 397, [], [], 'fam1', 1 ).
test( 't78', 331, ['m7','m11'], [], 'fam1', 1 ).
test( 't79', 799, [], [], 'fam1', 1 ).
test( 't80', 685, [], [], 'fam1', 1 ).
test( 't81', 333, [], ['r4','r1','r2'], 'fam1', 1 ).
test( 't82', 748, [], ['r2','r5'], 'fam1', 1 ).
test( 't83', 34, [], [], 'fam1', 1 ).
test( 't84', 355, [], [], 'fam1', 1 ).
test( 't85', 50, [], [], 'fam1', 1 ).
test( 't86', 3, [], [], 'fam1', 1 ).
test( 't87', 6, [], [], 'fam1', 1 ).
test( 't88', 75, [], [], 'fam1', 1 ).
test( 't89', 632, [], ['r2','r1'], 'fam1', 1 ).
test( 't90', 159, [], [], 'fam1', 1 ).
test( 't91', 535, ['m20','m11','m10','m8','m17','m5','m14','m19'], [], 'fam1', 1 ).
test( 't92', 589, [], [], 'fam1', 1 ).
test( 't93', 576, [], [], 'fam1', 1 ).
test( 't94', 171, [], [], 'fam1', 1 ).
test( 't95', 546, [], ['r2','r5','r4'], 'fam1', 1 ).
test( 't96', 155, [], [], 'fam1', 1 ).
test( 't97', 22, [], [], 'fam1', 1 ).
test( 't98', 266, ['m7'], ['r4','r3'], 'fam1', 1 ).
test( 't99', 28, [], ['r4','r1','r3','r2'], 'fam1', 1 ).
test( 't100', 322, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
