%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 20
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 631, ['m7','m12','m4','m6','m9','m2','m20','m17'], ['r10','r6','r9','r3','r4'], 'fam1', 1 ).
test( 't2', 302, [], [], 'fam1', 1 ).
test( 't3', 181, [], [], 'fam1', 1 ).
test( 't4', 266, [], [], 'fam1', 1 ).
test( 't5', 590, [], ['r5','r4','r9','r1','r3','r10','r7','r2','r6'], 'fam1', 1 ).
test( 't6', 684, [], ['r8'], 'fam1', 1 ).
test( 't7', 786, [], [], 'fam1', 1 ).
test( 't8', 375, [], [], 'fam1', 1 ).
test( 't9', 556, [], [], 'fam1', 1 ).
test( 't10', 735, [], ['r5'], 'fam1', 1 ).
test( 't11', 407, [], [], 'fam1', 1 ).
test( 't12', 597, [], ['r2','r10','r3','r6','r7','r4','r5','r8','r9'], 'fam1', 1 ).
test( 't13', 487, ['m7','m11','m20'], ['r1','r8','r10','r7','r4','r9','r3','r6'], 'fam1', 1 ).
test( 't14', 62, [], [], 'fam1', 1 ).
test( 't15', 304, [], [], 'fam1', 1 ).
test( 't16', 156, [], [], 'fam1', 1 ).
test( 't17', 660, ['m10','m17','m19','m5','m18','m14'], [], 'fam1', 1 ).
test( 't18', 553, ['m3','m6','m14','m12','m19','m2','m5'], [], 'fam1', 1 ).
test( 't19', 492, [], [], 'fam1', 1 ).
test( 't20', 242, [], [], 'fam1', 1 ).
test( 't21', 613, [], [], 'fam1', 1 ).
test( 't22', 576, [], [], 'fam1', 1 ).
test( 't23', 16, [], [], 'fam1', 1 ).
test( 't24', 632, [], ['r6','r1','r9','r3','r7','r4','r5','r2','r8'], 'fam1', 1 ).
test( 't25', 667, [], [], 'fam1', 1 ).
test( 't26', 693, [], [], 'fam1', 1 ).
test( 't27', 559, [], [], 'fam1', 1 ).
test( 't28', 659, ['m9','m20','m6','m7','m3','m2'], [], 'fam1', 1 ).
test( 't29', 275, [], [], 'fam1', 1 ).
test( 't30', 386, [], [], 'fam1', 1 ).
test( 't31', 712, ['m11','m17','m1','m8','m18','m16','m5','m20'], [], 'fam1', 1 ).
test( 't32', 205, [], [], 'fam1', 1 ).
test( 't33', 764, [], [], 'fam1', 1 ).
test( 't34', 132, [], [], 'fam1', 1 ).
test( 't35', 74, [], [], 'fam1', 1 ).
test( 't36', 76, [], [], 'fam1', 1 ).
test( 't37', 544, [], [], 'fam1', 1 ).
test( 't38', 175, [], ['r5','r3','r6','r8','r7'], 'fam1', 1 ).
test( 't39', 313, ['m16','m6','m13','m11'], [], 'fam1', 1 ).
test( 't40', 153, [], ['r9','r2','r6','r4','r8'], 'fam1', 1 ).
test( 't41', 345, [], [], 'fam1', 1 ).
test( 't42', 254, ['m8','m6','m3','m7','m11','m16','m1','m9'], ['r6'], 'fam1', 1 ).
test( 't43', 190, [], [], 'fam1', 1 ).
test( 't44', 594, ['m19','m6','m9'], [], 'fam1', 1 ).
test( 't45', 559, [], [], 'fam1', 1 ).
test( 't46', 520, [], [], 'fam1', 1 ).
test( 't47', 513, [], ['r1','r7'], 'fam1', 1 ).
test( 't48', 448, [], [], 'fam1', 1 ).
test( 't49', 708, [], [], 'fam1', 1 ).
test( 't50', 111, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
