%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 642, [], [], 'fam1', 1 ).
test( 't2', 352, [], [], 'fam1', 1 ).
test( 't3', 495, [], [], 'fam1', 1 ).
test( 't4', 155, ['m6'], ['r1','r3'], 'fam1', 1 ).
test( 't5', 585, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't6', 191, [], ['r1'], 'fam1', 1 ).
test( 't7', 380, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't8', 763, ['m2'], [], 'fam1', 1 ).
test( 't9', 631, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't10', 715, [], [], 'fam1', 1 ).
test( 't11', 311, [], [], 'fam1', 1 ).
test( 't12', 114, ['m5','m7'], ['r2','r3'], 'fam1', 1 ).
test( 't13', 661, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't14', 89, [], [], 'fam1', 1 ).
test( 't15', 293, [], [], 'fam1', 1 ).
test( 't16', 650, [], [], 'fam1', 1 ).
test( 't17', 131, ['m5','m1','m9'], [], 'fam1', 1 ).
test( 't18', 283, ['m9'], [], 'fam1', 1 ).
test( 't19', 17, [], [], 'fam1', 1 ).
test( 't20', 155, [], [], 'fam1', 1 ).
test( 't21', 647, [], [], 'fam1', 1 ).
test( 't22', 72, ['m4','m2','m5'], [], 'fam1', 1 ).
test( 't23', 587, ['m9','m4','m10','m6'], ['r3','r1','r2'], 'fam1', 1 ).
test( 't24', 406, [], ['r2','r3'], 'fam1', 1 ).
test( 't25', 511, ['m2','m1'], [], 'fam1', 1 ).
test( 't26', 434, [], ['r3','r1'], 'fam1', 1 ).
test( 't27', 787, [], ['r2'], 'fam1', 1 ).
test( 't28', 59, [], [], 'fam1', 1 ).
test( 't29', 738, [], ['r1'], 'fam1', 1 ).
test( 't30', 246, [], [], 'fam1', 1 ).
test( 't31', 709, [], [], 'fam1', 1 ).
test( 't32', 593, [], [], 'fam1', 1 ).
test( 't33', 642, [], [], 'fam1', 1 ).
test( 't34', 335, [], ['r1'], 'fam1', 1 ).
test( 't35', 420, [], [], 'fam1', 1 ).
test( 't36', 673, [], ['r1','r2'], 'fam1', 1 ).
test( 't37', 83, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't38', 463, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't39', 187, ['m2'], [], 'fam1', 1 ).
test( 't40', 577, [], ['r1'], 'fam1', 1 ).
test( 't41', 785, [], [], 'fam1', 1 ).
test( 't42', 640, [], [], 'fam1', 1 ).
test( 't43', 265, ['m5','m8','m2'], [], 'fam1', 1 ).
test( 't44', 687, ['m1','m5'], [], 'fam1', 1 ).
test( 't45', 639, [], [], 'fam1', 1 ).
test( 't46', 284, [], [], 'fam1', 1 ).
test( 't47', 770, ['m9'], [], 'fam1', 1 ).
test( 't48', 189, [], ['r3'], 'fam1', 1 ).
test( 't49', 279, ['m8','m7'], ['r3'], 'fam1', 1 ).
test( 't50', 39, [], [], 'fam1', 1 ).
test( 't51', 466, [], [], 'fam1', 1 ).
test( 't52', 392, [], ['r1','r2'], 'fam1', 1 ).
test( 't53', 742, ['m6','m7'], [], 'fam1', 1 ).
test( 't54', 275, [], ['r2','r3'], 'fam1', 1 ).
test( 't55', 591, [], [], 'fam1', 1 ).
test( 't56', 114, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't57', 478, [], [], 'fam1', 1 ).
test( 't58', 473, [], [], 'fam1', 1 ).
test( 't59', 613, [], ['r2'], 'fam1', 1 ).
test( 't60', 684, [], [], 'fam1', 1 ).
test( 't61', 385, ['m2','m4','m1','m8'], [], 'fam1', 1 ).
test( 't62', 742, [], [], 'fam1', 1 ).
test( 't63', 428, [], [], 'fam1', 1 ).
test( 't64', 769, ['m7','m8','m1'], [], 'fam1', 1 ).
test( 't65', 617, ['m7','m5','m1'], ['r2','r3'], 'fam1', 1 ).
test( 't66', 685, [], [], 'fam1', 1 ).
test( 't67', 754, ['m5','m7'], [], 'fam1', 1 ).
test( 't68', 185, [], [], 'fam1', 1 ).
test( 't69', 538, [], [], 'fam1', 1 ).
test( 't70', 685, ['m7','m5'], ['r3','r2'], 'fam1', 1 ).
test( 't71', 421, [], [], 'fam1', 1 ).
test( 't72', 678, [], [], 'fam1', 1 ).
test( 't73', 252, [], [], 'fam1', 1 ).
test( 't74', 674, ['m10','m4','m5'], [], 'fam1', 1 ).
test( 't75', 698, [], ['r2','r1'], 'fam1', 1 ).
test( 't76', 694, [], [], 'fam1', 1 ).
test( 't77', 537, ['m6','m9','m10'], ['r1','r3','r2'], 'fam1', 1 ).
test( 't78', 593, [], [], 'fam1', 1 ).
test( 't79', 639, [], [], 'fam1', 1 ).
test( 't80', 333, ['m7','m6','m3','m5'], [], 'fam1', 1 ).
test( 't81', 566, [], [], 'fam1', 1 ).
test( 't82', 704, ['m10'], [], 'fam1', 1 ).
test( 't83', 180, ['m5','m3'], [], 'fam1', 1 ).
test( 't84', 52, ['m8','m6','m4'], [], 'fam1', 1 ).
test( 't85', 374, ['m3','m9','m5','m8'], ['r2','r1','r3'], 'fam1', 1 ).
test( 't86', 383, [], ['r2'], 'fam1', 1 ).
test( 't87', 599, ['m4'], ['r2','r3'], 'fam1', 1 ).
test( 't88', 174, ['m2','m6','m1','m7'], [], 'fam1', 1 ).
test( 't89', 353, [], ['r2'], 'fam1', 1 ).
test( 't90', 322, [], [], 'fam1', 1 ).
test( 't91', 567, ['m1','m7','m6'], [], 'fam1', 1 ).
test( 't92', 9, [], [], 'fam1', 1 ).
test( 't93', 358, [], [], 'fam1', 1 ).
test( 't94', 569, [], [], 'fam1', 1 ).
test( 't95', 71, [], [], 'fam1', 1 ).
test( 't96', 224, [], ['r3'], 'fam1', 1 ).
test( 't97', 398, [], [], 'fam1', 1 ).
test( 't98', 126, [], ['r1'], 'fam1', 1 ).
test( 't99', 602, [], [], 'fam1', 1 ).
test( 't100', 194, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
