%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 84, [], [], 'fam1', 1 ).
test( 't2', 494, [], [], 'fam1', 1 ).
test( 't3', 43, [], [], 'fam1', 1 ).
test( 't4', 130, [], [], 'fam1', 1 ).
test( 't5', 262, [], [], 'fam1', 1 ).
test( 't6', 534, [], [], 'fam1', 1 ).
test( 't7', 160, ['m1'], [], 'fam1', 1 ).
test( 't8', 54, [], ['r3','r1','r5','r2'], 'fam1', 1 ).
test( 't9', 789, ['m4','m3','m7','m9'], ['r1','r4','r5','r3'], 'fam1', 1 ).
test( 't10', 341, [], ['r2'], 'fam1', 1 ).
test( 't11', 792, ['m8','m5','m2','m4'], [], 'fam1', 1 ).
test( 't12', 485, [], [], 'fam1', 1 ).
test( 't13', 763, [], [], 'fam1', 1 ).
test( 't14', 793, [], [], 'fam1', 1 ).
test( 't15', 153, [], [], 'fam1', 1 ).
test( 't16', 46, [], [], 'fam1', 1 ).
test( 't17', 723, [], ['r5','r4','r3','r2','r1'], 'fam1', 1 ).
test( 't18', 785, [], ['r5','r4','r2','r3','r1'], 'fam1', 1 ).
test( 't19', 658, [], [], 'fam1', 1 ).
test( 't20', 212, [], [], 'fam1', 1 ).
test( 't21', 309, [], [], 'fam1', 1 ).
test( 't22', 398, [], [], 'fam1', 1 ).
test( 't23', 422, [], [], 'fam1', 1 ).
test( 't24', 385, [], [], 'fam1', 1 ).
test( 't25', 564, [], [], 'fam1', 1 ).
test( 't26', 571, [], ['r2'], 'fam1', 1 ).
test( 't27', 271, [], ['r3'], 'fam1', 1 ).
test( 't28', 13, [], ['r3','r2'], 'fam1', 1 ).
test( 't29', 287, [], [], 'fam1', 1 ).
test( 't30', 167, [], [], 'fam1', 1 ).
test( 't31', 498, [], ['r2','r3'], 'fam1', 1 ).
test( 't32', 227, [], [], 'fam1', 1 ).
test( 't33', 786, [], [], 'fam1', 1 ).
test( 't34', 485, [], [], 'fam1', 1 ).
test( 't35', 58, [], [], 'fam1', 1 ).
test( 't36', 109, ['m4','m9'], [], 'fam1', 1 ).
test( 't37', 333, [], [], 'fam1', 1 ).
test( 't38', 371, [], ['r5','r2','r4'], 'fam1', 1 ).
test( 't39', 459, [], ['r1','r2','r5'], 'fam1', 1 ).
test( 't40', 335, [], ['r1','r5'], 'fam1', 1 ).
test( 't41', 664, ['m7','m8','m9'], [], 'fam1', 1 ).
test( 't42', 730, ['m3'], [], 'fam1', 1 ).
test( 't43', 737, [], [], 'fam1', 1 ).
test( 't44', 342, [], ['r5','r2','r1','r4','r3'], 'fam1', 1 ).
test( 't45', 758, [], [], 'fam1', 1 ).
test( 't46', 768, [], [], 'fam1', 1 ).
test( 't47', 164, [], ['r4','r5','r3'], 'fam1', 1 ).
test( 't48', 163, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't49', 147, [], ['r1'], 'fam1', 1 ).
test( 't50', 347, ['m10','m2','m7'], ['r2','r5','r3','r4'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
