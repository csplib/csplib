%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 20
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 343, ['m18'], [], 'fam1', 1 ).
test( 't2', 477, [], ['r4'], 'fam1', 1 ).
test( 't3', 654, [], [], 'fam1', 1 ).
test( 't4', 224, [], [], 'fam1', 1 ).
test( 't5', 792, [], [], 'fam1', 1 ).
test( 't6', 73, ['m2','m20','m10','m5'], [], 'fam1', 1 ).
test( 't7', 470, [], ['r5'], 'fam1', 1 ).
test( 't8', 223, [], [], 'fam1', 1 ).
test( 't9', 303, [], ['r5','r8','r2','r7','r9','r6','r3'], 'fam1', 1 ).
test( 't10', 545, [], [], 'fam1', 1 ).
test( 't11', 94, [], ['r9','r1','r3','r6','r8','r2','r4','r7','r5'], 'fam1', 1 ).
test( 't12', 519, [], [], 'fam1', 1 ).
test( 't13', 662, ['m12','m14','m5','m7','m19','m18','m10'], [], 'fam1', 1 ).
test( 't14', 717, [], [], 'fam1', 1 ).
test( 't15', 513, [], [], 'fam1', 1 ).
test( 't16', 737, [], [], 'fam1', 1 ).
test( 't17', 363, [], [], 'fam1', 1 ).
test( 't18', 640, [], ['r9','r8'], 'fam1', 1 ).
test( 't19', 65, [], [], 'fam1', 1 ).
test( 't20', 79, [], [], 'fam1', 1 ).
test( 't21', 169, [], ['r5','r6','r2','r9','r1'], 'fam1', 1 ).
test( 't22', 621, [], ['r6','r8'], 'fam1', 1 ).
test( 't23', 295, ['m18','m6','m3'], [], 'fam1', 1 ).
test( 't24', 55, [], ['r9','r7','r6','r8'], 'fam1', 1 ).
test( 't25', 205, ['m14'], [], 'fam1', 1 ).
test( 't26', 83, ['m15','m14','m2','m17','m18','m7'], [], 'fam1', 1 ).
test( 't27', 591, [], [], 'fam1', 1 ).
test( 't28', 627, [], [], 'fam1', 1 ).
test( 't29', 707, ['m13','m4','m14','m2','m6'], [], 'fam1', 1 ).
test( 't30', 611, ['m8'], [], 'fam1', 1 ).
test( 't31', 555, [], [], 'fam1', 1 ).
test( 't32', 781, [], [], 'fam1', 1 ).
test( 't33', 22, [], ['r5','r6','r7','r10','r3','r8','r2'], 'fam1', 1 ).
test( 't34', 584, ['m3'], [], 'fam1', 1 ).
test( 't35', 499, [], [], 'fam1', 1 ).
test( 't36', 83, [], ['r3','r10','r7','r8','r5','r6','r9'], 'fam1', 1 ).
test( 't37', 623, [], [], 'fam1', 1 ).
test( 't38', 656, [], [], 'fam1', 1 ).
test( 't39', 782, [], ['r3','r8','r2','r9','r6','r4','r10','r7','r5','r1'], 'fam1', 1 ).
test( 't40', 569, [], [], 'fam1', 1 ).
test( 't41', 138, [], ['r9','r5','r3','r1','r10','r7','r8','r6','r4'], 'fam1', 1 ).
test( 't42', 588, [], [], 'fam1', 1 ).
test( 't43', 311, [], [], 'fam1', 1 ).
test( 't44', 490, ['m1','m12','m8','m4','m2'], [], 'fam1', 1 ).
test( 't45', 51, [], [], 'fam1', 1 ).
test( 't46', 83, ['m11','m14'], ['r10','r6','r7'], 'fam1', 1 ).
test( 't47', 269, [], ['r2','r9'], 'fam1', 1 ).
test( 't48', 431, [], ['r2','r5','r7','r4','r3','r1','r8','r6','r10'], 'fam1', 1 ).
test( 't49', 442, [], [], 'fam1', 1 ).
test( 't50', 278, [], ['r9','r8'], 'fam1', 1 ).
test( 't51', 425, [], [], 'fam1', 1 ).
test( 't52', 353, [], [], 'fam1', 1 ).
test( 't53', 391, [], ['r5','r9','r6','r1','r10'], 'fam1', 1 ).
test( 't54', 122, [], ['r3','r1','r10','r6','r4'], 'fam1', 1 ).
test( 't55', 235, [], ['r8','r1'], 'fam1', 1 ).
test( 't56', 271, [], [], 'fam1', 1 ).
test( 't57', 201, [], [], 'fam1', 1 ).
test( 't58', 763, [], [], 'fam1', 1 ).
test( 't59', 1, [], ['r2'], 'fam1', 1 ).
test( 't60', 498, ['m15'], [], 'fam1', 1 ).
test( 't61', 79, [], [], 'fam1', 1 ).
test( 't62', 406, [], [], 'fam1', 1 ).
test( 't63', 374, [], ['r7','r2','r3','r4','r9','r6','r5','r1'], 'fam1', 1 ).
test( 't64', 255, [], ['r7','r5'], 'fam1', 1 ).
test( 't65', 337, [], [], 'fam1', 1 ).
test( 't66', 652, [], ['r9','r6','r1','r2'], 'fam1', 1 ).
test( 't67', 612, [], ['r2','r3','r7','r10','r1','r6','r9'], 'fam1', 1 ).
test( 't68', 702, [], [], 'fam1', 1 ).
test( 't69', 281, [], [], 'fam1', 1 ).
test( 't70', 70, [], [], 'fam1', 1 ).
test( 't71', 348, [], [], 'fam1', 1 ).
test( 't72', 196, [], ['r9','r7','r8','r1','r4','r6','r10','r3','r2'], 'fam1', 1 ).
test( 't73', 294, [], [], 'fam1', 1 ).
test( 't74', 205, [], [], 'fam1', 1 ).
test( 't75', 99, ['m11','m14','m16','m12','m7','m18','m9','m1'], [], 'fam1', 1 ).
test( 't76', 797, [], [], 'fam1', 1 ).
test( 't77', 585, ['m5','m2','m18','m19','m16'], [], 'fam1', 1 ).
test( 't78', 326, ['m1','m20','m16'], [], 'fam1', 1 ).
test( 't79', 626, [], [], 'fam1', 1 ).
test( 't80', 9, [], [], 'fam1', 1 ).
test( 't81', 768, [], [], 'fam1', 1 ).
test( 't82', 9, [], ['r1'], 'fam1', 1 ).
test( 't83', 147, [], [], 'fam1', 1 ).
test( 't84', 269, [], ['r2','r9','r4','r1'], 'fam1', 1 ).
test( 't85', 322, [], [], 'fam1', 1 ).
test( 't86', 203, ['m11'], ['r8','r10','r4','r3','r5','r1','r2','r9','r7','r6'], 'fam1', 1 ).
test( 't87', 412, ['m14','m7','m9','m19','m4','m1','m2'], ['r1','r4','r10','r6','r2','r9','r8','r3','r5','r7'], 'fam1', 1 ).
test( 't88', 130, ['m1','m20','m9','m13'], [], 'fam1', 1 ).
test( 't89', 285, [], [], 'fam1', 1 ).
test( 't90', 179, [], [], 'fam1', 1 ).
test( 't91', 467, [], [], 'fam1', 1 ).
test( 't92', 5, [], ['r8','r2','r4','r6','r9','r1','r5','r3','r7'], 'fam1', 1 ).
test( 't93', 761, [], [], 'fam1', 1 ).
test( 't94', 232, [], [], 'fam1', 1 ).
test( 't95', 695, [], ['r3','r5','r8','r9','r6'], 'fam1', 1 ).
test( 't96', 331, [], ['r1','r10','r5','r6','r4'], 'fam1', 1 ).
test( 't97', 239, [], [], 'fam1', 1 ).
test( 't98', 770, [], [], 'fam1', 1 ).
test( 't99', 457, [], [], 'fam1', 1 ).
test( 't100', 368, ['m10'], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
