%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 20
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 801, [], [], 'fam1', 1 ).
test( 't2', 16, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't3', 601, [], [], 'fam1', 1 ).
test( 't4', 233, [], [], 'fam1', 1 ).
test( 't5', 184, [], [], 'fam1', 1 ).
test( 't6', 789, [], [], 'fam1', 1 ).
test( 't7', 774, [], [], 'fam1', 1 ).
test( 't8', 475, [], ['r2','r1'], 'fam1', 1 ).
test( 't9', 266, [], ['r2','r1'], 'fam1', 1 ).
test( 't10', 459, [], ['r3'], 'fam1', 1 ).
test( 't11', 760, [], [], 'fam1', 1 ).
test( 't12', 539, [], [], 'fam1', 1 ).
test( 't13', 25, [], [], 'fam1', 1 ).
test( 't14', 581, [], [], 'fam1', 1 ).
test( 't15', 576, [], ['r1'], 'fam1', 1 ).
test( 't16', 589, [], [], 'fam1', 1 ).
test( 't17', 543, ['m16','m2','m14','m17'], [], 'fam1', 1 ).
test( 't18', 486, [], [], 'fam1', 1 ).
test( 't19', 52, [], [], 'fam1', 1 ).
test( 't20', 376, [], ['r2'], 'fam1', 1 ).
test( 't21', 84, [], ['r2','r1'], 'fam1', 1 ).
test( 't22', 58, [], [], 'fam1', 1 ).
test( 't23', 343, [], [], 'fam1', 1 ).
test( 't24', 294, [], ['r1'], 'fam1', 1 ).
test( 't25', 358, [], [], 'fam1', 1 ).
test( 't26', 342, [], [], 'fam1', 1 ).
test( 't27', 321, [], [], 'fam1', 1 ).
test( 't28', 31, [], [], 'fam1', 1 ).
test( 't29', 72, ['m5','m16','m14','m3','m8','m2','m6'], [], 'fam1', 1 ).
test( 't30', 75, [], [], 'fam1', 1 ).
test( 't31', 390, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't32', 269, [], [], 'fam1', 1 ).
test( 't33', 595, [], [], 'fam1', 1 ).
test( 't34', 607, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't35', 325, [], [], 'fam1', 1 ).
test( 't36', 88, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't37', 178, [], [], 'fam1', 1 ).
test( 't38', 569, ['m10','m20','m2','m1','m17'], [], 'fam1', 1 ).
test( 't39', 223, [], [], 'fam1', 1 ).
test( 't40', 585, [], [], 'fam1', 1 ).
test( 't41', 137, [], [], 'fam1', 1 ).
test( 't42', 205, [], [], 'fam1', 1 ).
test( 't43', 718, [], [], 'fam1', 1 ).
test( 't44', 570, ['m2','m8','m6'], [], 'fam1', 1 ).
test( 't45', 426, [], [], 'fam1', 1 ).
test( 't46', 679, [], [], 'fam1', 1 ).
test( 't47', 669, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't48', 525, [], [], 'fam1', 1 ).
test( 't49', 411, [], ['r2','r3'], 'fam1', 1 ).
test( 't50', 739, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
