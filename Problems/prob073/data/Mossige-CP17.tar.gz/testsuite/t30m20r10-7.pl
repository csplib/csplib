%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 20
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 703, ['m2','m17','m7','m18','m15'], [], 'fam1', 1 ).
test( 't2', 287, [], [], 'fam1', 1 ).
test( 't3', 264, ['m2','m7'], [], 'fam1', 1 ).
test( 't4', 610, [], [], 'fam1', 1 ).
test( 't5', 603, [], [], 'fam1', 1 ).
test( 't6', 6, [], ['r3','r8','r7','r6','r10','r2','r9'], 'fam1', 1 ).
test( 't7', 716, [], [], 'fam1', 1 ).
test( 't8', 31, [], [], 'fam1', 1 ).
test( 't9', 483, [], ['r1'], 'fam1', 1 ).
test( 't10', 86, [], ['r10','r1','r4','r5','r6','r8'], 'fam1', 1 ).
test( 't11', 531, [], [], 'fam1', 1 ).
test( 't12', 113, [], [], 'fam1', 1 ).
test( 't13', 368, [], ['r7','r3','r2','r6','r8','r1','r4','r10'], 'fam1', 1 ).
test( 't14', 754, [], [], 'fam1', 1 ).
test( 't15', 648, [], [], 'fam1', 1 ).
test( 't16', 757, [], [], 'fam1', 1 ).
test( 't17', 563, [], [], 'fam1', 1 ).
test( 't18', 778, [], [], 'fam1', 1 ).
test( 't19', 723, [], [], 'fam1', 1 ).
test( 't20', 683, [], [], 'fam1', 1 ).
test( 't21', 730, ['m7'], ['r8','r3','r1','r2','r7','r10','r4','r9','r5','r6'], 'fam1', 1 ).
test( 't22', 211, [], [], 'fam1', 1 ).
test( 't23', 729, [], [], 'fam1', 1 ).
test( 't24', 564, [], [], 'fam1', 1 ).
test( 't25', 144, [], ['r5'], 'fam1', 1 ).
test( 't26', 285, [], [], 'fam1', 1 ).
test( 't27', 599, [], ['r2','r6','r1','r3'], 'fam1', 1 ).
test( 't28', 652, [], [], 'fam1', 1 ).
test( 't29', 167, [], [], 'fam1', 1 ).
test( 't30', 133, ['m16','m3','m1','m18','m14','m5'], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
