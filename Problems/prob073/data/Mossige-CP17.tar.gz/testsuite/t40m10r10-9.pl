%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 10
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 577, ['m5','m9'], ['r2','r7','r1','r5','r8','r3','r9','r4'], 'fam1', 1 ).
test( 't2', 524, ['m1'], [], 'fam1', 1 ).
test( 't3', 157, [], ['r8','r7'], 'fam1', 1 ).
test( 't4', 611, [], [], 'fam1', 1 ).
test( 't5', 640, ['m2','m10','m7','m9'], [], 'fam1', 1 ).
test( 't6', 638, ['m10','m9','m7'], [], 'fam1', 1 ).
test( 't7', 179, [], ['r5','r1'], 'fam1', 1 ).
test( 't8', 109, [], [], 'fam1', 1 ).
test( 't9', 491, [], [], 'fam1', 1 ).
test( 't10', 298, [], [], 'fam1', 1 ).
test( 't11', 5, [], ['r3','r7','r5','r1','r8','r2','r9'], 'fam1', 1 ).
test( 't12', 98, ['m5','m3'], ['r3','r10','r1','r6','r8','r5','r2'], 'fam1', 1 ).
test( 't13', 443, [], [], 'fam1', 1 ).
test( 't14', 143, [], [], 'fam1', 1 ).
test( 't15', 67, [], [], 'fam1', 1 ).
test( 't16', 307, [], ['r1','r8'], 'fam1', 1 ).
test( 't17', 798, [], [], 'fam1', 1 ).
test( 't18', 567, [], [], 'fam1', 1 ).
test( 't19', 610, [], [], 'fam1', 1 ).
test( 't20', 696, [], [], 'fam1', 1 ).
test( 't21', 253, [], [], 'fam1', 1 ).
test( 't22', 627, [], [], 'fam1', 1 ).
test( 't23', 377, [], [], 'fam1', 1 ).
test( 't24', 217, [], [], 'fam1', 1 ).
test( 't25', 271, [], [], 'fam1', 1 ).
test( 't26', 386, ['m2','m9'], [], 'fam1', 1 ).
test( 't27', 554, [], [], 'fam1', 1 ).
test( 't28', 726, [], ['r6','r5','r4','r2','r3','r8','r10','r9'], 'fam1', 1 ).
test( 't29', 600, [], [], 'fam1', 1 ).
test( 't30', 652, [], [], 'fam1', 1 ).
test( 't31', 565, [], [], 'fam1', 1 ).
test( 't32', 237, [], [], 'fam1', 1 ).
test( 't33', 575, ['m4','m2','m8','m1'], ['r8','r10'], 'fam1', 1 ).
test( 't34', 79, [], ['r1','r3','r10','r2','r5','r8','r9','r6','r4','r7'], 'fam1', 1 ).
test( 't35', 228, [], [], 'fam1', 1 ).
test( 't36', 254, [], [], 'fam1', 1 ).
test( 't37', 114, [], [], 'fam1', 1 ).
test( 't38', 490, [], ['r4','r3','r1','r2','r5'], 'fam1', 1 ).
test( 't39', 783, [], [], 'fam1', 1 ).
test( 't40', 719, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
