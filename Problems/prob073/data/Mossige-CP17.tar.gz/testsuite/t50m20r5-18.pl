%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 20
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 535, ['m6','m12'], [], 'fam1', 1 ).
test( 't2', 680, [], [], 'fam1', 1 ).
test( 't3', 445, [], [], 'fam1', 1 ).
test( 't4', 709, [], [], 'fam1', 1 ).
test( 't5', 91, [], [], 'fam1', 1 ).
test( 't6', 596, [], [], 'fam1', 1 ).
test( 't7', 50, [], [], 'fam1', 1 ).
test( 't8', 538, [], [], 'fam1', 1 ).
test( 't9', 652, [], [], 'fam1', 1 ).
test( 't10', 226, [], [], 'fam1', 1 ).
test( 't11', 280, [], [], 'fam1', 1 ).
test( 't12', 571, [], ['r3','r2'], 'fam1', 1 ).
test( 't13', 417, [], ['r2','r3','r4'], 'fam1', 1 ).
test( 't14', 729, [], ['r1','r5','r4','r2','r3'], 'fam1', 1 ).
test( 't15', 365, [], [], 'fam1', 1 ).
test( 't16', 529, [], [], 'fam1', 1 ).
test( 't17', 329, ['m16','m3'], [], 'fam1', 1 ).
test( 't18', 74, [], [], 'fam1', 1 ).
test( 't19', 552, ['m13','m12','m8','m14','m20','m15','m5'], [], 'fam1', 1 ).
test( 't20', 446, [], ['r4'], 'fam1', 1 ).
test( 't21', 239, [], ['r4','r3','r5','r1','r2'], 'fam1', 1 ).
test( 't22', 310, [], [], 'fam1', 1 ).
test( 't23', 660, ['m1','m3','m11','m6','m16','m19','m9'], ['r3'], 'fam1', 1 ).
test( 't24', 213, [], [], 'fam1', 1 ).
test( 't25', 36, ['m3','m7','m18','m5','m9','m8','m1'], [], 'fam1', 1 ).
test( 't26', 561, [], [], 'fam1', 1 ).
test( 't27', 750, ['m15','m14','m4'], [], 'fam1', 1 ).
test( 't28', 253, [], ['r4','r2','r1','r5','r3'], 'fam1', 1 ).
test( 't29', 278, ['m15','m20','m1','m18','m4','m17'], ['r3'], 'fam1', 1 ).
test( 't30', 101, [], [], 'fam1', 1 ).
test( 't31', 539, [], ['r1'], 'fam1', 1 ).
test( 't32', 13, [], [], 'fam1', 1 ).
test( 't33', 227, [], ['r2','r1','r5'], 'fam1', 1 ).
test( 't34', 288, ['m18','m13','m17','m16','m14','m19','m7','m10'], ['r4','r1'], 'fam1', 1 ).
test( 't35', 407, [], [], 'fam1', 1 ).
test( 't36', 222, [], [], 'fam1', 1 ).
test( 't37', 364, ['m14','m15','m16','m12'], [], 'fam1', 1 ).
test( 't38', 401, ['m9','m2','m20','m13','m16','m10','m18'], [], 'fam1', 1 ).
test( 't39', 553, [], [], 'fam1', 1 ).
test( 't40', 249, [], [], 'fam1', 1 ).
test( 't41', 542, [], [], 'fam1', 1 ).
test( 't42', 75, ['m10','m20','m12','m8','m18','m11','m19'], [], 'fam1', 1 ).
test( 't43', 608, [], [], 'fam1', 1 ).
test( 't44', 195, [], [], 'fam1', 1 ).
test( 't45', 157, [], [], 'fam1', 1 ).
test( 't46', 653, [], [], 'fam1', 1 ).
test( 't47', 506, [], [], 'fam1', 1 ).
test( 't48', 644, [], ['r5','r4'], 'fam1', 1 ).
test( 't49', 557, ['m14','m10','m19','m9','m5','m17','m7'], [], 'fam1', 1 ).
test( 't50', 685, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
