%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 800, [], [], 'fam1', 1 ).
test( 't2', 304, [], [], 'fam1', 1 ).
test( 't3', 435, [], [], 'fam1', 1 ).
test( 't4', 271, [], ['r3','r1'], 'fam1', 1 ).
test( 't5', 255, ['m10','m8','m9'], [], 'fam1', 1 ).
test( 't6', 216, ['m8','m6','m1'], [], 'fam1', 1 ).
test( 't7', 641, [], [], 'fam1', 1 ).
test( 't8', 739, [], ['r3'], 'fam1', 1 ).
test( 't9', 98, [], ['r1'], 'fam1', 1 ).
test( 't10', 62, ['m3','m5'], [], 'fam1', 1 ).
test( 't11', 370, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't12', 658, [], [], 'fam1', 1 ).
test( 't13', 194, [], [], 'fam1', 1 ).
test( 't14', 718, [], [], 'fam1', 1 ).
test( 't15', 226, [], ['r3','r2'], 'fam1', 1 ).
test( 't16', 447, [], ['r1','r3'], 'fam1', 1 ).
test( 't17', 580, ['m2'], [], 'fam1', 1 ).
test( 't18', 392, ['m7','m2','m6'], ['r3','r1','r2'], 'fam1', 1 ).
test( 't19', 132, [], ['r1'], 'fam1', 1 ).
test( 't20', 110, [], [], 'fam1', 1 ).
test( 't21', 634, [], ['r1'], 'fam1', 1 ).
test( 't22', 651, ['m5','m9','m4'], [], 'fam1', 1 ).
test( 't23', 30, [], [], 'fam1', 1 ).
test( 't24', 14, [], [], 'fam1', 1 ).
test( 't25', 570, [], [], 'fam1', 1 ).
test( 't26', 292, [], [], 'fam1', 1 ).
test( 't27', 769, [], [], 'fam1', 1 ).
test( 't28', 149, [], [], 'fam1', 1 ).
test( 't29', 386, [], [], 'fam1', 1 ).
test( 't30', 652, [], [], 'fam1', 1 ).
test( 't31', 313, [], ['r1','r3'], 'fam1', 1 ).
test( 't32', 494, [], [], 'fam1', 1 ).
test( 't33', 402, [], [], 'fam1', 1 ).
test( 't34', 591, [], [], 'fam1', 1 ).
test( 't35', 680, [], ['r1'], 'fam1', 1 ).
test( 't36', 741, [], [], 'fam1', 1 ).
test( 't37', 586, [], [], 'fam1', 1 ).
test( 't38', 34, [], [], 'fam1', 1 ).
test( 't39', 233, [], [], 'fam1', 1 ).
test( 't40', 259, ['m4','m5','m8'], [], 'fam1', 1 ).
test( 't41', 179, [], [], 'fam1', 1 ).
test( 't42', 478, ['m8','m7','m9','m10'], [], 'fam1', 1 ).
test( 't43', 253, [], [], 'fam1', 1 ).
test( 't44', 500, [], ['r3'], 'fam1', 1 ).
test( 't45', 352, [], [], 'fam1', 1 ).
test( 't46', 378, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't47', 439, [], [], 'fam1', 1 ).
test( 't48', 346, ['m6','m10'], ['r2'], 'fam1', 1 ).
test( 't49', 369, [], [], 'fam1', 1 ).
test( 't50', 300, [], [], 'fam1', 1 ).
test( 't51', 721, [], ['r1'], 'fam1', 1 ).
test( 't52', 725, ['m10','m3','m1','m2'], ['r1','r2','r3'], 'fam1', 1 ).
test( 't53', 279, ['m7','m9','m10'], ['r3'], 'fam1', 1 ).
test( 't54', 362, [], [], 'fam1', 1 ).
test( 't55', 764, [], ['r1','r2'], 'fam1', 1 ).
test( 't56', 628, ['m5'], [], 'fam1', 1 ).
test( 't57', 693, ['m6'], ['r3'], 'fam1', 1 ).
test( 't58', 117, ['m8','m2','m9'], [], 'fam1', 1 ).
test( 't59', 625, [], [], 'fam1', 1 ).
test( 't60', 119, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't61', 535, [], [], 'fam1', 1 ).
test( 't62', 589, [], [], 'fam1', 1 ).
test( 't63', 423, [], [], 'fam1', 1 ).
test( 't64', 607, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't65', 66, [], [], 'fam1', 1 ).
test( 't66', 509, ['m2','m6','m10'], [], 'fam1', 1 ).
test( 't67', 66, [], [], 'fam1', 1 ).
test( 't68', 56, [], [], 'fam1', 1 ).
test( 't69', 194, [], [], 'fam1', 1 ).
test( 't70', 69, [], ['r3'], 'fam1', 1 ).
test( 't71', 353, [], [], 'fam1', 1 ).
test( 't72', 354, [], [], 'fam1', 1 ).
test( 't73', 137, [], [], 'fam1', 1 ).
test( 't74', 733, ['m10','m2'], ['r1','r2'], 'fam1', 1 ).
test( 't75', 697, [], [], 'fam1', 1 ).
test( 't76', 286, [], [], 'fam1', 1 ).
test( 't77', 38, [], ['r2','r1'], 'fam1', 1 ).
test( 't78', 375, [], [], 'fam1', 1 ).
test( 't79', 352, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't80', 45, [], [], 'fam1', 1 ).
test( 't81', 21, [], ['r1'], 'fam1', 1 ).
test( 't82', 471, [], [], 'fam1', 1 ).
test( 't83', 21, [], [], 'fam1', 1 ).
test( 't84', 5, ['m4','m1','m10'], [], 'fam1', 1 ).
test( 't85', 96, [], [], 'fam1', 1 ).
test( 't86', 596, [], [], 'fam1', 1 ).
test( 't87', 480, ['m3','m5','m8'], ['r3','r2','r1'], 'fam1', 1 ).
test( 't88', 323, [], [], 'fam1', 1 ).
test( 't89', 363, [], ['r1','r3'], 'fam1', 1 ).
test( 't90', 790, [], [], 'fam1', 1 ).
test( 't91', 104, [], [], 'fam1', 1 ).
test( 't92', 223, [], [], 'fam1', 1 ).
test( 't93', 474, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't94', 461, [], [], 'fam1', 1 ).
test( 't95', 151, [], [], 'fam1', 1 ).
test( 't96', 303, [], [], 'fam1', 1 ).
test( 't97', 345, [], [], 'fam1', 1 ).
test( 't98', 181, ['m7'], [], 'fam1', 1 ).
test( 't99', 478, [], [], 'fam1', 1 ).
test( 't100', 206, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
