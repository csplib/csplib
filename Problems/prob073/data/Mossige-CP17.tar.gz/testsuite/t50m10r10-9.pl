%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 10
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 787, [], [], 'fam1', 1 ).
test( 't2', 152, [], ['r4','r7','r10'], 'fam1', 1 ).
test( 't3', 219, [], ['r8','r1','r4','r2','r7','r6','r9','r10'], 'fam1', 1 ).
test( 't4', 53, [], ['r10','r3','r7','r4','r1','r8','r9','r6','r5'], 'fam1', 1 ).
test( 't5', 352, [], [], 'fam1', 1 ).
test( 't6', 394, [], [], 'fam1', 1 ).
test( 't7', 599, ['m2','m10','m3'], [], 'fam1', 1 ).
test( 't8', 198, [], [], 'fam1', 1 ).
test( 't9', 555, [], ['r9','r1','r2'], 'fam1', 1 ).
test( 't10', 587, ['m1','m8'], ['r1','r7','r6','r8','r5','r4','r10','r2'], 'fam1', 1 ).
test( 't11', 727, [], [], 'fam1', 1 ).
test( 't12', 548, ['m8','m7','m9'], ['r10','r8'], 'fam1', 1 ).
test( 't13', 507, ['m4','m6','m1','m5'], [], 'fam1', 1 ).
test( 't14', 103, [], ['r10','r5','r1'], 'fam1', 1 ).
test( 't15', 792, ['m2'], [], 'fam1', 1 ).
test( 't16', 99, [], ['r9'], 'fam1', 1 ).
test( 't17', 424, [], [], 'fam1', 1 ).
test( 't18', 609, [], [], 'fam1', 1 ).
test( 't19', 260, [], ['r4'], 'fam1', 1 ).
test( 't20', 449, [], ['r3','r8','r1','r6','r10','r4','r9'], 'fam1', 1 ).
test( 't21', 265, [], [], 'fam1', 1 ).
test( 't22', 304, [], [], 'fam1', 1 ).
test( 't23', 288, ['m4','m1'], [], 'fam1', 1 ).
test( 't24', 662, [], [], 'fam1', 1 ).
test( 't25', 298, ['m10','m1','m3'], ['r2','r9','r10','r4','r1'], 'fam1', 1 ).
test( 't26', 723, [], ['r4','r8','r1','r9','r5','r7','r10','r2','r3'], 'fam1', 1 ).
test( 't27', 449, ['m6','m1'], [], 'fam1', 1 ).
test( 't28', 87, ['m7'], [], 'fam1', 1 ).
test( 't29', 791, [], [], 'fam1', 1 ).
test( 't30', 64, [], [], 'fam1', 1 ).
test( 't31', 208, [], [], 'fam1', 1 ).
test( 't32', 780, [], [], 'fam1', 1 ).
test( 't33', 742, ['m2','m1','m4','m7'], [], 'fam1', 1 ).
test( 't34', 595, [], ['r1','r9','r3','r6','r8','r2','r5','r7','r4','r10'], 'fam1', 1 ).
test( 't35', 411, ['m6','m2','m5','m3'], [], 'fam1', 1 ).
test( 't36', 220, [], ['r4','r10','r7','r5','r9','r8','r2','r1'], 'fam1', 1 ).
test( 't37', 716, [], ['r1','r8','r7','r4','r5','r2','r3','r6','r9','r10'], 'fam1', 1 ).
test( 't38', 509, [], [], 'fam1', 1 ).
test( 't39', 581, [], [], 'fam1', 1 ).
test( 't40', 389, ['m4','m9','m8'], [], 'fam1', 1 ).
test( 't41', 686, [], [], 'fam1', 1 ).
test( 't42', 699, ['m8','m2','m5'], [], 'fam1', 1 ).
test( 't43', 51, [], ['r1','r6'], 'fam1', 1 ).
test( 't44', 165, [], ['r8'], 'fam1', 1 ).
test( 't45', 731, [], [], 'fam1', 1 ).
test( 't46', 77, [], [], 'fam1', 1 ).
test( 't47', 758, [], [], 'fam1', 1 ).
test( 't48', 637, [], [], 'fam1', 1 ).
test( 't49', 446, [], ['r8','r1','r9','r5','r2','r3','r6','r7'], 'fam1', 1 ).
test( 't50', 631, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
