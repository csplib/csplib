%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 50
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 119, [], [], 'fam1', 1 ).
test( 't2', 775, [], [], 'fam1', 1 ).
test( 't3', 618, [], [], 'fam1', 1 ).
test( 't4', 690, [], [], 'fam1', 1 ).
test( 't5', 546, [], [], 'fam1', 1 ).
test( 't6', 99, [], [], 'fam1', 1 ).
test( 't7', 738, [], [], 'fam1', 1 ).
test( 't8', 93, [], ['r5','r6','r1','r9','r8','r4','r10'], 'fam1', 1 ).
test( 't9', 769, [], [], 'fam1', 1 ).
test( 't10', 796, [], [], 'fam1', 1 ).
test( 't11', 323, [], [], 'fam1', 1 ).
test( 't12', 74, [], [], 'fam1', 1 ).
test( 't13', 638, [], [], 'fam1', 1 ).
test( 't14', 677, [], [], 'fam1', 1 ).
test( 't15', 667, ['m13','m26','m17','m9','m36','m49','m20'], ['r5','r9'], 'fam1', 1 ).
test( 't16', 428, [], ['r6','r9','r1','r10','r2','r8','r4','r5','r3'], 'fam1', 1 ).
test( 't17', 9, [], [], 'fam1', 1 ).
test( 't18', 49, [], [], 'fam1', 1 ).
test( 't19', 292, [], [], 'fam1', 1 ).
test( 't20', 67, [], [], 'fam1', 1 ).
test( 't21', 656, [], [], 'fam1', 1 ).
test( 't22', 332, ['m33','m20','m32','m7','m9','m41','m18','m25','m46','m13','m47','m27','m49','m8'], [], 'fam1', 1 ).
test( 't23', 651, [], [], 'fam1', 1 ).
test( 't24', 384, [], [], 'fam1', 1 ).
test( 't25', 184, [], ['r4','r3','r2'], 'fam1', 1 ).
test( 't26', 179, [], [], 'fam1', 1 ).
test( 't27', 394, [], [], 'fam1', 1 ).
test( 't28', 163, ['m37','m36'], [], 'fam1', 1 ).
test( 't29', 112, [], [], 'fam1', 1 ).
test( 't30', 777, [], ['r2','r10','r4'], 'fam1', 1 ).
test( 't31', 209, [], [], 'fam1', 1 ).
test( 't32', 678, [], [], 'fam1', 1 ).
test( 't33', 118, [], [], 'fam1', 1 ).
test( 't34', 166, [], ['r1','r5','r10','r8','r3','r2'], 'fam1', 1 ).
test( 't35', 155, [], [], 'fam1', 1 ).
test( 't36', 537, ['m48','m38','m10','m13','m7','m24','m27','m28','m46','m43'], [], 'fam1', 1 ).
test( 't37', 564, [], [], 'fam1', 1 ).
test( 't38', 177, [], [], 'fam1', 1 ).
test( 't39', 210, [], ['r7','r1','r10','r8','r9'], 'fam1', 1 ).
test( 't40', 133, [], [], 'fam1', 1 ).
test( 't41', 729, [], [], 'fam1', 1 ).
test( 't42', 663, ['m34','m8','m37','m47','m48','m7','m42','m22','m38','m1','m15','m18','m36'], [], 'fam1', 1 ).
test( 't43', 497, [], [], 'fam1', 1 ).
test( 't44', 161, [], ['r3','r1','r10','r9','r6','r4','r8','r5'], 'fam1', 1 ).
test( 't45', 135, [], [], 'fam1', 1 ).
test( 't46', 478, [], [], 'fam1', 1 ).
test( 't47', 605, ['m33','m38','m5','m20','m36','m6','m4','m3','m47','m46','m37','m32','m9','m40'], ['r1','r7','r9'], 'fam1', 1 ).
test( 't48', 197, [], [], 'fam1', 1 ).
test( 't49', 560, [], [], 'fam1', 1 ).
test( 't50', 551, [], [], 'fam1', 1 ).
test( 't51', 736, [], [], 'fam1', 1 ).
test( 't52', 520, [], [], 'fam1', 1 ).
test( 't53', 678, [], ['r10','r7','r6','r2','r4','r1','r9','r8','r3','r5'], 'fam1', 1 ).
test( 't54', 238, ['m33','m28','m5','m29','m49','m36','m7','m25','m12','m11','m46'], [], 'fam1', 1 ).
test( 't55', 116, [], [], 'fam1', 1 ).
test( 't56', 628, [], [], 'fam1', 1 ).
test( 't57', 379, [], [], 'fam1', 1 ).
test( 't58', 608, [], ['r2','r10','r3','r4','r5','r1','r6','r8','r9','r7'], 'fam1', 1 ).
test( 't59', 692, ['m46','m38','m43','m44','m28'], ['r2','r3','r4','r9','r7','r5','r8','r6','r1'], 'fam1', 1 ).
test( 't60', 476, [], [], 'fam1', 1 ).
test( 't61', 774, [], [], 'fam1', 1 ).
test( 't62', 596, [], [], 'fam1', 1 ).
test( 't63', 233, [], [], 'fam1', 1 ).
test( 't64', 232, [], [], 'fam1', 1 ).
test( 't65', 88, [], [], 'fam1', 1 ).
test( 't66', 56, [], [], 'fam1', 1 ).
test( 't67', 573, [], [], 'fam1', 1 ).
test( 't68', 573, [], [], 'fam1', 1 ).
test( 't69', 38, ['m14'], [], 'fam1', 1 ).
test( 't70', 166, [], ['r6','r5','r2','r3','r9'], 'fam1', 1 ).
test( 't71', 48, [], ['r6','r8','r1','r2','r5','r4'], 'fam1', 1 ).
test( 't72', 576, [], [], 'fam1', 1 ).
test( 't73', 464, [], [], 'fam1', 1 ).
test( 't74', 257, [], [], 'fam1', 1 ).
test( 't75', 99, [], [], 'fam1', 1 ).
test( 't76', 757, [], [], 'fam1', 1 ).
test( 't77', 171, [], [], 'fam1', 1 ).
test( 't78', 675, [], [], 'fam1', 1 ).
test( 't79', 449, [], [], 'fam1', 1 ).
test( 't80', 28, ['m49','m48'], [], 'fam1', 1 ).
test( 't81', 172, [], [], 'fam1', 1 ).
test( 't82', 228, [], [], 'fam1', 1 ).
test( 't83', 474, ['m49'], ['r4','r8','r10','r6','r9'], 'fam1', 1 ).
test( 't84', 760, [], [], 'fam1', 1 ).
test( 't85', 358, [], [], 'fam1', 1 ).
test( 't86', 637, [], ['r3','r5','r6','r2','r7','r1','r10','r4','r9'], 'fam1', 1 ).
test( 't87', 420, [], ['r7','r2','r5','r6','r8'], 'fam1', 1 ).
test( 't88', 653, ['m32','m20','m13','m5','m27'], ['r4','r2','r7','r5','r8'], 'fam1', 1 ).
test( 't89', 426, [], [], 'fam1', 1 ).
test( 't90', 146, ['m46','m22','m15','m28','m26','m3','m8','m19','m12','m47','m5','m31','m11','m35','m43'], [], 'fam1', 1 ).
test( 't91', 202, [], [], 'fam1', 1 ).
test( 't92', 703, [], [], 'fam1', 1 ).
test( 't93', 430, [], ['r3','r5'], 'fam1', 1 ).
test( 't94', 766, ['m14','m4','m16','m7','m6','m25'], ['r9','r5','r7','r2','r1','r4','r6'], 'fam1', 1 ).
test( 't95', 452, ['m35','m31','m34','m9','m40','m5','m22','m46'], [], 'fam1', 1 ).
test( 't96', 268, [], [], 'fam1', 1 ).
test( 't97', 430, [], [], 'fam1', 1 ).
test( 't98', 600, [], [], 'fam1', 1 ).
test( 't99', 141, [], [], 'fam1', 1 ).
test( 't100', 224, ['m22','m33','m19','m47','m34','m30','m26','m12','m38','m37','m24','m18','m29','m45','m21'], ['r8','r5','r1','r3','r10','r4','r9','r2','r6','r7'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').
embedded_board( 'm21').
embedded_board( 'm22').
embedded_board( 'm23').
embedded_board( 'm24').
embedded_board( 'm25').
embedded_board( 'm26').
embedded_board( 'm27').
embedded_board( 'm28').
embedded_board( 'm29').
embedded_board( 'm30').
embedded_board( 'm31').
embedded_board( 'm32').
embedded_board( 'm33').
embedded_board( 'm34').
embedded_board( 'm35').
embedded_board( 'm36').
embedded_board( 'm37').
embedded_board( 'm38').
embedded_board( 'm39').
embedded_board( 'm40').
embedded_board( 'm41').
embedded_board( 'm42').
embedded_board( 'm43').
embedded_board( 'm44').
embedded_board( 'm45').
embedded_board( 'm46').
embedded_board( 'm47').
embedded_board( 'm48').
embedded_board( 'm49').
embedded_board( 'm50').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
