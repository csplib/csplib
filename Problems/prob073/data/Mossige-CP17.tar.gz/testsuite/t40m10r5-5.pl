%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 14, [], [], 'fam1', 1 ).
test( 't2', 187, [], [], 'fam1', 1 ).
test( 't3', 348, [], [], 'fam1', 1 ).
test( 't4', 571, [], ['r4'], 'fam1', 1 ).
test( 't5', 510, [], [], 'fam1', 1 ).
test( 't6', 559, [], [], 'fam1', 1 ).
test( 't7', 264, [], ['r3','r2','r1','r4','r5'], 'fam1', 1 ).
test( 't8', 277, [], [], 'fam1', 1 ).
test( 't9', 393, ['m1','m8','m10','m2'], [], 'fam1', 1 ).
test( 't10', 535, [], [], 'fam1', 1 ).
test( 't11', 549, [], [], 'fam1', 1 ).
test( 't12', 390, [], [], 'fam1', 1 ).
test( 't13', 734, [], [], 'fam1', 1 ).
test( 't14', 569, [], ['r2','r3','r4','r5','r1'], 'fam1', 1 ).
test( 't15', 413, ['m6','m4','m8'], [], 'fam1', 1 ).
test( 't16', 185, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't17', 281, [], [], 'fam1', 1 ).
test( 't18', 141, [], [], 'fam1', 1 ).
test( 't19', 556, [], [], 'fam1', 1 ).
test( 't20', 325, [], [], 'fam1', 1 ).
test( 't21', 288, [], ['r3','r5'], 'fam1', 1 ).
test( 't22', 497, [], ['r4','r2'], 'fam1', 1 ).
test( 't23', 35, ['m6','m5','m1'], [], 'fam1', 1 ).
test( 't24', 458, [], [], 'fam1', 1 ).
test( 't25', 76, [], [], 'fam1', 1 ).
test( 't26', 489, [], [], 'fam1', 1 ).
test( 't27', 798, [], [], 'fam1', 1 ).
test( 't28', 269, [], ['r1','r5','r3','r2','r4'], 'fam1', 1 ).
test( 't29', 606, [], [], 'fam1', 1 ).
test( 't30', 289, ['m7'], [], 'fam1', 1 ).
test( 't31', 716, [], [], 'fam1', 1 ).
test( 't32', 94, ['m5','m7','m2','m3'], [], 'fam1', 1 ).
test( 't33', 350, [], ['r4','r3','r2','r1','r5'], 'fam1', 1 ).
test( 't34', 774, [], [], 'fam1', 1 ).
test( 't35', 642, [], ['r4','r1'], 'fam1', 1 ).
test( 't36', 646, [], [], 'fam1', 1 ).
test( 't37', 437, ['m3','m1','m10','m6'], ['r5','r4','r2','r3','r1'], 'fam1', 1 ).
test( 't38', 10, [], [], 'fam1', 1 ).
test( 't39', 229, [], ['r1','r2','r5','r4'], 'fam1', 1 ).
test( 't40', 26, ['m5'], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
