%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 460, [], [], 'fam1', 1 ).
test( 't2', 273, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't3', 755, ['m6','m4'], ['r1','r3','r2'], 'fam1', 1 ).
test( 't4', 128, [], [], 'fam1', 1 ).
test( 't5', 132, [], [], 'fam1', 1 ).
test( 't6', 750, ['m3','m2'], [], 'fam1', 1 ).
test( 't7', 204, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't8', 486, [], ['r3'], 'fam1', 1 ).
test( 't9', 101, ['m10','m3'], [], 'fam1', 1 ).
test( 't10', 216, [], [], 'fam1', 1 ).
test( 't11', 252, [], [], 'fam1', 1 ).
test( 't12', 129, [], [], 'fam1', 1 ).
test( 't13', 641, ['m6'], ['r3'], 'fam1', 1 ).
test( 't14', 134, [], [], 'fam1', 1 ).
test( 't15', 355, [], [], 'fam1', 1 ).
test( 't16', 262, [], [], 'fam1', 1 ).
test( 't17', 451, [], [], 'fam1', 1 ).
test( 't18', 520, [], ['r3'], 'fam1', 1 ).
test( 't19', 780, ['m4','m2','m6','m5'], [], 'fam1', 1 ).
test( 't20', 174, [], [], 'fam1', 1 ).
test( 't21', 670, [], ['r2'], 'fam1', 1 ).
test( 't22', 750, ['m2','m3','m8','m9'], ['r1','r3'], 'fam1', 1 ).
test( 't23', 326, [], [], 'fam1', 1 ).
test( 't24', 378, [], [], 'fam1', 1 ).
test( 't25', 202, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't26', 664, ['m7','m10'], ['r1'], 'fam1', 1 ).
test( 't27', 61, [], [], 'fam1', 1 ).
test( 't28', 538, [], [], 'fam1', 1 ).
test( 't29', 533, ['m10','m6','m2','m7'], [], 'fam1', 1 ).
test( 't30', 280, [], [], 'fam1', 1 ).
test( 't31', 454, ['m5','m8'], [], 'fam1', 1 ).
test( 't32', 707, [], [], 'fam1', 1 ).
test( 't33', 738, [], [], 'fam1', 1 ).
test( 't34', 668, [], ['r1'], 'fam1', 1 ).
test( 't35', 720, [], ['r2'], 'fam1', 1 ).
test( 't36', 600, ['m8'], [], 'fam1', 1 ).
test( 't37', 262, ['m1','m10','m9'], [], 'fam1', 1 ).
test( 't38', 23, [], ['r2'], 'fam1', 1 ).
test( 't39', 272, ['m7','m9'], [], 'fam1', 1 ).
test( 't40', 216, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't41', 432, [], ['r2','r3'], 'fam1', 1 ).
test( 't42', 614, ['m9','m8'], ['r1','r2','r3'], 'fam1', 1 ).
test( 't43', 103, [], [], 'fam1', 1 ).
test( 't44', 699, [], [], 'fam1', 1 ).
test( 't45', 629, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't46', 768, [], ['r1','r3'], 'fam1', 1 ).
test( 't47', 58, [], ['r1'], 'fam1', 1 ).
test( 't48', 184, ['m4'], ['r2'], 'fam1', 1 ).
test( 't49', 278, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't50', 299, ['m4','m5','m10','m2'], ['r3'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
