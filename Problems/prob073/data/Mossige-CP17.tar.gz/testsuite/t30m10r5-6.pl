%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 269, [], ['r1','r2','r5','r3'], 'fam1', 1 ).
test( 't2', 298, [], [], 'fam1', 1 ).
test( 't3', 517, ['m1'], [], 'fam1', 1 ).
test( 't4', 625, [], ['r2','r1','r3','r4','r5'], 'fam1', 1 ).
test( 't5', 307, ['m2','m5','m10'], [], 'fam1', 1 ).
test( 't6', 522, [], [], 'fam1', 1 ).
test( 't7', 667, [], [], 'fam1', 1 ).
test( 't8', 469, ['m8','m9','m5','m3'], [], 'fam1', 1 ).
test( 't9', 108, [], ['r2','r3','r1','r5','r4'], 'fam1', 1 ).
test( 't10', 322, ['m6','m10','m4','m8'], [], 'fam1', 1 ).
test( 't11', 375, [], ['r2'], 'fam1', 1 ).
test( 't12', 473, [], [], 'fam1', 1 ).
test( 't13', 427, [], [], 'fam1', 1 ).
test( 't14', 312, ['m10','m8'], [], 'fam1', 1 ).
test( 't15', 64, [], ['r1','r2','r3','r4','r5'], 'fam1', 1 ).
test( 't16', 488, [], [], 'fam1', 1 ).
test( 't17', 133, [], [], 'fam1', 1 ).
test( 't18', 680, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't19', 298, [], [], 'fam1', 1 ).
test( 't20', 268, ['m3','m6','m2'], [], 'fam1', 1 ).
test( 't21', 655, [], [], 'fam1', 1 ).
test( 't22', 180, [], [], 'fam1', 1 ).
test( 't23', 277, [], [], 'fam1', 1 ).
test( 't24', 656, [], [], 'fam1', 1 ).
test( 't25', 575, [], [], 'fam1', 1 ).
test( 't26', 636, [], [], 'fam1', 1 ).
test( 't27', 435, [], [], 'fam1', 1 ).
test( 't28', 632, [], [], 'fam1', 1 ).
test( 't29', 261, [], ['r1','r3','r4','r5','r2'], 'fam1', 1 ).
test( 't30', 668, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
