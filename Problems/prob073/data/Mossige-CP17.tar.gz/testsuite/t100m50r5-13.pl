%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 50
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 310, ['m31','m3','m41','m50','m9','m46','m2','m35','m4','m27','m24','m47'], [], 'fam1', 1 ).
test( 't2', 205, [], [], 'fam1', 1 ).
test( 't3', 601, [], [], 'fam1', 1 ).
test( 't4', 647, ['m7','m22','m47','m3','m25','m20','m46','m23','m39','m43','m24','m5','m35','m4','m38'], [], 'fam1', 1 ).
test( 't5', 374, [], [], 'fam1', 1 ).
test( 't6', 614, [], [], 'fam1', 1 ).
test( 't7', 248, ['m23','m36','m32','m26','m43','m30','m44','m10','m22','m12','m40','m48'], [], 'fam1', 1 ).
test( 't8', 428, [], [], 'fam1', 1 ).
test( 't9', 269, [], [], 'fam1', 1 ).
test( 't10', 43, [], [], 'fam1', 1 ).
test( 't11', 506, [], [], 'fam1', 1 ).
test( 't12', 769, ['m44','m15','m23','m45','m22','m36','m28','m43','m31','m2','m34','m13'], [], 'fam1', 1 ).
test( 't13', 375, ['m31','m30'], [], 'fam1', 1 ).
test( 't14', 103, [], ['r2'], 'fam1', 1 ).
test( 't15', 105, ['m21','m17','m2','m39','m9','m41','m8','m29','m43','m35','m27','m47','m42'], [], 'fam1', 1 ).
test( 't16', 461, [], [], 'fam1', 1 ).
test( 't17', 396, [], ['r4','r3'], 'fam1', 1 ).
test( 't18', 461, ['m28','m20','m15','m21','m47','m8','m4','m13','m49','m29'], ['r2'], 'fam1', 1 ).
test( 't19', 618, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't20', 223, [], ['r4','r2','r1','r5'], 'fam1', 1 ).
test( 't21', 365, ['m28','m17','m45','m38','m25','m19','m33','m35','m48','m12','m30','m39'], [], 'fam1', 1 ).
test( 't22', 359, [], [], 'fam1', 1 ).
test( 't23', 698, [], ['r5','r3','r4'], 'fam1', 1 ).
test( 't24', 466, ['m28','m41'], [], 'fam1', 1 ).
test( 't25', 676, [], ['r4','r5','r3'], 'fam1', 1 ).
test( 't26', 383, ['m19','m5','m35','m27','m47','m12','m14','m31','m41','m2','m30','m37','m40','m6','m49','m7','m39'], [], 'fam1', 1 ).
test( 't27', 515, [], ['r4','r3'], 'fam1', 1 ).
test( 't28', 198, [], [], 'fam1', 1 ).
test( 't29', 120, [], [], 'fam1', 1 ).
test( 't30', 97, ['m14','m25','m33','m11','m43','m5','m29','m6','m38','m10','m9','m13','m26','m48','m17','m22'], [], 'fam1', 1 ).
test( 't31', 779, [], ['r2','r5','r1','r4','r3'], 'fam1', 1 ).
test( 't32', 762, [], ['r5','r3','r2'], 'fam1', 1 ).
test( 't33', 411, ['m25','m15','m20','m9','m34','m38','m22','m29','m17','m6','m11','m30','m7','m50','m3','m12','m13','m26'], [], 'fam1', 1 ).
test( 't34', 255, [], ['r3'], 'fam1', 1 ).
test( 't35', 654, ['m14','m21','m47','m37','m3','m34'], [], 'fam1', 1 ).
test( 't36', 81, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't37', 385, [], [], 'fam1', 1 ).
test( 't38', 227, [], ['r2','r4','r1','r5'], 'fam1', 1 ).
test( 't39', 473, [], [], 'fam1', 1 ).
test( 't40', 630, [], ['r2','r3','r4','r5','r1'], 'fam1', 1 ).
test( 't41', 158, [], ['r4','r2','r3','r5'], 'fam1', 1 ).
test( 't42', 542, [], ['r4','r3','r1'], 'fam1', 1 ).
test( 't43', 758, ['m8','m30','m40','m17','m43','m50','m26','m24','m18','m21','m7','m44','m36','m38','m11','m6'], ['r3','r4','r5','r1','r2'], 'fam1', 1 ).
test( 't44', 712, [], ['r1'], 'fam1', 1 ).
test( 't45', 707, [], [], 'fam1', 1 ).
test( 't46', 374, [], [], 'fam1', 1 ).
test( 't47', 560, [], [], 'fam1', 1 ).
test( 't48', 287, ['m27','m44','m47','m46','m29','m9','m41','m42','m24','m43','m12','m2'], [], 'fam1', 1 ).
test( 't49', 374, [], [], 'fam1', 1 ).
test( 't50', 361, ['m31','m41'], [], 'fam1', 1 ).
test( 't51', 84, [], [], 'fam1', 1 ).
test( 't52', 58, [], [], 'fam1', 1 ).
test( 't53', 119, [], [], 'fam1', 1 ).
test( 't54', 123, [], [], 'fam1', 1 ).
test( 't55', 523, [], [], 'fam1', 1 ).
test( 't56', 237, [], ['r4'], 'fam1', 1 ).
test( 't57', 474, [], [], 'fam1', 1 ).
test( 't58', 750, [], [], 'fam1', 1 ).
test( 't59', 674, [], [], 'fam1', 1 ).
test( 't60', 415, [], [], 'fam1', 1 ).
test( 't61', 731, [], ['r2'], 'fam1', 1 ).
test( 't62', 624, ['m41','m28','m35','m33','m49','m10','m22','m29','m23','m26','m11','m8','m31'], [], 'fam1', 1 ).
test( 't63', 332, [], [], 'fam1', 1 ).
test( 't64', 12, [], [], 'fam1', 1 ).
test( 't65', 544, [], [], 'fam1', 1 ).
test( 't66', 651, [], ['r5','r2','r3','r4','r1'], 'fam1', 1 ).
test( 't67', 579, ['m35','m30','m31','m34'], [], 'fam1', 1 ).
test( 't68', 690, [], ['r1'], 'fam1', 1 ).
test( 't69', 558, ['m20','m45','m31'], [], 'fam1', 1 ).
test( 't70', 312, [], [], 'fam1', 1 ).
test( 't71', 325, [], [], 'fam1', 1 ).
test( 't72', 746, [], [], 'fam1', 1 ).
test( 't73', 330, [], [], 'fam1', 1 ).
test( 't74', 8, [], [], 'fam1', 1 ).
test( 't75', 43, [], [], 'fam1', 1 ).
test( 't76', 380, [], [], 'fam1', 1 ).
test( 't77', 34, ['m16','m44','m11','m36','m21','m29','m34','m1','m6','m41'], [], 'fam1', 1 ).
test( 't78', 247, [], [], 'fam1', 1 ).
test( 't79', 701, ['m6'], [], 'fam1', 1 ).
test( 't80', 528, ['m1','m25','m48','m39','m2','m30','m46','m23','m17','m20','m21','m41','m27','m29','m6','m13','m44'], ['r1','r3'], 'fam1', 1 ).
test( 't81', 145, [], [], 'fam1', 1 ).
test( 't82', 532, [], [], 'fam1', 1 ).
test( 't83', 105, [], ['r5','r2','r3','r1'], 'fam1', 1 ).
test( 't84', 522, [], [], 'fam1', 1 ).
test( 't85', 453, [], [], 'fam1', 1 ).
test( 't86', 357, [], ['r1','r2','r3','r4'], 'fam1', 1 ).
test( 't87', 481, [], [], 'fam1', 1 ).
test( 't88', 437, [], ['r3','r1','r5','r2'], 'fam1', 1 ).
test( 't89', 25, [], ['r5','r1','r3'], 'fam1', 1 ).
test( 't90', 445, [], ['r1'], 'fam1', 1 ).
test( 't91', 187, ['m24','m18','m31','m4','m48','m23','m9','m10','m7','m27','m41','m38','m47','m36','m2','m14','m49','m35'], [], 'fam1', 1 ).
test( 't92', 328, [], [], 'fam1', 1 ).
test( 't93', 42, ['m30','m17','m6','m29','m31','m43','m45','m44','m16','m24','m13','m27','m42','m37'], [], 'fam1', 1 ).
test( 't94', 292, [], ['r4','r2'], 'fam1', 1 ).
test( 't95', 390, ['m15','m40'], [], 'fam1', 1 ).
test( 't96', 560, [], [], 'fam1', 1 ).
test( 't97', 547, [], [], 'fam1', 1 ).
test( 't98', 539, [], ['r4','r5','r1','r2'], 'fam1', 1 ).
test( 't99', 768, ['m42','m23'], ['r5','r1','r4'], 'fam1', 1 ).
test( 't100', 727, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').
embedded_board( 'm21').
embedded_board( 'm22').
embedded_board( 'm23').
embedded_board( 'm24').
embedded_board( 'm25').
embedded_board( 'm26').
embedded_board( 'm27').
embedded_board( 'm28').
embedded_board( 'm29').
embedded_board( 'm30').
embedded_board( 'm31').
embedded_board( 'm32').
embedded_board( 'm33').
embedded_board( 'm34').
embedded_board( 'm35').
embedded_board( 'm36').
embedded_board( 'm37').
embedded_board( 'm38').
embedded_board( 'm39').
embedded_board( 'm40').
embedded_board( 'm41').
embedded_board( 'm42').
embedded_board( 'm43').
embedded_board( 'm44').
embedded_board( 'm45').
embedded_board( 'm46').
embedded_board( 'm47').
embedded_board( 'm48').
embedded_board( 'm49').
embedded_board( 'm50').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
