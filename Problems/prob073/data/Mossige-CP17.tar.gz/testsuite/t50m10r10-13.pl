%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 10
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 87, [], [], 'fam1', 1 ).
test( 't2', 557, [], ['r5'], 'fam1', 1 ).
test( 't3', 170, [], [], 'fam1', 1 ).
test( 't4', 596, [], ['r6','r9','r5'], 'fam1', 1 ).
test( 't5', 177, ['m5','m7'], [], 'fam1', 1 ).
test( 't6', 164, [], ['r3','r5','r8','r7','r2','r4','r9','r6'], 'fam1', 1 ).
test( 't7', 86, ['m10','m5'], [], 'fam1', 1 ).
test( 't8', 333, [], [], 'fam1', 1 ).
test( 't9', 283, [], [], 'fam1', 1 ).
test( 't10', 608, ['m4','m8'], ['r2','r8','r6','r9','r3','r1','r4','r5','r7','r10'], 'fam1', 1 ).
test( 't11', 707, [], ['r6','r4','r5','r9','r10'], 'fam1', 1 ).
test( 't12', 738, [], [], 'fam1', 1 ).
test( 't13', 426, [], [], 'fam1', 1 ).
test( 't14', 547, [], [], 'fam1', 1 ).
test( 't15', 432, [], [], 'fam1', 1 ).
test( 't16', 350, [], [], 'fam1', 1 ).
test( 't17', 478, [], ['r3','r6','r9','r10','r8','r7','r4'], 'fam1', 1 ).
test( 't18', 629, [], [], 'fam1', 1 ).
test( 't19', 325, [], ['r8','r7','r3'], 'fam1', 1 ).
test( 't20', 257, [], [], 'fam1', 1 ).
test( 't21', 431, [], [], 'fam1', 1 ).
test( 't22', 293, [], ['r3','r1','r4','r8','r6'], 'fam1', 1 ).
test( 't23', 795, [], [], 'fam1', 1 ).
test( 't24', 629, [], [], 'fam1', 1 ).
test( 't25', 283, ['m10','m3'], [], 'fam1', 1 ).
test( 't26', 764, [], [], 'fam1', 1 ).
test( 't27', 549, ['m3','m9','m5'], [], 'fam1', 1 ).
test( 't28', 586, [], [], 'fam1', 1 ).
test( 't29', 111, [], [], 'fam1', 1 ).
test( 't30', 408, [], [], 'fam1', 1 ).
test( 't31', 730, [], [], 'fam1', 1 ).
test( 't32', 400, [], [], 'fam1', 1 ).
test( 't33', 723, [], [], 'fam1', 1 ).
test( 't34', 414, [], [], 'fam1', 1 ).
test( 't35', 278, [], [], 'fam1', 1 ).
test( 't36', 40, [], [], 'fam1', 1 ).
test( 't37', 411, ['m1','m4','m5'], ['r3'], 'fam1', 1 ).
test( 't38', 125, ['m3'], ['r10','r4'], 'fam1', 1 ).
test( 't39', 371, [], [], 'fam1', 1 ).
test( 't40', 759, [], [], 'fam1', 1 ).
test( 't41', 413, ['m6','m9','m5','m10'], [], 'fam1', 1 ).
test( 't42', 526, [], ['r5','r6','r10','r7','r3','r8','r2','r1','r4','r9'], 'fam1', 1 ).
test( 't43', 748, [], ['r9','r4','r1','r10','r5','r6'], 'fam1', 1 ).
test( 't44', 491, [], [], 'fam1', 1 ).
test( 't45', 639, [], ['r9','r4','r10','r6','r1','r7','r2','r5','r3','r8'], 'fam1', 1 ).
test( 't46', 705, [], [], 'fam1', 1 ).
test( 't47', 725, [], ['r2','r7','r9','r1'], 'fam1', 1 ).
test( 't48', 122, [], [], 'fam1', 1 ).
test( 't49', 18, [], ['r8'], 'fam1', 1 ).
test( 't50', 682, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
