%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 144, [], [], 'fam1', 1 ).
test( 't2', 87, [], [], 'fam1', 1 ).
test( 't3', 270, [], [], 'fam1', 1 ).
test( 't4', 13, [], [], 'fam1', 1 ).
test( 't5', 291, [], [], 'fam1', 1 ).
test( 't6', 573, [], ['r2','r1'], 'fam1', 1 ).
test( 't7', 577, [], [], 'fam1', 1 ).
test( 't8', 457, [], [], 'fam1', 1 ).
test( 't9', 263, ['m2','m1','m3','m8'], [], 'fam1', 1 ).
test( 't10', 440, [], [], 'fam1', 1 ).
test( 't11', 640, [], ['r3'], 'fam1', 1 ).
test( 't12', 558, [], ['r2'], 'fam1', 1 ).
test( 't13', 34, [], ['r3','r2'], 'fam1', 1 ).
test( 't14', 599, [], [], 'fam1', 1 ).
test( 't15', 607, ['m8'], ['r3','r1','r2'], 'fam1', 1 ).
test( 't16', 414, [], [], 'fam1', 1 ).
test( 't17', 691, ['m2','m5','m1'], [], 'fam1', 1 ).
test( 't18', 653, [], [], 'fam1', 1 ).
test( 't19', 371, [], ['r2'], 'fam1', 1 ).
test( 't20', 510, [], ['r3','r2'], 'fam1', 1 ).
test( 't21', 143, [], ['r2'], 'fam1', 1 ).
test( 't22', 437, [], [], 'fam1', 1 ).
test( 't23', 646, [], [], 'fam1', 1 ).
test( 't24', 433, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't25', 584, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't26', 744, [], [], 'fam1', 1 ).
test( 't27', 692, [], [], 'fam1', 1 ).
test( 't28', 235, [], ['r2'], 'fam1', 1 ).
test( 't29', 576, [], [], 'fam1', 1 ).
test( 't30', 582, [], [], 'fam1', 1 ).
test( 't31', 655, [], [], 'fam1', 1 ).
test( 't32', 390, ['m10'], [], 'fam1', 1 ).
test( 't33', 528, [], ['r3'], 'fam1', 1 ).
test( 't34', 614, [], ['r2','r1'], 'fam1', 1 ).
test( 't35', 215, [], [], 'fam1', 1 ).
test( 't36', 309, [], ['r3'], 'fam1', 1 ).
test( 't37', 415, [], [], 'fam1', 1 ).
test( 't38', 75, [], [], 'fam1', 1 ).
test( 't39', 487, [], [], 'fam1', 1 ).
test( 't40', 58, [], [], 'fam1', 1 ).
test( 't41', 156, [], ['r2'], 'fam1', 1 ).
test( 't42', 153, [], ['r3'], 'fam1', 1 ).
test( 't43', 612, [], [], 'fam1', 1 ).
test( 't44', 498, [], [], 'fam1', 1 ).
test( 't45', 301, ['m5','m2','m4'], [], 'fam1', 1 ).
test( 't46', 552, ['m1'], [], 'fam1', 1 ).
test( 't47', 324, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't48', 434, [], [], 'fam1', 1 ).
test( 't49', 396, [], [], 'fam1', 1 ).
test( 't50', 529, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
