%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 20
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 644, [], ['r4','r5','r3','r1','r2'], 'fam1', 1 ).
test( 't2', 334, [], ['r3','r2'], 'fam1', 1 ).
test( 't3', 196, [], [], 'fam1', 1 ).
test( 't4', 577, [], [], 'fam1', 1 ).
test( 't5', 212, ['m13','m9','m5'], [], 'fam1', 1 ).
test( 't6', 737, [], [], 'fam1', 1 ).
test( 't7', 492, [], [], 'fam1', 1 ).
test( 't8', 293, [], [], 'fam1', 1 ).
test( 't9', 15, [], [], 'fam1', 1 ).
test( 't10', 735, ['m8','m5'], [], 'fam1', 1 ).
test( 't11', 671, [], [], 'fam1', 1 ).
test( 't12', 32, ['m20','m1','m16','m3','m12'], ['r1','r3','r2','r5'], 'fam1', 1 ).
test( 't13', 150, [], [], 'fam1', 1 ).
test( 't14', 471, [], [], 'fam1', 1 ).
test( 't15', 159, ['m15','m11'], ['r4','r5','r1','r3'], 'fam1', 1 ).
test( 't16', 392, [], [], 'fam1', 1 ).
test( 't17', 314, [], [], 'fam1', 1 ).
test( 't18', 566, ['m14','m5','m7','m18','m8'], ['r1','r4','r3','r5','r2'], 'fam1', 1 ).
test( 't19', 716, [], [], 'fam1', 1 ).
test( 't20', 287, [], [], 'fam1', 1 ).
test( 't21', 618, [], [], 'fam1', 1 ).
test( 't22', 582, [], [], 'fam1', 1 ).
test( 't23', 131, [], [], 'fam1', 1 ).
test( 't24', 328, [], ['r3','r4','r5'], 'fam1', 1 ).
test( 't25', 452, [], [], 'fam1', 1 ).
test( 't26', 505, [], [], 'fam1', 1 ).
test( 't27', 436, [], [], 'fam1', 1 ).
test( 't28', 369, ['m10','m18','m16'], [], 'fam1', 1 ).
test( 't29', 26, [], [], 'fam1', 1 ).
test( 't30', 569, [], [], 'fam1', 1 ).
test( 't31', 626, ['m2','m6','m12','m3','m11','m5'], [], 'fam1', 1 ).
test( 't32', 521, [], [], 'fam1', 1 ).
test( 't33', 91, [], ['r2','r4','r1','r3','r5'], 'fam1', 1 ).
test( 't34', 609, [], [], 'fam1', 1 ).
test( 't35', 737, [], [], 'fam1', 1 ).
test( 't36', 277, [], [], 'fam1', 1 ).
test( 't37', 45, [], [], 'fam1', 1 ).
test( 't38', 182, ['m19','m17','m4','m5','m3','m12','m2'], [], 'fam1', 1 ).
test( 't39', 442, [], [], 'fam1', 1 ).
test( 't40', 427, [], ['r2','r3','r5','r4','r1'], 'fam1', 1 ).
test( 't41', 408, [], [], 'fam1', 1 ).
test( 't42', 465, [], [], 'fam1', 1 ).
test( 't43', 160, [], ['r4','r2','r1','r5','r3'], 'fam1', 1 ).
test( 't44', 581, [], [], 'fam1', 1 ).
test( 't45', 771, [], ['r3','r4','r1'], 'fam1', 1 ).
test( 't46', 274, [], [], 'fam1', 1 ).
test( 't47', 257, [], [], 'fam1', 1 ).
test( 't48', 716, ['m15','m9','m8'], [], 'fam1', 1 ).
test( 't49', 60, [], [], 'fam1', 1 ).
test( 't50', 401, [], ['r1','r2','r5','r3'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
