%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 20
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 209, [], [], 'fam1', 1 ).
test( 't2', 520, [], [], 'fam1', 1 ).
test( 't3', 515, [], ['r2','r1','r5','r3','r4'], 'fam1', 1 ).
test( 't4', 49, [], ['r1','r5'], 'fam1', 1 ).
test( 't5', 793, [], ['r5','r4','r1','r2','r3'], 'fam1', 1 ).
test( 't6', 390, [], [], 'fam1', 1 ).
test( 't7', 85, [], [], 'fam1', 1 ).
test( 't8', 462, [], [], 'fam1', 1 ).
test( 't9', 287, [], [], 'fam1', 1 ).
test( 't10', 258, [], ['r1','r5'], 'fam1', 1 ).
test( 't11', 778, [], [], 'fam1', 1 ).
test( 't12', 358, [], [], 'fam1', 1 ).
test( 't13', 337, ['m11','m7','m17','m15','m14'], [], 'fam1', 1 ).
test( 't14', 94, ['m17','m1','m16'], ['r2','r3','r4','r5','r1'], 'fam1', 1 ).
test( 't15', 226, [], [], 'fam1', 1 ).
test( 't16', 578, [], ['r4'], 'fam1', 1 ).
test( 't17', 795, [], [], 'fam1', 1 ).
test( 't18', 684, [], ['r4','r2','r5','r1','r3'], 'fam1', 1 ).
test( 't19', 603, [], [], 'fam1', 1 ).
test( 't20', 467, [], ['r2'], 'fam1', 1 ).
test( 't21', 322, ['m7','m16','m2','m1','m4','m18','m14','m6'], [], 'fam1', 1 ).
test( 't22', 232, [], [], 'fam1', 1 ).
test( 't23', 199, [], ['r5','r4','r3'], 'fam1', 1 ).
test( 't24', 511, [], [], 'fam1', 1 ).
test( 't25', 439, [], ['r3','r4','r2','r1'], 'fam1', 1 ).
test( 't26', 791, [], [], 'fam1', 1 ).
test( 't27', 169, [], [], 'fam1', 1 ).
test( 't28', 787, [], ['r2','r1','r5','r3'], 'fam1', 1 ).
test( 't29', 376, [], [], 'fam1', 1 ).
test( 't30', 498, ['m17','m14','m20','m10','m6','m8'], [], 'fam1', 1 ).
test( 't31', 91, [], ['r5','r4','r2'], 'fam1', 1 ).
test( 't32', 272, [], ['r2','r1','r4','r5','r3'], 'fam1', 1 ).
test( 't33', 249, ['m14','m6'], [], 'fam1', 1 ).
test( 't34', 374, ['m14','m2','m15','m8','m5'], [], 'fam1', 1 ).
test( 't35', 391, [], ['r2','r1'], 'fam1', 1 ).
test( 't36', 251, [], [], 'fam1', 1 ).
test( 't37', 381, [], [], 'fam1', 1 ).
test( 't38', 91, [], [], 'fam1', 1 ).
test( 't39', 254, [], [], 'fam1', 1 ).
test( 't40', 593, ['m5','m7','m3'], ['r5','r1','r3','r2'], 'fam1', 1 ).
test( 't41', 44, [], ['r4','r1','r2','r5','r3'], 'fam1', 1 ).
test( 't42', 524, [], [], 'fam1', 1 ).
test( 't43', 406, [], ['r5','r1','r4','r3','r2'], 'fam1', 1 ).
test( 't44', 389, [], [], 'fam1', 1 ).
test( 't45', 274, [], [], 'fam1', 1 ).
test( 't46', 69, [], ['r3'], 'fam1', 1 ).
test( 't47', 330, [], [], 'fam1', 1 ).
test( 't48', 279, [], [], 'fam1', 1 ).
test( 't49', 644, ['m8','m16','m1','m18','m5'], [], 'fam1', 1 ).
test( 't50', 681, [], ['r3','r4','r2','r5'], 'fam1', 1 ).
test( 't51', 372, [], [], 'fam1', 1 ).
test( 't52', 434, [], ['r3'], 'fam1', 1 ).
test( 't53', 34, [], ['r4'], 'fam1', 1 ).
test( 't54', 569, ['m8','m18'], ['r4'], 'fam1', 1 ).
test( 't55', 453, [], [], 'fam1', 1 ).
test( 't56', 462, [], [], 'fam1', 1 ).
test( 't57', 13, [], [], 'fam1', 1 ).
test( 't58', 509, [], [], 'fam1', 1 ).
test( 't59', 389, [], [], 'fam1', 1 ).
test( 't60', 690, [], [], 'fam1', 1 ).
test( 't61', 289, ['m1','m2','m10','m20','m12'], [], 'fam1', 1 ).
test( 't62', 668, ['m10','m19','m14','m18','m20','m15','m4','m16'], ['r1','r4'], 'fam1', 1 ).
test( 't63', 255, ['m10'], ['r1','r3'], 'fam1', 1 ).
test( 't64', 758, ['m13','m15','m2'], [], 'fam1', 1 ).
test( 't65', 212, [], ['r3','r1'], 'fam1', 1 ).
test( 't66', 236, [], ['r5','r2'], 'fam1', 1 ).
test( 't67', 595, ['m18','m15'], ['r5','r1'], 'fam1', 1 ).
test( 't68', 467, [], [], 'fam1', 1 ).
test( 't69', 101, [], [], 'fam1', 1 ).
test( 't70', 167, ['m1','m7','m18','m10','m8'], ['r4','r1','r2'], 'fam1', 1 ).
test( 't71', 69, ['m14','m15','m13','m9'], [], 'fam1', 1 ).
test( 't72', 481, [], [], 'fam1', 1 ).
test( 't73', 774, [], ['r2','r1'], 'fam1', 1 ).
test( 't74', 480, [], [], 'fam1', 1 ).
test( 't75', 602, ['m2','m18'], [], 'fam1', 1 ).
test( 't76', 789, [], ['r1','r4','r2'], 'fam1', 1 ).
test( 't77', 133, [], [], 'fam1', 1 ).
test( 't78', 311, [], ['r2','r5'], 'fam1', 1 ).
test( 't79', 646, [], [], 'fam1', 1 ).
test( 't80', 717, [], [], 'fam1', 1 ).
test( 't81', 211, [], [], 'fam1', 1 ).
test( 't82', 632, [], ['r5','r1','r3'], 'fam1', 1 ).
test( 't83', 306, [], [], 'fam1', 1 ).
test( 't84', 649, [], [], 'fam1', 1 ).
test( 't85', 682, [], ['r1','r2','r5'], 'fam1', 1 ).
test( 't86', 367, [], [], 'fam1', 1 ).
test( 't87', 474, [], ['r2','r5','r3','r4'], 'fam1', 1 ).
test( 't88', 784, [], [], 'fam1', 1 ).
test( 't89', 143, [], [], 'fam1', 1 ).
test( 't90', 627, [], [], 'fam1', 1 ).
test( 't91', 313, [], ['r3','r4'], 'fam1', 1 ).
test( 't92', 535, ['m18','m20','m13','m2','m16','m5','m19','m4'], ['r3'], 'fam1', 1 ).
test( 't93', 624, [], [], 'fam1', 1 ).
test( 't94', 68, [], [], 'fam1', 1 ).
test( 't95', 157, ['m17','m18'], [], 'fam1', 1 ).
test( 't96', 354, [], [], 'fam1', 1 ).
test( 't97', 22, [], [], 'fam1', 1 ).
test( 't98', 746, [], ['r5'], 'fam1', 1 ).
test( 't99', 242, [], [], 'fam1', 1 ).
test( 't100', 133, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
