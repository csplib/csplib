%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 20
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 112, ['m2','m16'], [], 'fam1', 1 ).
test( 't2', 87, [], ['r7','r6'], 'fam1', 1 ).
test( 't3', 792, [], [], 'fam1', 1 ).
test( 't4', 137, ['m6','m9'], [], 'fam1', 1 ).
test( 't5', 211, [], [], 'fam1', 1 ).
test( 't6', 88, [], ['r2','r8','r7','r1','r10'], 'fam1', 1 ).
test( 't7', 451, [], [], 'fam1', 1 ).
test( 't8', 768, [], ['r1','r6','r3','r10','r9'], 'fam1', 1 ).
test( 't9', 132, [], [], 'fam1', 1 ).
test( 't10', 221, [], ['r2','r3','r9','r5'], 'fam1', 1 ).
test( 't11', 709, [], ['r2','r6','r7','r5','r8'], 'fam1', 1 ).
test( 't12', 89, [], [], 'fam1', 1 ).
test( 't13', 3, ['m18','m3','m6','m4'], ['r8','r9','r6','r1','r3','r10','r7'], 'fam1', 1 ).
test( 't14', 384, [], ['r9','r4','r3','r7','r10','r2'], 'fam1', 1 ).
test( 't15', 3, ['m11','m16','m1','m15'], [], 'fam1', 1 ).
test( 't16', 306, [], ['r1'], 'fam1', 1 ).
test( 't17', 606, [], [], 'fam1', 1 ).
test( 't18', 214, [], [], 'fam1', 1 ).
test( 't19', 379, [], [], 'fam1', 1 ).
test( 't20', 311, [], [], 'fam1', 1 ).
test( 't21', 70, [], ['r3','r9','r8','r6'], 'fam1', 1 ).
test( 't22', 502, [], [], 'fam1', 1 ).
test( 't23', 629, ['m3','m2'], [], 'fam1', 1 ).
test( 't24', 310, [], [], 'fam1', 1 ).
test( 't25', 532, ['m9','m4','m13','m11','m10','m3','m14'], [], 'fam1', 1 ).
test( 't26', 111, [], ['r6'], 'fam1', 1 ).
test( 't27', 91, [], [], 'fam1', 1 ).
test( 't28', 141, [], ['r10','r5'], 'fam1', 1 ).
test( 't29', 255, [], [], 'fam1', 1 ).
test( 't30', 317, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
