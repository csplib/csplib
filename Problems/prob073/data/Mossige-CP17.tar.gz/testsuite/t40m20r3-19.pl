%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 20
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 560, [], [], 'fam1', 1 ).
test( 't2', 638, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't3', 772, [], ['r3'], 'fam1', 1 ).
test( 't4', 447, [], ['r3'], 'fam1', 1 ).
test( 't5', 23, [], [], 'fam1', 1 ).
test( 't6', 378, [], [], 'fam1', 1 ).
test( 't7', 424, [], [], 'fam1', 1 ).
test( 't8', 359, [], [], 'fam1', 1 ).
test( 't9', 313, [], [], 'fam1', 1 ).
test( 't10', 282, [], [], 'fam1', 1 ).
test( 't11', 193, ['m2','m13','m4','m16','m7'], [], 'fam1', 1 ).
test( 't12', 489, ['m8','m12','m1','m15','m4','m16','m18'], [], 'fam1', 1 ).
test( 't13', 727, [], [], 'fam1', 1 ).
test( 't14', 162, [], [], 'fam1', 1 ).
test( 't15', 681, [], [], 'fam1', 1 ).
test( 't16', 581, [], [], 'fam1', 1 ).
test( 't17', 238, ['m12','m17','m20','m7','m16','m3'], [], 'fam1', 1 ).
test( 't18', 8, [], ['r2','r3'], 'fam1', 1 ).
test( 't19', 472, ['m12','m2','m1','m16','m3'], ['r2','r1','r3'], 'fam1', 1 ).
test( 't20', 348, [], [], 'fam1', 1 ).
test( 't21', 193, [], ['r2','r3'], 'fam1', 1 ).
test( 't22', 5, [], [], 'fam1', 1 ).
test( 't23', 626, [], [], 'fam1', 1 ).
test( 't24', 623, [], [], 'fam1', 1 ).
test( 't25', 109, [], [], 'fam1', 1 ).
test( 't26', 470, [], [], 'fam1', 1 ).
test( 't27', 283, [], [], 'fam1', 1 ).
test( 't28', 779, ['m6','m9','m11','m13','m20'], [], 'fam1', 1 ).
test( 't29', 508, [], [], 'fam1', 1 ).
test( 't30', 374, [], [], 'fam1', 1 ).
test( 't31', 456, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't32', 595, [], ['r1','r3'], 'fam1', 1 ).
test( 't33', 250, [], [], 'fam1', 1 ).
test( 't34', 591, ['m2','m4','m12','m5'], [], 'fam1', 1 ).
test( 't35', 647, [], [], 'fam1', 1 ).
test( 't36', 345, [], [], 'fam1', 1 ).
test( 't37', 521, ['m16','m4','m19','m9','m2'], [], 'fam1', 1 ).
test( 't38', 710, [], [], 'fam1', 1 ).
test( 't39', 218, [], [], 'fam1', 1 ).
test( 't40', 411, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
