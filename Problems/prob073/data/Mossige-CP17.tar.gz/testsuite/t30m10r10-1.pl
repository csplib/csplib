%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 10
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 383, [], ['r3','r6','r5','r1','r7'], 'fam1', 1 ).
test( 't2', 764, [], [], 'fam1', 1 ).
test( 't3', 650, [], [], 'fam1', 1 ).
test( 't4', 441, [], ['r4','r10'], 'fam1', 1 ).
test( 't5', 710, [], [], 'fam1', 1 ).
test( 't6', 773, [], ['r6','r1','r2','r3','r5','r9','r7','r4'], 'fam1', 1 ).
test( 't7', 791, [], [], 'fam1', 1 ).
test( 't8', 101, [], ['r9','r5','r3','r4','r8','r10','r2','r1'], 'fam1', 1 ).
test( 't9', 521, [], ['r4','r3','r10','r9','r2','r5','r7','r1'], 'fam1', 1 ).
test( 't10', 123, [], [], 'fam1', 1 ).
test( 't11', 617, [], [], 'fam1', 1 ).
test( 't12', 215, [], [], 'fam1', 1 ).
test( 't13', 207, [], [], 'fam1', 1 ).
test( 't14', 97, [], ['r2','r8','r4','r9','r1','r10'], 'fam1', 1 ).
test( 't15', 602, ['m3','m5'], [], 'fam1', 1 ).
test( 't16', 668, [], ['r4','r5','r6','r2','r8'], 'fam1', 1 ).
test( 't17', 718, ['m4','m8','m1','m5'], ['r3','r10','r9','r7','r8'], 'fam1', 1 ).
test( 't18', 707, [], [], 'fam1', 1 ).
test( 't19', 468, [], [], 'fam1', 1 ).
test( 't20', 438, [], [], 'fam1', 1 ).
test( 't21', 116, [], [], 'fam1', 1 ).
test( 't22', 344, [], [], 'fam1', 1 ).
test( 't23', 776, [], [], 'fam1', 1 ).
test( 't24', 157, [], [], 'fam1', 1 ).
test( 't25', 287, [], [], 'fam1', 1 ).
test( 't26', 83, [], ['r2','r6','r9','r3','r7'], 'fam1', 1 ).
test( 't27', 346, [], [], 'fam1', 1 ).
test( 't28', 112, [], [], 'fam1', 1 ).
test( 't29', 11, ['m1','m10','m9','m3'], [], 'fam1', 1 ).
test( 't30', 317, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
