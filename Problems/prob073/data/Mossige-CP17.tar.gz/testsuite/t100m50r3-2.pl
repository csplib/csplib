%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 50
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 662, [], [], 'fam1', 1 ).
test( 't2', 404, [], ['r2','r1'], 'fam1', 1 ).
test( 't3', 588, ['m3','m32','m16','m13','m15','m43','m39','m45','m48','m17','m25','m27','m50','m14','m18'], ['r2','r3','r1'], 'fam1', 1 ).
test( 't4', 401, [], [], 'fam1', 1 ).
test( 't5', 681, [], [], 'fam1', 1 ).
test( 't6', 488, ['m10','m9','m46','m34','m20','m33','m44','m14','m45','m27','m37','m15','m7','m43','m16','m50','m2','m5'], ['r2','r1'], 'fam1', 1 ).
test( 't7', 63, ['m42','m36','m21','m13','m5','m37','m38','m39','m16','m20','m25','m22'], [], 'fam1', 1 ).
test( 't8', 34, [], [], 'fam1', 1 ).
test( 't9', 60, [], [], 'fam1', 1 ).
test( 't10', 606, [], [], 'fam1', 1 ).
test( 't11', 623, ['m41','m40','m21','m10','m7','m22','m44','m50','m6','m9','m48','m32','m45','m12','m29','m17'], [], 'fam1', 1 ).
test( 't12', 515, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't13', 272, ['m35','m21','m41','m24','m29','m32','m10','m31','m49','m36','m6','m25','m33','m20','m5','m23'], [], 'fam1', 1 ).
test( 't14', 92, [], [], 'fam1', 1 ).
test( 't15', 231, [], [], 'fam1', 1 ).
test( 't16', 721, ['m9','m36','m8','m35','m2','m3','m7','m4','m42','m29','m13','m15','m16','m34','m25','m49','m19'], [], 'fam1', 1 ).
test( 't17', 237, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't18', 730, [], [], 'fam1', 1 ).
test( 't19', 676, ['m23','m33','m20','m39','m40','m6','m13','m2','m11','m28','m21'], [], 'fam1', 1 ).
test( 't20', 300, [], [], 'fam1', 1 ).
test( 't21', 241, [], [], 'fam1', 1 ).
test( 't22', 29, [], [], 'fam1', 1 ).
test( 't23', 387, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't24', 428, [], [], 'fam1', 1 ).
test( 't25', 636, ['m25','m10','m36','m7','m38'], [], 'fam1', 1 ).
test( 't26', 443, [], ['r2'], 'fam1', 1 ).
test( 't27', 614, [], ['r2','r3'], 'fam1', 1 ).
test( 't28', 73, ['m21','m19','m35','m28','m17','m7','m47','m26','m46','m14','m2','m9','m24','m38','m37','m45','m12','m39','m1','m43'], [], 'fam1', 1 ).
test( 't29', 545, [], [], 'fam1', 1 ).
test( 't30', 458, ['m37','m42','m45'], ['r2'], 'fam1', 1 ).
test( 't31', 286, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't32', 447, ['m21','m22','m32','m24','m41','m7','m29','m17','m50','m9','m40','m10','m47','m30','m48','m38','m19','m28'], ['r3'], 'fam1', 1 ).
test( 't33', 7, [], [], 'fam1', 1 ).
test( 't34', 226, ['m18','m38','m48','m8','m49','m9','m30','m14','m4','m12'], ['r3','r2','r1'], 'fam1', 1 ).
test( 't35', 159, [], [], 'fam1', 1 ).
test( 't36', 709, ['m36','m17','m40'], [], 'fam1', 1 ).
test( 't37', 77, [], [], 'fam1', 1 ).
test( 't38', 221, [], [], 'fam1', 1 ).
test( 't39', 248, [], ['r2','r3'], 'fam1', 1 ).
test( 't40', 220, ['m7','m28','m47'], [], 'fam1', 1 ).
test( 't41', 689, [], [], 'fam1', 1 ).
test( 't42', 703, [], [], 'fam1', 1 ).
test( 't43', 427, [], [], 'fam1', 1 ).
test( 't44', 325, [], [], 'fam1', 1 ).
test( 't45', 289, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't46', 105, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't47', 108, [], ['r2','r3'], 'fam1', 1 ).
test( 't48', 374, [], [], 'fam1', 1 ).
test( 't49', 795, ['m48','m40','m31','m49','m26','m18'], [], 'fam1', 1 ).
test( 't50', 780, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't51', 265, [], [], 'fam1', 1 ).
test( 't52', 773, [], [], 'fam1', 1 ).
test( 't53', 384, [], [], 'fam1', 1 ).
test( 't54', 1, ['m30','m21','m46','m11','m34'], [], 'fam1', 1 ).
test( 't55', 306, [], ['r3','r2'], 'fam1', 1 ).
test( 't56', 686, [], [], 'fam1', 1 ).
test( 't57', 98, [], [], 'fam1', 1 ).
test( 't58', 649, [], [], 'fam1', 1 ).
test( 't59', 284, [], [], 'fam1', 1 ).
test( 't60', 237, ['m47','m35','m12'], ['r2','r1','r3'], 'fam1', 1 ).
test( 't61', 129, ['m44','m50'], [], 'fam1', 1 ).
test( 't62', 766, ['m38','m5','m49','m48','m34','m4','m31','m35','m15','m12','m7','m8','m11'], ['r3','r2','r1'], 'fam1', 1 ).
test( 't63', 508, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't64', 6, [], ['r2'], 'fam1', 1 ).
test( 't65', 719, ['m39','m32','m7','m27','m11','m38','m10','m25','m30','m35','m20','m29','m48','m45','m24','m12','m49','m2','m8','m31'], [], 'fam1', 1 ).
test( 't66', 125, [], ['r2','r3'], 'fam1', 1 ).
test( 't67', 796, [], ['r3'], 'fam1', 1 ).
test( 't68', 662, [], [], 'fam1', 1 ).
test( 't69', 134, [], [], 'fam1', 1 ).
test( 't70', 484, [], ['r1','r3'], 'fam1', 1 ).
test( 't71', 714, ['m19','m26','m10','m6','m43','m29','m33','m32','m49','m23','m50','m30','m48','m44','m27','m5','m20','m2'], [], 'fam1', 1 ).
test( 't72', 250, [], [], 'fam1', 1 ).
test( 't73', 590, ['m16','m35','m34','m4','m49'], [], 'fam1', 1 ).
test( 't74', 776, [], [], 'fam1', 1 ).
test( 't75', 708, [], [], 'fam1', 1 ).
test( 't76', 783, ['m1'], [], 'fam1', 1 ).
test( 't77', 439, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't78', 334, [], ['r2','r1'], 'fam1', 1 ).
test( 't79', 556, [], [], 'fam1', 1 ).
test( 't80', 95, [], [], 'fam1', 1 ).
test( 't81', 239, [], [], 'fam1', 1 ).
test( 't82', 262, ['m9','m50','m41','m20','m23','m46','m38','m21','m22','m36','m26','m15','m27','m17','m39','m44','m5'], [], 'fam1', 1 ).
test( 't83', 398, [], [], 'fam1', 1 ).
test( 't84', 772, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't85', 82, [], ['r3','r2'], 'fam1', 1 ).
test( 't86', 68, [], [], 'fam1', 1 ).
test( 't87', 724, ['m37','m42','m29','m9','m48','m38','m7','m45','m16','m33','m39','m10','m8'], [], 'fam1', 1 ).
test( 't88', 234, [], [], 'fam1', 1 ).
test( 't89', 423, [], [], 'fam1', 1 ).
test( 't90', 421, [], [], 'fam1', 1 ).
test( 't91', 174, [], [], 'fam1', 1 ).
test( 't92', 350, [], [], 'fam1', 1 ).
test( 't93', 626, [], ['r2'], 'fam1', 1 ).
test( 't94', 632, [], ['r3','r2'], 'fam1', 1 ).
test( 't95', 473, ['m17','m46','m31','m43','m32','m3','m33','m28','m1','m26'], [], 'fam1', 1 ).
test( 't96', 226, [], ['r3'], 'fam1', 1 ).
test( 't97', 78, [], ['r1','r3'], 'fam1', 1 ).
test( 't98', 50, [], [], 'fam1', 1 ).
test( 't99', 21, [], ['r1','r2'], 'fam1', 1 ).
test( 't100', 285, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').
embedded_board( 'm21').
embedded_board( 'm22').
embedded_board( 'm23').
embedded_board( 'm24').
embedded_board( 'm25').
embedded_board( 'm26').
embedded_board( 'm27').
embedded_board( 'm28').
embedded_board( 'm29').
embedded_board( 'm30').
embedded_board( 'm31').
embedded_board( 'm32').
embedded_board( 'm33').
embedded_board( 'm34').
embedded_board( 'm35').
embedded_board( 'm36').
embedded_board( 'm37').
embedded_board( 'm38').
embedded_board( 'm39').
embedded_board( 'm40').
embedded_board( 'm41').
embedded_board( 'm42').
embedded_board( 'm43').
embedded_board( 'm44').
embedded_board( 'm45').
embedded_board( 'm46').
embedded_board( 'm47').
embedded_board( 'm48').
embedded_board( 'm49').
embedded_board( 'm50').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
