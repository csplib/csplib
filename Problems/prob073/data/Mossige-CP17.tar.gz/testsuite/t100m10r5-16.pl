%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 206, [], [], 'fam1', 1 ).
test( 't2', 300, ['m8','m1','m10','m4'], [], 'fam1', 1 ).
test( 't3', 421, [], ['r5','r2','r3','r1'], 'fam1', 1 ).
test( 't4', 464, [], ['r3','r5','r4'], 'fam1', 1 ).
test( 't5', 200, [], [], 'fam1', 1 ).
test( 't6', 262, [], [], 'fam1', 1 ).
test( 't7', 235, [], [], 'fam1', 1 ).
test( 't8', 254, [], [], 'fam1', 1 ).
test( 't9', 534, [], [], 'fam1', 1 ).
test( 't10', 606, ['m10','m1'], [], 'fam1', 1 ).
test( 't11', 268, [], ['r2','r5','r4'], 'fam1', 1 ).
test( 't12', 662, [], ['r5','r2','r1','r3','r4'], 'fam1', 1 ).
test( 't13', 789, ['m9'], [], 'fam1', 1 ).
test( 't14', 475, [], [], 'fam1', 1 ).
test( 't15', 277, [], [], 'fam1', 1 ).
test( 't16', 717, [], [], 'fam1', 1 ).
test( 't17', 558, [], [], 'fam1', 1 ).
test( 't18', 358, [], [], 'fam1', 1 ).
test( 't19', 503, [], [], 'fam1', 1 ).
test( 't20', 690, [], [], 'fam1', 1 ).
test( 't21', 104, [], [], 'fam1', 1 ).
test( 't22', 16, [], [], 'fam1', 1 ).
test( 't23', 183, [], ['r1'], 'fam1', 1 ).
test( 't24', 709, [], [], 'fam1', 1 ).
test( 't25', 595, [], [], 'fam1', 1 ).
test( 't26', 360, [], [], 'fam1', 1 ).
test( 't27', 592, [], [], 'fam1', 1 ).
test( 't28', 367, [], [], 'fam1', 1 ).
test( 't29', 340, [], [], 'fam1', 1 ).
test( 't30', 589, ['m3','m7','m5'], ['r5','r1','r4','r3'], 'fam1', 1 ).
test( 't31', 162, [], [], 'fam1', 1 ).
test( 't32', 666, [], [], 'fam1', 1 ).
test( 't33', 239, [], ['r5','r1','r3','r2','r4'], 'fam1', 1 ).
test( 't34', 73, [], [], 'fam1', 1 ).
test( 't35', 690, [], [], 'fam1', 1 ).
test( 't36', 80, ['m2'], [], 'fam1', 1 ).
test( 't37', 285, ['m3','m9'], [], 'fam1', 1 ).
test( 't38', 406, [], [], 'fam1', 1 ).
test( 't39', 479, [], [], 'fam1', 1 ).
test( 't40', 263, [], [], 'fam1', 1 ).
test( 't41', 192, [], ['r5','r2','r1'], 'fam1', 1 ).
test( 't42', 49, ['m8','m1'], [], 'fam1', 1 ).
test( 't43', 473, [], [], 'fam1', 1 ).
test( 't44', 372, ['m1','m10','m6','m3'], [], 'fam1', 1 ).
test( 't45', 540, ['m3','m7','m8'], ['r2','r5'], 'fam1', 1 ).
test( 't46', 293, [], [], 'fam1', 1 ).
test( 't47', 206, ['m3','m10'], [], 'fam1', 1 ).
test( 't48', 700, [], [], 'fam1', 1 ).
test( 't49', 497, [], ['r4'], 'fam1', 1 ).
test( 't50', 481, [], [], 'fam1', 1 ).
test( 't51', 550, [], [], 'fam1', 1 ).
test( 't52', 693, ['m8','m4'], ['r3','r2'], 'fam1', 1 ).
test( 't53', 123, [], [], 'fam1', 1 ).
test( 't54', 81, [], [], 'fam1', 1 ).
test( 't55', 512, [], ['r1','r2','r4','r3','r5'], 'fam1', 1 ).
test( 't56', 705, ['m5','m10'], [], 'fam1', 1 ).
test( 't57', 376, [], [], 'fam1', 1 ).
test( 't58', 331, ['m1','m4','m5','m10'], ['r3','r5','r2','r4','r1'], 'fam1', 1 ).
test( 't59', 755, [], ['r1'], 'fam1', 1 ).
test( 't60', 102, [], [], 'fam1', 1 ).
test( 't61', 383, [], [], 'fam1', 1 ).
test( 't62', 107, [], [], 'fam1', 1 ).
test( 't63', 94, ['m6','m5','m10','m2'], ['r5','r2','r1','r4'], 'fam1', 1 ).
test( 't64', 53, ['m2','m5','m7','m9'], [], 'fam1', 1 ).
test( 't65', 660, [], [], 'fam1', 1 ).
test( 't66', 381, [], ['r2','r4','r1','r3'], 'fam1', 1 ).
test( 't67', 39, ['m6','m5','m9'], ['r3','r4','r1','r2','r5'], 'fam1', 1 ).
test( 't68', 698, [], [], 'fam1', 1 ).
test( 't69', 428, [], [], 'fam1', 1 ).
test( 't70', 211, [], ['r4'], 'fam1', 1 ).
test( 't71', 780, [], ['r2','r4','r1','r3'], 'fam1', 1 ).
test( 't72', 25, [], [], 'fam1', 1 ).
test( 't73', 302, [], ['r3'], 'fam1', 1 ).
test( 't74', 735, [], [], 'fam1', 1 ).
test( 't75', 112, ['m2','m7'], [], 'fam1', 1 ).
test( 't76', 134, [], [], 'fam1', 1 ).
test( 't77', 93, [], [], 'fam1', 1 ).
test( 't78', 300, [], [], 'fam1', 1 ).
test( 't79', 102, [], ['r3'], 'fam1', 1 ).
test( 't80', 394, [], [], 'fam1', 1 ).
test( 't81', 409, [], [], 'fam1', 1 ).
test( 't82', 384, [], ['r3','r4','r2','r5'], 'fam1', 1 ).
test( 't83', 76, [], ['r3','r1'], 'fam1', 1 ).
test( 't84', 69, ['m6','m7','m10','m5'], [], 'fam1', 1 ).
test( 't85', 733, [], ['r5'], 'fam1', 1 ).
test( 't86', 595, [], [], 'fam1', 1 ).
test( 't87', 90, [], [], 'fam1', 1 ).
test( 't88', 730, ['m2','m3'], [], 'fam1', 1 ).
test( 't89', 150, [], ['r5','r1'], 'fam1', 1 ).
test( 't90', 64, [], ['r2','r4','r1'], 'fam1', 1 ).
test( 't91', 389, [], [], 'fam1', 1 ).
test( 't92', 556, [], [], 'fam1', 1 ).
test( 't93', 631, ['m5','m7'], [], 'fam1', 1 ).
test( 't94', 134, [], ['r5','r2'], 'fam1', 1 ).
test( 't95', 640, [], [], 'fam1', 1 ).
test( 't96', 14, [], [], 'fam1', 1 ).
test( 't97', 66, ['m1'], [], 'fam1', 1 ).
test( 't98', 232, [], ['r3','r2','r5'], 'fam1', 1 ).
test( 't99', 608, [], [], 'fam1', 1 ).
test( 't100', 504, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
