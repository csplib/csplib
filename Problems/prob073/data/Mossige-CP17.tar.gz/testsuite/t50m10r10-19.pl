%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 10
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 145, [], [], 'fam1', 1 ).
test( 't2', 303, [], ['r7','r6','r2'], 'fam1', 1 ).
test( 't3', 365, [], ['r6'], 'fam1', 1 ).
test( 't4', 307, [], [], 'fam1', 1 ).
test( 't5', 253, [], [], 'fam1', 1 ).
test( 't6', 109, ['m9','m3','m2','m8'], [], 'fam1', 1 ).
test( 't7', 724, [], [], 'fam1', 1 ).
test( 't8', 632, ['m6','m1','m3','m4'], [], 'fam1', 1 ).
test( 't9', 450, [], ['r5','r2','r3','r8','r9','r7'], 'fam1', 1 ).
test( 't10', 708, ['m5','m2','m9','m6'], [], 'fam1', 1 ).
test( 't11', 583, [], ['r10','r4'], 'fam1', 1 ).
test( 't12', 429, [], [], 'fam1', 1 ).
test( 't13', 284, [], ['r6','r1'], 'fam1', 1 ).
test( 't14', 700, [], [], 'fam1', 1 ).
test( 't15', 144, [], [], 'fam1', 1 ).
test( 't16', 689, [], [], 'fam1', 1 ).
test( 't17', 591, [], [], 'fam1', 1 ).
test( 't18', 12, [], [], 'fam1', 1 ).
test( 't19', 440, [], [], 'fam1', 1 ).
test( 't20', 695, [], ['r4','r2','r8','r6'], 'fam1', 1 ).
test( 't21', 422, [], [], 'fam1', 1 ).
test( 't22', 470, [], [], 'fam1', 1 ).
test( 't23', 215, [], [], 'fam1', 1 ).
test( 't24', 548, [], [], 'fam1', 1 ).
test( 't25', 406, [], [], 'fam1', 1 ).
test( 't26', 149, [], ['r6','r2','r4','r9','r5'], 'fam1', 1 ).
test( 't27', 433, [], [], 'fam1', 1 ).
test( 't28', 112, [], [], 'fam1', 1 ).
test( 't29', 625, ['m2','m9','m10','m5'], [], 'fam1', 1 ).
test( 't30', 558, [], [], 'fam1', 1 ).
test( 't31', 407, [], ['r2','r3','r10','r1','r8','r4','r7'], 'fam1', 1 ).
test( 't32', 49, [], ['r9','r8','r6','r7','r4','r10','r2'], 'fam1', 1 ).
test( 't33', 178, [], ['r2','r10','r9'], 'fam1', 1 ).
test( 't34', 250, [], [], 'fam1', 1 ).
test( 't35', 341, ['m5'], ['r4','r7','r10','r9','r5','r6','r3'], 'fam1', 1 ).
test( 't36', 634, [], [], 'fam1', 1 ).
test( 't37', 663, [], [], 'fam1', 1 ).
test( 't38', 522, [], ['r10','r9','r4','r2','r3'], 'fam1', 1 ).
test( 't39', 778, ['m7'], [], 'fam1', 1 ).
test( 't40', 597, [], [], 'fam1', 1 ).
test( 't41', 400, ['m5'], ['r10','r3','r8','r2'], 'fam1', 1 ).
test( 't42', 677, [], ['r2','r4','r5','r8','r9','r1','r7','r3','r10'], 'fam1', 1 ).
test( 't43', 107, [], ['r10','r2','r7','r3','r4','r8','r6'], 'fam1', 1 ).
test( 't44', 576, [], [], 'fam1', 1 ).
test( 't45', 595, [], ['r3','r1','r6','r8','r4','r5','r9','r2','r7'], 'fam1', 1 ).
test( 't46', 533, ['m3','m9','m10'], [], 'fam1', 1 ).
test( 't47', 705, [], [], 'fam1', 1 ).
test( 't48', 428, ['m2','m5'], [], 'fam1', 1 ).
test( 't49', 393, ['m9','m4','m1','m10'], [], 'fam1', 1 ).
test( 't50', 780, ['m6'], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
