%% ****  Testsuite  ****
% Number of tests                  : 20
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 604, [], [], 'fam1', 1 ).
test( 't2', 217, ['m10','m3'], ['r1'], 'fam1', 1 ).
test( 't3', 586, ['m2','m1','m3'], [], 'fam1', 1 ).
test( 't4', 268, [], [], 'fam1', 1 ).
test( 't5', 21, [], [], 'fam1', 1 ).
test( 't6', 34, [], [], 'fam1', 1 ).
test( 't7', 27, [], [], 'fam1', 1 ).
test( 't8', 782, [], [], 'fam1', 1 ).
test( 't9', 358, ['m4','m7','m6','m9'], ['r1'], 'fam1', 1 ).
test( 't10', 9, [], [], 'fam1', 1 ).
test( 't11', 483, ['m9','m1'], [], 'fam1', 1 ).
test( 't12', 365, ['m8','m4','m6','m5'], [], 'fam1', 1 ).
test( 't13', 181, [], ['r1'], 'fam1', 1 ).
test( 't14', 114, [], ['r3'], 'fam1', 1 ).
test( 't15', 111, [], [], 'fam1', 1 ).
test( 't16', 717, ['m2','m7'], [], 'fam1', 1 ).
test( 't17', 347, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't18', 635, [], ['r1'], 'fam1', 1 ).
test( 't19', 270, [], [], 'fam1', 1 ).
test( 't20', 482, ['m5','m1','m3','m4'], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
