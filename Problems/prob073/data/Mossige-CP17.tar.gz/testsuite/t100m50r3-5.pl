%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 50
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 605, ['m50','m47','m35','m25','m37','m1','m33','m44','m36','m39','m8'], [], 'fam1', 1 ).
test( 't2', 258, [], [], 'fam1', 1 ).
test( 't3', 243, [], [], 'fam1', 1 ).
test( 't4', 714, [], [], 'fam1', 1 ).
test( 't5', 382, ['m31','m19','m3','m25','m45','m18','m47','m44','m37','m17','m14'], [], 'fam1', 1 ).
test( 't6', 430, [], [], 'fam1', 1 ).
test( 't7', 789, [], [], 'fam1', 1 ).
test( 't8', 117, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't9', 68, [], [], 'fam1', 1 ).
test( 't10', 133, [], [], 'fam1', 1 ).
test( 't11', 81, [], ['r3'], 'fam1', 1 ).
test( 't12', 445, [], [], 'fam1', 1 ).
test( 't13', 350, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't14', 417, ['m7','m29','m9','m34','m37','m10','m6','m35'], [], 'fam1', 1 ).
test( 't15', 429, [], [], 'fam1', 1 ).
test( 't16', 317, [], ['r3'], 'fam1', 1 ).
test( 't17', 445, [], [], 'fam1', 1 ).
test( 't18', 4, [], [], 'fam1', 1 ).
test( 't19', 752, [], [], 'fam1', 1 ).
test( 't20', 134, [], [], 'fam1', 1 ).
test( 't21', 691, [], [], 'fam1', 1 ).
test( 't22', 597, [], [], 'fam1', 1 ).
test( 't23', 112, [], [], 'fam1', 1 ).
test( 't24', 89, [], [], 'fam1', 1 ).
test( 't25', 355, ['m25','m4','m44','m37','m20','m28','m32','m7','m47','m38'], [], 'fam1', 1 ).
test( 't26', 634, [], [], 'fam1', 1 ).
test( 't27', 157, [], ['r1'], 'fam1', 1 ).
test( 't28', 12, [], ['r1'], 'fam1', 1 ).
test( 't29', 161, [], [], 'fam1', 1 ).
test( 't30', 89, ['m2','m45','m18','m5'], [], 'fam1', 1 ).
test( 't31', 484, [], [], 'fam1', 1 ).
test( 't32', 258, [], ['r3','r2'], 'fam1', 1 ).
test( 't33', 474, ['m50','m26','m35','m49','m48','m15','m20','m42'], [], 'fam1', 1 ).
test( 't34', 770, ['m1','m10','m12','m37','m8','m28','m32','m38','m17','m25'], [], 'fam1', 1 ).
test( 't35', 83, ['m27','m44','m18','m42','m50','m25','m26','m45','m28','m1','m37','m47','m31','m49','m29','m40','m24','m11','m34','m17'], [], 'fam1', 1 ).
test( 't36', 461, [], [], 'fam1', 1 ).
test( 't37', 639, [], [], 'fam1', 1 ).
test( 't38', 349, [], ['r3'], 'fam1', 1 ).
test( 't39', 258, [], [], 'fam1', 1 ).
test( 't40', 9, [], ['r1'], 'fam1', 1 ).
test( 't41', 427, [], [], 'fam1', 1 ).
test( 't42', 491, [], ['r1','r2'], 'fam1', 1 ).
test( 't43', 607, [], [], 'fam1', 1 ).
test( 't44', 432, ['m20','m39','m47','m37','m6'], [], 'fam1', 1 ).
test( 't45', 300, [], [], 'fam1', 1 ).
test( 't46', 62, [], [], 'fam1', 1 ).
test( 't47', 579, [], [], 'fam1', 1 ).
test( 't48', 401, [], [], 'fam1', 1 ).
test( 't49', 33, [], [], 'fam1', 1 ).
test( 't50', 499, [], [], 'fam1', 1 ).
test( 't51', 36, [], ['r2'], 'fam1', 1 ).
test( 't52', 15, [], [], 'fam1', 1 ).
test( 't53', 664, [], [], 'fam1', 1 ).
test( 't54', 164, [], [], 'fam1', 1 ).
test( 't55', 703, [], [], 'fam1', 1 ).
test( 't56', 431, [], [], 'fam1', 1 ).
test( 't57', 370, [], ['r3','r2'], 'fam1', 1 ).
test( 't58', 558, [], [], 'fam1', 1 ).
test( 't59', 248, ['m7','m16','m28','m1','m39','m44','m20','m19','m13','m9','m8','m18','m35','m5'], [], 'fam1', 1 ).
test( 't60', 147, [], [], 'fam1', 1 ).
test( 't61', 288, [], [], 'fam1', 1 ).
test( 't62', 767, ['m16','m10','m17','m5','m30','m20','m43','m35','m32','m6','m28','m36','m26','m46','m44','m1','m47'], [], 'fam1', 1 ).
test( 't63', 273, ['m11','m24','m20','m47','m32','m48','m37','m9','m41','m43','m42','m16','m2','m33'], [], 'fam1', 1 ).
test( 't64', 159, [], ['r3','r1'], 'fam1', 1 ).
test( 't65', 488, [], [], 'fam1', 1 ).
test( 't66', 509, [], [], 'fam1', 1 ).
test( 't67', 747, [], [], 'fam1', 1 ).
test( 't68', 267, ['m41','m13','m40','m1','m37','m2','m20','m23','m21','m29','m32','m27','m5'], ['r3'], 'fam1', 1 ).
test( 't69', 761, [], [], 'fam1', 1 ).
test( 't70', 433, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't71', 402, [], [], 'fam1', 1 ).
test( 't72', 456, [], [], 'fam1', 1 ).
test( 't73', 595, ['m32','m42','m2','m19','m21','m5','m41','m25','m13','m44','m12'], [], 'fam1', 1 ).
test( 't74', 313, [], [], 'fam1', 1 ).
test( 't75', 312, ['m49','m37','m33','m31','m44','m11','m8','m1','m38','m14','m32','m17','m9','m36','m18','m27','m28','m23'], [], 'fam1', 1 ).
test( 't76', 663, [], ['r2'], 'fam1', 1 ).
test( 't77', 109, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't78', 343, [], [], 'fam1', 1 ).
test( 't79', 530, ['m37','m48','m15','m9','m2','m24','m50','m40','m3','m31','m42','m32','m41','m25','m6','m13','m29','m19','m26','m38'], [], 'fam1', 1 ).
test( 't80', 33, [], ['r2'], 'fam1', 1 ).
test( 't81', 447, [], [], 'fam1', 1 ).
test( 't82', 156, [], [], 'fam1', 1 ).
test( 't83', 180, [], ['r1','r3'], 'fam1', 1 ).
test( 't84', 353, [], [], 'fam1', 1 ).
test( 't85', 442, [], [], 'fam1', 1 ).
test( 't86', 314, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't87', 770, ['m20','m37','m36','m19','m40','m41','m32','m28','m27','m39','m48','m17','m35'], ['r2'], 'fam1', 1 ).
test( 't88', 248, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't89', 543, ['m18','m38','m40','m28','m2','m39','m10','m24','m49','m35','m14','m48','m4'], [], 'fam1', 1 ).
test( 't90', 291, [], [], 'fam1', 1 ).
test( 't91', 781, [], [], 'fam1', 1 ).
test( 't92', 383, [], ['r1'], 'fam1', 1 ).
test( 't93', 463, [], ['r1','r3'], 'fam1', 1 ).
test( 't94', 159, [], [], 'fam1', 1 ).
test( 't95', 209, [], [], 'fam1', 1 ).
test( 't96', 57, [], ['r1','r3'], 'fam1', 1 ).
test( 't97', 6, [], [], 'fam1', 1 ).
test( 't98', 125, [], [], 'fam1', 1 ).
test( 't99', 135, [], ['r3'], 'fam1', 1 ).
test( 't100', 571, ['m41','m37','m25','m48','m20','m31','m27','m9','m7','m47','m28','m11','m42','m15','m43','m30','m10'], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').
embedded_board( 'm21').
embedded_board( 'm22').
embedded_board( 'm23').
embedded_board( 'm24').
embedded_board( 'm25').
embedded_board( 'm26').
embedded_board( 'm27').
embedded_board( 'm28').
embedded_board( 'm29').
embedded_board( 'm30').
embedded_board( 'm31').
embedded_board( 'm32').
embedded_board( 'm33').
embedded_board( 'm34').
embedded_board( 'm35').
embedded_board( 'm36').
embedded_board( 'm37').
embedded_board( 'm38').
embedded_board( 'm39').
embedded_board( 'm40').
embedded_board( 'm41').
embedded_board( 'm42').
embedded_board( 'm43').
embedded_board( 'm44').
embedded_board( 'm45').
embedded_board( 'm46').
embedded_board( 'm47').
embedded_board( 'm48').
embedded_board( 'm49').
embedded_board( 'm50').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
