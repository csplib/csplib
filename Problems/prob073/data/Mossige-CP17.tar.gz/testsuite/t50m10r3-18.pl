%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 732, [], ['r2'], 'fam1', 1 ).
test( 't2', 257, [], ['r1'], 'fam1', 1 ).
test( 't3', 269, [], ['r3','r1'], 'fam1', 1 ).
test( 't4', 783, [], [], 'fam1', 1 ).
test( 't5', 120, [], [], 'fam1', 1 ).
test( 't6', 304, [], [], 'fam1', 1 ).
test( 't7', 143, [], [], 'fam1', 1 ).
test( 't8', 342, ['m7','m9','m10','m5'], [], 'fam1', 1 ).
test( 't9', 80, [], [], 'fam1', 1 ).
test( 't10', 348, [], [], 'fam1', 1 ).
test( 't11', 13, [], ['r1'], 'fam1', 1 ).
test( 't12', 305, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't13', 755, ['m3','m2','m4','m7'], [], 'fam1', 1 ).
test( 't14', 709, [], ['r3','r1'], 'fam1', 1 ).
test( 't15', 319, [], [], 'fam1', 1 ).
test( 't16', 599, ['m10','m1','m8','m9'], ['r3','r1','r2'], 'fam1', 1 ).
test( 't17', 551, ['m7'], ['r2'], 'fam1', 1 ).
test( 't18', 9, ['m8','m3','m5','m10'], [], 'fam1', 1 ).
test( 't19', 61, [], [], 'fam1', 1 ).
test( 't20', 484, ['m5'], [], 'fam1', 1 ).
test( 't21', 463, [], [], 'fam1', 1 ).
test( 't22', 411, [], [], 'fam1', 1 ).
test( 't23', 596, ['m5','m7','m2'], ['r2'], 'fam1', 1 ).
test( 't24', 782, [], [], 'fam1', 1 ).
test( 't25', 775, [], [], 'fam1', 1 ).
test( 't26', 426, [], [], 'fam1', 1 ).
test( 't27', 481, [], [], 'fam1', 1 ).
test( 't28', 640, [], [], 'fam1', 1 ).
test( 't29', 665, [], [], 'fam1', 1 ).
test( 't30', 423, [], ['r3'], 'fam1', 1 ).
test( 't31', 596, [], [], 'fam1', 1 ).
test( 't32', 425, ['m9'], [], 'fam1', 1 ).
test( 't33', 594, [], ['r2'], 'fam1', 1 ).
test( 't34', 753, [], [], 'fam1', 1 ).
test( 't35', 248, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't36', 545, [], [], 'fam1', 1 ).
test( 't37', 94, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't38', 705, [], [], 'fam1', 1 ).
test( 't39', 412, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't40', 590, ['m2','m10'], ['r3','r1','r2'], 'fam1', 1 ).
test( 't41', 144, [], [], 'fam1', 1 ).
test( 't42', 463, [], [], 'fam1', 1 ).
test( 't43', 146, [], [], 'fam1', 1 ).
test( 't44', 181, [], [], 'fam1', 1 ).
test( 't45', 82, ['m9','m8','m3','m7'], [], 'fam1', 1 ).
test( 't46', 465, [], [], 'fam1', 1 ).
test( 't47', 465, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't48', 131, [], [], 'fam1', 1 ).
test( 't49', 457, [], [], 'fam1', 1 ).
test( 't50', 132, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
