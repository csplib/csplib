%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 20
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 620, ['m3','m7','m9','m1','m15'], ['r3','r2','r4'], 'fam1', 1 ).
test( 't2', 513, [], ['r4'], 'fam1', 1 ).
test( 't3', 317, ['m2','m16'], [], 'fam1', 1 ).
test( 't4', 786, [], [], 'fam1', 1 ).
test( 't5', 445, [], [], 'fam1', 1 ).
test( 't6', 281, [], [], 'fam1', 1 ).
test( 't7', 40, ['m15','m14'], [], 'fam1', 1 ).
test( 't8', 780, [], [], 'fam1', 1 ).
test( 't9', 729, [], [], 'fam1', 1 ).
test( 't10', 424, [], [], 'fam1', 1 ).
test( 't11', 324, [], [], 'fam1', 1 ).
test( 't12', 610, ['m5','m4','m20'], [], 'fam1', 1 ).
test( 't13', 304, [], ['r1','r5','r3','r4','r2'], 'fam1', 1 ).
test( 't14', 437, [], [], 'fam1', 1 ).
test( 't15', 266, ['m19','m2','m16','m10','m9','m12','m7'], [], 'fam1', 1 ).
test( 't16', 625, ['m17','m20','m5','m13','m10'], [], 'fam1', 1 ).
test( 't17', 153, [], [], 'fam1', 1 ).
test( 't18', 296, [], [], 'fam1', 1 ).
test( 't19', 91, [], [], 'fam1', 1 ).
test( 't20', 67, ['m2','m15','m16','m14'], [], 'fam1', 1 ).
test( 't21', 775, [], [], 'fam1', 1 ).
test( 't22', 154, [], [], 'fam1', 1 ).
test( 't23', 433, [], ['r3'], 'fam1', 1 ).
test( 't24', 445, [], [], 'fam1', 1 ).
test( 't25', 131, ['m1','m18','m3'], [], 'fam1', 1 ).
test( 't26', 374, ['m5','m13','m10','m1','m7'], ['r1','r5'], 'fam1', 1 ).
test( 't27', 358, [], ['r3','r5'], 'fam1', 1 ).
test( 't28', 177, [], [], 'fam1', 1 ).
test( 't29', 577, ['m7','m1','m6','m17','m8','m2'], [], 'fam1', 1 ).
test( 't30', 798, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
