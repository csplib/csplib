%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 53, [], ['r5'], 'fam1', 1 ).
test( 't2', 757, [], [], 'fam1', 1 ).
test( 't3', 664, [], ['r5','r1','r4'], 'fam1', 1 ).
test( 't4', 580, [], ['r3','r5','r4'], 'fam1', 1 ).
test( 't5', 796, [], [], 'fam1', 1 ).
test( 't6', 619, [], [], 'fam1', 1 ).
test( 't7', 528, ['m7','m9','m1'], [], 'fam1', 1 ).
test( 't8', 310, [], [], 'fam1', 1 ).
test( 't9', 764, [], [], 'fam1', 1 ).
test( 't10', 172, [], [], 'fam1', 1 ).
test( 't11', 544, [], [], 'fam1', 1 ).
test( 't12', 473, [], [], 'fam1', 1 ).
test( 't13', 214, ['m5','m3','m2','m9'], [], 'fam1', 1 ).
test( 't14', 131, ['m5','m8','m6'], [], 'fam1', 1 ).
test( 't15', 374, ['m1','m4','m3','m5'], [], 'fam1', 1 ).
test( 't16', 536, [], [], 'fam1', 1 ).
test( 't17', 132, [], [], 'fam1', 1 ).
test( 't18', 459, [], [], 'fam1', 1 ).
test( 't19', 455, [], [], 'fam1', 1 ).
test( 't20', 100, ['m1','m9','m3','m5'], ['r2','r3','r4'], 'fam1', 1 ).
test( 't21', 775, [], ['r2','r3'], 'fam1', 1 ).
test( 't22', 588, ['m4','m8'], [], 'fam1', 1 ).
test( 't23', 235, [], [], 'fam1', 1 ).
test( 't24', 587, [], [], 'fam1', 1 ).
test( 't25', 436, ['m4','m6','m7'], ['r5','r1','r3','r4'], 'fam1', 1 ).
test( 't26', 321, [], [], 'fam1', 1 ).
test( 't27', 91, [], [], 'fam1', 1 ).
test( 't28', 466, [], [], 'fam1', 1 ).
test( 't29', 575, [], [], 'fam1', 1 ).
test( 't30', 586, [], ['r4'], 'fam1', 1 ).
test( 't31', 392, ['m7','m1'], [], 'fam1', 1 ).
test( 't32', 362, [], [], 'fam1', 1 ).
test( 't33', 32, [], [], 'fam1', 1 ).
test( 't34', 29, ['m6','m10'], [], 'fam1', 1 ).
test( 't35', 360, [], [], 'fam1', 1 ).
test( 't36', 747, [], ['r2','r3','r1','r4'], 'fam1', 1 ).
test( 't37', 259, ['m1'], [], 'fam1', 1 ).
test( 't38', 465, [], ['r2','r1'], 'fam1', 1 ).
test( 't39', 425, [], [], 'fam1', 1 ).
test( 't40', 630, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
