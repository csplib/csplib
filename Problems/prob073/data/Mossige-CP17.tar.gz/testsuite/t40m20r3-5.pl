%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 20
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 586, [], [], 'fam1', 1 ).
test( 't2', 152, [], ['r2'], 'fam1', 1 ).
test( 't3', 695, [], [], 'fam1', 1 ).
test( 't4', 593, [], [], 'fam1', 1 ).
test( 't5', 416, ['m18','m8'], [], 'fam1', 1 ).
test( 't6', 424, [], [], 'fam1', 1 ).
test( 't7', 167, ['m17'], [], 'fam1', 1 ).
test( 't8', 298, [], [], 'fam1', 1 ).
test( 't9', 406, [], [], 'fam1', 1 ).
test( 't10', 735, [], ['r3','r1'], 'fam1', 1 ).
test( 't11', 709, [], [], 'fam1', 1 ).
test( 't12', 622, [], [], 'fam1', 1 ).
test( 't13', 128, [], [], 'fam1', 1 ).
test( 't14', 11, [], [], 'fam1', 1 ).
test( 't15', 27, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't16', 541, [], [], 'fam1', 1 ).
test( 't17', 122, [], [], 'fam1', 1 ).
test( 't18', 221, [], ['r2','r1'], 'fam1', 1 ).
test( 't19', 395, [], [], 'fam1', 1 ).
test( 't20', 338, [], [], 'fam1', 1 ).
test( 't21', 418, [], [], 'fam1', 1 ).
test( 't22', 191, [], [], 'fam1', 1 ).
test( 't23', 366, [], [], 'fam1', 1 ).
test( 't24', 92, [], ['r1','r2'], 'fam1', 1 ).
test( 't25', 439, ['m4','m1','m3','m11'], [], 'fam1', 1 ).
test( 't26', 734, ['m19','m10'], ['r2','r1'], 'fam1', 1 ).
test( 't27', 435, [], [], 'fam1', 1 ).
test( 't28', 338, [], [], 'fam1', 1 ).
test( 't29', 173, ['m15','m2','m6'], [], 'fam1', 1 ).
test( 't30', 578, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't31', 71, [], [], 'fam1', 1 ).
test( 't32', 41, [], [], 'fam1', 1 ).
test( 't33', 528, [], [], 'fam1', 1 ).
test( 't34', 71, [], [], 'fam1', 1 ).
test( 't35', 746, [], ['r3','r2'], 'fam1', 1 ).
test( 't36', 655, [], [], 'fam1', 1 ).
test( 't37', 159, [], [], 'fam1', 1 ).
test( 't38', 652, [], ['r2'], 'fam1', 1 ).
test( 't39', 424, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't40', 594, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
