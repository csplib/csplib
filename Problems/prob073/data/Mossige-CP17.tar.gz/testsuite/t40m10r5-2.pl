%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 564, [], [], 'fam1', 1 ).
test( 't2', 76, ['m1','m10','m2'], [], 'fam1', 1 ).
test( 't3', 141, [], [], 'fam1', 1 ).
test( 't4', 281, [], [], 'fam1', 1 ).
test( 't5', 335, [], [], 'fam1', 1 ).
test( 't6', 771, [], ['r2','r3','r4','r5','r1'], 'fam1', 1 ).
test( 't7', 664, [], [], 'fam1', 1 ).
test( 't8', 532, [], [], 'fam1', 1 ).
test( 't9', 448, [], [], 'fam1', 1 ).
test( 't10', 309, [], ['r3','r2','r5','r4','r1'], 'fam1', 1 ).
test( 't11', 607, [], [], 'fam1', 1 ).
test( 't12', 132, [], [], 'fam1', 1 ).
test( 't13', 703, [], [], 'fam1', 1 ).
test( 't14', 512, [], [], 'fam1', 1 ).
test( 't15', 357, [], [], 'fam1', 1 ).
test( 't16', 495, [], ['r3','r5','r1','r4','r2'], 'fam1', 1 ).
test( 't17', 778, [], [], 'fam1', 1 ).
test( 't18', 22, [], [], 'fam1', 1 ).
test( 't19', 329, [], [], 'fam1', 1 ).
test( 't20', 39, [], [], 'fam1', 1 ).
test( 't21', 154, [], [], 'fam1', 1 ).
test( 't22', 785, [], [], 'fam1', 1 ).
test( 't23', 136, ['m1'], ['r1','r5','r3','r4'], 'fam1', 1 ).
test( 't24', 72, [], [], 'fam1', 1 ).
test( 't25', 572, [], ['r2','r1'], 'fam1', 1 ).
test( 't26', 231, [], [], 'fam1', 1 ).
test( 't27', 372, ['m1','m3'], [], 'fam1', 1 ).
test( 't28', 777, [], [], 'fam1', 1 ).
test( 't29', 792, ['m4'], ['r2','r5','r1'], 'fam1', 1 ).
test( 't30', 380, ['m2','m4','m10'], [], 'fam1', 1 ).
test( 't31', 398, [], [], 'fam1', 1 ).
test( 't32', 111, [], [], 'fam1', 1 ).
test( 't33', 547, [], [], 'fam1', 1 ).
test( 't34', 635, ['m1'], [], 'fam1', 1 ).
test( 't35', 485, [], [], 'fam1', 1 ).
test( 't36', 289, [], [], 'fam1', 1 ).
test( 't37', 215, [], [], 'fam1', 1 ).
test( 't38', 228, [], [], 'fam1', 1 ).
test( 't39', 694, [], ['r1','r3'], 'fam1', 1 ).
test( 't40', 330, [], ['r3','r4','r5','r2'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
