%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 20
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 778, [], [], 'fam1', 1 ).
test( 't2', 305, [], ['r4','r3','r2','r1','r5'], 'fam1', 1 ).
test( 't3', 254, [], [], 'fam1', 1 ).
test( 't4', 434, [], [], 'fam1', 1 ).
test( 't5', 638, [], [], 'fam1', 1 ).
test( 't6', 536, [], ['r1'], 'fam1', 1 ).
test( 't7', 213, [], ['r4','r2','r3','r5'], 'fam1', 1 ).
test( 't8', 594, [], [], 'fam1', 1 ).
test( 't9', 29, [], [], 'fam1', 1 ).
test( 't10', 58, [], [], 'fam1', 1 ).
test( 't11', 185, [], [], 'fam1', 1 ).
test( 't12', 453, [], [], 'fam1', 1 ).
test( 't13', 547, [], [], 'fam1', 1 ).
test( 't14', 603, [], [], 'fam1', 1 ).
test( 't15', 204, [], [], 'fam1', 1 ).
test( 't16', 214, ['m16','m3','m4','m7','m1','m14'], [], 'fam1', 1 ).
test( 't17', 314, ['m5','m1','m8','m12','m20','m16','m7'], ['r1','r5','r3'], 'fam1', 1 ).
test( 't18', 692, ['m12','m16','m14','m4','m1'], [], 'fam1', 1 ).
test( 't19', 625, [], [], 'fam1', 1 ).
test( 't20', 480, ['m18','m8','m1','m2','m17','m3'], [], 'fam1', 1 ).
test( 't21', 521, [], [], 'fam1', 1 ).
test( 't22', 588, [], [], 'fam1', 1 ).
test( 't23', 210, [], ['r1','r4','r3','r2'], 'fam1', 1 ).
test( 't24', 244, [], [], 'fam1', 1 ).
test( 't25', 72, [], [], 'fam1', 1 ).
test( 't26', 135, [], [], 'fam1', 1 ).
test( 't27', 50, [], [], 'fam1', 1 ).
test( 't28', 515, [], [], 'fam1', 1 ).
test( 't29', 55, [], [], 'fam1', 1 ).
test( 't30', 88, [], ['r4','r3','r1','r2','r5'], 'fam1', 1 ).
test( 't31', 43, [], [], 'fam1', 1 ).
test( 't32', 245, [], ['r4','r1','r3','r5'], 'fam1', 1 ).
test( 't33', 626, [], ['r3','r1','r2','r4','r5'], 'fam1', 1 ).
test( 't34', 750, [], ['r4'], 'fam1', 1 ).
test( 't35', 486, ['m16','m8'], [], 'fam1', 1 ).
test( 't36', 714, [], [], 'fam1', 1 ).
test( 't37', 242, [], [], 'fam1', 1 ).
test( 't38', 174, [], ['r2'], 'fam1', 1 ).
test( 't39', 255, [], [], 'fam1', 1 ).
test( 't40', 720, [], [], 'fam1', 1 ).
test( 't41', 155, [], [], 'fam1', 1 ).
test( 't42', 691, [], ['r2','r3','r5','r4','r1'], 'fam1', 1 ).
test( 't43', 277, [], [], 'fam1', 1 ).
test( 't44', 427, ['m11','m3','m19'], [], 'fam1', 1 ).
test( 't45', 443, [], ['r3','r4','r2'], 'fam1', 1 ).
test( 't46', 239, [], [], 'fam1', 1 ).
test( 't47', 598, ['m5','m17','m14','m10','m6'], ['r4'], 'fam1', 1 ).
test( 't48', 286, [], ['r2','r4','r1','r3'], 'fam1', 1 ).
test( 't49', 569, [], [], 'fam1', 1 ).
test( 't50', 452, ['m6','m1','m9','m4'], [], 'fam1', 1 ).
test( 't51', 525, [], ['r1','r4','r3','r2','r5'], 'fam1', 1 ).
test( 't52', 10, [], ['r4'], 'fam1', 1 ).
test( 't53', 696, [], ['r3'], 'fam1', 1 ).
test( 't54', 87, [], [], 'fam1', 1 ).
test( 't55', 797, [], [], 'fam1', 1 ).
test( 't56', 523, [], [], 'fam1', 1 ).
test( 't57', 292, [], [], 'fam1', 1 ).
test( 't58', 311, [], [], 'fam1', 1 ).
test( 't59', 311, [], [], 'fam1', 1 ).
test( 't60', 599, [], ['r3','r5','r2','r4','r1'], 'fam1', 1 ).
test( 't61', 21, [], [], 'fam1', 1 ).
test( 't62', 247, [], [], 'fam1', 1 ).
test( 't63', 639, [], [], 'fam1', 1 ).
test( 't64', 210, [], [], 'fam1', 1 ).
test( 't65', 728, [], [], 'fam1', 1 ).
test( 't66', 400, [], [], 'fam1', 1 ).
test( 't67', 245, [], [], 'fam1', 1 ).
test( 't68', 205, [], [], 'fam1', 1 ).
test( 't69', 367, ['m6','m10'], ['r1','r5','r2','r3','r4'], 'fam1', 1 ).
test( 't70', 237, [], [], 'fam1', 1 ).
test( 't71', 611, [], [], 'fam1', 1 ).
test( 't72', 733, [], [], 'fam1', 1 ).
test( 't73', 222, ['m15','m9','m10','m8','m7','m1'], [], 'fam1', 1 ).
test( 't74', 184, ['m10'], [], 'fam1', 1 ).
test( 't75', 198, ['m12','m15','m13','m10','m5'], [], 'fam1', 1 ).
test( 't76', 789, [], [], 'fam1', 1 ).
test( 't77', 712, [], [], 'fam1', 1 ).
test( 't78', 344, [], [], 'fam1', 1 ).
test( 't79', 793, ['m6','m2','m5','m3','m13','m8'], ['r1','r4','r2','r5'], 'fam1', 1 ).
test( 't80', 408, [], [], 'fam1', 1 ).
test( 't81', 562, ['m14','m17','m20','m8'], ['r3'], 'fam1', 1 ).
test( 't82', 675, ['m2','m14'], ['r4'], 'fam1', 1 ).
test( 't83', 444, [], [], 'fam1', 1 ).
test( 't84', 519, [], [], 'fam1', 1 ).
test( 't85', 339, ['m4'], ['r1','r4'], 'fam1', 1 ).
test( 't86', 738, ['m1','m7','m13','m9'], ['r5','r4','r3','r1','r2'], 'fam1', 1 ).
test( 't87', 46, ['m17','m9','m14','m12','m20','m13','m5'], [], 'fam1', 1 ).
test( 't88', 49, [], [], 'fam1', 1 ).
test( 't89', 159, [], ['r2'], 'fam1', 1 ).
test( 't90', 84, ['m8','m14'], ['r3','r1','r2','r4'], 'fam1', 1 ).
test( 't91', 648, [], ['r3','r1'], 'fam1', 1 ).
test( 't92', 517, [], [], 'fam1', 1 ).
test( 't93', 284, ['m13','m4'], [], 'fam1', 1 ).
test( 't94', 263, ['m2','m20','m19','m1'], [], 'fam1', 1 ).
test( 't95', 420, [], [], 'fam1', 1 ).
test( 't96', 788, [], [], 'fam1', 1 ).
test( 't97', 792, [], [], 'fam1', 1 ).
test( 't98', 742, [], [], 'fam1', 1 ).
test( 't99', 425, [], [], 'fam1', 1 ).
test( 't100', 790, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
