%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 198, [], [], 'fam1', 1 ).
test( 't2', 142, [], [], 'fam1', 1 ).
test( 't3', 22, [], ['r1','r3'], 'fam1', 1 ).
test( 't4', 625, [], [], 'fam1', 1 ).
test( 't5', 63, [], ['r1'], 'fam1', 1 ).
test( 't6', 667, [], [], 'fam1', 1 ).
test( 't7', 86, [], ['r2','r3'], 'fam1', 1 ).
test( 't8', 200, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't9', 383, ['m10','m7','m9'], [], 'fam1', 1 ).
test( 't10', 766, ['m9'], [], 'fam1', 1 ).
test( 't11', 600, ['m7'], [], 'fam1', 1 ).
test( 't12', 84, ['m8','m6'], ['r3'], 'fam1', 1 ).
test( 't13', 576, [], [], 'fam1', 1 ).
test( 't14', 266, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't15', 336, ['m5'], [], 'fam1', 1 ).
test( 't16', 356, [], [], 'fam1', 1 ).
test( 't17', 110, ['m4','m10','m7','m6'], ['r2','r1','r3'], 'fam1', 1 ).
test( 't18', 270, [], [], 'fam1', 1 ).
test( 't19', 368, [], ['r3','r2'], 'fam1', 1 ).
test( 't20', 702, [], [], 'fam1', 1 ).
test( 't21', 389, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't22', 86, [], [], 'fam1', 1 ).
test( 't23', 760, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't24', 404, [], [], 'fam1', 1 ).
test( 't25', 664, ['m3','m7'], [], 'fam1', 1 ).
test( 't26', 609, [], [], 'fam1', 1 ).
test( 't27', 168, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't28', 131, ['m4','m5','m6','m8'], ['r2','r3'], 'fam1', 1 ).
test( 't29', 644, [], [], 'fam1', 1 ).
test( 't30', 541, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
