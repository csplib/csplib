%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 20
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 585, [], [], 'fam1', 1 ).
test( 't2', 778, [], [], 'fam1', 1 ).
test( 't3', 164, [], [], 'fam1', 1 ).
test( 't4', 560, [], ['r1','r2'], 'fam1', 1 ).
test( 't5', 217, [], [], 'fam1', 1 ).
test( 't6', 684, [], [], 'fam1', 1 ).
test( 't7', 737, [], [], 'fam1', 1 ).
test( 't8', 784, [], ['r3','r1'], 'fam1', 1 ).
test( 't9', 471, [], ['r3','r5','r2','r1'], 'fam1', 1 ).
test( 't10', 719, [], [], 'fam1', 1 ).
test( 't11', 172, [], [], 'fam1', 1 ).
test( 't12', 434, [], [], 'fam1', 1 ).
test( 't13', 43, [], [], 'fam1', 1 ).
test( 't14', 425, ['m9','m2','m19','m14','m15','m5','m13'], [], 'fam1', 1 ).
test( 't15', 671, [], [], 'fam1', 1 ).
test( 't16', 649, [], [], 'fam1', 1 ).
test( 't17', 348, [], [], 'fam1', 1 ).
test( 't18', 709, [], [], 'fam1', 1 ).
test( 't19', 163, [], [], 'fam1', 1 ).
test( 't20', 56, [], [], 'fam1', 1 ).
test( 't21', 410, [], [], 'fam1', 1 ).
test( 't22', 234, [], ['r1'], 'fam1', 1 ).
test( 't23', 39, [], [], 'fam1', 1 ).
test( 't24', 488, [], [], 'fam1', 1 ).
test( 't25', 197, [], [], 'fam1', 1 ).
test( 't26', 310, [], [], 'fam1', 1 ).
test( 't27', 637, [], [], 'fam1', 1 ).
test( 't28', 686, ['m6','m2','m7','m11','m19','m12','m20'], ['r5','r2','r1','r4'], 'fam1', 1 ).
test( 't29', 401, [], ['r3','r5','r4'], 'fam1', 1 ).
test( 't30', 88, [], ['r5','r2','r3'], 'fam1', 1 ).
test( 't31', 659, [], ['r2'], 'fam1', 1 ).
test( 't32', 444, [], [], 'fam1', 1 ).
test( 't33', 231, ['m16','m10','m8'], ['r5'], 'fam1', 1 ).
test( 't34', 125, [], ['r2','r1','r5'], 'fam1', 1 ).
test( 't35', 32, ['m3','m7','m10','m19','m16','m6'], [], 'fam1', 1 ).
test( 't36', 141, [], [], 'fam1', 1 ).
test( 't37', 310, [], ['r2','r3','r4'], 'fam1', 1 ).
test( 't38', 372, [], [], 'fam1', 1 ).
test( 't39', 736, [], ['r5','r4','r2','r3'], 'fam1', 1 ).
test( 't40', 437, [], ['r3','r4','r1','r2','r5'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
