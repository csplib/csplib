%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 20
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 722, ['m7','m20','m16','m6','m18','m13','m1'], [], 'fam1', 1 ).
test( 't2', 246, [], [], 'fam1', 1 ).
test( 't3', 538, [], [], 'fam1', 1 ).
test( 't4', 581, ['m7'], [], 'fam1', 1 ).
test( 't5', 647, [], [], 'fam1', 1 ).
test( 't6', 697, [], [], 'fam1', 1 ).
test( 't7', 294, ['m6'], ['r3','r2'], 'fam1', 1 ).
test( 't8', 670, [], [], 'fam1', 1 ).
test( 't9', 257, [], [], 'fam1', 1 ).
test( 't10', 537, ['m11','m1','m5','m2','m16','m9','m7'], [], 'fam1', 1 ).
test( 't11', 390, [], [], 'fam1', 1 ).
test( 't12', 87, [], [], 'fam1', 1 ).
test( 't13', 707, [], ['r5','r1'], 'fam1', 1 ).
test( 't14', 201, [], [], 'fam1', 1 ).
test( 't15', 797, [], [], 'fam1', 1 ).
test( 't16', 385, [], [], 'fam1', 1 ).
test( 't17', 669, [], [], 'fam1', 1 ).
test( 't18', 542, [], [], 'fam1', 1 ).
test( 't19', 687, [], [], 'fam1', 1 ).
test( 't20', 444, [], [], 'fam1', 1 ).
test( 't21', 589, [], ['r1','r2','r3','r4','r5'], 'fam1', 1 ).
test( 't22', 12, [], [], 'fam1', 1 ).
test( 't23', 38, [], [], 'fam1', 1 ).
test( 't24', 730, [], ['r1','r2','r5'], 'fam1', 1 ).
test( 't25', 89, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't26', 741, [], [], 'fam1', 1 ).
test( 't27', 282, [], [], 'fam1', 1 ).
test( 't28', 600, [], [], 'fam1', 1 ).
test( 't29', 777, [], ['r4','r3','r1','r5'], 'fam1', 1 ).
test( 't30', 236, [], [], 'fam1', 1 ).
test( 't31', 481, [], ['r3','r2'], 'fam1', 1 ).
test( 't32', 461, ['m7','m1'], ['r5','r2','r4'], 'fam1', 1 ).
test( 't33', 536, [], [], 'fam1', 1 ).
test( 't34', 626, [], [], 'fam1', 1 ).
test( 't35', 61, [], ['r1'], 'fam1', 1 ).
test( 't36', 444, [], ['r2','r1','r4'], 'fam1', 1 ).
test( 't37', 503, [], [], 'fam1', 1 ).
test( 't38', 83, [], [], 'fam1', 1 ).
test( 't39', 412, [], [], 'fam1', 1 ).
test( 't40', 675, [], ['r4','r2','r5','r1','r3'], 'fam1', 1 ).
test( 't41', 15, [], ['r4','r3','r2','r5','r1'], 'fam1', 1 ).
test( 't42', 611, ['m15'], [], 'fam1', 1 ).
test( 't43', 117, ['m8','m15','m20','m1'], [], 'fam1', 1 ).
test( 't44', 302, ['m15','m7','m9','m16','m17','m10','m8'], [], 'fam1', 1 ).
test( 't45', 565, [], [], 'fam1', 1 ).
test( 't46', 372, [], ['r1','r3','r5'], 'fam1', 1 ).
test( 't47', 743, ['m10','m11','m9','m16','m12','m2','m7'], [], 'fam1', 1 ).
test( 't48', 587, ['m15','m12','m7','m1','m16','m11','m17'], [], 'fam1', 1 ).
test( 't49', 76, [], ['r3','r5','r4','r1','r2'], 'fam1', 1 ).
test( 't50', 629, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
