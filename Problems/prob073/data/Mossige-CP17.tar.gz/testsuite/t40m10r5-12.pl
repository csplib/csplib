%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 57, ['m8','m6','m1','m10'], ['r5'], 'fam1', 1 ).
test( 't2', 274, [], [], 'fam1', 1 ).
test( 't3', 557, [], [], 'fam1', 1 ).
test( 't4', 396, [], [], 'fam1', 1 ).
test( 't5', 255, [], [], 'fam1', 1 ).
test( 't6', 182, [], [], 'fam1', 1 ).
test( 't7', 387, [], ['r5','r4','r1','r2'], 'fam1', 1 ).
test( 't8', 127, [], ['r3'], 'fam1', 1 ).
test( 't9', 388, [], [], 'fam1', 1 ).
test( 't10', 19, [], [], 'fam1', 1 ).
test( 't11', 105, [], [], 'fam1', 1 ).
test( 't12', 445, [], ['r2','r3','r5','r1'], 'fam1', 1 ).
test( 't13', 734, [], [], 'fam1', 1 ).
test( 't14', 420, [], ['r5','r1','r2','r4','r3'], 'fam1', 1 ).
test( 't15', 49, [], ['r4','r2','r5','r3'], 'fam1', 1 ).
test( 't16', 407, ['m8','m2','m10'], [], 'fam1', 1 ).
test( 't17', 266, [], [], 'fam1', 1 ).
test( 't18', 733, [], ['r5'], 'fam1', 1 ).
test( 't19', 580, [], [], 'fam1', 1 ).
test( 't20', 168, [], [], 'fam1', 1 ).
test( 't21', 191, [], ['r4'], 'fam1', 1 ).
test( 't22', 661, [], [], 'fam1', 1 ).
test( 't23', 680, ['m4'], ['r1','r4','r2','r5','r3'], 'fam1', 1 ).
test( 't24', 577, [], [], 'fam1', 1 ).
test( 't25', 763, [], [], 'fam1', 1 ).
test( 't26', 98, [], [], 'fam1', 1 ).
test( 't27', 186, [], [], 'fam1', 1 ).
test( 't28', 781, [], ['r1'], 'fam1', 1 ).
test( 't29', 358, [], ['r4','r5','r3'], 'fam1', 1 ).
test( 't30', 419, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't31', 183, ['m4','m6','m3'], [], 'fam1', 1 ).
test( 't32', 276, [], [], 'fam1', 1 ).
test( 't33', 205, [], ['r5'], 'fam1', 1 ).
test( 't34', 30, ['m2'], [], 'fam1', 1 ).
test( 't35', 660, [], ['r5','r4'], 'fam1', 1 ).
test( 't36', 428, [], [], 'fam1', 1 ).
test( 't37', 286, ['m5'], [], 'fam1', 1 ).
test( 't38', 590, ['m6','m2'], ['r1','r2','r3','r5','r4'], 'fam1', 1 ).
test( 't39', 341, [], [], 'fam1', 1 ).
test( 't40', 347, ['m6','m10','m9'], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
