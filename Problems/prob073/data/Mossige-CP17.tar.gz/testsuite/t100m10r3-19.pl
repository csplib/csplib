%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 680, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't2', 213, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't3', 370, [], [], 'fam1', 1 ).
test( 't4', 524, ['m2','m7'], [], 'fam1', 1 ).
test( 't5', 536, [], [], 'fam1', 1 ).
test( 't6', 71, [], [], 'fam1', 1 ).
test( 't7', 215, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't8', 435, [], ['r1','r2'], 'fam1', 1 ).
test( 't9', 465, [], [], 'fam1', 1 ).
test( 't10', 312, ['m9','m5'], ['r2'], 'fam1', 1 ).
test( 't11', 318, [], [], 'fam1', 1 ).
test( 't12', 245, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't13', 326, [], [], 'fam1', 1 ).
test( 't14', 715, [], ['r2','r3'], 'fam1', 1 ).
test( 't15', 88, [], [], 'fam1', 1 ).
test( 't16', 474, [], [], 'fam1', 1 ).
test( 't17', 688, [], [], 'fam1', 1 ).
test( 't18', 253, [], [], 'fam1', 1 ).
test( 't19', 371, ['m7','m8','m2','m9'], ['r3'], 'fam1', 1 ).
test( 't20', 173, [], [], 'fam1', 1 ).
test( 't21', 307, [], [], 'fam1', 1 ).
test( 't22', 478, [], [], 'fam1', 1 ).
test( 't23', 374, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't24', 694, [], [], 'fam1', 1 ).
test( 't25', 604, [], [], 'fam1', 1 ).
test( 't26', 66, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't27', 691, [], [], 'fam1', 1 ).
test( 't28', 793, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't29', 357, ['m9','m4'], ['r1'], 'fam1', 1 ).
test( 't30', 312, ['m5','m1','m8','m3'], [], 'fam1', 1 ).
test( 't31', 17, [], ['r3'], 'fam1', 1 ).
test( 't32', 583, [], [], 'fam1', 1 ).
test( 't33', 286, [], [], 'fam1', 1 ).
test( 't34', 563, [], [], 'fam1', 1 ).
test( 't35', 12, [], ['r2','r3'], 'fam1', 1 ).
test( 't36', 558, [], [], 'fam1', 1 ).
test( 't37', 792, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't38', 127, [], [], 'fam1', 1 ).
test( 't39', 465, [], ['r1','r3'], 'fam1', 1 ).
test( 't40', 87, [], [], 'fam1', 1 ).
test( 't41', 754, [], [], 'fam1', 1 ).
test( 't42', 50, [], ['r2','r3'], 'fam1', 1 ).
test( 't43', 601, [], [], 'fam1', 1 ).
test( 't44', 439, [], [], 'fam1', 1 ).
test( 't45', 614, [], [], 'fam1', 1 ).
test( 't46', 354, ['m3','m4','m1','m7'], [], 'fam1', 1 ).
test( 't47', 422, ['m5','m9','m1','m6'], [], 'fam1', 1 ).
test( 't48', 355, [], [], 'fam1', 1 ).
test( 't49', 629, ['m6'], [], 'fam1', 1 ).
test( 't50', 116, [], [], 'fam1', 1 ).
test( 't51', 164, [], [], 'fam1', 1 ).
test( 't52', 513, [], ['r2'], 'fam1', 1 ).
test( 't53', 766, [], [], 'fam1', 1 ).
test( 't54', 535, ['m9','m7','m4','m3'], [], 'fam1', 1 ).
test( 't55', 328, [], [], 'fam1', 1 ).
test( 't56', 657, [], [], 'fam1', 1 ).
test( 't57', 273, [], [], 'fam1', 1 ).
test( 't58', 661, [], [], 'fam1', 1 ).
test( 't59', 523, [], [], 'fam1', 1 ).
test( 't60', 115, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't61', 525, ['m8','m10','m6'], [], 'fam1', 1 ).
test( 't62', 649, [], [], 'fam1', 1 ).
test( 't63', 304, [], [], 'fam1', 1 ).
test( 't64', 539, [], [], 'fam1', 1 ).
test( 't65', 780, [], [], 'fam1', 1 ).
test( 't66', 59, [], [], 'fam1', 1 ).
test( 't67', 779, ['m7','m6','m2','m8'], [], 'fam1', 1 ).
test( 't68', 801, ['m1'], [], 'fam1', 1 ).
test( 't69', 744, [], ['r3','r1'], 'fam1', 1 ).
test( 't70', 775, [], [], 'fam1', 1 ).
test( 't71', 502, [], [], 'fam1', 1 ).
test( 't72', 85, ['m9','m5','m6'], ['r1','r2','r3'], 'fam1', 1 ).
test( 't73', 216, [], [], 'fam1', 1 ).
test( 't74', 484, [], [], 'fam1', 1 ).
test( 't75', 773, [], [], 'fam1', 1 ).
test( 't76', 185, [], [], 'fam1', 1 ).
test( 't77', 416, [], [], 'fam1', 1 ).
test( 't78', 81, ['m1','m6'], [], 'fam1', 1 ).
test( 't79', 233, [], ['r1','r2'], 'fam1', 1 ).
test( 't80', 111, [], [], 'fam1', 1 ).
test( 't81', 106, [], [], 'fam1', 1 ).
test( 't82', 590, ['m4','m2','m8'], [], 'fam1', 1 ).
test( 't83', 437, [], [], 'fam1', 1 ).
test( 't84', 594, [], ['r2','r1'], 'fam1', 1 ).
test( 't85', 318, [], [], 'fam1', 1 ).
test( 't86', 190, [], [], 'fam1', 1 ).
test( 't87', 335, [], [], 'fam1', 1 ).
test( 't88', 769, ['m9'], [], 'fam1', 1 ).
test( 't89', 564, ['m10','m1','m4','m7'], ['r3','r1'], 'fam1', 1 ).
test( 't90', 600, [], [], 'fam1', 1 ).
test( 't91', 316, [], ['r3','r2'], 'fam1', 1 ).
test( 't92', 390, [], [], 'fam1', 1 ).
test( 't93', 678, [], [], 'fam1', 1 ).
test( 't94', 379, [], [], 'fam1', 1 ).
test( 't95', 675, [], [], 'fam1', 1 ).
test( 't96', 390, [], [], 'fam1', 1 ).
test( 't97', 93, [], [], 'fam1', 1 ).
test( 't98', 341, [], [], 'fam1', 1 ).
test( 't99', 720, ['m3'], [], 'fam1', 1 ).
test( 't100', 669, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
