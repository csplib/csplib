%% ****  Testsuite  ****
% Number of tests                  : 20
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 38, [], ['r3','r5','r4','r2'], 'fam1', 1 ).
test( 't2', 751, ['m7','m10'], ['r3','r5','r1','r2'], 'fam1', 1 ).
test( 't3', 68, ['m9'], [], 'fam1', 1 ).
test( 't4', 181, ['m3'], [], 'fam1', 1 ).
test( 't5', 648, [], ['r4','r5','r1','r2','r3'], 'fam1', 1 ).
test( 't6', 72, [], [], 'fam1', 1 ).
test( 't7', 11, [], [], 'fam1', 1 ).
test( 't8', 76, [], [], 'fam1', 1 ).
test( 't9', 299, [], [], 'fam1', 1 ).
test( 't10', 506, [], [], 'fam1', 1 ).
test( 't11', 186, ['m4','m10'], [], 'fam1', 1 ).
test( 't12', 784, ['m4','m1','m9'], [], 'fam1', 1 ).
test( 't13', 587, [], [], 'fam1', 1 ).
test( 't14', 515, [], ['r5','r4'], 'fam1', 1 ).
test( 't15', 715, [], [], 'fam1', 1 ).
test( 't16', 260, [], [], 'fam1', 1 ).
test( 't17', 366, ['m10'], [], 'fam1', 1 ).
test( 't18', 95, [], [], 'fam1', 1 ).
test( 't19', 657, ['m1','m7'], [], 'fam1', 1 ).
test( 't20', 684, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
