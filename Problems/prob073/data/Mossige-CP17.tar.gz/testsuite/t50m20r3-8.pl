%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 20
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 160, [], ['r2','r3'], 'fam1', 1 ).
test( 't2', 769, [], [], 'fam1', 1 ).
test( 't3', 65, [], ['r1','r3'], 'fam1', 1 ).
test( 't4', 654, [], [], 'fam1', 1 ).
test( 't5', 525, [], [], 'fam1', 1 ).
test( 't6', 681, [], ['r2'], 'fam1', 1 ).
test( 't7', 709, [], [], 'fam1', 1 ).
test( 't8', 232, ['m5','m20','m14'], [], 'fam1', 1 ).
test( 't9', 26, [], [], 'fam1', 1 ).
test( 't10', 574, [], [], 'fam1', 1 ).
test( 't11', 736, [], ['r1','r2'], 'fam1', 1 ).
test( 't12', 480, [], [], 'fam1', 1 ).
test( 't13', 63, [], ['r1'], 'fam1', 1 ).
test( 't14', 642, [], [], 'fam1', 1 ).
test( 't15', 536, [], [], 'fam1', 1 ).
test( 't16', 526, ['m20','m16'], [], 'fam1', 1 ).
test( 't17', 474, ['m11','m18','m20','m19','m1','m3'], [], 'fam1', 1 ).
test( 't18', 244, ['m16','m8'], [], 'fam1', 1 ).
test( 't19', 415, [], [], 'fam1', 1 ).
test( 't20', 296, [], [], 'fam1', 1 ).
test( 't21', 501, [], [], 'fam1', 1 ).
test( 't22', 29, [], [], 'fam1', 1 ).
test( 't23', 608, [], [], 'fam1', 1 ).
test( 't24', 330, ['m18','m12','m3'], ['r3','r1'], 'fam1', 1 ).
test( 't25', 674, [], [], 'fam1', 1 ).
test( 't26', 446, [], [], 'fam1', 1 ).
test( 't27', 285, ['m19','m1','m15','m12'], [], 'fam1', 1 ).
test( 't28', 487, [], [], 'fam1', 1 ).
test( 't29', 131, [], [], 'fam1', 1 ).
test( 't30', 334, [], ['r2'], 'fam1', 1 ).
test( 't31', 598, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't32', 300, ['m20','m17','m5','m6'], [], 'fam1', 1 ).
test( 't33', 279, ['m19','m7','m8','m5','m6','m2','m10'], ['r3','r2'], 'fam1', 1 ).
test( 't34', 75, ['m7','m10'], ['r1','r2','r3'], 'fam1', 1 ).
test( 't35', 492, [], [], 'fam1', 1 ).
test( 't36', 124, [], [], 'fam1', 1 ).
test( 't37', 484, [], [], 'fam1', 1 ).
test( 't38', 314, [], [], 'fam1', 1 ).
test( 't39', 315, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't40', 594, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't41', 4, ['m4','m2','m19','m5','m14','m20'], [], 'fam1', 1 ).
test( 't42', 140, [], [], 'fam1', 1 ).
test( 't43', 241, [], [], 'fam1', 1 ).
test( 't44', 756, [], ['r1','r3'], 'fam1', 1 ).
test( 't45', 322, [], [], 'fam1', 1 ).
test( 't46', 643, [], [], 'fam1', 1 ).
test( 't47', 129, [], [], 'fam1', 1 ).
test( 't48', 415, [], [], 'fam1', 1 ).
test( 't49', 357, ['m3'], [], 'fam1', 1 ).
test( 't50', 200, ['m8','m5','m19','m17','m7','m15'], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
