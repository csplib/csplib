%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 20
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 497, ['m20','m5','m7','m10'], [], 'fam1', 1 ).
test( 't2', 297, [], [], 'fam1', 1 ).
test( 't3', 32, [], [], 'fam1', 1 ).
test( 't4', 487, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't5', 130, [], [], 'fam1', 1 ).
test( 't6', 84, [], [], 'fam1', 1 ).
test( 't7', 54, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't8', 543, [], [], 'fam1', 1 ).
test( 't9', 332, [], [], 'fam1', 1 ).
test( 't10', 3, [], [], 'fam1', 1 ).
test( 't11', 167, [], ['r2'], 'fam1', 1 ).
test( 't12', 329, [], [], 'fam1', 1 ).
test( 't13', 515, ['m9','m13','m6','m4','m17','m2','m8','m11'], [], 'fam1', 1 ).
test( 't14', 666, [], [], 'fam1', 1 ).
test( 't15', 653, [], [], 'fam1', 1 ).
test( 't16', 769, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't17', 780, ['m7','m11','m4'], [], 'fam1', 1 ).
test( 't18', 126, [], [], 'fam1', 1 ).
test( 't19', 407, [], [], 'fam1', 1 ).
test( 't20', 532, [], [], 'fam1', 1 ).
test( 't21', 199, [], ['r3','r2'], 'fam1', 1 ).
test( 't22', 594, [], [], 'fam1', 1 ).
test( 't23', 499, [], [], 'fam1', 1 ).
test( 't24', 142, ['m2'], [], 'fam1', 1 ).
test( 't25', 291, [], [], 'fam1', 1 ).
test( 't26', 781, [], [], 'fam1', 1 ).
test( 't27', 105, ['m5','m6','m12','m14','m9','m16'], ['r3','r1','r2'], 'fam1', 1 ).
test( 't28', 133, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't29', 126, [], [], 'fam1', 1 ).
test( 't30', 212, [], [], 'fam1', 1 ).
test( 't31', 342, [], [], 'fam1', 1 ).
test( 't32', 605, [], [], 'fam1', 1 ).
test( 't33', 753, [], [], 'fam1', 1 ).
test( 't34', 463, ['m19','m9','m8','m1','m20'], ['r2','r3','r1'], 'fam1', 1 ).
test( 't35', 346, [], [], 'fam1', 1 ).
test( 't36', 75, [], [], 'fam1', 1 ).
test( 't37', 359, [], [], 'fam1', 1 ).
test( 't38', 86, [], ['r1','r2'], 'fam1', 1 ).
test( 't39', 242, [], ['r3'], 'fam1', 1 ).
test( 't40', 327, ['m15'], ['r2'], 'fam1', 1 ).
test( 't41', 747, [], [], 'fam1', 1 ).
test( 't42', 777, [], [], 'fam1', 1 ).
test( 't43', 376, [], [], 'fam1', 1 ).
test( 't44', 186, [], [], 'fam1', 1 ).
test( 't45', 85, [], [], 'fam1', 1 ).
test( 't46', 327, [], [], 'fam1', 1 ).
test( 't47', 695, [], [], 'fam1', 1 ).
test( 't48', 601, ['m3','m19','m20'], ['r1','r2','r3'], 'fam1', 1 ).
test( 't49', 753, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't50', 504, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
