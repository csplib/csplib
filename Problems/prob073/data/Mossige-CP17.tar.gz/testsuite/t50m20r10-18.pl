%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 20
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 440, ['m12'], [], 'fam1', 1 ).
test( 't2', 263, [], ['r10','r8','r7'], 'fam1', 1 ).
test( 't3', 5, [], ['r6','r2'], 'fam1', 1 ).
test( 't4', 223, [], ['r2','r3','r9','r8','r5','r10'], 'fam1', 1 ).
test( 't5', 133, ['m9','m14','m15','m19'], [], 'fam1', 1 ).
test( 't6', 700, [], [], 'fam1', 1 ).
test( 't7', 573, [], [], 'fam1', 1 ).
test( 't8', 458, [], [], 'fam1', 1 ).
test( 't9', 515, [], ['r9','r4','r1','r8','r6','r10','r5','r3','r2'], 'fam1', 1 ).
test( 't10', 795, [], [], 'fam1', 1 ).
test( 't11', 731, [], [], 'fam1', 1 ).
test( 't12', 668, [], [], 'fam1', 1 ).
test( 't13', 752, [], ['r2','r4','r6','r8','r10','r5','r3','r7','r1'], 'fam1', 1 ).
test( 't14', 728, ['m19','m6','m18','m9','m4','m1','m3','m17'], [], 'fam1', 1 ).
test( 't15', 120, ['m11'], [], 'fam1', 1 ).
test( 't16', 743, [], [], 'fam1', 1 ).
test( 't17', 350, [], ['r8','r4','r9','r2','r6','r7','r5','r10','r1'], 'fam1', 1 ).
test( 't18', 313, [], [], 'fam1', 1 ).
test( 't19', 686, [], [], 'fam1', 1 ).
test( 't20', 331, [], [], 'fam1', 1 ).
test( 't21', 762, ['m5','m17','m20','m2','m6','m16'], ['r3','r5','r1','r6','r7'], 'fam1', 1 ).
test( 't22', 8, ['m12','m17','m9'], [], 'fam1', 1 ).
test( 't23', 581, [], [], 'fam1', 1 ).
test( 't24', 280, ['m12'], [], 'fam1', 1 ).
test( 't25', 92, [], [], 'fam1', 1 ).
test( 't26', 735, ['m8','m4','m12','m17'], [], 'fam1', 1 ).
test( 't27', 498, ['m5','m13','m6','m12','m2','m17','m9','m1'], [], 'fam1', 1 ).
test( 't28', 407, [], [], 'fam1', 1 ).
test( 't29', 241, [], [], 'fam1', 1 ).
test( 't30', 339, [], ['r3','r2'], 'fam1', 1 ).
test( 't31', 126, [], ['r5','r6'], 'fam1', 1 ).
test( 't32', 779, [], ['r1','r2','r6','r8','r10','r7','r9','r5','r4'], 'fam1', 1 ).
test( 't33', 87, [], [], 'fam1', 1 ).
test( 't34', 230, ['m15','m16','m18','m7','m10','m1','m19'], ['r8','r7','r5','r6'], 'fam1', 1 ).
test( 't35', 689, [], [], 'fam1', 1 ).
test( 't36', 429, [], ['r1','r9','r2','r7','r10','r3','r5','r6'], 'fam1', 1 ).
test( 't37', 113, ['m3','m14','m2','m8','m10','m19','m20'], ['r6','r3','r9','r5','r2','r1','r4','r10'], 'fam1', 1 ).
test( 't38', 132, [], [], 'fam1', 1 ).
test( 't39', 266, [], ['r3','r10','r9'], 'fam1', 1 ).
test( 't40', 102, ['m14','m11','m6','m3','m19','m12','m5','m4'], [], 'fam1', 1 ).
test( 't41', 79, [], [], 'fam1', 1 ).
test( 't42', 320, [], ['r5','r7','r10','r4','r3'], 'fam1', 1 ).
test( 't43', 239, [], [], 'fam1', 1 ).
test( 't44', 480, [], [], 'fam1', 1 ).
test( 't45', 521, [], [], 'fam1', 1 ).
test( 't46', 796, [], ['r2'], 'fam1', 1 ).
test( 't47', 120, [], [], 'fam1', 1 ).
test( 't48', 409, [], [], 'fam1', 1 ).
test( 't49', 212, [], [], 'fam1', 1 ).
test( 't50', 658, ['m3','m16','m6'], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
