%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 380, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't2', 176, [], ['r1','r2'], 'fam1', 1 ).
test( 't3', 359, [], [], 'fam1', 1 ).
test( 't4', 75, [], [], 'fam1', 1 ).
test( 't5', 764, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't6', 63, [], [], 'fam1', 1 ).
test( 't7', 759, ['m6'], ['r3','r2','r1'], 'fam1', 1 ).
test( 't8', 226, [], [], 'fam1', 1 ).
test( 't9', 87, [], [], 'fam1', 1 ).
test( 't10', 89, [], [], 'fam1', 1 ).
test( 't11', 507, [], [], 'fam1', 1 ).
test( 't12', 538, [], [], 'fam1', 1 ).
test( 't13', 217, [], [], 'fam1', 1 ).
test( 't14', 367, ['m6'], [], 'fam1', 1 ).
test( 't15', 674, [], ['r2','r1'], 'fam1', 1 ).
test( 't16', 789, [], [], 'fam1', 1 ).
test( 't17', 18, [], [], 'fam1', 1 ).
test( 't18', 465, [], [], 'fam1', 1 ).
test( 't19', 146, [], ['r1','r2'], 'fam1', 1 ).
test( 't20', 303, ['m6','m2'], [], 'fam1', 1 ).
test( 't21', 405, [], ['r1'], 'fam1', 1 ).
test( 't22', 275, [], ['r2','r1'], 'fam1', 1 ).
test( 't23', 202, [], ['r1','r3'], 'fam1', 1 ).
test( 't24', 445, ['m1','m7'], ['r3','r2'], 'fam1', 1 ).
test( 't25', 14, [], ['r1'], 'fam1', 1 ).
test( 't26', 239, ['m7'], ['r1'], 'fam1', 1 ).
test( 't27', 598, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't28', 751, [], [], 'fam1', 1 ).
test( 't29', 434, ['m8','m10','m1'], ['r3','r1'], 'fam1', 1 ).
test( 't30', 287, [], [], 'fam1', 1 ).
test( 't31', 300, [], [], 'fam1', 1 ).
test( 't32', 583, [], [], 'fam1', 1 ).
test( 't33', 291, [], ['r3'], 'fam1', 1 ).
test( 't34', 261, [], [], 'fam1', 1 ).
test( 't35', 432, [], [], 'fam1', 1 ).
test( 't36', 263, [], [], 'fam1', 1 ).
test( 't37', 698, [], [], 'fam1', 1 ).
test( 't38', 667, [], [], 'fam1', 1 ).
test( 't39', 366, ['m3','m2'], [], 'fam1', 1 ).
test( 't40', 531, [], [], 'fam1', 1 ).
test( 't41', 272, ['m2'], [], 'fam1', 1 ).
test( 't42', 400, ['m1','m3','m5','m9'], [], 'fam1', 1 ).
test( 't43', 261, [], [], 'fam1', 1 ).
test( 't44', 566, [], [], 'fam1', 1 ).
test( 't45', 766, [], [], 'fam1', 1 ).
test( 't46', 613, ['m8','m4','m6'], ['r2','r1','r3'], 'fam1', 1 ).
test( 't47', 632, [], [], 'fam1', 1 ).
test( 't48', 681, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't49', 589, [], [], 'fam1', 1 ).
test( 't50', 360, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
