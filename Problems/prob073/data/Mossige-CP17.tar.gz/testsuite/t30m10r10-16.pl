%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 10
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 160, [], ['r6','r9','r5','r1','r3','r4','r7','r10','r2'], 'fam1', 1 ).
test( 't2', 683, [], ['r9','r4','r2'], 'fam1', 1 ).
test( 't3', 441, [], [], 'fam1', 1 ).
test( 't4', 618, [], [], 'fam1', 1 ).
test( 't5', 697, [], ['r8','r2'], 'fam1', 1 ).
test( 't6', 493, ['m1','m5','m4'], [], 'fam1', 1 ).
test( 't7', 593, [], [], 'fam1', 1 ).
test( 't8', 228, [], [], 'fam1', 1 ).
test( 't9', 589, [], [], 'fam1', 1 ).
test( 't10', 543, [], ['r10','r8','r6','r3','r1','r7','r2','r9','r5'], 'fam1', 1 ).
test( 't11', 419, [], [], 'fam1', 1 ).
test( 't12', 141, [], ['r3','r7','r4','r6','r5','r1','r10','r9'], 'fam1', 1 ).
test( 't13', 786, ['m10','m4','m1','m6'], ['r4','r7'], 'fam1', 1 ).
test( 't14', 162, [], [], 'fam1', 1 ).
test( 't15', 747, ['m9','m1','m7','m5'], [], 'fam1', 1 ).
test( 't16', 571, ['m5','m7','m8','m10'], [], 'fam1', 1 ).
test( 't17', 443, [], ['r3','r6','r2','r5','r1','r7','r4','r8'], 'fam1', 1 ).
test( 't18', 23, ['m4','m3','m6','m10'], [], 'fam1', 1 ).
test( 't19', 181, ['m8'], [], 'fam1', 1 ).
test( 't20', 778, [], [], 'fam1', 1 ).
test( 't21', 403, ['m9','m10','m3','m2'], [], 'fam1', 1 ).
test( 't22', 209, [], [], 'fam1', 1 ).
test( 't23', 616, [], ['r9','r5','r1','r6','r8','r3'], 'fam1', 1 ).
test( 't24', 590, [], [], 'fam1', 1 ).
test( 't25', 441, [], ['r9','r8','r10','r3','r6'], 'fam1', 1 ).
test( 't26', 625, [], [], 'fam1', 1 ).
test( 't27', 193, [], [], 'fam1', 1 ).
test( 't28', 1, [], ['r3','r8','r6','r9','r4','r10','r1'], 'fam1', 1 ).
test( 't29', 641, [], ['r10','r3','r4','r9','r5','r1','r2','r6','r8','r7'], 'fam1', 1 ).
test( 't30', 500, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
