%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 20
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 327, [], [], 'fam1', 1 ).
test( 't2', 470, [], [], 'fam1', 1 ).
test( 't3', 204, [], [], 'fam1', 1 ).
test( 't4', 601, ['m10'], [], 'fam1', 1 ).
test( 't5', 517, [], ['r4','r2','r1'], 'fam1', 1 ).
test( 't6', 489, [], ['r2','r1','r3','r5','r4'], 'fam1', 1 ).
test( 't7', 580, ['m7','m5','m3','m4'], [], 'fam1', 1 ).
test( 't8', 127, [], [], 'fam1', 1 ).
test( 't9', 725, ['m10','m3','m9'], [], 'fam1', 1 ).
test( 't10', 389, [], [], 'fam1', 1 ).
test( 't11', 85, [], [], 'fam1', 1 ).
test( 't12', 423, [], [], 'fam1', 1 ).
test( 't13', 38, [], [], 'fam1', 1 ).
test( 't14', 716, [], ['r4'], 'fam1', 1 ).
test( 't15', 746, [], [], 'fam1', 1 ).
test( 't16', 300, ['m13'], ['r1','r3','r5'], 'fam1', 1 ).
test( 't17', 476, ['m18','m11','m7','m15','m6','m4','m12'], [], 'fam1', 1 ).
test( 't18', 721, [], [], 'fam1', 1 ).
test( 't19', 389, ['m10'], [], 'fam1', 1 ).
test( 't20', 486, ['m11'], [], 'fam1', 1 ).
test( 't21', 533, [], ['r4','r3'], 'fam1', 1 ).
test( 't22', 415, [], ['r4','r3','r2'], 'fam1', 1 ).
test( 't23', 282, [], ['r3','r2','r4'], 'fam1', 1 ).
test( 't24', 139, [], ['r2'], 'fam1', 1 ).
test( 't25', 173, [], [], 'fam1', 1 ).
test( 't26', 18, [], ['r3'], 'fam1', 1 ).
test( 't27', 362, [], [], 'fam1', 1 ).
test( 't28', 205, ['m18','m12','m5'], [], 'fam1', 1 ).
test( 't29', 258, [], ['r3','r5','r4'], 'fam1', 1 ).
test( 't30', 124, ['m4'], [], 'fam1', 1 ).
test( 't31', 410, [], ['r2','r4','r5','r3'], 'fam1', 1 ).
test( 't32', 469, [], [], 'fam1', 1 ).
test( 't33', 685, [], ['r4','r1','r3','r5','r2'], 'fam1', 1 ).
test( 't34', 287, [], [], 'fam1', 1 ).
test( 't35', 722, [], ['r3'], 'fam1', 1 ).
test( 't36', 558, [], [], 'fam1', 1 ).
test( 't37', 322, [], [], 'fam1', 1 ).
test( 't38', 722, [], ['r5','r3','r2'], 'fam1', 1 ).
test( 't39', 667, [], ['r5','r1'], 'fam1', 1 ).
test( 't40', 773, ['m2','m8'], ['r2','r1','r5'], 'fam1', 1 ).
test( 't41', 74, [], ['r3','r5'], 'fam1', 1 ).
test( 't42', 311, ['m3','m10','m15','m7','m17','m1','m12','m16'], [], 'fam1', 1 ).
test( 't43', 286, [], [], 'fam1', 1 ).
test( 't44', 562, [], ['r3'], 'fam1', 1 ).
test( 't45', 189, [], [], 'fam1', 1 ).
test( 't46', 433, [], ['r1','r2'], 'fam1', 1 ).
test( 't47', 86, ['m3','m7','m11','m4','m6','m14'], [], 'fam1', 1 ).
test( 't48', 593, ['m14','m17','m9','m3'], ['r5','r2','r1'], 'fam1', 1 ).
test( 't49', 403, [], ['r5','r4','r3'], 'fam1', 1 ).
test( 't50', 474, ['m7','m16','m18','m19','m10','m20'], ['r3','r2','r1','r5','r4'], 'fam1', 1 ).
test( 't51', 433, ['m11','m1','m10','m17','m19','m12','m14','m13'], [], 'fam1', 1 ).
test( 't52', 597, [], [], 'fam1', 1 ).
test( 't53', 255, [], [], 'fam1', 1 ).
test( 't54', 90, [], ['r1','r3'], 'fam1', 1 ).
test( 't55', 47, [], [], 'fam1', 1 ).
test( 't56', 395, [], ['r3','r2','r4','r5','r1'], 'fam1', 1 ).
test( 't57', 238, [], ['r2'], 'fam1', 1 ).
test( 't58', 454, [], ['r5','r1','r3','r2','r4'], 'fam1', 1 ).
test( 't59', 345, [], [], 'fam1', 1 ).
test( 't60', 386, ['m13'], [], 'fam1', 1 ).
test( 't61', 476, [], [], 'fam1', 1 ).
test( 't62', 336, [], [], 'fam1', 1 ).
test( 't63', 563, ['m2','m1','m15','m3'], [], 'fam1', 1 ).
test( 't64', 167, [], [], 'fam1', 1 ).
test( 't65', 235, [], [], 'fam1', 1 ).
test( 't66', 586, [], [], 'fam1', 1 ).
test( 't67', 524, ['m19','m2','m17','m16'], [], 'fam1', 1 ).
test( 't68', 64, [], [], 'fam1', 1 ).
test( 't69', 191, [], ['r1','r5','r4','r3'], 'fam1', 1 ).
test( 't70', 105, [], ['r3','r1'], 'fam1', 1 ).
test( 't71', 393, [], [], 'fam1', 1 ).
test( 't72', 256, [], ['r2','r1'], 'fam1', 1 ).
test( 't73', 620, ['m13','m12','m6','m11','m8'], [], 'fam1', 1 ).
test( 't74', 91, ['m6','m12','m20','m15','m7','m8'], ['r1','r4'], 'fam1', 1 ).
test( 't75', 526, [], [], 'fam1', 1 ).
test( 't76', 137, [], [], 'fam1', 1 ).
test( 't77', 204, ['m1','m5','m19','m2'], ['r3','r4'], 'fam1', 1 ).
test( 't78', 131, [], [], 'fam1', 1 ).
test( 't79', 512, [], [], 'fam1', 1 ).
test( 't80', 242, [], ['r2','r3','r4'], 'fam1', 1 ).
test( 't81', 420, [], ['r5','r3'], 'fam1', 1 ).
test( 't82', 742, [], [], 'fam1', 1 ).
test( 't83', 140, [], [], 'fam1', 1 ).
test( 't84', 560, ['m8','m7','m14','m6','m15','m3','m1','m16'], [], 'fam1', 1 ).
test( 't85', 389, [], [], 'fam1', 1 ).
test( 't86', 426, [], ['r5','r1','r4','r3'], 'fam1', 1 ).
test( 't87', 597, [], [], 'fam1', 1 ).
test( 't88', 508, ['m9','m3','m17','m8','m6','m10'], [], 'fam1', 1 ).
test( 't89', 394, [], [], 'fam1', 1 ).
test( 't90', 104, [], [], 'fam1', 1 ).
test( 't91', 784, [], [], 'fam1', 1 ).
test( 't92', 520, [], [], 'fam1', 1 ).
test( 't93', 64, [], [], 'fam1', 1 ).
test( 't94', 320, [], [], 'fam1', 1 ).
test( 't95', 485, [], [], 'fam1', 1 ).
test( 't96', 693, ['m18'], [], 'fam1', 1 ).
test( 't97', 621, [], [], 'fam1', 1 ).
test( 't98', 154, ['m13','m16','m15','m1'], [], 'fam1', 1 ).
test( 't99', 492, [], ['r3','r4','r2'], 'fam1', 1 ).
test( 't100', 280, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
