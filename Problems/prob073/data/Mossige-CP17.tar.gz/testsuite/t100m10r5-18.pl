%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 234, [], [], 'fam1', 1 ).
test( 't2', 345, [], ['r2'], 'fam1', 1 ).
test( 't3', 556, [], [], 'fam1', 1 ).
test( 't4', 383, [], ['r2'], 'fam1', 1 ).
test( 't5', 603, [], [], 'fam1', 1 ).
test( 't6', 218, ['m9','m3'], [], 'fam1', 1 ).
test( 't7', 667, [], ['r2','r1'], 'fam1', 1 ).
test( 't8', 329, [], [], 'fam1', 1 ).
test( 't9', 222, [], [], 'fam1', 1 ).
test( 't10', 591, ['m4','m7'], ['r4','r5','r1'], 'fam1', 1 ).
test( 't11', 92, [], [], 'fam1', 1 ).
test( 't12', 748, [], [], 'fam1', 1 ).
test( 't13', 197, [], [], 'fam1', 1 ).
test( 't14', 781, [], ['r2','r4'], 'fam1', 1 ).
test( 't15', 15, [], [], 'fam1', 1 ).
test( 't16', 229, [], ['r2','r5','r1'], 'fam1', 1 ).
test( 't17', 177, [], [], 'fam1', 1 ).
test( 't18', 754, [], [], 'fam1', 1 ).
test( 't19', 645, [], [], 'fam1', 1 ).
test( 't20', 461, [], [], 'fam1', 1 ).
test( 't21', 334, [], [], 'fam1', 1 ).
test( 't22', 281, [], [], 'fam1', 1 ).
test( 't23', 443, [], [], 'fam1', 1 ).
test( 't24', 374, [], [], 'fam1', 1 ).
test( 't25', 735, [], [], 'fam1', 1 ).
test( 't26', 130, [], [], 'fam1', 1 ).
test( 't27', 137, [], ['r4','r1','r2'], 'fam1', 1 ).
test( 't28', 627, [], [], 'fam1', 1 ).
test( 't29', 295, [], [], 'fam1', 1 ).
test( 't30', 261, ['m3','m2','m4'], [], 'fam1', 1 ).
test( 't31', 437, [], [], 'fam1', 1 ).
test( 't32', 65, [], [], 'fam1', 1 ).
test( 't33', 674, [], ['r2','r4'], 'fam1', 1 ).
test( 't34', 649, [], [], 'fam1', 1 ).
test( 't35', 215, [], [], 'fam1', 1 ).
test( 't36', 362, ['m5','m4','m8','m10'], [], 'fam1', 1 ).
test( 't37', 251, [], ['r5','r4','r3'], 'fam1', 1 ).
test( 't38', 177, [], [], 'fam1', 1 ).
test( 't39', 646, ['m3','m2','m4','m7'], ['r1'], 'fam1', 1 ).
test( 't40', 796, ['m5'], ['r1','r3'], 'fam1', 1 ).
test( 't41', 456, [], [], 'fam1', 1 ).
test( 't42', 695, [], ['r4','r2','r5'], 'fam1', 1 ).
test( 't43', 779, ['m1','m2','m6'], [], 'fam1', 1 ).
test( 't44', 1, [], [], 'fam1', 1 ).
test( 't45', 259, [], [], 'fam1', 1 ).
test( 't46', 84, ['m2','m3','m10'], [], 'fam1', 1 ).
test( 't47', 749, [], [], 'fam1', 1 ).
test( 't48', 356, ['m7','m4'], [], 'fam1', 1 ).
test( 't49', 44, [], ['r1','r3','r5'], 'fam1', 1 ).
test( 't50', 579, [], [], 'fam1', 1 ).
test( 't51', 715, [], [], 'fam1', 1 ).
test( 't52', 614, [], [], 'fam1', 1 ).
test( 't53', 708, [], [], 'fam1', 1 ).
test( 't54', 644, [], [], 'fam1', 1 ).
test( 't55', 231, [], ['r2','r5','r3','r4'], 'fam1', 1 ).
test( 't56', 300, [], [], 'fam1', 1 ).
test( 't57', 107, [], ['r2','r1','r4'], 'fam1', 1 ).
test( 't58', 65, [], ['r5'], 'fam1', 1 ).
test( 't59', 343, ['m7','m8','m4','m2'], [], 'fam1', 1 ).
test( 't60', 634, [], [], 'fam1', 1 ).
test( 't61', 14, ['m5','m9'], [], 'fam1', 1 ).
test( 't62', 46, [], [], 'fam1', 1 ).
test( 't63', 397, ['m3','m9','m10','m5'], [], 'fam1', 1 ).
test( 't64', 10, [], ['r4','r5','r3','r2','r1'], 'fam1', 1 ).
test( 't65', 391, [], [], 'fam1', 1 ).
test( 't66', 595, [], [], 'fam1', 1 ).
test( 't67', 30, [], ['r5','r3','r2','r1'], 'fam1', 1 ).
test( 't68', 659, [], ['r2','r1','r5','r3'], 'fam1', 1 ).
test( 't69', 303, [], [], 'fam1', 1 ).
test( 't70', 373, [], [], 'fam1', 1 ).
test( 't71', 70, [], [], 'fam1', 1 ).
test( 't72', 491, [], [], 'fam1', 1 ).
test( 't73', 704, [], ['r4','r2','r3','r5','r1'], 'fam1', 1 ).
test( 't74', 318, [], [], 'fam1', 1 ).
test( 't75', 793, [], ['r2','r5','r3'], 'fam1', 1 ).
test( 't76', 409, [], [], 'fam1', 1 ).
test( 't77', 368, [], ['r2'], 'fam1', 1 ).
test( 't78', 378, [], [], 'fam1', 1 ).
test( 't79', 695, [], [], 'fam1', 1 ).
test( 't80', 288, [], ['r3','r1','r2','r5'], 'fam1', 1 ).
test( 't81', 769, [], [], 'fam1', 1 ).
test( 't82', 730, [], [], 'fam1', 1 ).
test( 't83', 385, [], [], 'fam1', 1 ).
test( 't84', 34, [], [], 'fam1', 1 ).
test( 't85', 359, [], [], 'fam1', 1 ).
test( 't86', 24, ['m2'], ['r2','r1','r4'], 'fam1', 1 ).
test( 't87', 669, ['m5'], ['r4','r2'], 'fam1', 1 ).
test( 't88', 746, [], ['r1','r4'], 'fam1', 1 ).
test( 't89', 1, [], [], 'fam1', 1 ).
test( 't90', 144, ['m4'], [], 'fam1', 1 ).
test( 't91', 689, [], ['r1','r3','r4','r2','r5'], 'fam1', 1 ).
test( 't92', 646, [], [], 'fam1', 1 ).
test( 't93', 286, [], [], 'fam1', 1 ).
test( 't94', 612, [], [], 'fam1', 1 ).
test( 't95', 531, ['m2','m1'], [], 'fam1', 1 ).
test( 't96', 573, [], [], 'fam1', 1 ).
test( 't97', 328, [], ['r5','r4','r2'], 'fam1', 1 ).
test( 't98', 681, [], ['r4','r5','r3','r1'], 'fam1', 1 ).
test( 't99', 538, ['m1'], ['r4'], 'fam1', 1 ).
test( 't100', 388, [], ['r5','r3'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
