%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 20
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 338, [], [], 'fam1', 1 ).
test( 't2', 431, [], [], 'fam1', 1 ).
test( 't3', 388, [], [], 'fam1', 1 ).
test( 't4', 210, [], [], 'fam1', 1 ).
test( 't5', 773, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't6', 147, [], ['r3'], 'fam1', 1 ).
test( 't7', 570, [], [], 'fam1', 1 ).
test( 't8', 126, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't9', 94, [], [], 'fam1', 1 ).
test( 't10', 135, [], [], 'fam1', 1 ).
test( 't11', 280, [], ['r2'], 'fam1', 1 ).
test( 't12', 782, [], [], 'fam1', 1 ).
test( 't13', 378, ['m12','m7','m13','m9','m14','m2'], [], 'fam1', 1 ).
test( 't14', 97, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't15', 6, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't16', 401, [], ['r3','r1'], 'fam1', 1 ).
test( 't17', 457, [], [], 'fam1', 1 ).
test( 't18', 751, [], ['r3','r1'], 'fam1', 1 ).
test( 't19', 298, [], [], 'fam1', 1 ).
test( 't20', 219, [], [], 'fam1', 1 ).
test( 't21', 182, [], [], 'fam1', 1 ).
test( 't22', 413, [], [], 'fam1', 1 ).
test( 't23', 72, ['m11','m19','m5'], [], 'fam1', 1 ).
test( 't24', 530, [], [], 'fam1', 1 ).
test( 't25', 704, ['m5'], [], 'fam1', 1 ).
test( 't26', 260, ['m4','m9','m5','m19','m15'], [], 'fam1', 1 ).
test( 't27', 229, [], [], 'fam1', 1 ).
test( 't28', 116, [], [], 'fam1', 1 ).
test( 't29', 517, [], [], 'fam1', 1 ).
test( 't30', 456, [], [], 'fam1', 1 ).
test( 't31', 735, [], [], 'fam1', 1 ).
test( 't32', 698, ['m12','m18','m9','m4'], ['r3'], 'fam1', 1 ).
test( 't33', 126, [], [], 'fam1', 1 ).
test( 't34', 443, [], ['r1'], 'fam1', 1 ).
test( 't35', 326, [], [], 'fam1', 1 ).
test( 't36', 473, [], ['r3','r2'], 'fam1', 1 ).
test( 't37', 413, [], ['r3','r1'], 'fam1', 1 ).
test( 't38', 622, [], [], 'fam1', 1 ).
test( 't39', 410, [], ['r1','r3'], 'fam1', 1 ).
test( 't40', 735, ['m14','m15'], [], 'fam1', 1 ).
test( 't41', 316, ['m11','m5'], [], 'fam1', 1 ).
test( 't42', 348, [], ['r1'], 'fam1', 1 ).
test( 't43', 243, [], ['r2'], 'fam1', 1 ).
test( 't44', 369, ['m6','m13','m1','m8','m2','m9','m3'], ['r2','r3','r1'], 'fam1', 1 ).
test( 't45', 470, [], ['r3','r1'], 'fam1', 1 ).
test( 't46', 789, ['m2','m5','m15','m3'], [], 'fam1', 1 ).
test( 't47', 407, [], ['r2','r3'], 'fam1', 1 ).
test( 't48', 1, [], [], 'fam1', 1 ).
test( 't49', 655, [], [], 'fam1', 1 ).
test( 't50', 705, ['m13','m5','m19'], [], 'fam1', 1 ).
test( 't51', 701, [], ['r2','r1'], 'fam1', 1 ).
test( 't52', 386, [], [], 'fam1', 1 ).
test( 't53', 649, [], [], 'fam1', 1 ).
test( 't54', 74, [], [], 'fam1', 1 ).
test( 't55', 13, [], [], 'fam1', 1 ).
test( 't56', 202, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't57', 572, [], [], 'fam1', 1 ).
test( 't58', 410, [], [], 'fam1', 1 ).
test( 't59', 87, [], [], 'fam1', 1 ).
test( 't60', 80, ['m19','m18','m10','m9','m1','m17','m6'], [], 'fam1', 1 ).
test( 't61', 361, [], [], 'fam1', 1 ).
test( 't62', 314, [], [], 'fam1', 1 ).
test( 't63', 212, [], ['r1'], 'fam1', 1 ).
test( 't64', 301, [], [], 'fam1', 1 ).
test( 't65', 369, ['m18'], ['r3','r1'], 'fam1', 1 ).
test( 't66', 62, [], [], 'fam1', 1 ).
test( 't67', 88, ['m12','m9','m10','m8','m11','m5','m18'], ['r2'], 'fam1', 1 ).
test( 't68', 668, [], [], 'fam1', 1 ).
test( 't69', 149, [], [], 'fam1', 1 ).
test( 't70', 732, [], [], 'fam1', 1 ).
test( 't71', 664, [], [], 'fam1', 1 ).
test( 't72', 471, ['m4','m17','m12','m8','m20','m2','m19','m3'], [], 'fam1', 1 ).
test( 't73', 194, [], [], 'fam1', 1 ).
test( 't74', 560, [], [], 'fam1', 1 ).
test( 't75', 589, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't76', 453, [], [], 'fam1', 1 ).
test( 't77', 520, [], [], 'fam1', 1 ).
test( 't78', 675, ['m16','m2'], ['r3'], 'fam1', 1 ).
test( 't79', 142, ['m5','m12','m9','m1','m14','m6','m20'], [], 'fam1', 1 ).
test( 't80', 657, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't81', 668, [], ['r1'], 'fam1', 1 ).
test( 't82', 160, [], [], 'fam1', 1 ).
test( 't83', 676, [], ['r2','r3'], 'fam1', 1 ).
test( 't84', 376, [], [], 'fam1', 1 ).
test( 't85', 25, [], [], 'fam1', 1 ).
test( 't86', 80, [], ['r2','r1'], 'fam1', 1 ).
test( 't87', 443, [], [], 'fam1', 1 ).
test( 't88', 230, [], [], 'fam1', 1 ).
test( 't89', 103, [], [], 'fam1', 1 ).
test( 't90', 379, [], [], 'fam1', 1 ).
test( 't91', 396, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't92', 780, [], ['r3'], 'fam1', 1 ).
test( 't93', 95, [], [], 'fam1', 1 ).
test( 't94', 207, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't95', 406, ['m18','m14'], [], 'fam1', 1 ).
test( 't96', 476, [], ['r1','r2'], 'fam1', 1 ).
test( 't97', 308, [], [], 'fam1', 1 ).
test( 't98', 502, [], [], 'fam1', 1 ).
test( 't99', 316, [], [], 'fam1', 1 ).
test( 't100', 113, [], ['r1','r3'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
