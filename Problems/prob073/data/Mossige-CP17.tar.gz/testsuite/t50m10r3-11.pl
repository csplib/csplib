%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 310, [], ['r2'], 'fam1', 1 ).
test( 't2', 12, [], [], 'fam1', 1 ).
test( 't3', 461, ['m10'], ['r2'], 'fam1', 1 ).
test( 't4', 259, [], ['r1','r3'], 'fam1', 1 ).
test( 't5', 647, [], [], 'fam1', 1 ).
test( 't6', 675, [], ['r1','r2'], 'fam1', 1 ).
test( 't7', 106, [], ['r2'], 'fam1', 1 ).
test( 't8', 595, [], ['r3','r2'], 'fam1', 1 ).
test( 't9', 767, [], [], 'fam1', 1 ).
test( 't10', 206, [], [], 'fam1', 1 ).
test( 't11', 84, [], [], 'fam1', 1 ).
test( 't12', 223, ['m9','m4','m1'], [], 'fam1', 1 ).
test( 't13', 630, ['m3','m8'], ['r3'], 'fam1', 1 ).
test( 't14', 310, ['m7','m1'], [], 'fam1', 1 ).
test( 't15', 641, [], [], 'fam1', 1 ).
test( 't16', 305, [], [], 'fam1', 1 ).
test( 't17', 27, [], [], 'fam1', 1 ).
test( 't18', 207, [], [], 'fam1', 1 ).
test( 't19', 145, [], [], 'fam1', 1 ).
test( 't20', 485, [], ['r3','r1'], 'fam1', 1 ).
test( 't21', 352, [], [], 'fam1', 1 ).
test( 't22', 257, [], [], 'fam1', 1 ).
test( 't23', 577, ['m6','m1'], ['r2','r3'], 'fam1', 1 ).
test( 't24', 438, ['m8','m7','m10'], [], 'fam1', 1 ).
test( 't25', 58, [], ['r1','r3'], 'fam1', 1 ).
test( 't26', 205, [], ['r3','r2'], 'fam1', 1 ).
test( 't27', 278, ['m2'], ['r2','r1','r3'], 'fam1', 1 ).
test( 't28', 356, [], [], 'fam1', 1 ).
test( 't29', 108, ['m1','m9'], [], 'fam1', 1 ).
test( 't30', 51, [], [], 'fam1', 1 ).
test( 't31', 555, ['m8','m3'], ['r1','r3'], 'fam1', 1 ).
test( 't32', 602, [], [], 'fam1', 1 ).
test( 't33', 456, [], [], 'fam1', 1 ).
test( 't34', 5, [], [], 'fam1', 1 ).
test( 't35', 109, [], ['r2'], 'fam1', 1 ).
test( 't36', 716, [], [], 'fam1', 1 ).
test( 't37', 91, ['m3','m5','m6','m9'], [], 'fam1', 1 ).
test( 't38', 270, [], [], 'fam1', 1 ).
test( 't39', 15, [], [], 'fam1', 1 ).
test( 't40', 11, [], [], 'fam1', 1 ).
test( 't41', 83, [], ['r3','r2'], 'fam1', 1 ).
test( 't42', 774, ['m3'], [], 'fam1', 1 ).
test( 't43', 126, [], [], 'fam1', 1 ).
test( 't44', 784, ['m3','m6','m1','m10'], [], 'fam1', 1 ).
test( 't45', 415, [], [], 'fam1', 1 ).
test( 't46', 235, [], [], 'fam1', 1 ).
test( 't47', 135, ['m4','m3'], [], 'fam1', 1 ).
test( 't48', 534, [], [], 'fam1', 1 ).
test( 't49', 86, [], ['r3','r2'], 'fam1', 1 ).
test( 't50', 126, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
