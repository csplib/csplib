%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 20
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 81, [], [], 'fam1', 1 ).
test( 't2', 292, [], [], 'fam1', 1 ).
test( 't3', 491, [], [], 'fam1', 1 ).
test( 't4', 366, [], ['r9','r8','r2','r7','r4','r1','r5'], 'fam1', 1 ).
test( 't5', 529, [], [], 'fam1', 1 ).
test( 't6', 736, ['m2'], [], 'fam1', 1 ).
test( 't7', 177, [], [], 'fam1', 1 ).
test( 't8', 222, [], [], 'fam1', 1 ).
test( 't9', 558, [], [], 'fam1', 1 ).
test( 't10', 444, ['m8','m2','m16'], [], 'fam1', 1 ).
test( 't11', 726, [], ['r6','r9','r10','r8','r2','r3','r1','r7','r4'], 'fam1', 1 ).
test( 't12', 454, [], [], 'fam1', 1 ).
test( 't13', 784, ['m2','m5','m7','m6','m13'], [], 'fam1', 1 ).
test( 't14', 658, [], [], 'fam1', 1 ).
test( 't15', 128, [], ['r8','r4','r9','r1','r7','r2','r6','r3','r5','r10'], 'fam1', 1 ).
test( 't16', 666, [], [], 'fam1', 1 ).
test( 't17', 277, [], [], 'fam1', 1 ).
test( 't18', 37, ['m4','m10','m14','m15','m1','m18','m5','m16'], ['r3','r2','r6','r9','r8','r5','r1','r7','r4','r10'], 'fam1', 1 ).
test( 't19', 25, [], [], 'fam1', 1 ).
test( 't20', 414, [], ['r7','r4','r8','r2','r6','r5','r1','r10','r9'], 'fam1', 1 ).
test( 't21', 511, [], [], 'fam1', 1 ).
test( 't22', 530, ['m2'], ['r9','r10','r1','r4','r3'], 'fam1', 1 ).
test( 't23', 532, [], [], 'fam1', 1 ).
test( 't24', 704, [], [], 'fam1', 1 ).
test( 't25', 336, [], [], 'fam1', 1 ).
test( 't26', 476, [], [], 'fam1', 1 ).
test( 't27', 289, [], [], 'fam1', 1 ).
test( 't28', 120, [], [], 'fam1', 1 ).
test( 't29', 743, [], [], 'fam1', 1 ).
test( 't30', 236, [], [], 'fam1', 1 ).
test( 't31', 336, [], [], 'fam1', 1 ).
test( 't32', 357, [], ['r9','r10','r8','r5','r2','r3'], 'fam1', 1 ).
test( 't33', 150, [], ['r5','r9'], 'fam1', 1 ).
test( 't34', 380, [], [], 'fam1', 1 ).
test( 't35', 792, [], [], 'fam1', 1 ).
test( 't36', 574, [], [], 'fam1', 1 ).
test( 't37', 219, [], ['r6','r1','r7','r5','r9','r3','r4','r8','r10','r2'], 'fam1', 1 ).
test( 't38', 282, [], [], 'fam1', 1 ).
test( 't39', 694, [], [], 'fam1', 1 ).
test( 't40', 361, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
