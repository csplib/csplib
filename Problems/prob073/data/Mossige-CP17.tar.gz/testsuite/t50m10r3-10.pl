%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 411, [], [], 'fam1', 1 ).
test( 't2', 361, [], ['r2'], 'fam1', 1 ).
test( 't3', 448, [], [], 'fam1', 1 ).
test( 't4', 49, [], [], 'fam1', 1 ).
test( 't5', 40, [], [], 'fam1', 1 ).
test( 't6', 589, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't7', 456, [], [], 'fam1', 1 ).
test( 't8', 289, [], [], 'fam1', 1 ).
test( 't9', 153, ['m10','m5','m6','m8'], ['r3','r1','r2'], 'fam1', 1 ).
test( 't10', 694, [], [], 'fam1', 1 ).
test( 't11', 647, [], [], 'fam1', 1 ).
test( 't12', 25, [], [], 'fam1', 1 ).
test( 't13', 14, [], ['r2','r1'], 'fam1', 1 ).
test( 't14', 605, [], ['r3','r1'], 'fam1', 1 ).
test( 't15', 25, [], [], 'fam1', 1 ).
test( 't16', 486, [], [], 'fam1', 1 ).
test( 't17', 649, [], [], 'fam1', 1 ).
test( 't18', 436, ['m1'], ['r3','r1','r2'], 'fam1', 1 ).
test( 't19', 455, [], [], 'fam1', 1 ).
test( 't20', 768, [], [], 'fam1', 1 ).
test( 't21', 717, [], [], 'fam1', 1 ).
test( 't22', 89, [], ['r1','r3'], 'fam1', 1 ).
test( 't23', 189, [], [], 'fam1', 1 ).
test( 't24', 407, [], [], 'fam1', 1 ).
test( 't25', 778, [], ['r1','r3'], 'fam1', 1 ).
test( 't26', 365, [], [], 'fam1', 1 ).
test( 't27', 351, ['m6','m10','m4'], ['r1'], 'fam1', 1 ).
test( 't28', 187, [], [], 'fam1', 1 ).
test( 't29', 307, [], [], 'fam1', 1 ).
test( 't30', 99, [], [], 'fam1', 1 ).
test( 't31', 110, [], [], 'fam1', 1 ).
test( 't32', 452, ['m7','m1','m4','m10'], [], 'fam1', 1 ).
test( 't33', 341, ['m3','m5','m6','m7'], [], 'fam1', 1 ).
test( 't34', 793, [], ['r3','r1'], 'fam1', 1 ).
test( 't35', 611, [], [], 'fam1', 1 ).
test( 't36', 527, ['m8','m9','m10'], [], 'fam1', 1 ).
test( 't37', 700, ['m1','m6','m4','m2'], [], 'fam1', 1 ).
test( 't38', 650, [], [], 'fam1', 1 ).
test( 't39', 56, [], [], 'fam1', 1 ).
test( 't40', 53, [], [], 'fam1', 1 ).
test( 't41', 128, [], [], 'fam1', 1 ).
test( 't42', 730, [], [], 'fam1', 1 ).
test( 't43', 577, ['m1','m7','m8','m5'], [], 'fam1', 1 ).
test( 't44', 117, [], [], 'fam1', 1 ).
test( 't45', 696, [], ['r1'], 'fam1', 1 ).
test( 't46', 398, [], [], 'fam1', 1 ).
test( 't47', 212, [], ['r2'], 'fam1', 1 ).
test( 't48', 736, ['m2','m3','m5'], [], 'fam1', 1 ).
test( 't49', 161, [], [], 'fam1', 1 ).
test( 't50', 731, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
