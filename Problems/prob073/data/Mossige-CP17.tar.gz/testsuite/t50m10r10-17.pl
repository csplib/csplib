%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 10
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 291, [], [], 'fam1', 1 ).
test( 't2', 736, [], ['r4','r9','r2','r10','r8','r1','r3'], 'fam1', 1 ).
test( 't3', 254, [], [], 'fam1', 1 ).
test( 't4', 163, ['m8','m1'], [], 'fam1', 1 ).
test( 't5', 635, [], [], 'fam1', 1 ).
test( 't6', 177, [], ['r1'], 'fam1', 1 ).
test( 't7', 115, [], ['r8','r2','r7','r5','r4'], 'fam1', 1 ).
test( 't8', 605, [], [], 'fam1', 1 ).
test( 't9', 470, [], [], 'fam1', 1 ).
test( 't10', 4, [], ['r7','r3','r9','r4','r10','r6','r2','r1','r8','r5'], 'fam1', 1 ).
test( 't11', 472, [], [], 'fam1', 1 ).
test( 't12', 472, [], [], 'fam1', 1 ).
test( 't13', 90, [], [], 'fam1', 1 ).
test( 't14', 344, [], [], 'fam1', 1 ).
test( 't15', 339, [], [], 'fam1', 1 ).
test( 't16', 720, ['m8','m4','m7'], [], 'fam1', 1 ).
test( 't17', 336, [], [], 'fam1', 1 ).
test( 't18', 447, ['m8','m5'], ['r4','r2','r8','r10','r3','r1','r7','r9','r5','r6'], 'fam1', 1 ).
test( 't19', 219, [], [], 'fam1', 1 ).
test( 't20', 615, ['m2','m8'], [], 'fam1', 1 ).
test( 't21', 769, [], [], 'fam1', 1 ).
test( 't22', 58, ['m2','m4','m6','m1'], [], 'fam1', 1 ).
test( 't23', 478, [], [], 'fam1', 1 ).
test( 't24', 92, [], ['r9','r3','r4','r10','r8'], 'fam1', 1 ).
test( 't25', 72, [], ['r7'], 'fam1', 1 ).
test( 't26', 124, [], ['r8','r5'], 'fam1', 1 ).
test( 't27', 341, ['m5'], [], 'fam1', 1 ).
test( 't28', 166, ['m1','m10','m3','m2'], ['r4'], 'fam1', 1 ).
test( 't29', 547, ['m3','m8','m1','m7'], [], 'fam1', 1 ).
test( 't30', 577, [], ['r3','r2','r8','r5','r4','r1','r10','r9','r7'], 'fam1', 1 ).
test( 't31', 464, ['m5','m3','m10','m1'], [], 'fam1', 1 ).
test( 't32', 284, [], [], 'fam1', 1 ).
test( 't33', 536, [], [], 'fam1', 1 ).
test( 't34', 396, ['m5','m4'], ['r9'], 'fam1', 1 ).
test( 't35', 499, [], [], 'fam1', 1 ).
test( 't36', 78, [], [], 'fam1', 1 ).
test( 't37', 651, ['m7','m5','m4','m2'], [], 'fam1', 1 ).
test( 't38', 261, [], [], 'fam1', 1 ).
test( 't39', 740, [], [], 'fam1', 1 ).
test( 't40', 721, [], [], 'fam1', 1 ).
test( 't41', 366, [], [], 'fam1', 1 ).
test( 't42', 337, [], [], 'fam1', 1 ).
test( 't43', 184, [], [], 'fam1', 1 ).
test( 't44', 338, ['m3','m5','m7','m6'], [], 'fam1', 1 ).
test( 't45', 791, [], [], 'fam1', 1 ).
test( 't46', 690, [], [], 'fam1', 1 ).
test( 't47', 683, [], [], 'fam1', 1 ).
test( 't48', 400, [], [], 'fam1', 1 ).
test( 't49', 409, [], [], 'fam1', 1 ).
test( 't50', 346, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
