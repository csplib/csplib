%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 20
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 747, ['m4','m19','m3','m17'], [], 'fam1', 1 ).
test( 't2', 91, [], [], 'fam1', 1 ).
test( 't3', 339, [], [], 'fam1', 1 ).
test( 't4', 40, [], ['r2','r1'], 'fam1', 1 ).
test( 't5', 773, [], [], 'fam1', 1 ).
test( 't6', 355, [], [], 'fam1', 1 ).
test( 't7', 56, [], [], 'fam1', 1 ).
test( 't8', 156, [], [], 'fam1', 1 ).
test( 't9', 9, [], [], 'fam1', 1 ).
test( 't10', 677, [], [], 'fam1', 1 ).
test( 't11', 189, [], [], 'fam1', 1 ).
test( 't12', 219, [], [], 'fam1', 1 ).
test( 't13', 175, [], [], 'fam1', 1 ).
test( 't14', 299, [], [], 'fam1', 1 ).
test( 't15', 94, ['m11','m5','m9','m8','m2','m7','m15'], ['r1','r2','r3','r5'], 'fam1', 1 ).
test( 't16', 605, ['m7','m11'], ['r1','r4','r5','r3'], 'fam1', 1 ).
test( 't17', 638, [], ['r4','r3','r1'], 'fam1', 1 ).
test( 't18', 53, [], [], 'fam1', 1 ).
test( 't19', 378, [], ['r1','r5','r4','r2'], 'fam1', 1 ).
test( 't20', 45, [], [], 'fam1', 1 ).
test( 't21', 422, [], [], 'fam1', 1 ).
test( 't22', 504, [], [], 'fam1', 1 ).
test( 't23', 311, [], [], 'fam1', 1 ).
test( 't24', 43, [], ['r4','r2','r5','r3','r1'], 'fam1', 1 ).
test( 't25', 263, ['m4','m7','m3','m12','m11','m14','m17'], [], 'fam1', 1 ).
test( 't26', 392, [], [], 'fam1', 1 ).
test( 't27', 9, [], ['r1','r5'], 'fam1', 1 ).
test( 't28', 572, [], [], 'fam1', 1 ).
test( 't29', 363, [], [], 'fam1', 1 ).
test( 't30', 489, [], ['r1','r2','r4'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
