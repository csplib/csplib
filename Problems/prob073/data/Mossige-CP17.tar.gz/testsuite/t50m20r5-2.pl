%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 20
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 94, ['m10','m4','m7','m1','m15','m6','m16','m19'], [], 'fam1', 1 ).
test( 't2', 218, [], ['r1'], 'fam1', 1 ).
test( 't3', 446, ['m12','m6','m18'], ['r1'], 'fam1', 1 ).
test( 't4', 566, [], [], 'fam1', 1 ).
test( 't5', 111, [], [], 'fam1', 1 ).
test( 't6', 340, [], [], 'fam1', 1 ).
test( 't7', 8, [], ['r4','r1','r5','r3','r2'], 'fam1', 1 ).
test( 't8', 247, [], [], 'fam1', 1 ).
test( 't9', 759, [], [], 'fam1', 1 ).
test( 't10', 660, ['m12','m7','m14','m18','m2','m19'], [], 'fam1', 1 ).
test( 't11', 734, ['m1','m17','m16','m14','m18','m8','m15','m5'], ['r2','r5'], 'fam1', 1 ).
test( 't12', 229, [], [], 'fam1', 1 ).
test( 't13', 295, [], [], 'fam1', 1 ).
test( 't14', 29, ['m6','m14','m9','m8','m20','m13','m4','m15'], [], 'fam1', 1 ).
test( 't15', 718, [], ['r2','r3','r5','r4','r1'], 'fam1', 1 ).
test( 't16', 336, [], ['r5','r4'], 'fam1', 1 ).
test( 't17', 241, [], [], 'fam1', 1 ).
test( 't18', 176, [], [], 'fam1', 1 ).
test( 't19', 14, [], [], 'fam1', 1 ).
test( 't20', 589, [], [], 'fam1', 1 ).
test( 't21', 775, ['m9','m10'], [], 'fam1', 1 ).
test( 't22', 132, [], ['r1','r4','r2','r5'], 'fam1', 1 ).
test( 't23', 224, ['m5','m14'], ['r5','r2','r3','r4','r1'], 'fam1', 1 ).
test( 't24', 236, [], ['r4','r1','r5'], 'fam1', 1 ).
test( 't25', 93, [], [], 'fam1', 1 ).
test( 't26', 591, ['m1','m17','m5','m12','m19','m6','m14'], [], 'fam1', 1 ).
test( 't27', 539, [], [], 'fam1', 1 ).
test( 't28', 626, [], [], 'fam1', 1 ).
test( 't29', 703, [], ['r4'], 'fam1', 1 ).
test( 't30', 79, [], [], 'fam1', 1 ).
test( 't31', 378, [], [], 'fam1', 1 ).
test( 't32', 633, ['m17','m1','m10','m7','m13','m9','m14','m4'], ['r1','r5','r3','r4','r2'], 'fam1', 1 ).
test( 't33', 466, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't34', 450, [], ['r3','r1','r4'], 'fam1', 1 ).
test( 't35', 754, [], [], 'fam1', 1 ).
test( 't36', 506, [], [], 'fam1', 1 ).
test( 't37', 65, [], [], 'fam1', 1 ).
test( 't38', 18, [], [], 'fam1', 1 ).
test( 't39', 618, [], ['r5','r2'], 'fam1', 1 ).
test( 't40', 713, [], [], 'fam1', 1 ).
test( 't41', 137, [], [], 'fam1', 1 ).
test( 't42', 393, [], ['r4','r5','r1','r2','r3'], 'fam1', 1 ).
test( 't43', 314, [], ['r4','r5','r2'], 'fam1', 1 ).
test( 't44', 531, [], ['r3','r5'], 'fam1', 1 ).
test( 't45', 55, [], [], 'fam1', 1 ).
test( 't46', 719, ['m2','m3','m13','m4','m7','m12','m17','m6'], [], 'fam1', 1 ).
test( 't47', 540, [], ['r2','r5','r3','r1'], 'fam1', 1 ).
test( 't48', 213, [], [], 'fam1', 1 ).
test( 't49', 769, [], [], 'fam1', 1 ).
test( 't50', 625, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
