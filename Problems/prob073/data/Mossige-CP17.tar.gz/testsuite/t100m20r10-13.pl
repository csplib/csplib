%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 20
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 430, [], [], 'fam1', 1 ).
test( 't2', 538, [], [], 'fam1', 1 ).
test( 't3', 673, ['m10','m20','m1','m13','m5'], [], 'fam1', 1 ).
test( 't4', 514, [], [], 'fam1', 1 ).
test( 't5', 510, [], [], 'fam1', 1 ).
test( 't6', 623, [], [], 'fam1', 1 ).
test( 't7', 180, [], ['r8','r4','r1','r6','r3','r7'], 'fam1', 1 ).
test( 't8', 769, [], [], 'fam1', 1 ).
test( 't9', 508, [], ['r9'], 'fam1', 1 ).
test( 't10', 107, [], [], 'fam1', 1 ).
test( 't11', 725, [], [], 'fam1', 1 ).
test( 't12', 353, [], [], 'fam1', 1 ).
test( 't13', 247, [], [], 'fam1', 1 ).
test( 't14', 704, [], [], 'fam1', 1 ).
test( 't15', 509, [], ['r4','r8','r5','r6','r2'], 'fam1', 1 ).
test( 't16', 730, [], [], 'fam1', 1 ).
test( 't17', 474, [], [], 'fam1', 1 ).
test( 't18', 211, [], [], 'fam1', 1 ).
test( 't19', 650, [], [], 'fam1', 1 ).
test( 't20', 180, [], [], 'fam1', 1 ).
test( 't21', 66, [], ['r4','r8','r9','r3'], 'fam1', 1 ).
test( 't22', 484, ['m13','m1','m14'], [], 'fam1', 1 ).
test( 't23', 507, [], [], 'fam1', 1 ).
test( 't24', 189, [], [], 'fam1', 1 ).
test( 't25', 150, [], [], 'fam1', 1 ).
test( 't26', 314, [], [], 'fam1', 1 ).
test( 't27', 735, [], ['r8','r4','r9','r1','r3','r5','r7'], 'fam1', 1 ).
test( 't28', 375, ['m16','m19','m20'], [], 'fam1', 1 ).
test( 't29', 419, ['m2','m11','m8','m15','m20','m6'], [], 'fam1', 1 ).
test( 't30', 427, [], [], 'fam1', 1 ).
test( 't31', 722, [], ['r4','r1','r3','r6','r10'], 'fam1', 1 ).
test( 't32', 324, ['m11','m16','m15','m8','m6','m1','m9'], [], 'fam1', 1 ).
test( 't33', 703, [], ['r7','r8'], 'fam1', 1 ).
test( 't34', 468, [], [], 'fam1', 1 ).
test( 't35', 715, [], ['r2','r5','r10','r8','r3','r1'], 'fam1', 1 ).
test( 't36', 661, ['m4'], [], 'fam1', 1 ).
test( 't37', 482, [], [], 'fam1', 1 ).
test( 't38', 149, ['m20','m13','m6','m16'], [], 'fam1', 1 ).
test( 't39', 632, [], [], 'fam1', 1 ).
test( 't40', 548, [], [], 'fam1', 1 ).
test( 't41', 66, [], [], 'fam1', 1 ).
test( 't42', 801, [], ['r4','r1'], 'fam1', 1 ).
test( 't43', 359, [], ['r5','r2','r7','r9','r10','r1','r4','r3'], 'fam1', 1 ).
test( 't44', 483, [], [], 'fam1', 1 ).
test( 't45', 704, [], [], 'fam1', 1 ).
test( 't46', 799, [], ['r10','r6','r8','r2','r4','r7','r9','r3'], 'fam1', 1 ).
test( 't47', 411, [], ['r5','r3','r6','r4','r2','r9','r8','r7','r10','r1'], 'fam1', 1 ).
test( 't48', 555, ['m1','m3'], ['r5','r7','r10','r9','r8','r1','r4','r3'], 'fam1', 1 ).
test( 't49', 259, [], ['r4','r9'], 'fam1', 1 ).
test( 't50', 348, [], [], 'fam1', 1 ).
test( 't51', 130, [], [], 'fam1', 1 ).
test( 't52', 673, [], [], 'fam1', 1 ).
test( 't53', 691, [], [], 'fam1', 1 ).
test( 't54', 415, [], ['r10','r3','r4','r8','r2','r1'], 'fam1', 1 ).
test( 't55', 336, ['m13','m6','m11'], [], 'fam1', 1 ).
test( 't56', 263, [], [], 'fam1', 1 ).
test( 't57', 353, [], ['r7','r9','r1','r3'], 'fam1', 1 ).
test( 't58', 514, ['m6'], [], 'fam1', 1 ).
test( 't59', 638, [], [], 'fam1', 1 ).
test( 't60', 561, [], ['r8','r10','r4','r5'], 'fam1', 1 ).
test( 't61', 160, [], [], 'fam1', 1 ).
test( 't62', 316, ['m11','m6','m12','m8','m9','m18','m2','m19'], [], 'fam1', 1 ).
test( 't63', 411, [], ['r3','r6'], 'fam1', 1 ).
test( 't64', 220, [], ['r6','r9','r5','r1','r10','r2','r7','r8'], 'fam1', 1 ).
test( 't65', 411, [], ['r1','r4','r7','r9','r3','r6','r8'], 'fam1', 1 ).
test( 't66', 96, ['m9','m4','m6','m13','m15'], ['r1','r2','r8','r5','r10','r4','r3','r6'], 'fam1', 1 ).
test( 't67', 567, [], [], 'fam1', 1 ).
test( 't68', 210, [], ['r4','r6'], 'fam1', 1 ).
test( 't69', 228, [], [], 'fam1', 1 ).
test( 't70', 119, [], [], 'fam1', 1 ).
test( 't71', 35, ['m18','m3'], ['r6','r1','r9'], 'fam1', 1 ).
test( 't72', 775, ['m17','m11','m19','m10','m7','m5'], [], 'fam1', 1 ).
test( 't73', 639, [], [], 'fam1', 1 ).
test( 't74', 694, [], ['r4','r3','r8','r1','r6','r10','r2','r5','r9'], 'fam1', 1 ).
test( 't75', 521, [], [], 'fam1', 1 ).
test( 't76', 798, [], [], 'fam1', 1 ).
test( 't77', 106, [], ['r5','r8','r10','r4','r7','r9','r2','r3'], 'fam1', 1 ).
test( 't78', 412, [], [], 'fam1', 1 ).
test( 't79', 538, ['m6','m8','m5','m9','m18','m14','m7','m13'], [], 'fam1', 1 ).
test( 't80', 722, [], [], 'fam1', 1 ).
test( 't81', 105, [], [], 'fam1', 1 ).
test( 't82', 330, [], [], 'fam1', 1 ).
test( 't83', 33, [], [], 'fam1', 1 ).
test( 't84', 304, [], ['r10','r1'], 'fam1', 1 ).
test( 't85', 554, [], [], 'fam1', 1 ).
test( 't86', 487, [], [], 'fam1', 1 ).
test( 't87', 299, [], [], 'fam1', 1 ).
test( 't88', 67, [], [], 'fam1', 1 ).
test( 't89', 99, [], [], 'fam1', 1 ).
test( 't90', 499, [], ['r7','r4','r5','r1','r10','r9'], 'fam1', 1 ).
test( 't91', 89, [], [], 'fam1', 1 ).
test( 't92', 393, [], [], 'fam1', 1 ).
test( 't93', 232, [], [], 'fam1', 1 ).
test( 't94', 749, [], ['r3','r4','r8','r5','r10','r1'], 'fam1', 1 ).
test( 't95', 92, [], ['r9','r4','r3','r6','r7','r10','r8'], 'fam1', 1 ).
test( 't96', 368, [], [], 'fam1', 1 ).
test( 't97', 148, [], [], 'fam1', 1 ).
test( 't98', 564, [], [], 'fam1', 1 ).
test( 't99', 500, [], [], 'fam1', 1 ).
test( 't100', 650, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
