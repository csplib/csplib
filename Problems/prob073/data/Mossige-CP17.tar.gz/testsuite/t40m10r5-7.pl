%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 55, [], ['r5','r2','r3','r1','r4'], 'fam1', 1 ).
test( 't2', 318, [], [], 'fam1', 1 ).
test( 't3', 361, ['m7'], [], 'fam1', 1 ).
test( 't4', 447, [], [], 'fam1', 1 ).
test( 't5', 546, [], [], 'fam1', 1 ).
test( 't6', 245, [], [], 'fam1', 1 ).
test( 't7', 564, ['m5','m1','m2','m7'], [], 'fam1', 1 ).
test( 't8', 598, [], [], 'fam1', 1 ).
test( 't9', 1, [], ['r2','r3','r4'], 'fam1', 1 ).
test( 't10', 463, [], ['r1','r4','r3','r5','r2'], 'fam1', 1 ).
test( 't11', 67, [], ['r4','r5','r2'], 'fam1', 1 ).
test( 't12', 198, [], ['r4','r3','r1','r2'], 'fam1', 1 ).
test( 't13', 423, [], [], 'fam1', 1 ).
test( 't14', 580, ['m1','m4','m5','m10'], [], 'fam1', 1 ).
test( 't15', 576, ['m10','m9','m2'], ['r4'], 'fam1', 1 ).
test( 't16', 354, [], ['r2','r3','r1','r5'], 'fam1', 1 ).
test( 't17', 575, [], [], 'fam1', 1 ).
test( 't18', 68, [], [], 'fam1', 1 ).
test( 't19', 755, [], [], 'fam1', 1 ).
test( 't20', 4, [], [], 'fam1', 1 ).
test( 't21', 541, ['m10','m7'], [], 'fam1', 1 ).
test( 't22', 484, [], [], 'fam1', 1 ).
test( 't23', 437, [], ['r4','r3','r1','r2'], 'fam1', 1 ).
test( 't24', 654, ['m9'], [], 'fam1', 1 ).
test( 't25', 536, [], [], 'fam1', 1 ).
test( 't26', 784, [], ['r5','r1','r4','r2','r3'], 'fam1', 1 ).
test( 't27', 752, ['m2','m5','m3','m6'], [], 'fam1', 1 ).
test( 't28', 777, [], [], 'fam1', 1 ).
test( 't29', 388, ['m2','m5','m10','m6'], ['r3','r1','r4','r2','r5'], 'fam1', 1 ).
test( 't30', 642, [], ['r3','r5'], 'fam1', 1 ).
test( 't31', 96, [], [], 'fam1', 1 ).
test( 't32', 739, [], [], 'fam1', 1 ).
test( 't33', 476, [], ['r4'], 'fam1', 1 ).
test( 't34', 356, [], ['r5','r2','r3','r4'], 'fam1', 1 ).
test( 't35', 480, [], [], 'fam1', 1 ).
test( 't36', 438, [], ['r5','r4','r1'], 'fam1', 1 ).
test( 't37', 470, [], [], 'fam1', 1 ).
test( 't38', 64, [], ['r5','r3','r1','r4','r2'], 'fam1', 1 ).
test( 't39', 430, [], [], 'fam1', 1 ).
test( 't40', 547, [], ['r5'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
