%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 20
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 306, [], [], 'fam1', 1 ).
test( 't2', 78, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't3', 653, [], ['r1'], 'fam1', 1 ).
test( 't4', 309, [], [], 'fam1', 1 ).
test( 't5', 610, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't6', 412, [], [], 'fam1', 1 ).
test( 't7', 301, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't8', 232, [], [], 'fam1', 1 ).
test( 't9', 437, ['m20','m6','m1','m18'], [], 'fam1', 1 ).
test( 't10', 283, [], [], 'fam1', 1 ).
test( 't11', 158, [], [], 'fam1', 1 ).
test( 't12', 489, [], [], 'fam1', 1 ).
test( 't13', 202, ['m2','m19','m15','m13','m20'], [], 'fam1', 1 ).
test( 't14', 703, [], [], 'fam1', 1 ).
test( 't15', 671, ['m2','m3','m13','m10'], [], 'fam1', 1 ).
test( 't16', 172, [], [], 'fam1', 1 ).
test( 't17', 754, [], [], 'fam1', 1 ).
test( 't18', 479, [], [], 'fam1', 1 ).
test( 't19', 710, ['m10','m14','m12','m2'], [], 'fam1', 1 ).
test( 't20', 570, [], [], 'fam1', 1 ).
test( 't21', 384, ['m8','m11','m20','m9','m7'], ['r1','r3','r2'], 'fam1', 1 ).
test( 't22', 592, [], [], 'fam1', 1 ).
test( 't23', 126, [], ['r3'], 'fam1', 1 ).
test( 't24', 275, [], [], 'fam1', 1 ).
test( 't25', 661, [], [], 'fam1', 1 ).
test( 't26', 583, ['m17','m8','m14','m1'], ['r3','r1'], 'fam1', 1 ).
test( 't27', 254, [], [], 'fam1', 1 ).
test( 't28', 565, [], [], 'fam1', 1 ).
test( 't29', 712, [], [], 'fam1', 1 ).
test( 't30', 62, ['m14','m9','m8','m19','m13','m1','m15'], [], 'fam1', 1 ).
test( 't31', 219, ['m6','m2','m16','m12'], [], 'fam1', 1 ).
test( 't32', 507, ['m16','m11','m20','m10','m13','m14','m6','m17'], [], 'fam1', 1 ).
test( 't33', 364, ['m19','m11','m15','m17','m2','m12','m4'], [], 'fam1', 1 ).
test( 't34', 670, ['m18','m10'], ['r3','r2'], 'fam1', 1 ).
test( 't35', 161, [], [], 'fam1', 1 ).
test( 't36', 295, [], [], 'fam1', 1 ).
test( 't37', 322, [], [], 'fam1', 1 ).
test( 't38', 418, [], [], 'fam1', 1 ).
test( 't39', 661, [], [], 'fam1', 1 ).
test( 't40', 151, ['m3','m9','m19','m14','m12','m2','m6'], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
