%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 296, ['m7','m5'], [], 'fam1', 1 ).
test( 't2', 27, [], ['r3'], 'fam1', 1 ).
test( 't3', 477, [], [], 'fam1', 1 ).
test( 't4', 477, [], ['r2','r1'], 'fam1', 1 ).
test( 't5', 442, [], [], 'fam1', 1 ).
test( 't6', 16, [], [], 'fam1', 1 ).
test( 't7', 34, [], ['r2','r1'], 'fam1', 1 ).
test( 't8', 82, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't9', 216, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't10', 29, [], ['r1','r2'], 'fam1', 1 ).
test( 't11', 496, ['m3','m1','m7','m9'], [], 'fam1', 1 ).
test( 't12', 264, ['m9','m7'], ['r1','r2','r3'], 'fam1', 1 ).
test( 't13', 301, ['m10'], ['r2','r3','r1'], 'fam1', 1 ).
test( 't14', 361, ['m6','m3'], [], 'fam1', 1 ).
test( 't15', 425, [], [], 'fam1', 1 ).
test( 't16', 486, [], ['r3'], 'fam1', 1 ).
test( 't17', 658, [], [], 'fam1', 1 ).
test( 't18', 600, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't19', 172, [], ['r1'], 'fam1', 1 ).
test( 't20', 328, ['m9'], [], 'fam1', 1 ).
test( 't21', 153, [], [], 'fam1', 1 ).
test( 't22', 598, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't23', 664, [], [], 'fam1', 1 ).
test( 't24', 449, [], [], 'fam1', 1 ).
test( 't25', 695, [], [], 'fam1', 1 ).
test( 't26', 288, [], [], 'fam1', 1 ).
test( 't27', 666, ['m4'], ['r1','r2','r3'], 'fam1', 1 ).
test( 't28', 341, [], [], 'fam1', 1 ).
test( 't29', 36, [], [], 'fam1', 1 ).
test( 't30', 481, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't31', 643, ['m5','m7','m9'], ['r3'], 'fam1', 1 ).
test( 't32', 234, ['m7','m8'], [], 'fam1', 1 ).
test( 't33', 404, ['m3'], [], 'fam1', 1 ).
test( 't34', 340, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't35', 237, [], [], 'fam1', 1 ).
test( 't36', 26, [], ['r2'], 'fam1', 1 ).
test( 't37', 140, ['m8','m3','m5'], [], 'fam1', 1 ).
test( 't38', 801, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't39', 698, [], ['r1'], 'fam1', 1 ).
test( 't40', 407, [], [], 'fam1', 1 ).
test( 't41', 302, [], [], 'fam1', 1 ).
test( 't42', 693, [], [], 'fam1', 1 ).
test( 't43', 782, [], [], 'fam1', 1 ).
test( 't44', 397, [], [], 'fam1', 1 ).
test( 't45', 85, ['m8','m2','m4'], [], 'fam1', 1 ).
test( 't46', 322, [], [], 'fam1', 1 ).
test( 't47', 648, [], [], 'fam1', 1 ).
test( 't48', 187, ['m5','m7'], [], 'fam1', 1 ).
test( 't49', 110, [], [], 'fam1', 1 ).
test( 't50', 211, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
