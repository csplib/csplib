%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 20
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 177, [], [], 'fam1', 1 ).
test( 't2', 111, [], ['r7','r8'], 'fam1', 1 ).
test( 't3', 765, [], [], 'fam1', 1 ).
test( 't4', 166, [], ['r7','r8','r10','r4','r9','r5','r2'], 'fam1', 1 ).
test( 't5', 547, [], [], 'fam1', 1 ).
test( 't6', 450, [], [], 'fam1', 1 ).
test( 't7', 518, [], [], 'fam1', 1 ).
test( 't8', 479, [], [], 'fam1', 1 ).
test( 't9', 203, [], [], 'fam1', 1 ).
test( 't10', 23, ['m2','m17','m20','m4','m12','m5','m11','m7'], ['r2'], 'fam1', 1 ).
test( 't11', 681, [], [], 'fam1', 1 ).
test( 't12', 390, [], [], 'fam1', 1 ).
test( 't13', 429, [], [], 'fam1', 1 ).
test( 't14', 109, ['m5'], [], 'fam1', 1 ).
test( 't15', 435, [], [], 'fam1', 1 ).
test( 't16', 244, ['m11','m4','m19','m2','m9','m13','m7','m18'], ['r8','r2','r7','r3','r6','r9','r4','r5'], 'fam1', 1 ).
test( 't17', 662, [], ['r1','r3','r2','r7','r9','r8'], 'fam1', 1 ).
test( 't18', 623, [], [], 'fam1', 1 ).
test( 't19', 734, [], ['r6','r5','r2','r8','r7','r3','r1','r9'], 'fam1', 1 ).
test( 't20', 156, ['m18','m10','m17','m5','m15','m12','m11'], [], 'fam1', 1 ).
test( 't21', 239, [], [], 'fam1', 1 ).
test( 't22', 554, [], ['r10','r3','r4'], 'fam1', 1 ).
test( 't23', 25, [], [], 'fam1', 1 ).
test( 't24', 44, [], ['r7','r6','r8','r4','r5','r2','r3','r10'], 'fam1', 1 ).
test( 't25', 46, [], [], 'fam1', 1 ).
test( 't26', 111, [], ['r7','r4','r2','r3','r10','r1','r5','r8','r6','r9'], 'fam1', 1 ).
test( 't27', 349, [], [], 'fam1', 1 ).
test( 't28', 691, [], ['r6','r4','r8','r10','r7','r3','r1','r9','r2'], 'fam1', 1 ).
test( 't29', 442, ['m15','m2','m12','m17','m3'], ['r2','r3','r8','r4'], 'fam1', 1 ).
test( 't30', 671, ['m12','m20'], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
