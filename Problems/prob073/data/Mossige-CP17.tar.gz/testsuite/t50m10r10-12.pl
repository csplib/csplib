%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 10
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 161, ['m10','m4','m2','m1'], [], 'fam1', 1 ).
test( 't2', 699, [], [], 'fam1', 1 ).
test( 't3', 442, [], [], 'fam1', 1 ).
test( 't4', 695, [], [], 'fam1', 1 ).
test( 't5', 529, [], [], 'fam1', 1 ).
test( 't6', 142, [], [], 'fam1', 1 ).
test( 't7', 651, [], [], 'fam1', 1 ).
test( 't8', 762, ['m8','m5'], ['r7','r9','r4'], 'fam1', 1 ).
test( 't9', 510, [], ['r1','r5','r9','r7','r3','r8','r4'], 'fam1', 1 ).
test( 't10', 201, ['m5','m3','m6'], [], 'fam1', 1 ).
test( 't11', 174, ['m7','m3'], ['r1','r9','r8'], 'fam1', 1 ).
test( 't12', 519, [], [], 'fam1', 1 ).
test( 't13', 746, [], ['r4','r9','r2','r10','r3'], 'fam1', 1 ).
test( 't14', 56, [], [], 'fam1', 1 ).
test( 't15', 255, [], ['r4','r7','r5','r9','r10','r8'], 'fam1', 1 ).
test( 't16', 791, [], [], 'fam1', 1 ).
test( 't17', 18, ['m1'], [], 'fam1', 1 ).
test( 't18', 336, [], [], 'fam1', 1 ).
test( 't19', 469, [], [], 'fam1', 1 ).
test( 't20', 356, ['m3','m8'], [], 'fam1', 1 ).
test( 't21', 452, ['m4'], [], 'fam1', 1 ).
test( 't22', 1, [], [], 'fam1', 1 ).
test( 't23', 260, [], [], 'fam1', 1 ).
test( 't24', 416, ['m2'], [], 'fam1', 1 ).
test( 't25', 490, [], ['r8','r7','r2','r5','r3','r4','r6','r9','r1','r10'], 'fam1', 1 ).
test( 't26', 419, [], ['r6','r9','r10','r3','r2','r1','r7','r5','r4'], 'fam1', 1 ).
test( 't27', 104, [], [], 'fam1', 1 ).
test( 't28', 124, [], [], 'fam1', 1 ).
test( 't29', 552, [], ['r10'], 'fam1', 1 ).
test( 't30', 712, [], [], 'fam1', 1 ).
test( 't31', 794, [], ['r8','r6','r4','r1','r2','r5','r10','r3'], 'fam1', 1 ).
test( 't32', 17, [], [], 'fam1', 1 ).
test( 't33', 625, ['m2','m1','m8'], ['r2','r10','r8','r7','r6','r5'], 'fam1', 1 ).
test( 't34', 387, [], [], 'fam1', 1 ).
test( 't35', 512, ['m3','m2'], ['r6','r5'], 'fam1', 1 ).
test( 't36', 713, ['m3','m6'], [], 'fam1', 1 ).
test( 't37', 715, [], [], 'fam1', 1 ).
test( 't38', 349, [], [], 'fam1', 1 ).
test( 't39', 695, [], [], 'fam1', 1 ).
test( 't40', 407, ['m8','m5','m6'], ['r6','r10','r1','r4','r9','r5','r2','r8','r3','r7'], 'fam1', 1 ).
test( 't41', 457, [], [], 'fam1', 1 ).
test( 't42', 596, [], ['r7','r10','r6'], 'fam1', 1 ).
test( 't43', 286, [], ['r1','r4','r6','r5','r3','r2','r7','r9'], 'fam1', 1 ).
test( 't44', 451, [], ['r4','r2','r10','r1','r5','r3','r6','r7','r8','r9'], 'fam1', 1 ).
test( 't45', 492, [], ['r10','r7','r2','r4'], 'fam1', 1 ).
test( 't46', 447, [], ['r8','r3','r5','r4','r10','r6'], 'fam1', 1 ).
test( 't47', 396, [], [], 'fam1', 1 ).
test( 't48', 714, [], [], 'fam1', 1 ).
test( 't49', 270, [], ['r10','r3','r6','r9'], 'fam1', 1 ).
test( 't50', 133, [], ['r2','r9'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
