%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 20
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 739, [], [], 'fam1', 1 ).
test( 't2', 450, [], [], 'fam1', 1 ).
test( 't3', 266, [], ['r3'], 'fam1', 1 ).
test( 't4', 661, ['m17','m16','m5','m19','m20'], ['r3','r2','r4','r1'], 'fam1', 1 ).
test( 't5', 398, [], ['r3'], 'fam1', 1 ).
test( 't6', 242, [], [], 'fam1', 1 ).
test( 't7', 194, [], [], 'fam1', 1 ).
test( 't8', 226, [], [], 'fam1', 1 ).
test( 't9', 538, ['m16','m15','m1'], [], 'fam1', 1 ).
test( 't10', 601, [], [], 'fam1', 1 ).
test( 't11', 327, [], [], 'fam1', 1 ).
test( 't12', 457, [], ['r3','r2','r5','r1','r4'], 'fam1', 1 ).
test( 't13', 282, [], [], 'fam1', 1 ).
test( 't14', 295, ['m12'], [], 'fam1', 1 ).
test( 't15', 413, [], ['r5','r1','r2','r3'], 'fam1', 1 ).
test( 't16', 86, ['m15','m10','m6','m2'], [], 'fam1', 1 ).
test( 't17', 515, [], ['r5','r1','r4','r2'], 'fam1', 1 ).
test( 't18', 379, ['m14','m6','m11'], [], 'fam1', 1 ).
test( 't19', 601, [], [], 'fam1', 1 ).
test( 't20', 263, [], [], 'fam1', 1 ).
test( 't21', 47, [], ['r5','r2'], 'fam1', 1 ).
test( 't22', 405, [], [], 'fam1', 1 ).
test( 't23', 665, [], ['r4'], 'fam1', 1 ).
test( 't24', 586, ['m6','m20','m8'], ['r2','r5'], 'fam1', 1 ).
test( 't25', 241, [], [], 'fam1', 1 ).
test( 't26', 225, ['m3','m14'], ['r3','r2','r4','r5','r1'], 'fam1', 1 ).
test( 't27', 459, [], ['r1','r4'], 'fam1', 1 ).
test( 't28', 451, [], [], 'fam1', 1 ).
test( 't29', 776, [], [], 'fam1', 1 ).
test( 't30', 711, [], [], 'fam1', 1 ).
test( 't31', 54, [], [], 'fam1', 1 ).
test( 't32', 16, [], [], 'fam1', 1 ).
test( 't33', 421, [], [], 'fam1', 1 ).
test( 't34', 338, ['m19','m12'], [], 'fam1', 1 ).
test( 't35', 648, ['m11','m19','m8','m5','m13','m3','m10'], ['r2'], 'fam1', 1 ).
test( 't36', 647, [], [], 'fam1', 1 ).
test( 't37', 591, [], [], 'fam1', 1 ).
test( 't38', 596, [], [], 'fam1', 1 ).
test( 't39', 754, [], [], 'fam1', 1 ).
test( 't40', 53, [], [], 'fam1', 1 ).
test( 't41', 651, ['m6','m4','m14','m10','m15','m1','m19'], ['r5','r4','r1'], 'fam1', 1 ).
test( 't42', 148, [], [], 'fam1', 1 ).
test( 't43', 340, [], ['r2','r3','r4','r5','r1'], 'fam1', 1 ).
test( 't44', 201, ['m20','m19','m1','m6','m4','m12','m5','m8'], [], 'fam1', 1 ).
test( 't45', 484, ['m8','m5','m2'], ['r5'], 'fam1', 1 ).
test( 't46', 308, ['m11','m6','m12','m1','m7','m2'], ['r5','r3','r2','r1','r4'], 'fam1', 1 ).
test( 't47', 685, [], [], 'fam1', 1 ).
test( 't48', 679, [], [], 'fam1', 1 ).
test( 't49', 529, [], [], 'fam1', 1 ).
test( 't50', 539, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
