%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 18, [], [], 'fam1', 1 ).
test( 't2', 683, [], [], 'fam1', 1 ).
test( 't3', 668, [], ['r3','r2'], 'fam1', 1 ).
test( 't4', 469, ['m8','m1','m5','m10'], ['r1','r3','r2'], 'fam1', 1 ).
test( 't5', 7, [], [], 'fam1', 1 ).
test( 't6', 175, [], [], 'fam1', 1 ).
test( 't7', 470, ['m7','m3'], ['r3'], 'fam1', 1 ).
test( 't8', 570, ['m1'], ['r3','r1','r2'], 'fam1', 1 ).
test( 't9', 716, ['m3'], [], 'fam1', 1 ).
test( 't10', 324, ['m1','m10'], [], 'fam1', 1 ).
test( 't11', 7, ['m4','m9','m2'], [], 'fam1', 1 ).
test( 't12', 674, [], ['r3','r2'], 'fam1', 1 ).
test( 't13', 340, [], [], 'fam1', 1 ).
test( 't14', 270, [], [], 'fam1', 1 ).
test( 't15', 422, [], [], 'fam1', 1 ).
test( 't16', 98, [], [], 'fam1', 1 ).
test( 't17', 58, [], [], 'fam1', 1 ).
test( 't18', 354, [], [], 'fam1', 1 ).
test( 't19', 245, [], [], 'fam1', 1 ).
test( 't20', 96, [], [], 'fam1', 1 ).
test( 't21', 253, [], ['r2'], 'fam1', 1 ).
test( 't22', 92, [], ['r2','r3'], 'fam1', 1 ).
test( 't23', 319, ['m8','m1'], [], 'fam1', 1 ).
test( 't24', 615, [], [], 'fam1', 1 ).
test( 't25', 126, [], [], 'fam1', 1 ).
test( 't26', 387, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't27', 616, [], ['r2'], 'fam1', 1 ).
test( 't28', 689, [], ['r2'], 'fam1', 1 ).
test( 't29', 411, [], ['r3','r2'], 'fam1', 1 ).
test( 't30', 221, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
