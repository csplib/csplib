%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 20
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 595, [], [], 'fam1', 1 ).
test( 't2', 495, ['m4','m10','m6','m16','m12','m17','m1'], ['r5','r3','r2','r4','r1'], 'fam1', 1 ).
test( 't3', 229, [], [], 'fam1', 1 ).
test( 't4', 80, [], [], 'fam1', 1 ).
test( 't5', 269, ['m2','m14','m12','m9','m15','m13','m20'], [], 'fam1', 1 ).
test( 't6', 732, [], ['r3'], 'fam1', 1 ).
test( 't7', 744, ['m9','m3','m14','m4','m5','m12','m6','m8'], ['r3','r2','r1'], 'fam1', 1 ).
test( 't8', 638, ['m1','m11','m4','m16','m6','m10','m17','m9'], ['r5'], 'fam1', 1 ).
test( 't9', 217, ['m4','m11','m2','m16','m20','m5','m3'], [], 'fam1', 1 ).
test( 't10', 623, ['m6','m9','m1'], [], 'fam1', 1 ).
test( 't11', 16, ['m20','m4','m14','m10','m3','m15','m5','m2'], [], 'fam1', 1 ).
test( 't12', 758, [], [], 'fam1', 1 ).
test( 't13', 314, ['m12','m5','m8','m18','m11','m13'], [], 'fam1', 1 ).
test( 't14', 293, [], [], 'fam1', 1 ).
test( 't15', 271, ['m20','m5','m14','m13','m12','m9','m1'], [], 'fam1', 1 ).
test( 't16', 14, [], [], 'fam1', 1 ).
test( 't17', 381, [], [], 'fam1', 1 ).
test( 't18', 57, [], [], 'fam1', 1 ).
test( 't19', 671, ['m1','m17','m4'], [], 'fam1', 1 ).
test( 't20', 748, [], [], 'fam1', 1 ).
test( 't21', 330, [], ['r2','r1','r4','r3','r5'], 'fam1', 1 ).
test( 't22', 7, [], ['r2','r4','r1'], 'fam1', 1 ).
test( 't23', 496, [], ['r2'], 'fam1', 1 ).
test( 't24', 320, [], [], 'fam1', 1 ).
test( 't25', 229, [], ['r2','r5','r4','r3'], 'fam1', 1 ).
test( 't26', 117, [], [], 'fam1', 1 ).
test( 't27', 392, [], ['r3','r1','r2','r5'], 'fam1', 1 ).
test( 't28', 58, [], [], 'fam1', 1 ).
test( 't29', 615, ['m4','m12','m15','m13','m7'], ['r5','r1','r4','r3','r2'], 'fam1', 1 ).
test( 't30', 177, [], [], 'fam1', 1 ).
test( 't31', 185, [], [], 'fam1', 1 ).
test( 't32', 281, [], [], 'fam1', 1 ).
test( 't33', 492, [], [], 'fam1', 1 ).
test( 't34', 574, [], ['r3'], 'fam1', 1 ).
test( 't35', 788, [], [], 'fam1', 1 ).
test( 't36', 391, ['m6','m14','m4','m10','m20'], [], 'fam1', 1 ).
test( 't37', 216, [], [], 'fam1', 1 ).
test( 't38', 520, [], [], 'fam1', 1 ).
test( 't39', 179, [], [], 'fam1', 1 ).
test( 't40', 649, [], ['r3'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
