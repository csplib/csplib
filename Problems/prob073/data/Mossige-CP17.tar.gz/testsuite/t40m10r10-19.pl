%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 10
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 440, [], [], 'fam1', 1 ).
test( 't2', 633, ['m2'], [], 'fam1', 1 ).
test( 't3', 528, ['m7','m3'], [], 'fam1', 1 ).
test( 't4', 752, [], ['r2','r5','r3'], 'fam1', 1 ).
test( 't5', 205, ['m8','m5','m3','m7'], [], 'fam1', 1 ).
test( 't6', 784, ['m9','m6'], [], 'fam1', 1 ).
test( 't7', 437, ['m8','m10'], [], 'fam1', 1 ).
test( 't8', 758, [], [], 'fam1', 1 ).
test( 't9', 284, [], [], 'fam1', 1 ).
test( 't10', 480, [], ['r7','r1','r2','r6','r8','r5','r3','r4'], 'fam1', 1 ).
test( 't11', 315, [], [], 'fam1', 1 ).
test( 't12', 539, [], [], 'fam1', 1 ).
test( 't13', 662, [], [], 'fam1', 1 ).
test( 't14', 719, [], ['r4','r1'], 'fam1', 1 ).
test( 't15', 440, [], [], 'fam1', 1 ).
test( 't16', 217, [], ['r5','r9','r8','r7','r2','r1','r4','r3'], 'fam1', 1 ).
test( 't17', 199, ['m8','m6','m4','m2'], [], 'fam1', 1 ).
test( 't18', 80, ['m4','m6','m10','m7'], ['r1','r4','r5','r6','r7','r3','r9','r2','r8','r10'], 'fam1', 1 ).
test( 't19', 288, [], [], 'fam1', 1 ).
test( 't20', 530, [], [], 'fam1', 1 ).
test( 't21', 695, [], [], 'fam1', 1 ).
test( 't22', 74, [], [], 'fam1', 1 ).
test( 't23', 646, ['m10','m8','m1','m6'], [], 'fam1', 1 ).
test( 't24', 408, [], ['r2','r9','r7','r10','r4','r8','r1'], 'fam1', 1 ).
test( 't25', 599, [], ['r4','r9','r6','r1','r2','r10','r3'], 'fam1', 1 ).
test( 't26', 176, [], [], 'fam1', 1 ).
test( 't27', 140, [], [], 'fam1', 1 ).
test( 't28', 736, [], [], 'fam1', 1 ).
test( 't29', 221, [], [], 'fam1', 1 ).
test( 't30', 563, [], [], 'fam1', 1 ).
test( 't31', 221, [], [], 'fam1', 1 ).
test( 't32', 282, ['m3','m9'], ['r6'], 'fam1', 1 ).
test( 't33', 466, ['m9','m3'], ['r10','r7','r4','r8','r9','r3','r5','r6','r2','r1'], 'fam1', 1 ).
test( 't34', 725, ['m1','m2','m10','m8'], [], 'fam1', 1 ).
test( 't35', 255, [], [], 'fam1', 1 ).
test( 't36', 93, [], ['r1','r2','r5','r3','r8','r9','r4','r7'], 'fam1', 1 ).
test( 't37', 598, [], [], 'fam1', 1 ).
test( 't38', 86, [], ['r2','r8','r1','r7','r3'], 'fam1', 1 ).
test( 't39', 317, [], [], 'fam1', 1 ).
test( 't40', 649, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
