%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 208, [], [], 'fam1', 1 ).
test( 't2', 139, [], [], 'fam1', 1 ).
test( 't3', 573, [], ['r3','r2','r5','r1'], 'fam1', 1 ).
test( 't4', 283, ['m4','m2','m5'], [], 'fam1', 1 ).
test( 't5', 416, [], ['r4'], 'fam1', 1 ).
test( 't6', 432, ['m5'], [], 'fam1', 1 ).
test( 't7', 607, [], ['r2','r5','r3','r4'], 'fam1', 1 ).
test( 't8', 392, ['m7','m1','m5','m8'], ['r2','r4','r1'], 'fam1', 1 ).
test( 't9', 86, ['m10','m3','m4'], [], 'fam1', 1 ).
test( 't10', 564, [], [], 'fam1', 1 ).
test( 't11', 89, ['m6'], [], 'fam1', 1 ).
test( 't12', 35, [], ['r4','r2','r5','r1','r3'], 'fam1', 1 ).
test( 't13', 267, [], [], 'fam1', 1 ).
test( 't14', 795, [], ['r1','r4','r5','r3'], 'fam1', 1 ).
test( 't15', 646, [], ['r2','r1','r4'], 'fam1', 1 ).
test( 't16', 387, [], [], 'fam1', 1 ).
test( 't17', 684, [], [], 'fam1', 1 ).
test( 't18', 351, ['m10'], [], 'fam1', 1 ).
test( 't19', 19, [], ['r2','r4','r3','r1'], 'fam1', 1 ).
test( 't20', 129, [], [], 'fam1', 1 ).
test( 't21', 344, ['m9','m1','m7','m5'], [], 'fam1', 1 ).
test( 't22', 171, [], [], 'fam1', 1 ).
test( 't23', 161, [], ['r5'], 'fam1', 1 ).
test( 't24', 144, [], ['r3','r4','r5','r2'], 'fam1', 1 ).
test( 't25', 548, ['m9','m8','m1'], [], 'fam1', 1 ).
test( 't26', 591, [], [], 'fam1', 1 ).
test( 't27', 707, [], [], 'fam1', 1 ).
test( 't28', 261, [], ['r4','r3','r5','r2'], 'fam1', 1 ).
test( 't29', 87, [], [], 'fam1', 1 ).
test( 't30', 486, [], [], 'fam1', 1 ).
test( 't31', 711, [], [], 'fam1', 1 ).
test( 't32', 407, ['m10','m6','m8'], ['r4'], 'fam1', 1 ).
test( 't33', 522, [], [], 'fam1', 1 ).
test( 't34', 74, [], [], 'fam1', 1 ).
test( 't35', 26, [], [], 'fam1', 1 ).
test( 't36', 267, ['m3'], ['r2','r4','r5','r1'], 'fam1', 1 ).
test( 't37', 331, ['m8'], [], 'fam1', 1 ).
test( 't38', 250, ['m8','m7'], [], 'fam1', 1 ).
test( 't39', 611, [], [], 'fam1', 1 ).
test( 't40', 683, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
