%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 772, [], [], 'fam1', 1 ).
test( 't2', 186, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't3', 565, ['m3','m8'], [], 'fam1', 1 ).
test( 't4', 642, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't5', 297, [], ['r2'], 'fam1', 1 ).
test( 't6', 702, [], ['r3','r1'], 'fam1', 1 ).
test( 't7', 635, [], [], 'fam1', 1 ).
test( 't8', 474, [], [], 'fam1', 1 ).
test( 't9', 648, [], [], 'fam1', 1 ).
test( 't10', 90, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't11', 536, [], [], 'fam1', 1 ).
test( 't12', 318, [], [], 'fam1', 1 ).
test( 't13', 276, [], [], 'fam1', 1 ).
test( 't14', 62, [], [], 'fam1', 1 ).
test( 't15', 712, [], ['r2'], 'fam1', 1 ).
test( 't16', 407, ['m4'], [], 'fam1', 1 ).
test( 't17', 664, ['m8','m7','m10','m1'], [], 'fam1', 1 ).
test( 't18', 649, [], [], 'fam1', 1 ).
test( 't19', 32, [], [], 'fam1', 1 ).
test( 't20', 454, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't21', 517, [], ['r1','r2'], 'fam1', 1 ).
test( 't22', 731, [], [], 'fam1', 1 ).
test( 't23', 494, [], [], 'fam1', 1 ).
test( 't24', 618, [], [], 'fam1', 1 ).
test( 't25', 404, [], [], 'fam1', 1 ).
test( 't26', 785, [], [], 'fam1', 1 ).
test( 't27', 87, [], [], 'fam1', 1 ).
test( 't28', 308, ['m6','m1','m4'], [], 'fam1', 1 ).
test( 't29', 342, [], [], 'fam1', 1 ).
test( 't30', 352, [], [], 'fam1', 1 ).
test( 't31', 672, [], [], 'fam1', 1 ).
test( 't32', 644, [], [], 'fam1', 1 ).
test( 't33', 557, [], [], 'fam1', 1 ).
test( 't34', 237, ['m6','m10'], [], 'fam1', 1 ).
test( 't35', 622, [], [], 'fam1', 1 ).
test( 't36', 671, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't37', 613, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't38', 743, [], [], 'fam1', 1 ).
test( 't39', 129, [], [], 'fam1', 1 ).
test( 't40', 237, ['m3','m7','m10','m6'], [], 'fam1', 1 ).
test( 't41', 782, [], [], 'fam1', 1 ).
test( 't42', 791, [], [], 'fam1', 1 ).
test( 't43', 404, [], ['r1'], 'fam1', 1 ).
test( 't44', 462, [], [], 'fam1', 1 ).
test( 't45', 750, [], [], 'fam1', 1 ).
test( 't46', 717, [], [], 'fam1', 1 ).
test( 't47', 548, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't48', 790, [], [], 'fam1', 1 ).
test( 't49', 663, [], ['r3'], 'fam1', 1 ).
test( 't50', 115, [], ['r3','r2','r1'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
