%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 208, [], ['r3','r2'], 'fam1', 1 ).
test( 't2', 460, [], [], 'fam1', 1 ).
test( 't3', 102, [], ['r1','r2'], 'fam1', 1 ).
test( 't4', 155, [], [], 'fam1', 1 ).
test( 't5', 174, [], [], 'fam1', 1 ).
test( 't6', 304, [], [], 'fam1', 1 ).
test( 't7', 182, [], [], 'fam1', 1 ).
test( 't8', 355, [], [], 'fam1', 1 ).
test( 't9', 87, [], [], 'fam1', 1 ).
test( 't10', 686, [], [], 'fam1', 1 ).
test( 't11', 720, [], [], 'fam1', 1 ).
test( 't12', 661, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't13', 171, [], [], 'fam1', 1 ).
test( 't14', 438, ['m8'], [], 'fam1', 1 ).
test( 't15', 25, [], [], 'fam1', 1 ).
test( 't16', 700, ['m3','m1','m2'], [], 'fam1', 1 ).
test( 't17', 206, [], ['r3','r2'], 'fam1', 1 ).
test( 't18', 720, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't19', 251, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't20', 646, [], [], 'fam1', 1 ).
test( 't21', 394, [], [], 'fam1', 1 ).
test( 't22', 15, [], ['r3','r2'], 'fam1', 1 ).
test( 't23', 401, ['m5','m6'], [], 'fam1', 1 ).
test( 't24', 594, [], ['r2','r3'], 'fam1', 1 ).
test( 't25', 418, [], [], 'fam1', 1 ).
test( 't26', 455, ['m4','m7','m10','m5'], ['r1','r2','r3'], 'fam1', 1 ).
test( 't27', 483, [], [], 'fam1', 1 ).
test( 't28', 677, [], [], 'fam1', 1 ).
test( 't29', 685, [], [], 'fam1', 1 ).
test( 't30', 30, [], ['r1','r2'], 'fam1', 1 ).
test( 't31', 269, ['m5','m2'], [], 'fam1', 1 ).
test( 't32', 258, ['m9','m4','m7'], [], 'fam1', 1 ).
test( 't33', 116, [], [], 'fam1', 1 ).
test( 't34', 400, [], [], 'fam1', 1 ).
test( 't35', 540, [], ['r1'], 'fam1', 1 ).
test( 't36', 176, [], [], 'fam1', 1 ).
test( 't37', 562, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't38', 751, ['m6','m7'], [], 'fam1', 1 ).
test( 't39', 26, [], [], 'fam1', 1 ).
test( 't40', 724, [], ['r2'], 'fam1', 1 ).
test( 't41', 662, ['m9','m4','m7','m6'], ['r2'], 'fam1', 1 ).
test( 't42', 417, ['m6','m9','m7','m3'], [], 'fam1', 1 ).
test( 't43', 499, [], [], 'fam1', 1 ).
test( 't44', 766, [], [], 'fam1', 1 ).
test( 't45', 642, [], [], 'fam1', 1 ).
test( 't46', 349, [], [], 'fam1', 1 ).
test( 't47', 330, [], ['r1','r2'], 'fam1', 1 ).
test( 't48', 160, ['m10'], ['r1','r2','r3'], 'fam1', 1 ).
test( 't49', 509, [], [], 'fam1', 1 ).
test( 't50', 760, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
