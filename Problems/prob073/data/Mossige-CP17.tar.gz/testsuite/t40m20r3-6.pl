%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 20
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 571, [], [], 'fam1', 1 ).
test( 't2', 21, [], [], 'fam1', 1 ).
test( 't3', 37, [], [], 'fam1', 1 ).
test( 't4', 718, [], [], 'fam1', 1 ).
test( 't5', 171, [], [], 'fam1', 1 ).
test( 't6', 36, ['m17'], [], 'fam1', 1 ).
test( 't7', 554, [], [], 'fam1', 1 ).
test( 't8', 34, ['m5','m8','m17','m19','m18'], ['r2'], 'fam1', 1 ).
test( 't9', 439, [], ['r2'], 'fam1', 1 ).
test( 't10', 500, ['m7','m9','m16','m3'], [], 'fam1', 1 ).
test( 't11', 174, [], [], 'fam1', 1 ).
test( 't12', 767, [], [], 'fam1', 1 ).
test( 't13', 19, [], [], 'fam1', 1 ).
test( 't14', 709, [], ['r1','r3'], 'fam1', 1 ).
test( 't15', 518, [], [], 'fam1', 1 ).
test( 't16', 208, [], [], 'fam1', 1 ).
test( 't17', 731, [], [], 'fam1', 1 ).
test( 't18', 439, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't19', 27, [], [], 'fam1', 1 ).
test( 't20', 284, [], [], 'fam1', 1 ).
test( 't21', 261, [], [], 'fam1', 1 ).
test( 't22', 178, [], [], 'fam1', 1 ).
test( 't23', 342, [], ['r3','r1'], 'fam1', 1 ).
test( 't24', 409, [], [], 'fam1', 1 ).
test( 't25', 391, ['m3','m18','m12'], [], 'fam1', 1 ).
test( 't26', 96, [], [], 'fam1', 1 ).
test( 't27', 76, [], [], 'fam1', 1 ).
test( 't28', 748, [], [], 'fam1', 1 ).
test( 't29', 210, [], [], 'fam1', 1 ).
test( 't30', 348, ['m16','m5'], ['r3','r2'], 'fam1', 1 ).
test( 't31', 464, [], [], 'fam1', 1 ).
test( 't32', 633, [], [], 'fam1', 1 ).
test( 't33', 521, [], ['r1'], 'fam1', 1 ).
test( 't34', 440, [], [], 'fam1', 1 ).
test( 't35', 661, [], [], 'fam1', 1 ).
test( 't36', 107, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't37', 772, ['m2','m18','m19','m5','m7','m4'], [], 'fam1', 1 ).
test( 't38', 700, [], [], 'fam1', 1 ).
test( 't39', 361, [], [], 'fam1', 1 ).
test( 't40', 543, [], ['r3'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
