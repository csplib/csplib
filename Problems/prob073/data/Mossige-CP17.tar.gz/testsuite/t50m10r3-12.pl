%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 671, [], [], 'fam1', 1 ).
test( 't2', 336, ['m8'], [], 'fam1', 1 ).
test( 't3', 143, [], [], 'fam1', 1 ).
test( 't4', 615, ['m1','m4','m7','m5'], [], 'fam1', 1 ).
test( 't5', 609, [], [], 'fam1', 1 ).
test( 't6', 134, [], [], 'fam1', 1 ).
test( 't7', 226, ['m1'], [], 'fam1', 1 ).
test( 't8', 418, [], ['r1'], 'fam1', 1 ).
test( 't9', 464, [], ['r3','r1'], 'fam1', 1 ).
test( 't10', 343, [], [], 'fam1', 1 ).
test( 't11', 34, [], ['r3'], 'fam1', 1 ).
test( 't12', 137, [], [], 'fam1', 1 ).
test( 't13', 327, [], [], 'fam1', 1 ).
test( 't14', 82, [], [], 'fam1', 1 ).
test( 't15', 400, [], [], 'fam1', 1 ).
test( 't16', 733, [], [], 'fam1', 1 ).
test( 't17', 520, [], [], 'fam1', 1 ).
test( 't18', 28, [], ['r1'], 'fam1', 1 ).
test( 't19', 29, [], [], 'fam1', 1 ).
test( 't20', 789, [], [], 'fam1', 1 ).
test( 't21', 796, [], [], 'fam1', 1 ).
test( 't22', 440, [], [], 'fam1', 1 ).
test( 't23', 316, [], [], 'fam1', 1 ).
test( 't24', 281, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't25', 452, [], [], 'fam1', 1 ).
test( 't26', 37, [], [], 'fam1', 1 ).
test( 't27', 734, [], [], 'fam1', 1 ).
test( 't28', 576, [], ['r3','r1'], 'fam1', 1 ).
test( 't29', 290, [], [], 'fam1', 1 ).
test( 't30', 499, ['m4','m3'], [], 'fam1', 1 ).
test( 't31', 582, [], [], 'fam1', 1 ).
test( 't32', 470, [], [], 'fam1', 1 ).
test( 't33', 268, [], [], 'fam1', 1 ).
test( 't34', 533, [], [], 'fam1', 1 ).
test( 't35', 18, [], [], 'fam1', 1 ).
test( 't36', 361, [], [], 'fam1', 1 ).
test( 't37', 239, [], ['r3','r2'], 'fam1', 1 ).
test( 't38', 235, [], ['r2'], 'fam1', 1 ).
test( 't39', 149, ['m5','m4'], [], 'fam1', 1 ).
test( 't40', 243, [], [], 'fam1', 1 ).
test( 't41', 528, [], ['r1','r2'], 'fam1', 1 ).
test( 't42', 571, [], [], 'fam1', 1 ).
test( 't43', 194, [], [], 'fam1', 1 ).
test( 't44', 317, [], [], 'fam1', 1 ).
test( 't45', 201, [], [], 'fam1', 1 ).
test( 't46', 765, [], [], 'fam1', 1 ).
test( 't47', 92, [], [], 'fam1', 1 ).
test( 't48', 591, [], [], 'fam1', 1 ).
test( 't49', 697, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't50', 71, [], ['r2','r3','r1'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
