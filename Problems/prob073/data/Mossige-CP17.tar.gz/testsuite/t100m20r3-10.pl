%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 20
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 434, [], [], 'fam1', 1 ).
test( 't2', 588, [], ['r3'], 'fam1', 1 ).
test( 't3', 475, [], [], 'fam1', 1 ).
test( 't4', 323, [], ['r3'], 'fam1', 1 ).
test( 't5', 490, ['m3'], [], 'fam1', 1 ).
test( 't6', 495, [], [], 'fam1', 1 ).
test( 't7', 1, ['m3','m8'], [], 'fam1', 1 ).
test( 't8', 773, [], ['r1','r3'], 'fam1', 1 ).
test( 't9', 522, [], [], 'fam1', 1 ).
test( 't10', 190, ['m9','m11'], [], 'fam1', 1 ).
test( 't11', 353, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't12', 256, ['m9','m8','m4'], [], 'fam1', 1 ).
test( 't13', 134, [], ['r2'], 'fam1', 1 ).
test( 't14', 224, ['m11','m8','m13','m7','m1','m18','m2','m12'], [], 'fam1', 1 ).
test( 't15', 497, [], [], 'fam1', 1 ).
test( 't16', 25, [], [], 'fam1', 1 ).
test( 't17', 391, [], [], 'fam1', 1 ).
test( 't18', 758, [], [], 'fam1', 1 ).
test( 't19', 767, [], ['r3'], 'fam1', 1 ).
test( 't20', 338, [], [], 'fam1', 1 ).
test( 't21', 318, [], [], 'fam1', 1 ).
test( 't22', 730, [], [], 'fam1', 1 ).
test( 't23', 494, [], [], 'fam1', 1 ).
test( 't24', 448, [], [], 'fam1', 1 ).
test( 't25', 709, ['m17','m4','m5','m13'], [], 'fam1', 1 ).
test( 't26', 54, ['m1','m6','m10','m5'], ['r1'], 'fam1', 1 ).
test( 't27', 218, [], [], 'fam1', 1 ).
test( 't28', 665, [], [], 'fam1', 1 ).
test( 't29', 698, [], [], 'fam1', 1 ).
test( 't30', 754, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't31', 335, [], [], 'fam1', 1 ).
test( 't32', 685, ['m14','m6','m1','m11','m19','m12','m9','m10'], [], 'fam1', 1 ).
test( 't33', 526, [], [], 'fam1', 1 ).
test( 't34', 783, [], [], 'fam1', 1 ).
test( 't35', 459, [], [], 'fam1', 1 ).
test( 't36', 61, [], [], 'fam1', 1 ).
test( 't37', 795, [], [], 'fam1', 1 ).
test( 't38', 269, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't39', 796, [], [], 'fam1', 1 ).
test( 't40', 436, ['m13'], [], 'fam1', 1 ).
test( 't41', 97, [], [], 'fam1', 1 ).
test( 't42', 768, [], [], 'fam1', 1 ).
test( 't43', 50, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't44', 174, ['m4','m2','m13','m8','m19','m9','m6','m15'], [], 'fam1', 1 ).
test( 't45', 692, [], [], 'fam1', 1 ).
test( 't46', 240, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't47', 761, ['m19','m2','m1'], [], 'fam1', 1 ).
test( 't48', 111, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't49', 770, [], [], 'fam1', 1 ).
test( 't50', 684, [], [], 'fam1', 1 ).
test( 't51', 377, [], ['r3'], 'fam1', 1 ).
test( 't52', 548, [], [], 'fam1', 1 ).
test( 't53', 223, ['m6','m18','m14','m16','m2','m12','m9','m8'], [], 'fam1', 1 ).
test( 't54', 152, ['m13','m2','m8','m16','m4','m15','m19','m10'], ['r2'], 'fam1', 1 ).
test( 't55', 339, [], [], 'fam1', 1 ).
test( 't56', 179, [], ['r2','r1'], 'fam1', 1 ).
test( 't57', 318, [], [], 'fam1', 1 ).
test( 't58', 433, ['m18','m8','m17','m7','m19'], [], 'fam1', 1 ).
test( 't59', 177, [], ['r2','r3'], 'fam1', 1 ).
test( 't60', 494, [], [], 'fam1', 1 ).
test( 't61', 341, [], [], 'fam1', 1 ).
test( 't62', 706, [], ['r2','r1'], 'fam1', 1 ).
test( 't63', 347, [], [], 'fam1', 1 ).
test( 't64', 294, [], [], 'fam1', 1 ).
test( 't65', 564, [], ['r1','r3'], 'fam1', 1 ).
test( 't66', 605, [], [], 'fam1', 1 ).
test( 't67', 50, [], [], 'fam1', 1 ).
test( 't68', 265, ['m9','m17','m4'], ['r3','r1'], 'fam1', 1 ).
test( 't69', 38, [], [], 'fam1', 1 ).
test( 't70', 341, [], [], 'fam1', 1 ).
test( 't71', 695, [], [], 'fam1', 1 ).
test( 't72', 372, [], [], 'fam1', 1 ).
test( 't73', 616, ['m13','m15','m8','m17','m14','m1'], ['r1','r2','r3'], 'fam1', 1 ).
test( 't74', 258, ['m7'], ['r1','r2','r3'], 'fam1', 1 ).
test( 't75', 459, [], [], 'fam1', 1 ).
test( 't76', 193, [], [], 'fam1', 1 ).
test( 't77', 720, [], [], 'fam1', 1 ).
test( 't78', 549, [], [], 'fam1', 1 ).
test( 't79', 208, [], [], 'fam1', 1 ).
test( 't80', 719, [], ['r1','r3'], 'fam1', 1 ).
test( 't81', 523, [], [], 'fam1', 1 ).
test( 't82', 425, [], ['r3','r2'], 'fam1', 1 ).
test( 't83', 312, [], [], 'fam1', 1 ).
test( 't84', 312, [], [], 'fam1', 1 ).
test( 't85', 639, [], [], 'fam1', 1 ).
test( 't86', 749, [], [], 'fam1', 1 ).
test( 't87', 747, [], [], 'fam1', 1 ).
test( 't88', 404, [], [], 'fam1', 1 ).
test( 't89', 712, [], [], 'fam1', 1 ).
test( 't90', 75, ['m16','m12','m9','m1','m8','m14'], [], 'fam1', 1 ).
test( 't91', 203, [], [], 'fam1', 1 ).
test( 't92', 663, [], [], 'fam1', 1 ).
test( 't93', 795, [], [], 'fam1', 1 ).
test( 't94', 31, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't95', 394, ['m13','m19','m10'], ['r1'], 'fam1', 1 ).
test( 't96', 754, [], [], 'fam1', 1 ).
test( 't97', 647, ['m2','m18','m5','m6','m17','m3'], ['r1','r3','r2'], 'fam1', 1 ).
test( 't98', 222, [], [], 'fam1', 1 ).
test( 't99', 536, [], [], 'fam1', 1 ).
test( 't100', 228, ['m8','m14','m11','m10','m15','m19','m13','m6'], ['r3'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
