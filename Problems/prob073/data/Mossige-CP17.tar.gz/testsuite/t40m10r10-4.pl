%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 10
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 423, [], [], 'fam1', 1 ).
test( 't2', 645, [], [], 'fam1', 1 ).
test( 't3', 180, [], ['r7','r4','r6','r9','r3','r5','r10'], 'fam1', 1 ).
test( 't4', 204, [], ['r2','r6','r1','r7','r10','r8','r4','r5','r3'], 'fam1', 1 ).
test( 't5', 650, [], [], 'fam1', 1 ).
test( 't6', 396, [], [], 'fam1', 1 ).
test( 't7', 449, [], [], 'fam1', 1 ).
test( 't8', 368, [], [], 'fam1', 1 ).
test( 't9', 310, [], [], 'fam1', 1 ).
test( 't10', 708, [], ['r10','r2','r9','r3','r8','r6','r5','r4','r1','r7'], 'fam1', 1 ).
test( 't11', 126, [], [], 'fam1', 1 ).
test( 't12', 295, [], [], 'fam1', 1 ).
test( 't13', 219, ['m9','m1','m5'], ['r9','r1','r2','r5','r4','r8','r10'], 'fam1', 1 ).
test( 't14', 417, ['m2','m1'], [], 'fam1', 1 ).
test( 't15', 594, [], [], 'fam1', 1 ).
test( 't16', 491, [], [], 'fam1', 1 ).
test( 't17', 765, ['m1','m3','m7'], [], 'fam1', 1 ).
test( 't18', 160, [], [], 'fam1', 1 ).
test( 't19', 497, [], [], 'fam1', 1 ).
test( 't20', 633, [], [], 'fam1', 1 ).
test( 't21', 650, [], ['r10','r7','r3','r9','r1'], 'fam1', 1 ).
test( 't22', 465, [], [], 'fam1', 1 ).
test( 't23', 139, [], ['r7','r2','r4','r3','r10','r5','r1','r9'], 'fam1', 1 ).
test( 't24', 114, [], ['r5','r4','r10','r2','r3','r7','r9','r8','r6'], 'fam1', 1 ).
test( 't25', 592, [], ['r4'], 'fam1', 1 ).
test( 't26', 412, [], [], 'fam1', 1 ).
test( 't27', 405, [], [], 'fam1', 1 ).
test( 't28', 381, [], [], 'fam1', 1 ).
test( 't29', 770, [], [], 'fam1', 1 ).
test( 't30', 530, [], [], 'fam1', 1 ).
test( 't31', 520, [], ['r9','r8','r7','r3','r4','r10','r5','r6','r1','r2'], 'fam1', 1 ).
test( 't32', 241, ['m7','m4'], [], 'fam1', 1 ).
test( 't33', 54, [], [], 'fam1', 1 ).
test( 't34', 161, [], [], 'fam1', 1 ).
test( 't35', 19, [], [], 'fam1', 1 ).
test( 't36', 342, [], [], 'fam1', 1 ).
test( 't37', 6, [], [], 'fam1', 1 ).
test( 't38', 684, [], [], 'fam1', 1 ).
test( 't39', 558, [], [], 'fam1', 1 ).
test( 't40', 738, ['m1','m9'], ['r4'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
