%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 640, [], [], 'fam1', 1 ).
test( 't2', 737, ['m1','m4','m9','m7'], [], 'fam1', 1 ).
test( 't3', 261, [], ['r5','r1','r3'], 'fam1', 1 ).
test( 't4', 476, [], [], 'fam1', 1 ).
test( 't5', 89, [], ['r3','r2','r5','r1'], 'fam1', 1 ).
test( 't6', 676, [], [], 'fam1', 1 ).
test( 't7', 754, [], ['r5'], 'fam1', 1 ).
test( 't8', 461, [], ['r1','r5','r3','r2','r4'], 'fam1', 1 ).
test( 't9', 158, ['m9','m6','m10'], [], 'fam1', 1 ).
test( 't10', 79, [], [], 'fam1', 1 ).
test( 't11', 329, ['m7','m6'], [], 'fam1', 1 ).
test( 't12', 238, [], [], 'fam1', 1 ).
test( 't13', 523, [], [], 'fam1', 1 ).
test( 't14', 171, ['m2'], [], 'fam1', 1 ).
test( 't15', 711, [], ['r1','r4','r2','r5','r3'], 'fam1', 1 ).
test( 't16', 107, [], [], 'fam1', 1 ).
test( 't17', 352, [], [], 'fam1', 1 ).
test( 't18', 41, [], [], 'fam1', 1 ).
test( 't19', 628, [], ['r3','r1','r4'], 'fam1', 1 ).
test( 't20', 9, [], [], 'fam1', 1 ).
test( 't21', 741, [], [], 'fam1', 1 ).
test( 't22', 772, [], [], 'fam1', 1 ).
test( 't23', 727, [], ['r5','r2','r4'], 'fam1', 1 ).
test( 't24', 307, ['m3'], [], 'fam1', 1 ).
test( 't25', 156, [], [], 'fam1', 1 ).
test( 't26', 693, [], ['r3','r5','r4','r1','r2'], 'fam1', 1 ).
test( 't27', 597, ['m9','m1','m3','m8'], ['r2','r1','r4','r5'], 'fam1', 1 ).
test( 't28', 704, ['m10','m8'], [], 'fam1', 1 ).
test( 't29', 348, [], ['r1','r3'], 'fam1', 1 ).
test( 't30', 217, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
