%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 195, [], ['r1'], 'fam1', 1 ).
test( 't2', 646, [], [], 'fam1', 1 ).
test( 't3', 650, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't4', 85, [], [], 'fam1', 1 ).
test( 't5', 432, [], ['r1','r2'], 'fam1', 1 ).
test( 't6', 246, ['m2','m6','m4','m1'], ['r3'], 'fam1', 1 ).
test( 't7', 18, [], [], 'fam1', 1 ).
test( 't8', 362, [], [], 'fam1', 1 ).
test( 't9', 646, [], [], 'fam1', 1 ).
test( 't10', 365, [], [], 'fam1', 1 ).
test( 't11', 177, [], [], 'fam1', 1 ).
test( 't12', 245, [], [], 'fam1', 1 ).
test( 't13', 761, [], [], 'fam1', 1 ).
test( 't14', 77, [], [], 'fam1', 1 ).
test( 't15', 673, ['m9','m6'], [], 'fam1', 1 ).
test( 't16', 359, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't17', 793, ['m2','m10','m9','m6'], [], 'fam1', 1 ).
test( 't18', 157, [], [], 'fam1', 1 ).
test( 't19', 787, [], [], 'fam1', 1 ).
test( 't20', 34, [], ['r1','r3'], 'fam1', 1 ).
test( 't21', 335, [], [], 'fam1', 1 ).
test( 't22', 577, ['m7','m5'], [], 'fam1', 1 ).
test( 't23', 267, ['m3','m8','m4','m6'], [], 'fam1', 1 ).
test( 't24', 543, [], ['r3','r1'], 'fam1', 1 ).
test( 't25', 444, [], [], 'fam1', 1 ).
test( 't26', 445, [], [], 'fam1', 1 ).
test( 't27', 350, ['m10'], [], 'fam1', 1 ).
test( 't28', 492, [], [], 'fam1', 1 ).
test( 't29', 801, ['m5','m2','m3','m10'], [], 'fam1', 1 ).
test( 't30', 378, [], [], 'fam1', 1 ).
test( 't31', 712, [], [], 'fam1', 1 ).
test( 't32', 264, [], ['r2','r3'], 'fam1', 1 ).
test( 't33', 148, [], [], 'fam1', 1 ).
test( 't34', 276, [], [], 'fam1', 1 ).
test( 't35', 381, [], [], 'fam1', 1 ).
test( 't36', 690, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't37', 433, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't38', 156, [], [], 'fam1', 1 ).
test( 't39', 138, [], [], 'fam1', 1 ).
test( 't40', 743, [], [], 'fam1', 1 ).
test( 't41', 3, [], [], 'fam1', 1 ).
test( 't42', 699, ['m9','m8'], [], 'fam1', 1 ).
test( 't43', 632, [], [], 'fam1', 1 ).
test( 't44', 75, [], [], 'fam1', 1 ).
test( 't45', 353, ['m1','m8','m9','m3'], [], 'fam1', 1 ).
test( 't46', 716, [], [], 'fam1', 1 ).
test( 't47', 210, ['m2','m4','m9'], [], 'fam1', 1 ).
test( 't48', 707, [], ['r1'], 'fam1', 1 ).
test( 't49', 322, [], ['r3','r2'], 'fam1', 1 ).
test( 't50', 364, [], ['r3'], 'fam1', 1 ).
test( 't51', 131, [], [], 'fam1', 1 ).
test( 't52', 445, [], [], 'fam1', 1 ).
test( 't53', 595, [], [], 'fam1', 1 ).
test( 't54', 715, [], [], 'fam1', 1 ).
test( 't55', 716, [], [], 'fam1', 1 ).
test( 't56', 639, [], [], 'fam1', 1 ).
test( 't57', 112, [], ['r2','r3'], 'fam1', 1 ).
test( 't58', 742, ['m10','m2','m4'], ['r1'], 'fam1', 1 ).
test( 't59', 112, [], ['r3'], 'fam1', 1 ).
test( 't60', 86, ['m6'], [], 'fam1', 1 ).
test( 't61', 289, [], [], 'fam1', 1 ).
test( 't62', 291, [], ['r3'], 'fam1', 1 ).
test( 't63', 430, [], [], 'fam1', 1 ).
test( 't64', 302, [], [], 'fam1', 1 ).
test( 't65', 197, [], [], 'fam1', 1 ).
test( 't66', 230, [], [], 'fam1', 1 ).
test( 't67', 315, ['m1','m5','m4','m8'], [], 'fam1', 1 ).
test( 't68', 206, [], [], 'fam1', 1 ).
test( 't69', 439, ['m8','m2'], [], 'fam1', 1 ).
test( 't70', 697, ['m4','m6','m3'], [], 'fam1', 1 ).
test( 't71', 535, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't72', 396, [], [], 'fam1', 1 ).
test( 't73', 550, [], [], 'fam1', 1 ).
test( 't74', 775, [], [], 'fam1', 1 ).
test( 't75', 795, [], [], 'fam1', 1 ).
test( 't76', 60, [], [], 'fam1', 1 ).
test( 't77', 593, [], [], 'fam1', 1 ).
test( 't78', 646, [], ['r3'], 'fam1', 1 ).
test( 't79', 388, [], ['r3'], 'fam1', 1 ).
test( 't80', 417, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't81', 657, [], ['r2'], 'fam1', 1 ).
test( 't82', 130, [], [], 'fam1', 1 ).
test( 't83', 691, [], [], 'fam1', 1 ).
test( 't84', 741, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't85', 779, [], [], 'fam1', 1 ).
test( 't86', 261, [], [], 'fam1', 1 ).
test( 't87', 222, [], ['r2'], 'fam1', 1 ).
test( 't88', 65, [], [], 'fam1', 1 ).
test( 't89', 54, [], [], 'fam1', 1 ).
test( 't90', 481, [], [], 'fam1', 1 ).
test( 't91', 664, [], ['r2','r1'], 'fam1', 1 ).
test( 't92', 684, [], [], 'fam1', 1 ).
test( 't93', 693, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't94', 246, [], [], 'fam1', 1 ).
test( 't95', 42, ['m1','m3','m9'], ['r2'], 'fam1', 1 ).
test( 't96', 189, [], [], 'fam1', 1 ).
test( 't97', 38, [], [], 'fam1', 1 ).
test( 't98', 345, [], [], 'fam1', 1 ).
test( 't99', 424, [], [], 'fam1', 1 ).
test( 't100', 92, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
