%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 10
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 307, [], ['r8','r3','r2','r5','r1','r7','r4','r6','r9'], 'fam1', 1 ).
test( 't2', 95, ['m5','m10'], ['r8','r2','r6','r1','r4','r7','r10','r5','r3','r9'], 'fam1', 1 ).
test( 't3', 607, ['m4','m1','m8','m10'], [], 'fam1', 1 ).
test( 't4', 465, [], [], 'fam1', 1 ).
test( 't5', 666, [], [], 'fam1', 1 ).
test( 't6', 329, ['m1'], [], 'fam1', 1 ).
test( 't7', 75, [], ['r5','r10','r8'], 'fam1', 1 ).
test( 't8', 622, [], [], 'fam1', 1 ).
test( 't9', 597, ['m8'], ['r10','r7','r8','r3','r4','r2','r9','r6','r1'], 'fam1', 1 ).
test( 't10', 361, [], [], 'fam1', 1 ).
test( 't11', 16, [], [], 'fam1', 1 ).
test( 't12', 281, [], [], 'fam1', 1 ).
test( 't13', 337, [], [], 'fam1', 1 ).
test( 't14', 74, [], ['r6','r1','r5','r3','r4','r2','r8','r7','r9'], 'fam1', 1 ).
test( 't15', 409, [], [], 'fam1', 1 ).
test( 't16', 729, [], [], 'fam1', 1 ).
test( 't17', 220, [], [], 'fam1', 1 ).
test( 't18', 194, [], [], 'fam1', 1 ).
test( 't19', 421, ['m6','m10','m3','m8'], ['r6','r9'], 'fam1', 1 ).
test( 't20', 434, [], [], 'fam1', 1 ).
test( 't21', 15, [], ['r7','r1','r10'], 'fam1', 1 ).
test( 't22', 30, [], [], 'fam1', 1 ).
test( 't23', 71, [], ['r8','r4','r10','r6','r1','r7','r2','r3','r9'], 'fam1', 1 ).
test( 't24', 252, [], [], 'fam1', 1 ).
test( 't25', 235, [], [], 'fam1', 1 ).
test( 't26', 631, [], [], 'fam1', 1 ).
test( 't27', 660, ['m8','m1','m9','m10'], [], 'fam1', 1 ).
test( 't28', 1, [], ['r3'], 'fam1', 1 ).
test( 't29', 698, [], [], 'fam1', 1 ).
test( 't30', 140, [], [], 'fam1', 1 ).
test( 't31', 71, [], [], 'fam1', 1 ).
test( 't32', 381, [], [], 'fam1', 1 ).
test( 't33', 84, [], [], 'fam1', 1 ).
test( 't34', 507, [], [], 'fam1', 1 ).
test( 't35', 775, [], [], 'fam1', 1 ).
test( 't36', 540, [], [], 'fam1', 1 ).
test( 't37', 154, ['m9','m7','m3','m8'], [], 'fam1', 1 ).
test( 't38', 454, [], [], 'fam1', 1 ).
test( 't39', 653, [], [], 'fam1', 1 ).
test( 't40', 634, ['m7','m5','m2','m1'], ['r5','r6','r10','r2','r9','r7'], 'fam1', 1 ).
test( 't41', 359, [], [], 'fam1', 1 ).
test( 't42', 265, [], [], 'fam1', 1 ).
test( 't43', 146, [], [], 'fam1', 1 ).
test( 't44', 445, [], [], 'fam1', 1 ).
test( 't45', 328, [], [], 'fam1', 1 ).
test( 't46', 343, [], ['r3','r8','r7'], 'fam1', 1 ).
test( 't47', 520, [], [], 'fam1', 1 ).
test( 't48', 590, [], [], 'fam1', 1 ).
test( 't49', 487, [], [], 'fam1', 1 ).
test( 't50', 245, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
