%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 113, [], [], 'fam1', 1 ).
test( 't2', 44, [], [], 'fam1', 1 ).
test( 't3', 612, [], ['r2','r3'], 'fam1', 1 ).
test( 't4', 367, [], [], 'fam1', 1 ).
test( 't5', 397, ['m10','m6','m7','m1'], ['r1','r3'], 'fam1', 1 ).
test( 't6', 178, [], [], 'fam1', 1 ).
test( 't7', 423, [], ['r2','r1'], 'fam1', 1 ).
test( 't8', 612, [], ['r1'], 'fam1', 1 ).
test( 't9', 539, [], [], 'fam1', 1 ).
test( 't10', 711, [], ['r1'], 'fam1', 1 ).
test( 't11', 757, [], ['r1','r3'], 'fam1', 1 ).
test( 't12', 765, ['m5','m10','m8','m6'], [], 'fam1', 1 ).
test( 't13', 291, [], [], 'fam1', 1 ).
test( 't14', 693, [], [], 'fam1', 1 ).
test( 't15', 578, [], [], 'fam1', 1 ).
test( 't16', 417, ['m7','m6','m4'], [], 'fam1', 1 ).
test( 't17', 142, ['m4','m10','m9'], [], 'fam1', 1 ).
test( 't18', 498, [], ['r2'], 'fam1', 1 ).
test( 't19', 136, [], [], 'fam1', 1 ).
test( 't20', 35, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't21', 51, [], [], 'fam1', 1 ).
test( 't22', 587, [], [], 'fam1', 1 ).
test( 't23', 272, [], [], 'fam1', 1 ).
test( 't24', 42, [], [], 'fam1', 1 ).
test( 't25', 460, [], [], 'fam1', 1 ).
test( 't26', 486, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't27', 618, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't28', 573, [], [], 'fam1', 1 ).
test( 't29', 599, ['m9','m6','m1'], [], 'fam1', 1 ).
test( 't30', 185, [], ['r1'], 'fam1', 1 ).
test( 't31', 695, [], [], 'fam1', 1 ).
test( 't32', 243, [], [], 'fam1', 1 ).
test( 't33', 636, [], [], 'fam1', 1 ).
test( 't34', 454, [], [], 'fam1', 1 ).
test( 't35', 564, [], [], 'fam1', 1 ).
test( 't36', 451, [], ['r2'], 'fam1', 1 ).
test( 't37', 471, [], [], 'fam1', 1 ).
test( 't38', 637, [], ['r2','r1'], 'fam1', 1 ).
test( 't39', 41, ['m10','m2','m3','m4'], ['r3','r2','r1'], 'fam1', 1 ).
test( 't40', 185, [], [], 'fam1', 1 ).
test( 't41', 260, [], ['r2','r3'], 'fam1', 1 ).
test( 't42', 228, ['m6','m10','m7','m8'], [], 'fam1', 1 ).
test( 't43', 202, ['m7','m5','m4','m8'], [], 'fam1', 1 ).
test( 't44', 342, [], [], 'fam1', 1 ).
test( 't45', 136, [], ['r3','r1'], 'fam1', 1 ).
test( 't46', 95, [], ['r1','r2'], 'fam1', 1 ).
test( 't47', 321, [], [], 'fam1', 1 ).
test( 't48', 788, [], [], 'fam1', 1 ).
test( 't49', 344, [], [], 'fam1', 1 ).
test( 't50', 549, [], [], 'fam1', 1 ).
test( 't51', 567, [], ['r1'], 'fam1', 1 ).
test( 't52', 235, [], [], 'fam1', 1 ).
test( 't53', 654, [], [], 'fam1', 1 ).
test( 't54', 140, [], ['r2'], 'fam1', 1 ).
test( 't55', 338, [], [], 'fam1', 1 ).
test( 't56', 671, ['m10','m5','m7','m3'], [], 'fam1', 1 ).
test( 't57', 403, ['m9','m5','m3','m8'], [], 'fam1', 1 ).
test( 't58', 580, [], [], 'fam1', 1 ).
test( 't59', 365, ['m9'], [], 'fam1', 1 ).
test( 't60', 373, [], [], 'fam1', 1 ).
test( 't61', 594, ['m2','m1','m9'], ['r2','r3','r1'], 'fam1', 1 ).
test( 't62', 249, [], [], 'fam1', 1 ).
test( 't63', 33, [], [], 'fam1', 1 ).
test( 't64', 163, ['m6','m8','m1'], [], 'fam1', 1 ).
test( 't65', 710, [], ['r1','r3'], 'fam1', 1 ).
test( 't66', 22, [], [], 'fam1', 1 ).
test( 't67', 568, ['m2','m9','m8'], [], 'fam1', 1 ).
test( 't68', 271, [], [], 'fam1', 1 ).
test( 't69', 213, [], [], 'fam1', 1 ).
test( 't70', 40, [], [], 'fam1', 1 ).
test( 't71', 475, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't72', 535, [], [], 'fam1', 1 ).
test( 't73', 283, [], [], 'fam1', 1 ).
test( 't74', 234, [], [], 'fam1', 1 ).
test( 't75', 542, [], [], 'fam1', 1 ).
test( 't76', 664, [], ['r3'], 'fam1', 1 ).
test( 't77', 510, ['m9'], [], 'fam1', 1 ).
test( 't78', 726, [], [], 'fam1', 1 ).
test( 't79', 530, [], [], 'fam1', 1 ).
test( 't80', 163, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't81', 620, ['m9','m1'], ['r1','r3'], 'fam1', 1 ).
test( 't82', 664, [], [], 'fam1', 1 ).
test( 't83', 127, ['m4','m1'], ['r3','r2','r1'], 'fam1', 1 ).
test( 't84', 242, [], [], 'fam1', 1 ).
test( 't85', 469, [], [], 'fam1', 1 ).
test( 't86', 796, ['m3','m8','m9'], [], 'fam1', 1 ).
test( 't87', 333, [], [], 'fam1', 1 ).
test( 't88', 579, [], [], 'fam1', 1 ).
test( 't89', 600, [], [], 'fam1', 1 ).
test( 't90', 14, [], ['r2'], 'fam1', 1 ).
test( 't91', 143, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't92', 220, [], [], 'fam1', 1 ).
test( 't93', 505, [], [], 'fam1', 1 ).
test( 't94', 789, [], [], 'fam1', 1 ).
test( 't95', 320, [], [], 'fam1', 1 ).
test( 't96', 293, ['m6','m1','m10','m4'], [], 'fam1', 1 ).
test( 't97', 69, [], [], 'fam1', 1 ).
test( 't98', 780, ['m10','m1'], [], 'fam1', 1 ).
test( 't99', 274, [], [], 'fam1', 1 ).
test( 't100', 768, ['m2','m6','m5','m7'], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
