%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 20
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 509, [], [], 'fam1', 1 ).
test( 't2', 420, [], [], 'fam1', 1 ).
test( 't3', 461, [], ['r1'], 'fam1', 1 ).
test( 't4', 786, ['m7','m20','m2','m18','m16','m9'], [], 'fam1', 1 ).
test( 't5', 531, [], [], 'fam1', 1 ).
test( 't6', 367, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't7', 362, [], ['r3','r5','r2','r1','r4'], 'fam1', 1 ).
test( 't8', 605, ['m4'], [], 'fam1', 1 ).
test( 't9', 185, ['m12','m14','m6'], ['r3','r4'], 'fam1', 1 ).
test( 't10', 457, ['m6','m3','m12','m5','m8'], ['r1','r2','r5'], 'fam1', 1 ).
test( 't11', 623, [], [], 'fam1', 1 ).
test( 't12', 341, [], ['r2','r1','r4','r3'], 'fam1', 1 ).
test( 't13', 624, ['m6','m15','m10','m4','m2'], ['r2','r3','r1'], 'fam1', 1 ).
test( 't14', 426, [], ['r1','r3'], 'fam1', 1 ).
test( 't15', 181, [], [], 'fam1', 1 ).
test( 't16', 497, [], [], 'fam1', 1 ).
test( 't17', 50, [], [], 'fam1', 1 ).
test( 't18', 311, [], [], 'fam1', 1 ).
test( 't19', 663, [], [], 'fam1', 1 ).
test( 't20', 13, [], [], 'fam1', 1 ).
test( 't21', 22, [], [], 'fam1', 1 ).
test( 't22', 551, [], ['r5'], 'fam1', 1 ).
test( 't23', 786, [], ['r3','r4','r1'], 'fam1', 1 ).
test( 't24', 481, [], [], 'fam1', 1 ).
test( 't25', 249, [], [], 'fam1', 1 ).
test( 't26', 254, [], [], 'fam1', 1 ).
test( 't27', 696, [], ['r1','r4'], 'fam1', 1 ).
test( 't28', 792, [], ['r2','r3'], 'fam1', 1 ).
test( 't29', 179, [], [], 'fam1', 1 ).
test( 't30', 34, [], ['r3','r4','r2','r1','r5'], 'fam1', 1 ).
test( 't31', 25, ['m2','m16','m11','m17','m18','m12','m7'], [], 'fam1', 1 ).
test( 't32', 743, [], ['r1','r5','r3'], 'fam1', 1 ).
test( 't33', 725, [], ['r1','r4','r3'], 'fam1', 1 ).
test( 't34', 254, ['m14','m10','m11','m7','m2'], [], 'fam1', 1 ).
test( 't35', 126, ['m2','m3','m11','m12','m7'], [], 'fam1', 1 ).
test( 't36', 426, [], [], 'fam1', 1 ).
test( 't37', 335, [], ['r4','r5','r2','r1','r3'], 'fam1', 1 ).
test( 't38', 384, [], [], 'fam1', 1 ).
test( 't39', 675, ['m4','m19','m2','m14','m12','m3','m16','m11'], [], 'fam1', 1 ).
test( 't40', 767, [], [], 'fam1', 1 ).
test( 't41', 483, ['m2','m4','m15','m18','m3','m7','m1'], [], 'fam1', 1 ).
test( 't42', 74, [], [], 'fam1', 1 ).
test( 't43', 631, [], [], 'fam1', 1 ).
test( 't44', 81, [], ['r5'], 'fam1', 1 ).
test( 't45', 140, [], [], 'fam1', 1 ).
test( 't46', 356, [], ['r2','r5','r1'], 'fam1', 1 ).
test( 't47', 104, [], [], 'fam1', 1 ).
test( 't48', 687, [], [], 'fam1', 1 ).
test( 't49', 565, [], ['r2','r4','r5'], 'fam1', 1 ).
test( 't50', 545, [], ['r5','r2'], 'fam1', 1 ).
test( 't51', 267, [], [], 'fam1', 1 ).
test( 't52', 690, [], [], 'fam1', 1 ).
test( 't53', 5, [], ['r1'], 'fam1', 1 ).
test( 't54', 655, [], [], 'fam1', 1 ).
test( 't55', 80, [], [], 'fam1', 1 ).
test( 't56', 522, [], [], 'fam1', 1 ).
test( 't57', 256, [], ['r2','r4'], 'fam1', 1 ).
test( 't58', 290, ['m17','m8','m13'], ['r5','r2','r4','r1','r3'], 'fam1', 1 ).
test( 't59', 508, [], ['r3'], 'fam1', 1 ).
test( 't60', 173, ['m19'], [], 'fam1', 1 ).
test( 't61', 320, ['m8','m13','m1','m4','m11','m7','m18','m20'], ['r5','r2'], 'fam1', 1 ).
test( 't62', 462, [], ['r4','r5','r2'], 'fam1', 1 ).
test( 't63', 780, [], ['r2','r4','r5'], 'fam1', 1 ).
test( 't64', 532, [], ['r2','r1','r3','r5','r4'], 'fam1', 1 ).
test( 't65', 501, ['m10','m16'], ['r5','r1'], 'fam1', 1 ).
test( 't66', 720, [], ['r3'], 'fam1', 1 ).
test( 't67', 81, [], [], 'fam1', 1 ).
test( 't68', 116, [], [], 'fam1', 1 ).
test( 't69', 297, [], [], 'fam1', 1 ).
test( 't70', 318, [], [], 'fam1', 1 ).
test( 't71', 158, [], [], 'fam1', 1 ).
test( 't72', 427, [], [], 'fam1', 1 ).
test( 't73', 99, [], [], 'fam1', 1 ).
test( 't74', 700, [], [], 'fam1', 1 ).
test( 't75', 554, [], ['r2','r4','r5','r1'], 'fam1', 1 ).
test( 't76', 262, [], [], 'fam1', 1 ).
test( 't77', 580, [], [], 'fam1', 1 ).
test( 't78', 13, [], [], 'fam1', 1 ).
test( 't79', 367, [], [], 'fam1', 1 ).
test( 't80', 231, [], [], 'fam1', 1 ).
test( 't81', 541, [], ['r3'], 'fam1', 1 ).
test( 't82', 148, [], [], 'fam1', 1 ).
test( 't83', 771, [], ['r5','r2','r3','r4','r1'], 'fam1', 1 ).
test( 't84', 687, [], ['r4','r3','r5','r1'], 'fam1', 1 ).
test( 't85', 704, [], [], 'fam1', 1 ).
test( 't86', 606, [], ['r3','r5','r2','r1','r4'], 'fam1', 1 ).
test( 't87', 138, [], [], 'fam1', 1 ).
test( 't88', 540, [], ['r4','r1','r3','r5','r2'], 'fam1', 1 ).
test( 't89', 300, [], [], 'fam1', 1 ).
test( 't90', 392, [], ['r2','r4','r3','r1','r5'], 'fam1', 1 ).
test( 't91', 524, [], [], 'fam1', 1 ).
test( 't92', 435, ['m8'], [], 'fam1', 1 ).
test( 't93', 62, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't94', 36, [], ['r1','r3','r4'], 'fam1', 1 ).
test( 't95', 263, ['m6','m18'], [], 'fam1', 1 ).
test( 't96', 767, [], ['r1','r5'], 'fam1', 1 ).
test( 't97', 456, ['m9','m14','m1','m5'], [], 'fam1', 1 ).
test( 't98', 269, [], [], 'fam1', 1 ).
test( 't99', 737, [], ['r3','r4','r5'], 'fam1', 1 ).
test( 't100', 279, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
