// Solitaire.h: interface for the Solitaire class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SOLITAIRE_H__5C0137D9_7CA2_466C_B0E3_B0ED2D6234FE__INCLUDED_)
#define AFX_SOLITAIRE_H__5C0137D9_7CA2_466C_B0E3_B0ED2D6234FE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <ilsolver/ilosolver.h>
#include <ilsolver/ilctrace.h>
ILOSTLBEGIN

class Solitaire {
  IloEnv env ;
  IloModel model ;
  IloSolver solver ;
  IloNumVarArray boardStates ;
  IloNumVarArray moves ;
  IloConstraint partiallyConstructedExp;
  int BOARDSIZE ;
  int NOMOVES ;
  int NOTRANSITIONS ;
  int getBoardNum(int x,int y);
  int getTransitionNum(int x1,int y1,int x2,int y2);
  void modelC() ;
  void modelCAddConstraints(void);
  void TestAndBuildAndConstraint(int x1,int y1,int x2,int y2,int CurrentMove);
  void TestAndBuildOrConstraint(int x1,int y1,int x2,int y2,int CurrentMove);
  void TestAndBuildSymmetricAndConstraint(int x1,int y1,int x2,int y2,int CurrentMove);
public:
  Solitaire();
  virtual ~Solitaire() {}
  void solve() ;
  void display() ;
};

const int transitions[][4]={ 
	{2,0,4,0},{2,0,2,2},
	{3,0,3,2},
	{4,0,2,0},{4,0,4,2}, // 4
	
	{2,1,4,1},{2,1,2,3},
	{3,1,3,3},
	{4,1,2,1},{4,1,4,3}, // 9
	
	{0,2,0,4},{0,2,2,2},
	{1,2,3,2},{1,2,1,4},
	{2,2,2,0},{2,2,4,2},{2,2,2,4},{2,2,0,2},
	{3,2,3,0},{3,2,5,2},{3,2,3,4},{3,2,1,2},
	{4,2,4,0},{4,2,6,2},{4,2,4,4},{4,2,2,2},
	{5,2,3,2},{5,2,5,4},
	{6,2,6,4},{6,2,4,2},//29
	
	{0,3,2,3},
	{1,3,3,3},
	{2,3,0,3},{2,3,2,1},{2,3,2,5},{2,3,4,3},
	{3,3,1,3},{3,3,3,1},{3,3,3,5},{3,3,5,3}, //39
	{4,3,2,3},{4,3,4,1},{4,3,4,5},{4,3,6,3},
	{5,3,3,3},
	{6,3,4,3}, //45
	
	{0,4,0,2},{0,4,2,4},
	{1,4,3,4},{1,4,1,2},
	{2,4,0,4},{2,4,2,2},{2,4,4,4},{2,4,2,6},
	{3,4,1,4},{3,4,3,2},{3,4,5,4},{3,4,3,6}, //57
	{4,4,2,4},{4,4,4,2},{4,4,6,4},{4,4,4,6},
	{5,4,3,4},{5,4,5,2},
	{6,4,6,2},{6,4,4,4},
	
	{2,5,4,5},{2,5,2,3},
	{3,5,3,3},
	{4,5,2,5},{4,5,4,3},
	
	{2,6,4,6},{2,6,2,4},
	{3,6,3,4},
	{4,6,2,6},{4,6,4,4}
};

const int BoardPos[][2]={
	{0,2},{0,3},{0,4},
	{1,2},{1,3},{1,4},
	{2,0},{2,1},{2,2},{2,3},{2,4},{2,5},{2,6},
	{3,0},{3,1},{3,2},{3,3},{3,4},{3,5},{3,6},
	{4,0},{4,1},{4,2},{4,3},{4,4},{4,5},{4,6},
	{5,2},{5,3},{5,4},
	{6,2},{6,3},{6,4}
};


#endif // !defined(AFX_SOLITAIRE_H__5C0137D9_7CA2_466C_B0E3_B0ED2D6234FE__INCLUDED_)
