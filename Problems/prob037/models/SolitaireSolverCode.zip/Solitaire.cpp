// Solitaire.cpp: implementation of the Solitaire class.
//
//////////////////////////////////////////////////////////////////////

#include "Solitaire.h"


//////////////////////////////////////////////////////////////////////
// Construction
//////////////////////////////////////////////////////////////////////

Solitaire::Solitaire() {
  model = IloModel(env) ;
  solver = IloSolver(env) ;
  BOARDSIZE = 33 ;
  NOMOVES = 31 ;
  NOTRANSITIONS = 76 ;
}


//////////////////////////////////////////////////////////////////////
// display()
void Solitaire::display() {
    IloInt i ;
	solver.out() << "Moves: " ;
    for (i = 0; i < NOMOVES; i++) {
	  int move = solver.getValue(moves[i]) ;
	  solver.out() << move << " : " << transitions[move][0] << ", "
		  << transitions[move][1] << " -> " << transitions[move][2]
		  << ", " << transitions[move][3] << endl ;
	}
}

//////////////////////////////////////////////////////////////////////
// getBoardNum()
// Find flattened index into board given a coordinate pair.
int Solitaire::getBoardNum(int a,int b) {
	int loop;
	int returnVal=-1;
	for(loop=0;loop<BOARDSIZE;loop++) {
		if(a==BoardPos[loop][0] && b==BoardPos[loop][1]) returnVal=loop;
	}
	return returnVal;
}

//////////////////////////////////////////////////////////////////////
// getTransitionNum()
// Get the transition number for jump (x1,y1) -> (x2,y2)
int Solitaire::getTransitionNum(int x1,int y1,int x2,int y2) {
	int loop;
	int returnVal=-1;
	for(loop=0;loop<NOTRANSITIONS;loop++) {
		if(x1==transitions[loop][0] &&
			y1==transitions[loop][1] &&
			x2==transitions[loop][2] &&
			y2==transitions[loop][3])
			returnVal=loop;
	}
	return returnVal;
}


//////////////////////////////////////////////////////////////////////
// modelC()
void Solitaire::modelC() {
  IloInt i;
  boardStates = IloNumVarArray(env, (NOMOVES+1)*BOARDSIZE, 0, 1, ILOINT) ;
  moves = IloNumVarArray(env, NOMOVES, 0, NOTRANSITIONS-1, ILOINT) ;
  // Symmetry breaking
  model.add(moves[0] == 7) ;
  modelCAddConstraints();
  //Set up the first and last state of the board.
  for(i=0;i<BOARDSIZE;i++)
  {
	  if(i==16) {
		  model.add(boardStates[i]==0);
		  model.add(boardStates[NOMOVES*BOARDSIZE+i]==1) ;
	  }
	  else {
		  model.add(boardStates[i]==1);
		  model.add(boardStates[NOMOVES*BOARDSIZE+i]==0) ;
	  }
  }
}


//This variable is used in the building of constraints
bool FirstTime;


//////////////////////////////////////////////////////////////////////
// ModelCAddConstraints()
void Solitaire::modelCAddConstraints(void) {
	int loop1,loop2;
	int CurrentMove=0;
	int StepSize=BOARDSIZE;
	for(CurrentMove=0;CurrentMove<NOMOVES;CurrentMove++) {
		for(loop1=0;loop1<7;loop1++) 	{
			for(loop2=0;loop2<7;loop2++) {
				int BoardPos=getBoardNum(loop1,loop2);
				//If the (loop1,loop2) is on the board
				if(BoardPos!=-1) {
					FirstTime=true;
					// The moves detailed below (and their reverse) are the only moves
					// That could effect position (loop1,loop2), so we check all of them
					// To see if they are valid moves!
					TestAndBuildSymmetricAndConstraint(loop1,loop2+2,loop1,loop2,CurrentMove);
					TestAndBuildSymmetricAndConstraint(loop1,loop2+1,loop1,loop2-1,CurrentMove);
					TestAndBuildSymmetricAndConstraint(loop1,loop2,loop1,loop2-2,CurrentMove);
					TestAndBuildSymmetricAndConstraint(loop1+2,loop2,loop1,loop2,CurrentMove);
					TestAndBuildSymmetricAndConstraint(loop1+1,loop2,loop1-1,loop2,CurrentMove);
					TestAndBuildSymmetricAndConstraint(loop1,loop2,loop1-2,loop2,CurrentMove);	
					// Position BoardPos doesn't change unless the 
					// current move is one which would effect it
					model.add( (boardStates[CurrentMove*StepSize+BoardPos]	
						== boardStates[(CurrentMove+1)*StepSize+BoardPos])
						== partiallyConstructedExp);
					
					FirstTime=true;
					// The moves below are all the moves that could place a ball in
					// an empty hole at position (loop1,loop2)
					TestAndBuildOrConstraint(loop1-2,loop2,loop1,loop2,CurrentMove);
					TestAndBuildOrConstraint(loop1+2,loop2,loop1,loop2,CurrentMove);
					TestAndBuildOrConstraint(loop1,loop2-2,loop1,loop2,CurrentMove);
					TestAndBuildOrConstraint(loop1,loop2+2,loop1,loop2,CurrentMove);
					//The current board pos goes from 0 -> 1 if the current move says so
					model.add( (boardStates[CurrentMove*StepSize+BoardPos]==0
						&& boardStates[(CurrentMove+1)*StepSize+BoardPos]==1 )
						== partiallyConstructedExp);
		
					FirstTime=true;
					// The moves below are all the moves that could remove the ball
					// at position (loop1,loop2)
					TestAndBuildOrConstraint(loop1-1,loop2,loop1+1,loop2,CurrentMove);
					TestAndBuildOrConstraint(loop1+1,loop2,loop1-1,loop2,CurrentMove);
					TestAndBuildOrConstraint(loop1,loop2-1,loop1,loop2+1,CurrentMove);
					TestAndBuildOrConstraint(loop1,loop2+1,loop1,loop2-1,CurrentMove);
					TestAndBuildOrConstraint(loop1,loop2,loop1+2,loop2,CurrentMove);
					TestAndBuildOrConstraint(loop1,loop2,loop1-2,loop2,CurrentMove);
					TestAndBuildOrConstraint(loop1,loop2,loop1,loop2+2,CurrentMove);
					TestAndBuildOrConstraint(loop1,loop2,loop1,loop2-2,CurrentMove);
					//The current board pos goes 1 -> 0 if the current move says so
					model.add( (boardStates[CurrentMove*StepSize+BoardPos]==1 &&
						boardStates[(CurrentMove+1)*StepSize+BoardPos]==0)
						== partiallyConstructedExp);					
				}
			}
		}
	}
}

//////////////////////////////////////////////////////////////////////
// TestAndBuildAndConstraint()
void Solitaire::TestAndBuildAndConstraint(int x1,int y1,int x2,int y2,int CurrentMove) {
	if (getTransitionNum(x1,y1,x2,y2)!=-1) {
		if(FirstTime==true) {
			FirstTime=false;
			partiallyConstructedExp=(moves[CurrentMove]!=getTransitionNum(x1,y1,x2,y2));
		}
		else {
			partiallyConstructedExp=partiallyConstructedExp&&(moves[CurrentMove]!=getTransitionNum(x1,y1,x2,y2));
		}
	}
}

//////////////////////////////////////////////////////////////////////
// TestAndBuildOrConstraint()
void Solitaire::TestAndBuildOrConstraint(int x1,int y1,int x2,int y2,int CurrentMove) {
	if(getTransitionNum(x1,y1,x2,y2)!=-1) {
		if(FirstTime==true) {
			FirstTime=false;
			partiallyConstructedExp=(moves[CurrentMove]==getTransitionNum(x1,y1,x2,y2));
		}
		else {
			partiallyConstructedExp=partiallyConstructedExp||(moves[CurrentMove]==getTransitionNum(x1,y1,x2,y2));
		}
	}
}

//////////////////////////////////////////////////////////////////////
// TestAndBuildSymmetricAndConstraint()
void Solitaire::TestAndBuildSymmetricAndConstraint(int x1,int y1,int x2,int y2,int CurrentMove) {
	TestAndBuildAndConstraint(x1,y1,x2,y2,CurrentMove);
	TestAndBuildAndConstraint(x2,y2,x1,y1,CurrentMove);
}
//////////////////////////////////////////////////////////////////////
// main()
int main(int argc, char* argv[])
{
  Solitaire * test = new Solitaire() ;
  test->solve() ;
  return 0;
}

//////////////////////////////////////////////////////////////////////
// solve()
void Solitaire::solve() {
  try {
	modelC() ;
	solver.extract(model) ;
	//Tracing:


	cout << "Starting search" << endl ;
    IlcBool res = solver.solve(IloGenerate(env, moves)) ;
	if (res) {
	  cout << "Solved" << endl ;
	  display() ;
	}
	solver.printInformation() ;
  }
  catch (IloException& ex) {
    cerr << "Error: " << ex << endl;
  }
  env.end();
}

