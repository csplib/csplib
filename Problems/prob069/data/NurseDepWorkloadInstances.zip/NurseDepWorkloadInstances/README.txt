Data file format:

<nb of nurses>  <nb of patients>  <nb of patient types>
<min nb of patients per nurse>  <max nb of patients per nurse>

For each patient type j
  <nb of patients of type j>

For each nurse i
  For each patient type j
    <acuity for i,j>
