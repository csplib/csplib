Data file format:

<nb of zones>  <nb of nurses>
<min nb of patients per nurse>  <max nb of patients per nurse>  <max workload per nurse>
For each zone:
<nb of patients in zone> followed by <acuity> for each patient


